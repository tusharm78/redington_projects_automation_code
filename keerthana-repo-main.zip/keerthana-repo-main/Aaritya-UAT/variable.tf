# variable for region
variable "aws_region" {
description = "Region"
type = string
default = "ap-south-1"    #change the region wrt to reqiurement
}

#variable for availability zone-1
variable "aws_availability_zone1" {
description = "Availability Zone1"
type = string
default = "ap-south-1a"
}

#variable for availability zone-2
variable "aws_availability_zone2" {
description = "Availability Zone2"
type = string
default = "ap-south-1b"
}

#variable for availability zone-3
variable "aws_availability_zone3" {
description = "Availability Zone3"
type = string
default = "ap-south-1c"
}


######Variable for VPC CIDR block
variable "vpc_cidr_block" {
  description = "CIDR block for the VPC"
  type = string
  default = "172.0.0.0/16"
}

######Variable for public subnet-1
variable "uat-subnet-public1-1a_cidr_block" {
  description = "CIDR block for the public subnet"
  type = string
  default = "172.0.0.0/20"
}

######Variable for public subnet-2
variable "uat-subnet-public1-1b_cidr_block" {
  description = "CIDR block for the public subnet"
  type = string
  default = "172.0.16.0/20"
}

#####Variable for private subnet-1
variable "uat-subnet-private1-1a_cidr_block" {
  description = "CIDR block for the private subnet"
  type = string
  default = "172.0.128.0/20"
}

#####Variable for private subnet-2
variable "uat-subnet-private1-1b_cidr_block" {
  description = "CIDR block for the private subnet"
  type = string
  default = "172.0.144.0/20"
}

#####Variable for private subnet-3
variable "uat-subnet-private1-1c_cidr_block" {
  description = "CIDR block for the private subnet"
  type = string
  default = "172.0.160.0/20"
}

####Variable for Transit gateway routes in Private Route Table
variable "Transit-gateway-routes_cidr_block" {
  description = "CIDR block for the transit gateway routes from Network Account"
  type = string
  default = "30.0.0.0/16" 
}

######Variable for Transit gateway ID
variable "Transit-gateway-id"  {
description = "Transit gateway id from Network account"
type = string
default = "tgw-0c2c12723fe0043c8"
}

######variable for Tag Name
variable "env-name" {
description = "Name of the environment" 
type = string
default = "UAT"  
}