#########Creating VPC######

resource "aws_vpc" "uat-vpc" {
  cidr_block = var.vpc_cidr_block #CIDR range in variable
  enable_dns_support = true
  enable_dns_hostnames = true
  tags = {
    Name = "uat-vpc"
    Environment = var.env-name
    Created-by = "Terraform-Automation"
  }
}

########Creating Public Subnet-1############
resource "aws_subnet" "uat-subnet-public1-1a" {
  vpc_id     = aws_vpc.uat-vpc.id    #VPC ID range
  cidr_block = var.uat-subnet-public1-1a_cidr_block
  availability_zone = var.aws_availability_zone1 # Change to your desired availability zone
  map_public_ip_on_launch = true
  tags = {
    Name = "uat-subnet-public1-1a"
    Environment = var.env-name
    Created-by = "Terraform-Automation"
  }
}

########Creating Public Subnet-2############
resource "aws_subnet" "uat-subnet-public1-1b" {
  vpc_id     = aws_vpc.uat-vpc.id    #VPC ID range
  cidr_block = var.uat-subnet-public1-1b_cidr_block
  availability_zone = var.aws_availability_zone2 # Change to your desired availability zone
  map_public_ip_on_launch = true
  tags = {
    Name = "uat-subnet-public1-1b"
    Environment = var.env-name
    Created-by = "Terraform-Automation"
  }
}

#########Creating Private Subnet-1############
resource "aws_subnet" "uat-subnet-private1-1a" {
  vpc_id     = aws_vpc.uat-vpc.id
  cidr_block = var.uat-subnet-private1-1a_cidr_block
  availability_zone = var.aws_availability_zone1 # Change to your desired availability zone
  tags = {
    Name = "uat-subnet-private1-1a"
    Environment = var.env-name
    Created-by = "Terraform-Automation"
  }
}

#########Creating Private Subnet-2############
resource "aws_subnet" "uat-subnet-private1-1b" {
  vpc_id     = aws_vpc.uat-vpc.id
  cidr_block = var.uat-subnet-private1-1b_cidr_block
  availability_zone = var.aws_availability_zone2 # Change to your desired availability zone
  tags = {
    Name = "uat-subnet-private1-1b"
    Environment = var.env-name
    Created-by = "Terraform-Automation"
  }
}

#########Creating Private Subnet-3############
resource "aws_subnet" "uat-subnet-private1-1c" {
  vpc_id     = aws_vpc.uat-vpc.id
  cidr_block = var.uat-subnet-private1-1c_cidr_block
  availability_zone = var.aws_availability_zone3 # Change to your desired availability zone
  tags = {
    Name = "uat-subnet-private1-1c"
    Environment = var.env-name
    Created-by = "Terraform-Automation"
  }
}

# Creating Internet Gateway
resource "aws_internet_gateway" "igw-UAT" {
  vpc_id = aws_vpc.uat-vpc.id
  tags = {
    Name = "igw-UAT"
    Environment = var.env-name
    Created-by = "Terraform-Automation"
  }
}


#creating public route table
resource "aws_route_table" "uat-rt-public" {
  vpc_id = aws_vpc.uat-vpc.id
  tags = {
    Name    = "uat-rt-public"   # Route table for Public subnet is created
    Environment = var.env-name
    Created-by = "Terraform-Automation"
  }
}
#associating public route table with respective public subnets
resource "aws_route_table_association" "uat-rt-public-associate-1" {
  route_table_id = aws_route_table.uat-rt-public.id     # public route table is associated with respective public subnet
  subnet_id    = aws_subnet.uat-subnet-public1-1a.id 
}

resource "aws_route_table_association" "uat-rt-public-associate-2" {
  route_table_id = aws_route_table.uat-rt-public.id     # public route table is associated with respective public subnet
  subnet_id    = aws_subnet.uat-subnet-public1-1b.id
}

# Create Route in Public Route Table for Internet Access
resource "aws_route" "uat-rt-public" {
  route_table_id         = aws_route_table.uat-rt-public.id
  destination_cidr_block = "0.0.0.0/0"
  gateway_id             = aws_internet_gateway.igw-UAT.id
}

#########Creating an Elastic IP for the NAT Gateway - 1a###########
resource "aws_eip" "nat-eip-uat-1a" {
  tags = {
    Name = "nat-eip-uat-1a"
    Environment = var.env-name
    Created-by = "Terraform-Automation"
  }
}


########Creating NAT Gateway - 1a################
resource "aws_nat_gateway" "nat-gateway-uat-1a" {
  allocation_id = aws_eip.nat-eip-uat-1a.id
  subnet_id    = aws_subnet.uat-subnet-public1-1a.id
  tags = {
    Name = "nat-gateway-uat-1a"
    Environment = var.env-name
    Created-by = "Terraform-Automation"
  }
}

resource "aws_ec2_transit_gateway_vpc_attachment" "uat-tgattachment" {
  transit_gateway_id = var.Transit-gateway-id
  vpc_id            = aws_vpc.uat-vpc.id
  subnet_ids       = [aws_subnet.uat-subnet-private1-1a.id , aws_subnet.uat-subnet-private1-1b.id, aws_subnet.uat-subnet-private1-1c.id ]
  tags = {
    Name = "uat-tgattachment"
    Environment = var.env-name
    Created-by = "Terraform-Automation"
  }
}

# Create a route table for private1-1a subnet
resource "aws_route_table" "uat-rt-private1-1a" {
  vpc_id = aws_vpc.uat-vpc.id
tags = {
    Name = "uat-rt-private1-1a"
    Environment = var.env-name
    Created-by = "Terraform-Automation"
  }
}

# Create a route table for private1-1b subnet
resource "aws_route_table" "uat-rt-private1-1b" {
  vpc_id = aws_vpc.uat-vpc.id
tags = {
    Name = "uat-rt-private1-1b"
    Environment = var.env-name
    Created-by = "Terraform-Automation"
  }
}

# Create a route table for private1-1c subnet
resource "aws_route_table" "uat-rt-private1-1c" {
  vpc_id = aws_vpc.uat-vpc.id
tags = {
    Name = "uat-rt-private1-1c"
    Environment = var.env-name
    Created-by = "Terraform-Automation"
  }
}

#associating private route table with respective private subnet
resource "aws_route_table_association" "uat-rt-private1-associate-1a" {
  route_table_id = aws_route_table.uat-rt-private1-1a.id    # private route table is associated with respective public subnet
  subnet_id = aws_subnet.uat-subnet-private1-1a.id
}

resource "aws_route_table_association" "uat-rt-private1-associate-1b" {
  route_table_id = aws_route_table.uat-rt-private1-1b.id    # private route table is associated with respective public subnet
  subnet_id = aws_subnet.uat-subnet-private1-1b.id
}

resource "aws_route_table_association" "uat-rt-private1-associate-1c" {
  route_table_id = aws_route_table.uat-rt-private1-1c.id    # private route table is associated with respective public subnet
  subnet_id = aws_subnet.uat-subnet-private1-1c.id
}


##Create Route in Private Route Table-1a 
resource "aws_route" "uat-rt-private-1a" {
  route_table_id         = aws_route_table.uat-rt-private1-1a.id
  destination_cidr_block = "0.0.0.0/0"
  gateway_id             = aws_nat_gateway.nat-gateway-uat-1a.id
}

resource "aws_route" "uat-rt-private-2a" {
  route_table_id         = aws_route_table.uat-rt-private1-1a.id
  destination_cidr_block = var.Transit-gateway-routes_cidr_block
  transit_gateway_id = aws_ec2_transit_gateway_vpc_attachment.uat-tgattachment.transit_gateway_id
  depends_on = [ aws_ec2_transit_gateway_vpc_attachment.uat-tgattachment]
}

##Create Route in Private Route Table-1b 
resource "aws_route" "uat-rt-private-1b" {
  route_table_id         = aws_route_table.uat-rt-private1-1b.id
  destination_cidr_block = "0.0.0.0/0"
  gateway_id             = aws_nat_gateway.nat-gateway-uat-1a.id
}

resource "aws_route" "uat-rt-private-2b" {
  route_table_id         = aws_route_table.uat-rt-private1-1b.id
  destination_cidr_block = var.Transit-gateway-routes_cidr_block
  transit_gateway_id = aws_ec2_transit_gateway_vpc_attachment.uat-tgattachment.transit_gateway_id
  depends_on = [ aws_ec2_transit_gateway_vpc_attachment.uat-tgattachment]
}

##Create Route in Private Route Table-1c
resource "aws_route" "uat-rt-private-1c" {
  route_table_id         = aws_route_table.uat-rt-private1-1c.id
  destination_cidr_block = "0.0.0.0/0"
  gateway_id             = aws_nat_gateway.nat-gateway-uat-1a.id
}

resource "aws_route" "uat-rt-private-2c" {
  route_table_id         = aws_route_table.uat-rt-private1-1c.id
  destination_cidr_block = var.Transit-gateway-routes_cidr_block
  transit_gateway_id = aws_ec2_transit_gateway_vpc_attachment.uat-tgattachment.transit_gateway_id
  depends_on = [ aws_ec2_transit_gateway_vpc_attachment.uat-tgattachment]
}