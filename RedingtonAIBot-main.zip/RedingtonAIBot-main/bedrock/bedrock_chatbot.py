import random
from io import BytesIO
from typing import List, Tuple, Union, Dict, Any
import re
import datetime
import hashlib
import uuid # Import uuid for generating unique message IDs
import pprint

import streamlit as st
from langchain_core.runnables import RunnableWithMessageHistory
from langchain.prompts.chat import ChatPromptTemplate, MessagesPlaceholder
from langchain_community.chat_message_histories import StreamlitChatMessageHistory
from langchain_community.utilities import SerpAPIWrapper
from langchain_aws import BedrockEmbeddings
from langchain_community.vectorstores import FAISS
from PIL import Image, UnidentifiedImageError
import pdfplumber
import pandas as pd # Import pandas for handling Excel and CSV files

# --- Import for DOCX generation ---
from docx import Document
from docx.shared import Inches # Often useful for docx, though not strictly needed for just text
from docx.enum.text import WD_ALIGN_PARAGRAPH # For paragraph alignment
from docx.enum.table import WD_ALIGN_VERTICAL # For table cell vertical alignment
from docx.shared import Pt # For font sizes


# --- AWS Cognito Authentication Imports ---
import os
from streamlit_cognito_auth import CognitoAuthenticator

# --- AWS DynamoDB Imports --
import boto3
from botocore.exceptions import ClientError
from boto3.dynamodb.conditions import Key # Import Key for query conditions

# --- Load environment variables ---
from dotenv import load_dotenv
load_dotenv()

# --- Streamlit Page Configuration (MUST BE FIRST STREAMLIT COMMANDS) ---
st.set_page_config(page_title="Redington AI Bot", layout="wide")

# --- Centering the main title ---
st.markdown("<h1 style='text-align: center;'>🤖 Chat with Redington AI Bot</h1>", unsafe_allow_html=True)

# --- Inject custom CSS for file uploader alignment and sticky footer ---
st.markdown("""
<style>
    /* Target the file uploader specifically to adjust its height and spacing */
    .stFileUploader {
        /* Make it take available height in its column - now it will take full width */
        /* height: 100%; */
        display: flex;
        flex-direction: column;
        justify-content: center; /* Center content vertically */
        padding: 0.5rem; /* Add some padding around the uploader */
        margin-bottom: 0.5rem; /* Space between uploader and prompt */
    }
    /* Adjust the inner elements of the file uploader to reduce their default padding/margin */
    .stFileUploader > div:first-child {
        padding-top: 0rem !important; /* Remove top padding */
        padding-bottom: 0rem !important; /* Remove bottom padding */
    }
    /* Style the actual drag and drop area */
    .stFileUploader .css-1byb522 { /* This class might change, but targets the file drop zone */
        min-height: 60px; /* Minimum height for the drop zone, adjust as needed */
        height: auto; /* Allow height to adjust */
        padding: 0.5rem; /* Reduce padding inside the drop zone */
    }
    /* Adjust the text area for better alignment with the file uploader */
    .stTextArea {
        height: 100%;
        display: flex;
        flex-direction: column;
    }
    .stTextArea > label {
        display: none; /* Hide the label to reduce space */
    }
    .stTextArea textarea {
        flex-grow: 1; /* Allow textarea to fill available space */
        min-height: 80px; /* Match or complement file uploader height */
    }
    /* Reduce gap between columns in the input section - now only for prompt and send button */
    .stForm > div > div {
        gap: 0.5rem; /* Smaller gap between prompt and send button columns */
    }
    /* Style for the sticky footer containing the input form */
    .st-emotion-cache-nahz7x { /* This class targets the main content area of Streamlit */
        padding-bottom: 120px; /* Add padding to prevent content from being hidden by sticky footer */
        /* Add min-height to ensure there's always scrollable content space */
        min-height: calc(100vh - 120px - 50px); /* Adjust based on header/footer actual height */
    }
    .fixed-bottom-container {
        position: sticky;
        bottom: 0;
        left: 0;
        right: 0;
        background-color: white; /* Or your app's background color */
        padding: 1rem;
        border-top: 1px solid #e0e0e0;
        z-index: 100; /* Ensure it stays on top */
    }
    /* Style for the scroll-to-bottom button - keeping this for now but new button uses inline styles */
    .scroll-to-bottom-button {
        position: fixed; /* Fixed position */
        bottom: 140px; /* Adjust as needed to be above the input bar */
        right: 20px; /* Adjust as needed */
        z-index: 101; /* Ensure it's above other elements */
        background-color: #007bff; /* Primary blue */
        color: white;
        border-radius: 50%; /* Make it circular */
        width: 50px; /* Fixed width */
        height: 50px; /* Fixed height */
        display: flex;
        justify-content: center;
        align-items: center;
        font-size: 24px;
        box_shadow: 2px 2px 10px rgba(0, 0, 0, 0.3); /* Add shadow */
        cursor: pointer;
        transition: background-color 0.3s ease;
    }
    .scroll-to-bottom-button:hover {
        background-color: #0056b3; /* Darker blue on hover */
    }
</style>
""", unsafe_allow_html=True)


# --- Initialize Cognito Authenticator ---
try:
    pool_id = os.environ["POOL_ID"]
    app_client_id = os.environ["APP_CLIENT_ID"]
    app_client_secret = os.environ["APP_CLIENT_SECRET"]

    authenticator = CognitoAuthenticator(
        pool_id=pool_id,
        app_client_id=app_client_id,
        app_client_secret=app_client_secret,
        use_cookies=True
    )

except KeyError as e:
    st.error(f"Missing Cognito environment variable: {e}. Please set POOL_ID, APP_CLIENT_ID, and APP_CLIENT_SECRET.")
    st.stop()

# --- Initialize DynamoDB Client ---
# Ensure AWS_REGION is set in your environment variables or replace "us-east-1" with your region
try:
    dynamodb = boto3.resource('dynamodb', region_name=os.environ.get("AWS_REGION", "us-east-1"))
    chat_history_table = dynamodb.Table('chat_history') # Ensure this matches your DynamoDB table name
    user_chat_sessions_table = dynamodb.Table('user_chat_sessions') # New table for chat metadata

    # Just ensure the call completes without error (less verbose)
    chat_history_table.load() # This will raise an error if table doesn't exist or no permissions
    user_chat_sessions_table.load()

except ClientError as e:
    st.error(f"Failed to connect to DynamoDB or tables not found: {e.response['Error']['Message']}. Ensure tables 'chat_history' and 'user_chat_sessions' exist and AWS credentials/permissions are correct.")
    st.stop() # Stop the app if DB connection is critical
except Exception as e:
    st.error(f"An unexpected error occurred initializing DynamoDB: {e}")
    st.stop() # Stop the app if DB connection is critical


from config import config
from models import ChatModel
from role_prompt import role_prompt
from bedrock_embedder import search_index

# --- Guardrail Configuration ---
DISALLOWED_KEYWORDS = [
    "harmful", "violence", "hate speech", "illegal", "dangerous",
    "unethical", "discriminatory", "sexual", "exploit", "abuse",
    "self-harm", "weapons", "drugs", "terrorism", "spam", "phishing",
    "malware", "sensitive personal information", "private data"
]
GUARDRAIL_MESSAGE = "I cannot respond to queries that contain sensitive or inappropriate content. Please rephrase your question."

class Guardrails:
    def __init__(self):
        pass
    def apply_input_guardrails(self, prompt: str) -> Tuple[bool, str, str]:
        for keyword in DISALLOWED_KEYWORDS:
            if re.search(r'\b' + re.escape(keyword) + r'\b', prompt, re.IGNORECASE):
                return True, f"contains '{keyword}'", GUARDRAIL_MESSAGE
        return False, "", prompt

    def apply_output_guardrails(self, output: str) -> Tuple[bool, str, str]:
        for keyword in DISALLOWED_KEYWORDS:
            if re.search(r'\b' + re.escape(keyword) + r'\b', output, re.IGNORECASE):
                return True, f"contains '{keyword}'", "I'm sorry, but I cannot generate content that contains sensitive or inappropriate material."
        return False, "", output

app_guardrails = Guardrails()


INIT_MESSAGE = {
    "role": "assistant",
    "content": "Hi there! I'm the Redington AI Bot, built to support you. How may I assist you today?",
    "llm_content": "Hi there! I'm the Redington AI Bot, built to support you. How may I assist you today?",
    "user_prompt": "",
    "has_context": False
}

def init_session_state() -> None:
    """
    Initialize Streamlit session state variables.
    """
    if "widget_key" not in st.session_state:
        st.session_state["widget_key"] = str(random.randint(1, 1000000))

    if "user_id" not in st.session_state:
        st.session_state["user_id"] = None

    if "current_chat_id" not in st.session_state: # Tracks the currently active chat session
        st.session_state["current_chat_id"] = None

    if "user_chat_sessions" not in st.session_state: # Stores {chat_id: chat_title} for the current user
        st.session_state["user_chat_sessions"] = {}

    if "messages" not in st.session_state:
        st.session_state.messages = [INIT_MESSAGE]
    if "current_llm_text" not in st.session_state:
        st.session_state.current_llm_text = ""
    if "msgs" not in st.session_state:
        st.session_state.msgs = StreamlitChatMessageHistory()
    if "file_uploader_key" not in st.session_state:
        st.session_state["file_uploader_key"] = 0

    default_model_name = list(config["models"].keys())[0] if config and "models" in config else "default_model"

    if "model_name" not in st.session_state:
        st.session_state["model_name"] = default_model_name

    if "system_prompt" not in st.session_state:
        # Changed default role to "Presales Pro"
        st.session_state["system_prompt"] = role_prompt.get("Presales Pro", "")

    if "web_local" not in st.session_state:
        st.session_state["web_local"] = "RAG"

    if "debug_mode" not in st.session_state:
        st.session_state["debug_mode"] = False

    # Initialize selected_role in session state to "Presales Pro"
    if "selected_role" not in st.session_state:
        st.session_state["selected_role"] = "Presales Pro" # Set "Presales Pro" as the default role


    default_model_config = config["models"].get(default_model_name, {})
    if "model_kwargs" not in st.session_state:
        st.session_state["model_kwargs"] = {
            "top_p": default_model_config.get("top_p", 1.0),
            "top_k": default_model_config.get("top_k", 500),
            "temperature": default_model_config.get("temperature", 1.0),
            "max_tokens": default_model_config.get("max_tokens", 4096),
        }

    # Initialize the hash for client-side deduplication of DynamoDB inserts
    if "last_saved_message_hash" not in st.session_state:
        st.session_state["last_saved_message_hash"] = None

    # New state variable to manage which chat title is being edited
    if "editing_chat_id" not in st.session_state:
        st.session_state["editing_chat_id"] = None


def logout_user():
    """
    Logs out the current user using Cognito Authenticator and clears session state.
    """
    try:
        authenticator.logout()
        st.session_state.clear()
        st.rerun()
    except Exception as e:
        st.error(f"Logout failed: {e}")

def load_user_chat_sessions() -> None:
    """
    Loads all chat sessions metadata for the current user from DynamoDB.
    Populates st.session_state.user_chat_sessions.
    """
    if not st.session_state.user_id:
        st.session_state.user_chat_sessions = {}
        return

    try:
        response = user_chat_sessions_table.query(
            KeyConditionExpression=Key('user_id').eq(st.session_state.user_id),
            ScanIndexForward=True # Order by chat_id (alphabetical)
        )

        st.session_state.user_chat_sessions = {
            item['chat_id']: item.get('chat_title', f"Chat {item['chat_id'][:8]}")
            for item in response.get('Items', [])
        }
    except ClientError as e:
        st.error(f"Error loading user chat sessions from DynamoDB: {e.response['Error']['Message']}")
        st.session_state.user_chat_sessions = {}
    except Exception as e:
        st.error(f"An unexpected error occurred loading chat sessions: {e}")
        st.session_state.user_chat_sessions = {}


def create_new_chat_session() -> None:
    """
    Creates a new chat session in DynamoDB and sets it as the current chat.
    """
    if not st.session_state.user_id:
        st.warning("Please log in to create a new chat.")
        return

    # MAX_CHATS_PER_USER is not defined in this scope. Let's define a reasonable limit.
    MAX_CHATS_PER_USER = 5

    if len(st.session_state.user_chat_sessions) >= MAX_CHATS_PER_USER:
        st.warning(f"You have reached the maximum of {MAX_CHATS_PER_USER} active chats. Please select an existing chat or delete one.")
        return

    new_chat_id = str(uuid.uuid4())
    chat_title = f"New Chat {datetime.datetime.now().strftime('%Y-%m-%d %H:%M')}"
    created_at_timestamp = int(datetime.datetime.now().timestamp() * 1000)

    try:
        user_chat_sessions_table.put_item(
            Item={
                'user_id': st.session_state.user_id,
                'chat_id': new_chat_id,
                'chat_title': chat_title,
                'created_at': created_at_timestamp
            }
        )
        # Add the initial message to the new chat's history
        initial_message_timestamp = int(datetime.datetime.now().timestamp() * 1000)
        chat_history_table.put_item(
            Item={
                'user_id': st.session_state.user_id,
                'chat_message_id': f"{new_chat_id}#{initial_message_timestamp}", # Composite Sort Key
                'chat_id': new_chat_id, # Separate attribute for chat_id
                'message_timestamp': initial_message_timestamp, # Separate attribute for timestamp
                'message_id': str(uuid.uuid4()), # Unique ID for this specific message
                'role': INIT_MESSAGE["role"],
                'content': INIT_MESSAGE["content"],
                'llm_content': INIT_MESSAGE["llm_content"],
                'user_prompt': INIT_MESSAGE["user_prompt"],
                'has_context': INIT_MESSAGE["has_context"],
                'images': []
            }
        )

        st.session_state.current_chat_id = new_chat_id
        st.session_state.user_chat_sessions[new_chat_id] = chat_title
        st.session_state.messages = [INIT_MESSAGE] # Reset displayed messages
        st.session_state.msgs.clear() # Clear LangChain history
        st.session_state["last_saved_message_hash"] = None # Reset hash for new chat
        st.session_state["editing_chat_id"] = None # Ensure no chat is in edit mode
        # st.rerun() # Removed redundant rerun
    except ClientError as e:
        st.error(f"Error creating new chat session in DynamoDB: {e.response['Error']['Message']}")
    except Exception as e:
        st.error(f"An unexpected error occurred creating new chat: {e}")


def delete_chat_session(chat_id_to_delete: str) -> None:
    """
    Deletes a chat session and all its messages from DynamoDB.
    """
    if not st.session_state.user_id or not chat_id_to_delete:
        st.warning("Cannot delete chat. User not logged in or chat not selected.")
        return

    try:
        # 1. Delete messages from chat_history table
        # We need to query for all messages belonging to this chat_id under the user_id
        response = chat_history_table.query(
            KeyConditionExpression=Key('user_id').eq(st.session_state.user_id) & Key('chat_message_id').begins_with(f"{chat_id_to_delete}#"),
            ProjectionExpression="user_id, chat_message_id" # Only fetch keys required for deletion
        )

        items_to_delete = response.get('Items', [])
        if items_to_delete:
            with chat_history_table.batch_writer() as batch:
                for item in items_to_delete:
                    batch.delete_item(Key={'user_id': item['user_id'], 'chat_message_id': item['chat_message_id']})
            # Removed the st.info message here
            # st.info(f"Deleted {len(items_to_delete)} messages for chat {chat_id_to_delete}.")

        # 2. Delete chat metadata from user_chat_sessions table
        user_chat_sessions_table.delete_item(
            Key={
                'user_id': st.session_state.user_id,
                'chat_id': chat_id_to_delete
            }
        )

        # Update session state
        if chat_id_to_delete in st.session_state.user_chat_sessions:
            del st.session_state.user_chat_sessions[chat_id_to_delete]

        st.success(f"Chat '{st.session_state.user_chat_sessions.get(chat_id_to_delete, 'Selected Chat')}' and its history deleted.")

        # After deletion, switch to another chat or create a new one
        if st.session_state.user_chat_sessions:
            st.session_state.current_chat_id = list(st.session_state.user_chat_sessions.keys())[0]
            load_chat_history(st.session_state.current_chat_id)
        else:
            create_new_chat_session() # Automatically create a new chat if none exist
        st.session_state["editing_chat_id"] = None # Reset edit mode
        st.rerun()

    except ClientError as e:
        st.error(f"Error deleting chat from DynamoDB: {e.response['Error']['Message']}")
    except Exception as e:
        st.error(f"An unexpected error occurred deleting chat: {e}")

def update_chat_title(chat_id: str, new_title: str) -> None:
    """
    Updates the title of a specific chat session in DynamoDB.
    """
    if not st.session_state.user_id or not chat_id or not new_title:
        st.warning("Cannot update chat title. User not logged in, chat not selected, or title is empty.")
        return

    try:
        user_chat_sessions_table.update_item(
            Key={
                'user_id': st.session_state.user_id,
                'chat_id': chat_id
            },
            UpdateExpression="SET chat_title = :new_title",
            ExpressionAttributeValues={
                ':new_title': new_title
            }
        )
        st.session_state.user_chat_sessions[chat_id] = new_title # Update session state immediately
        st.success(f"Chat title updated to '{new_title}'!")
        st.session_state["editing_chat_id"] = None # Exit edit mode
        # st.rerun() # Removed redundant rerun
    except ClientError as e:
        st.error(f"Error updating chat title in DynamoDB: {e.response['Error']['Message']}")
    except Exception as e:
        st.error(f"An unexpected error occurred updating chat title: {e}")


def render_sidebar_auth_and_params() -> Tuple[Dict, str, str, bool]:
    """
    Renders the authentication section and model parameters in the sidebar.
    Returns model parameters and debug mode setting.
    """
    with st.sidebar:
        # Add the Redington AI logo at the very top of the sidebar
        st.image("images/redington_ai.gif", use_container_width=True) # Changed to use_container_width
        
        st.header("Authentication")
        # Display content for logged-in users
        if authenticator.is_logged_in:
            username = "Guest" # Default username in case of error
            try:
                username_raw = authenticator.get_username()
                if username_raw:
                    username = ' '.join(word.capitalize() for word in username_raw.split())
                else:
                    st.warning("Could not retrieve a valid username. Displaying as 'Guest'.")
            except OSError as e:
                st.error(f"Error retrieving username due to I/O issue: {e}. Please try logging out and logging back in, or contact support if the issue persists.")
                # The app will continue with 'Guest' username.
            except Exception as e:
                st.error(f"An unexpected error occurred while retrieving username: {e}")
                
            st.write(f"Welcome, {username}")
            st.button("Logout", on_click=logout_user, type="secondary", use_container_width=True)

            st.markdown("---")
            st.header("Chat Sessions")
            load_user_chat_sessions() # Ensure latest chats are loaded

            # Display "New Chat" button prominently
            if st.button("➕ New Chat", on_click=create_new_chat_session, use_container_width=True, type="primary"):
                pass # Action handled by on_click

            chat_options = list(st.session_state.user_chat_sessions.keys())

            if chat_options:
                # Determine initial selection for the radio button
                if st.session_state.current_chat_id and st.session_state.current_chat_id in chat_options:
                    selected_chat_index = chat_options.index(st.session_state.current_chat_id)
                else:
                    # If current_chat_id is not set or invalid, default to the first chat
                    selected_chat_index = 0
                    st.session_state.current_chat_id = chat_options[0] # Set it in session state

                st.markdown("---")
                st.subheader("Your Chats")

                # Iterate through chat sessions to display them with edit/delete buttons
                for chat_id, chat_title in st.session_state.user_chat_sessions.items():
                    # Use a container for each chat entry to group elements visually
                    with st.container():
                        # Using columns for layout: title/input, edit button, delete button
                        col_title, col_edit, col_delete = st.columns([0.7, 0.15, 0.15])

                        with col_title:
                            if st.session_state.editing_chat_id == chat_id:
                                # This is the chat currently being edited
                                current_edited_title = st.text_input(
                                    "Edit Title",
                                    value=chat_title,
                                    key=f"edit_input_{chat_id}",
                                    label_visibility="collapsed",
                                    # Callback to save on Enter/unfocus of the text input
                                    on_change=lambda c=chat_id: update_chat_title(c, st.session_state[f"edit_input_{c}"])
                                )
                            else:
                                # Display as a radio button (clickable title for selection)
                                is_selected = (st.session_state.current_chat_id == chat_id)
                                st.radio(
                                    "", # Label is empty as title is the clickable part
                                    options=[chat_id],
                                    format_func=lambda x: chat_title,
                                    index=0 if is_selected else None, # Set index to 0 if selected, else None
                                    key=f"radio_{chat_id}",
                                    on_change=lambda c=chat_id: load_chat_history(c),
                                    label_visibility="collapsed"
                                )

                        with col_edit:
                            # Use an empty markdown div for vertical alignment with text_input if needed
                            # st.markdown("<div style='height: 28px;'></div>", unsafe_allow_html=True) # Adjust height as necessary
                            if st.session_state.editing_chat_id == chat_id:
                                # Show Save button if in edit mode
                                if st.button("💾", key=f"save_button_explicit_{chat_id}", help="Save Title"):
                                    # Ensure the value from text_input is used for saving
                                    new_title_from_input = st.session_state.get(f"edit_input_{chat_id}", chat_title)
                                    if new_title_from_input and new_title_from_input != chat_title:
                                        update_chat_title(chat_id, new_title_from_input)
                                    else:
                                        st.info("Title is unchanged or empty. Exiting edit mode.")
                                        st.session_state.editing_chat_id = None # Exit edit mode
                                        st.rerun() # Rerun to refresh the display
                            else:
                                # Show Edit button if not in edit mode
                                if st.button("✏️", key=f"edit_button_{chat_id}", help="Edit Title"):
                                    st.session_state.editing_chat_id = chat_id
                                    st.rerun()

                        with col_delete:
                            # Use an empty markdown div for vertical alignment with text_input if needed
                            # st.markdown("<div style='height: 28px;'></div>", unsafe_allow_html=True) # Adjust height as necessary
                            # Delete button is always present for each chat
                            if st.button("🗑️", key=f"delete_button_{chat_id}", help="Delete Chat"):
                                delete_chat_session(chat_id)
                                # Deletion will handle rerunning and setting current_chat_id


            else:
                st.info("No chats found. Click '➕ New Chat' to start one.")


            st.markdown("---")
            st.header("Model Parameters")

            model_name_select = st.selectbox(
                "Model",
                list(config["models"].keys()),
                index=list(config["models"].keys()).index(st.session_state["model_name"]) if st.session_state["model_name"] in config["models"] else 0,
                key=f"{st.session_state['widget_key']}_Model_Id",
            )
            st.session_state["model_name"] = model_name_select

            # Determine the initial selected role for the selectbox
            selected_role_from_session = st.session_state.get("selected_role", "Presales Pro") # Changed default
            
            # Create the list of available roles for the selectbox
            available_roles = ["Custom"] + list(role_prompt.keys())

            # Determine the effective role to be displayed and its index
            effective_selected_role = None
            
            if selected_role_from_session in available_roles:
                # If the role from session state is valid, use it
                effective_selected_role = selected_role_from_session
            elif "Presales Pro" in available_roles: # Prioritize "Presales Pro" if available
                effective_selected_role = "Presales Pro"
            elif "Default" in available_roles: # Fallback to "Default" if "Presales Pro" isn't an option
                effective_selected_role = "Default"
            elif "Custom" in available_roles: # Fallback to "Custom" if "Default" isn't an option
                effective_selected_role = "Custom"
            else: # If no suitable default found, pick the first available or None
                effective_selected_role = available_roles[0] if available_roles else ""
                
            # Get the index of the effective_selected_role. Handle case where it might not be found (e.g., if available_roles is empty)
            try:
                initial_role_index = available_roles.index(effective_selected_role)
            except ValueError:
                initial_role_index = 0 # Default to the first item if effective_selected_role isn't found (shouldn't happen with above logic)


            role_select = st.selectbox(
                "Role",
                available_roles,
                index=initial_role_index, # Use the robustly determined index
                key=f"{st.session_state['widget_key']}_role_Id",
            )
            st.session_state["selected_role"] = role_select # Update selected_role in session state

            system_prompt_value = role_prompt.get(role_select, "")
            if role_select == "Custom":
                system_prompt_value = st.session_state.get("system_prompt", "")

            system_prompt = st.text_area(
                "System Prompt",
                value=system_prompt_value,
                key=f"{st.session_state['widget_key']}_System_Prompt",
            )
            st.session_state["system_prompt"] = system_prompt

            web_local = st.selectbox(
                "Options",
                ("RAG", "Local"),
                index=("RAG", "Local").index(st.session_state["web_local"]),
                key=f"{st.session_state['widget_key']}_Options",
            )
            st.session_state["web_local"] = web_local

            debug_mode = st.checkbox(
                "Debug Mode (Show RAG Context and Thinking)",
                value=st.session_state.get("debug_mode", False),
                key=f"{st.session_state['widget_key']}_Debug_Mode",
                help="Enable to see RAG search results and backend processing"
            )
            st.session_state["debug_mode"] = debug_mode

            model_config = config["models"][st.session_state["model_name"]]

            with st.container():
                col1, col2 = st.columns(2)
                with col1:
                    top_p = st.slider(
                        "Top-P",
                        min_value=0.0,
                        max_value=1.0,
                        value=st.session_state["model_kwargs"].get("top_p", model_config.get("top_p", 1.0)),
                        step=0.01,
                        key=f"{st.session_state['widget_key']}_Top-P",
                    )
                with col2:
                    top_k = st.slider(
                        "Top-K",
                        min_value=1,
                        max_value=model_config.get("max_top_k", 500),
                        value=st.session_state["model_kwargs"].get("top_k", model_config.get("top_k", 500)),
                        step=5,
                        key=f"{st.session_state['widget_key']}_Top-K",
                    )
            with st.container():
                col1, col2 = st.columns(2)
                with col1:
                    temperature = st.slider(
                        "Temperature",
                        min_value=0.0,
                        max_value=1.0,
                        value=st.session_state["model_kwargs"].get("temperature", model_config.get("temperature", 1.0)),
                        key=f"{st.session_state['widget_key']}_Temperature",
                    )
                with col2:
                    max_tokens = st.slider(
                        "Max Token",
                        min_value=0,
                        max_value=4096,
                        value=model_config.get("max_tokens", 4096),
                        step=8,
                        key=f"{st.session_state['widget_key']}_Max_Token",
                    )

            model_kwargs = {
                "top_p": top_p,
                "top_k": top_k,
                "temperature": temperature,
                "max_tokens": max_tokens,
            }
            st.session_state["model_kwargs"] = model_kwargs

            return model_kwargs, system_prompt, web_local, debug_mode
        else:
            # If not logged in, no model parameters are returned here because the main app content won't render.
            return st.session_state["model_kwargs"], st.session_state["system_prompt"], st.session_state["web_local"], st.session_state["debug_mode"]


def extract_reasoning_and_text(input: Any, debug_mode: bool) -> str:
    """
    Extracts reasoning content and normal text from the LLM's output.
    Processes streaming responses and yields text chunks.
    Conditionally displays reasoning block based on debug_mode.
    """
    in_reasoning_block = False
    current_text = ""
    display_text = ""

    for chunk in input:
        content = chunk.content if hasattr(chunk, "content") else chunk
        if isinstance(content, list):
            for item in content:
                if item.get("type") == "reasoning_content":
                    reasoning_text = item.get("reasoning_content", {}).get("text", "")
                    if reasoning_text and debug_mode:  # Only show if debug_mode is True
                        if not in_reasoning_block:
                            display_text += "```thinking\n"
                            yield "```thinking\n"
                            in_reasoning_block = True
                        display_text += reasoning_text
                        yield reasoning_text
                elif item.get("type") == "text" and (text := item.get("text")):
                    if in_reasoning_block:
                        display_text += "\n```\n"
                        yield "\n```\n"
                        in_reasoning_block = False
                    display_text += text
                    current_text += text
                    yield text
        else:
            if in_reasoning_block:
                display_text += "\n```\n"
                yield "\n```\n"
                in_reasoning_block = False
            display_text += content
            current_text += content
            yield content

    if in_reasoning_block:
        display_text += "\n```"
        yield "\n```"

    st.session_state["current_llm_text"] = current_text
    st.session_state["current_display_text"] = display_text


def store_message(role: str, content: str, user_prompt: str = "", has_context: bool = False, images: List[str] = None) -> None:
    """
    Store a message in the session state for display purposes and persist to DynamoDB.
    """
    message = {"role": role, "has_context": has_context}

    if role == "assistant" and "current_display_text" in st.session_state:
        message["content"] = st.session_state["current_display_text"]
        if "current_llm_text" in st.session_state:
            message["llm_content"] = st.session_state["current_llm_text"]
    else:
        message["content"] = content
        if role == "user":
            message["llm_content"] = re.sub(r'`thinking.*?`', '', content, flags=re.DOTALL)
            message["user_prompt"] = user_prompt
        else:
            message["llm_content"] = content

    if images:
        message["images"] = images

    st.session_state.messages.append(message)

    # --- DynamoDB Persistence ---
    if st.session_state.user_id and st.session_state.current_chat_id:
        message_timestamp = int(datetime.datetime.now().timestamp() * 1000)
        chat_message_id = f"{st.session_state.current_chat_id}#{message_timestamp}" # Composite Sort Key

        # Create a unique hash for the current message to prevent duplicate DynamoDB inserts
        message_hash_data = f"{chat_message_id}-{role}-{content}"
        current_message_hash = hashlib.md5(message_hash_data.encode()).hexdigest()

        if st.session_state.get("last_saved_message_hash") == current_message_hash:
            # st.info("Skipping duplicate message save to DynamoDB.") # For debugging
            return

        try:
            item = {
                'user_id': st.session_state.user_id,
                'chat_message_id': chat_message_id,
                'chat_id': st.session_state.current_chat_id, # Separate attribute for chat_id
                'message_timestamp': message_timestamp, # Separate attribute for timestamp
                'message_id': str(uuid.uuid4()), # Unique ID for this specific message
                'role': message["role"],
                'content': message["content"],
                'llm_content': message.get("llm_content"),
                'user_prompt': message.get("user_prompt"),
                'has_context': message.get("has_context", False),
                'images': message.get("images") if message.get("images") else []
            }
            item = {k: v for k, v in item.items() if v is not None} # Remove None values

            chat_history_table.put_item(Item=item)
            st.session_state["last_saved_message_hash"] = current_message_hash
            # st.success("Message saved to history!") # Uncomment for debugging
        except ClientError as e:
            st.error(f"Error saving message to DynamoDB: {e.response['Error']['Message']}")
        except Exception as e:
            st.error(f"An unexpected error occurred saving message to DynamoDB: {e}")


def load_chat_history(chat_id: str) -> None:
    """
    Loads chat history for a given chat ID from DynamoDB and populates session state.
    """
    if not st.session_state.user_id or not chat_id:
        st.info("No user or chat ID available to load chat history.")
        st.session_state.messages = [INIT_MESSAGE]
        st.session_state.msgs.clear()
        return

    try:
        # Query DynamoDB for items belonging to the user_id and the specific chat_id
        # The KeyConditionExpression uses the Partition Key 'user_id' and
        # a 'begins_with' condition on the composite Sort Key 'chat_message_id'.
        response = chat_history_table.query(
            KeyConditionExpression=Key('user_id').eq(st.session_state.user_id) & Key('chat_message_id').begins_with(f"{chat_id}#"),
            ScanIndexForward=True # True for ascending order by Sort Key (timestamp part of chat_message_id)
        )

        if response and 'Items' in response:
            loaded_messages = []
            for record in response['Items']:
                msg = {
                    "role": record["role"],
                    "content": record["content"],
                    "llm_content": record.get("llm_content"),
                    "user_prompt": record.get("user_prompt"),
                    "has_context": record.get("has_context", False),
                    "images": record.get("images")
                }
                loaded_messages.append(msg)

            st.session_state.messages = loaded_messages if loaded_messages else [INIT_MESSAGE]
            st.session_state.msgs.clear() # Clear LangChain history

            # Re-populate LangChain's history
            for msg in st.session_state.messages:
                if msg["role"] == "user":
                    st.session_state.msgs.add_user_message(msg.get("llm_content") or msg["content"])
                elif msg["role"] == "assistant":
                    st.session_state.msgs.add_ai_message(msg.get("llm_content") or msg["content"])

            st.session_state.current_chat_id = chat_id # Set the current chat ID after loading
            # st.success(f"Chat history loaded for chat: {chat_id}!") # Uncomment for debugging
        else:
            st.info(f"No prior chat history found for chat: {chat_id}.")
            st.session_state.messages = [INIT_MESSAGE]
            st.session_state.msgs.clear()
            st.session_state.current_chat_id = chat_id # Still set current_chat_id even if empty
    except ClientError as e:
        st.error(f"Error loading chat history from DynamoDB: {e.response['Error']['Message']}")
        st.session_state.messages = [INIT_MESSAGE] # Fallback to initial message on error
        st.session_state.msgs.clear()
        st.session_state.current_chat_id = None
    except Exception as e:
        st.error(f"An unexpected error occurred loading chat history from DynamoDB: {e}")
        st.session_state.messages = [INIT_MESSAGE] # Fallback to initial message on error
        st.session_state.msgs.clear()
        st.session_state.current_chat_id = None


def init_runnablewithmessagehistory(
    system_prompt: str,
    chat_model: ChatModel,
    debug_mode: bool # Added debug_mode parameter
) -> RunnableWithMessageHistory:
    """
    Initialize the RunnableWithMessageHistory with the given parameters.
    """
    msgs = st.session_state.msgs
    conversation_chain = (
        ChatPromptTemplate.from_messages(
            [
                ("system", system_prompt),
                MessagesPlaceholder(variable_name="chat_history"),
                MessagesPlaceholder(variable_name="query"),
            ]
        )
        | chat_model.llm
    )

    runnable_with_history = RunnableWithMessageHistory(
        conversation_chain,
        lambda session_id: msgs,
        input_messages_key="query",
        history_messages_key="chat_history",
    )

    # Pass debug_mode to extract_reasoning_and_text
    final_runnable = runnable_with_history | (lambda x: extract_reasoning_and_text(x, debug_mode))

    return final_runnable


def generate_response(
    conversation: RunnableWithMessageHistory, input: Union[str, List[dict]]
) -> str:
    """
    Generate a response from the conversation chain with the given input and apply output guardrails.
    """
    # LangChain's Runnable expects a dictionary with a 'query' key
    # where the value is the input for the current turn.
    # For multimodal input, this 'query' value can be a list of dicts
    # like [{"type": "text", "text": "..."}] or [{"type": "image_url", "image_url": {"url": "..."}}].

    # If the input is already a list of dictionaries (multimodal parts),
    # wrap it as the 'content' of a user message.
    if isinstance(input, list):
        # This is the correct format for multimodal input to LangChain's ChatPromptTemplate
        # when using MessagesPlaceholder for 'query'.
        formatted_input = [{"role": "user", "content": input}]
    elif isinstance(input, str):
        # If it's a simple string, format it as a single text message.
        clean_input = re.sub(r'`thinking.*?`', '', input, flags=re.DOTALL)
        formatted_input = [{"role": "user", "content": clean_input}]
    else:
        # Fallback for unexpected input types, though ideally input should be Union[str, List[dict]]
        st.error(f"Unexpected input type for generate_response: {type(input)}")
        formatted_input = [{"role": "user", "content": str(input)}] # Attempt to convert to string

    session_id_for_langchain = st.session_state["current_chat_id"] if st.session_state.current_chat_id else "default_session"

    full_response_text = ""
    response_placeholder = st.empty()

    response_generator = conversation.stream(
        {"query": formatted_input}, # Pass the formatted input as the 'query' for the current turn
        config={"configurable": {"session_id": session_id_for_langchain}}
    )

    for chunk in response_generator:
        full_response_text += chunk
        response_placeholder.markdown(full_response_text)

    is_flagged, reason, moderated_output = app_guardrails.apply_output_guardrails(full_response_text)

    if is_flagged:
        response_placeholder.markdown(moderated_output)
        st.warning(f"Guardrail triggered for LLM output: {reason}")
        return moderated_output

    return full_response_text


def new_chat() -> None:
    """
    Resets the current chat session and creates a new one.
    """
    if st.session_state.user_id:
        create_new_chat_session()
    else:
        st.session_state["messages"] = [INIT_MESSAGE]
        st.session_state["msgs"].clear()
        st.session_state["file_uploader_key"] = random.randint(1, 100)
        if "current_llm_text" in st.session_state:
            del st.session_state["current_llm_text"]
        if "current_display_text" in st.session_state:
            del st.session_state["current_display_text"]
        st.session_state["last_saved_message_hash"] = None # Reset hash for new chat
        st.session_state["current_chat_id"] = None # No active chat until created/selected
        st.session_state["editing_chat_id"] = None # Reset edit mode
        st.rerun()


def apply_input_guardrails(prompt: str) -> Tuple[bool, str, str]:
    """
    Applies input guardrails to the user's prompt.
    """
    for keyword in DISALLOWED_KEYWORDS:
        if re.search(r'\b' + re.escape(keyword) + r'\b', prompt, re.IGNORECASE):
            return True, f"contains '{keyword}'", GUARDRAIL_MESSAGE
    return False, "", prompt


def display_images(
    image_ids: List[str],
    uploaded_files: List[st.runtime.uploaded_file_manager.UploadedFile],
) -> None:
    """
    Display uploaded images in the chat message.
    """
    num_cols = 10
    cols = st.columns(num_cols)
    i = 0

    for image_id in image_ids:
        for uploaded_file in uploaded_files:
            if image_id == uploaded_file.file_id:
                if uploaded_file.type.startswith("image/"):
                    img = Image.open(uploaded_file)

                    with cols[i]:
                        st.image(img, caption="", width=75)
                        i += 1

                    if i >= num_cols:
                        i = 0
    # No return value needed here as content is processed elsewhere


def display_user_message(message: dict, debug_mode: bool = False) -> None:
    """
    Display user message in the chat message.
    Shows clean user prompt by default, full content in debug mode.
    """
    if debug_mode and message.get("has_context", False):
        user_prompt = message.get("user_prompt", "")
        if user_prompt:
            st.markdown("**Your Question:**")
            st.markdown(user_prompt)

            with st.expander("🔬 RAG Context (Debug)", expanded=False):
                full_content = message["content"]
                if "<search>" in full_content and "</search>" in full_content:
                    rag_content = full_content.split("<search>")[1].split("</search>")[0]
                    st.markdown("**Retrieved Context:**")
                    st.text(rag_content.strip())
    else:
        user_prompt = message.get("user_prompt", "")
        if user_prompt:
            st.markdown(user_prompt)
        else:
            message_content = message["content"]
            if isinstance(message_content, str):
                clean_content = message_content.split("</search>\n\n", 1)[-1]
                st.markdown(clean_content)
            elif isinstance(message_content, dict):
                # This part needs to be robust for different input structures
                # Assuming text is in message_content["input"][0]["content"][0]["text"] for multimodal
                if "input" in message_content and isinstance(message_content["input"], list) and message_content["input"]:
                    if isinstance(message_content["input"][0], dict) and "content" in message_content["input"][0] and isinstance(message_content["input"][0]["content"], list) and message_content["input"][0]["content"]:
                        if isinstance(message_content["input"][0]["content"][0], dict) and "text" in message_content["input"][0]["content"][0]:
                            message_text = message_content["input"][0]["content"][0]["text"]
                            clean_content = message_text.split("</search>\n\n", 1)[-1]
                            st.markdown(clean_content)
                        else:
                            st.markdown("Error: Unexpected message content structure.")
                    else:
                        st.markdown("Error: Unexpected message content structure.")
                else:
                    st.markdown("Error: Unexpected message content structure.")
            else:
                st.markdown(message_content[0]["text"])


def display_assistant_message(message_content: Union[str, dict]) -> None:
    """
    Display assistant message in the chat message.
    """
    if isinstance(message_content, str):
        st.markdown(message_content)
    elif "response" in message_content:
        st.markdown(message_content["response"])

# Function to parse Markdown and generate DOCX in memory
def get_docx_bytes(markdown_text: str) -> bytes:
    """
    Parses Markdown text and generates a Word document (.docx) with formatted content.
    Supports headings, tables, bold, and ordered/unordered lists.
    """
    document = Document()

    # Split the markdown text into lines
    lines = markdown_text.split('\n')
    
    in_table = False
    table_data = []
    
    for line in lines:
        line = line.strip()

        if not line:
            # Skip empty lines, reset table state
            in_table = False
            if table_data:
                # Process the table data if it exists
                # Assuming the first row is header, second is separator
                if len(table_data) > 1:
                    headers = [h.strip() for h in table_data[0].split('|') if h.strip()]
                    # Filter out empty strings from headers (can happen with leading/trailing pipes)
                    headers = [h for h in headers if h] 
                    
                    table_rows = []
                    for row_str in table_data[2:]: # Skip header and separator
                        row_cells = [cell.strip() for cell in row_str.split('|') if cell.strip()]
                        table_rows.append(row_cells)

                    if headers and table_rows:
                        # Create table in docx
                        table = document.add_table(rows=1, cols=len(headers))
                        table.style = 'Table Grid' # Apply a basic grid style

                        # Add headers
                        hdr_cells = table.rows[0].cells
                        for i, header in enumerate(headers):
                            if i < len(hdr_cells): # Ensure column exists
                                hdr_cells[i].text = header
                                hdr_cells[i].paragraphs[0].runs[0].bold = True # Bold headers

                        # Add data rows
                        for row_cells in table_rows:
                            row = table.add_row().cells
                            for i, cell_text in enumerate(row_cells):
                                if i < len(row): # Ensure we don't go out of bounds for columns
                                    # Handle bold text within table cells
                                    p = row[i].paragraphs[0]
                                    parts = re.split(r'(\*\*.*?\*\*)', cell_text)
                                    for part in parts:
                                        if part.startswith('**') and part.endswith('**'):
                                            run = p.add_run(part[2:-2])
                                            run.bold = True
                                        else:
                                            p.add_run(part)

                table_data = [] # Reset for next table


            continue # Process the next line


        # Headings
        if line.startswith('#'):
            in_table = False
            # Process table if it ended here
            if table_data: # Process any pending table data
                if len(table_data) > 1:
                    headers = [h.strip() for h in table_data[0].split('|') if h.strip()]
                    headers = [h for h in headers if h] 
                    table_rows = []
                    for row_str in table_data[2:]: # Skip header and separator
                        row_cells = [cell.strip() for cell in row_str.split('|') if cell.strip()]
                        table_rows.append(row_cells)

                    if headers and table_rows:
                        table = document.add_table(rows=1, cols=len(headers))
                        table.style = 'Table Grid'
                        hdr_cells = table.rows[0].cells
                        for i, header in enumerate(headers):
                            if i < len(hdr_cells):
                                hdr_cells[i].text = header
                                hdr_cells[i].paragraphs[0].runs[0].bold = True
                        for row_cells in table_rows:
                            row = table.add_row().cells
                            for i, cell_text in enumerate(row_cells):
                                if i < len(row):
                                    p = row[i].paragraphs[0]
                                    parts = re.split(r'(\*\*.*?\*\*)', cell_text)
                                    for part in parts:
                                        if part.startswith('**') and part.endswith('**'):
                                            run = p.add_run(part[2:-2])
                                            run.bold = True
                                        else:
                                            p.add_run(part)
                table_data = [] # Reset for next table

            heading_level = line.count('#')
            text = line.lstrip('#').strip()
            # Special case for "PROPOSAL FOR GREENFIELD AZURE DEPLOYMENT" to be Title (level 0)
            if "PROPOSAL FOR GREENFIELD AZURE DEPLOYMENT" in text.upper():
                document.add_heading(text, level=0)
            else:
                # Map Markdown heading levels to docx heading levels
                # h1 -> Heading 1, h2 -> Heading 2, etc.
                # Max level is 9 for docx headings
                docx_level = min(heading_level, 9)
                document.add_heading(text, level=docx_level)

        # Tables
        elif line.startswith('|') and '|' in line[1:]: # Ensure it's not just a single |
            in_table = True
            table_data.append(line)
        
        # Ordered Lists (e.g., 1. Item)
        elif re.match(r'^\d+\.\s', line):
            in_table = False
            if table_data: # Process any pending table data
                if len(table_data) > 1:
                    headers = [h.strip() for h in table_data[0].split('|') if h.strip()]
                    headers = [h for h in headers if h] 
                    table_rows = []
                    for row_str in table_data[2:]: # Skip header and separator
                        row_cells = [cell.strip() for cell in row_str.split('|') if cell.strip()]
                        table_rows.append(row_cells)

                    if headers and table_rows:
                        table = document.add_table(rows=1, cols=len(headers))
                        table.style = 'Table Grid'
                        hdr_cells = table.rows[0].cells
                        for i, header in enumerate(headers):
                            if i < len(hdr_cells):
                                hdr_cells[i].text = header
                                hdr_cells[i].paragraphs[0].runs[0].bold = True
                        for row_cells in table_rows:
                            row = table.add_row().cells
                            for i, cell_text in enumerate(row_cells):
                                if i < len(row):
                                    p = row[i].paragraphs[0]
                                    parts = re.split(r'(\*\*.*?\*\*)', cell_text)
                                    for part in parts:
                                        if part.startswith('**') and part.endswith('**'):
                                            run = p.add_run(part[2:-2])
                                            run.bold = True
                                        else:
                                            p.add_run(part)
                table_data = []

            text = re.sub(r'^\d+\.\s*', '', line).strip()
            p = document.add_paragraph(text, style='List Number')
            # Handle bold within list items
            parts = re.split(r'(\*\*.*?\*\*)', text)
            p.clear() # Clear default run
            for part in parts:
                if part.startswith('**') and part.endswith('**'):
                    run = p.add_run(part[2:-2])
                    run.bold = True
                else:
                    p.add_run(part)

        # Unordered Lists (e.g., - Item or * Item)
        elif line.startswith('- ') or line.startswith('* '):
            in_table = False
            if table_data: # Process any pending table data
                if len(table_data) > 1:
                    headers = [h.strip() for h in table_data[0].split('|') if h.strip()]
                    headers = [h for h in headers if h] 
                    table_rows = []
                    for row_str in table_data[2:]: # Skip header and separator
                        row_cells = [cell.strip() for cell in row_str.split('|') if cell.strip()]
                        table_rows.append(row_cells)

                    if headers and table_rows:
                        table = document.add_table(rows=1, cols=len(headers))
                        table.style = 'Table Grid'
                        hdr_cells = table.rows[0].cells
                        for i, header in enumerate(headers):
                            if i < len(hdr_cells):
                                hdr_cells[i].text = header
                                hdr_cells[i].paragraphs[0].runs[0].bold = True
                        for row_cells in table_rows:
                            row = table.add_row().cells
                            for i, cell_text in enumerate(row_cells):
                                if i < len(row):
                                    p = row[i].paragraphs[0]
                                    parts = re.split(r'(\*\*.*?\*\*)', cell_text)
                                    for part in parts:
                                        if part.startswith('**') and part.endswith('**'):
                                            run = p.add_run(part[2:-2])
                                            run.bold = True
                                        else:
                                            p.add_run(part)
                table_data = []

            text = line[2:].strip() # Remove '- ' or '* '
            p = document.add_paragraph(text, style='List Bullet')
            # Handle bold within list items
            parts = re.split(r'(\*\*.*?\*\*)', text)
            p.clear() # Clear default run
            for part in parts:
                if part.startswith('**') and part.endswith('**'):
                    run = p.add_run(part[2:-2])
                    run.bold = True
                else:
                    p.add_run(part)

        # Regular Paragraphs (and bold text within them)
        elif not in_table:
            p = document.add_paragraph()
            parts = re.split(r'(\*\*.*?\*\*)', line) # Split by bold markdown
            for part in parts:
                if part.startswith('**') and part.endswith('**'):
                    run = p.add_run(part[2:-2]) # Remove **
                    run.bold = True
                else:
                    p.add_run(part)

    # After loop, process any remaining table data if the document ends with a table
    if table_data:
        if len(table_data) > 1:
            headers = [h.strip() for h in table_data[0].split('|') if h.strip()]
            headers = [h for h in headers if h] 
            table_rows = []
            for row_str in table_data[2:]: # Skip header and separator
                row_cells = [cell.strip() for cell in row_str.split('|') if cell.strip()]
                table_rows.append(row_cells)

            if headers and table_rows:
                table = document.add_table(rows=1, cols=len(headers))
                table.style = 'Table Grid'
                hdr_cells = table.rows[0].cells
                for i, header in enumerate(headers):
                    if i < len(hdr_cells):
                        hdr_cells[i].text = header
                        hdr_cells[i].paragraphs[0].runs[0].bold = True
                for row_cells in table_rows:
                    row = table.add_row().cells
                    for i, cell_text in enumerate(row_cells):
                        if i < len(row):
                            p = row[i].paragraphs[0]
                            parts = re.split(r'(\*\*.*?\*\*)', cell_text)
                            for part in parts:
                                if part.startswith('**') and part.endswith('**'):
                                    run = p.add_run(part[2:-2])
                                    run.bold = True
                                else:
                                    p.add_run(part)


    # Save the document to a BytesIO object
    bio = BytesIO()
    document.save(bio)
    return bio.getvalue()


def process_and_display_uploaded_files(
    uploaded_files: List[st.runtime.uploaded_file_manager.UploadedFile],
    message_images_list: List[str],
) -> Tuple[str, List[Dict]]:
    """
    Process uploaded files (images, text, PDF, CSV, XLSX) and prepare content for the LLM.
    Displays uploaded file previews in the chat.
    Returns a tuple: (concatenated_text_content, list_of_image_parts_for_llm).
    """
    total_text_content = []
    content_for_llm = [] # This will hold image and text parts for the LLM
    uploaded_file_ids_in_current_message = [] # Track files in current turn to avoid re-processing

    num_cols = 10
    cols = st.columns(num_cols)
    i = 0

    for uploaded_file in uploaded_files:
        if uploaded_file.file_id not in message_images_list and uploaded_file.file_id not in uploaded_file_ids_in_current_message:
            uploaded_file_ids_in_current_message.append(uploaded_file.file_id)

            file_type = uploaded_file.type
            file_name = uploaded_file.name

            if file_type.startswith("image/"):
                try:
                    img = Image.open(uploaded_file)
                    with BytesIO() as output_buffer:
                        img.save(output_buffer, format=img.format)
                        content_image = output_buffer.getvalue()

                    content_for_llm.append(
                        {
                            "image": {
                                "format": img.format.lower(),
                                "source": {"bytes": content_image},
                            }
                        }
                    )
                    with cols[i]:
                        st.image(img, caption="", width=75)
                        i += 1
                    if i >= num_cols:
                        i = 0
                except UnidentifiedImageError:
                    st.warning(f"Could not open image file: {file_name}. Skipping.")

            elif file_type == "text/plain":
                text_content = uploaded_file.read().decode("utf-8")
                total_text_content.append(f"\n--- Start of {file_name} ---\n{text_content}\n--- End of {file_name} ---\n")
                st.write(f"📄 Processed Text file: {file_name}")

            elif file_type == "text/csv":
                try:
                    df = pd.read_csv(uploaded_file)
                    csv_content = df.to_markdown(index=False) # Convert DataFrame to Markdown table string
                    total_text_content.append(f"\n--- Start of {file_name} (CSV Data) ---\n{csv_content}\n--- End of {file_name} ---\n")
                    st.write(f"📊 Processed CSV file: {file_name}")
                except Exception as e:
                    st.error(f"Error processing CSV file {file_name}: {e}")

            elif file_type == "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet": # .xlsx
                try:
                    xls = pd.ExcelFile(uploaded_file)
                    excel_content_str = ""
                    for sheet_name in xls.sheet_names:
                        df = pd.read_excel(xls, sheet_name=sheet_name)
                        excel_content_str += f"\n--- Start of Sheet '{sheet_name}' in {file_name} ---\n"
                        excel_content_str += df.to_markdown(index=False)
                        excel_content_str += f"\n--- End of Sheet '{sheet_name}' ---\n"
                    
                    total_text_content.append(f"\n--- Start of {file_name} (Excel Data) ---\n{excel_content_str}\n--- End of {file_name} ---\n")
                    st.write(f"📈 Processed Excel file: {file_name}")
                except Exception as e:
                    st.error(f"Error processing Excel file {file_name}: {e}")

            elif file_type == "application/pdf":
                try:
                    pdf_file = pdfplumber.open(uploaded_file)
                    page_text = ""
                    for page in pdf_file.pages:
                        page_text += page.extract_text() or "" # Ensure extract_text doesn't return None
                    total_text_content.append(f"\n--- Start of {file_name} ---\n{page_text}\n--- End of {file_name} ---\n")
                    st.write(f"📑 Processed PDF file: {file_name}")
                    pdf_file.close()
                except Exception as e:
                    st.error(f"Error processing PDF file {file_name}: {e}")

            elif file_type == "text/x-python-script":
                text_content = uploaded_file.read().decode("utf-8")
                total_text_content.append(f"\n--- Start of {file_name} (Python Code) ---\n```python\n{text_content}\n```\n--- End of {file_name} ---\n")
                st.write(f"🐍 Processed Python file: {file_name}")
            else:
                st.warning(f"Unsupported file type for {file_name}: {file_type}. Skipping.")

    # Combine all textual content into a single string
    combined_text_content = "\n".join(total_text_content)
    
    # Do not add combined textual content as a text part here.
    # It will be added in main() after RAG context.
    # This function now only returns the raw combined text and image parts.
    return combined_text_content, content_for_llm


def rag_search(query_for_embedding: str) -> str:
    """
    Perform RAG search using a truncated query for embedding and return relevant context.
    """
    # Truncate the query to ensure it's within the embedding model's limit (e.g., 2048 characters)
    # Using 2000 to be safe and leave some buffer.
    truncated_query = query_for_embedding[:2000] 

    embeddings = BedrockEmbeddings(model_id="amazon.titan-embed-text-v2:0")
    index_directory = "faiss_index"
    allow_dangerous = True # Be cautious with this in production environments

    try:
        db = FAISS.load_local(
            index_directory, embeddings, allow_dangerous_deserialization=allow_dangerous
        )
        # Perform similarity search with the truncated query
        docs = db.similarity_search(truncated_query, k=5) 
        rag_context = "\n\n".join(doc.page_content for doc in docs)
        return rag_context
    except Exception as e:
        st.error(f"Error during RAG search: {e}")
        return "" # Return empty string on error


def web_or_local(query_for_rag: str, web_local_rag: str) -> Tuple[str, bool]:
    """
    Processes the query for web search or RAG and returns the extracted context and a flag.
    This function should only take the *user's direct query* for context retrieval,
    not the full combined prompt.
    """
    has_context = False
    context_text = ""

    if web_local_rag == "Web":
        # Implement actual web search logic here if needed
        # For now, it's a placeholder
        st.warning("Web search functionality is not fully configured in this demo.")
        context_text = ""
        has_context = False
    elif web_local_rag == "RAG":
        context_text = rag_search(query_for_rag) # Pass only the direct query for RAG
        if context_text:
            context_text = f"Here are the RAG search results: \n\n<search>\n\n{context_text}\n\n</search>\n\n"
            has_context = True

    return context_text, has_context


def display_chat_messages(
    uploaded_files: List[st.runtime.uploaded_file_manager.UploadedFile] = None, # Make uploaded_files optional
    debug_mode: bool = False
) -> None:
    """
    Display chat messages and uploaded images in the Streamlit app.
    """
    # Ensure uploaded_files is an empty list if None, to prevent errors
    uploaded_files = uploaded_files if uploaded_files is not None else []

    for message in st.session_state.messages:
        with st.chat_message(message["role"]):
            if uploaded_files and "images" in message and message["images"]:
                display_images(message["images"], uploaded_files)

            if message["role"] == "user":
                display_user_message(message, debug_mode)

            if message["role"] == "assistant":
                display_assistant_message(message["content"])
                # Add download button if "Presales Pro" role is selected for assistant messages
                if st.session_state.get("selected_role") == "Presales Pro":
                    # Ensure the response content is a string for docx generation
                    response_text = message["llm_content"] if message.get("llm_content") else message["content"]
                    if isinstance(response_text, str):
                        docx_file_bytes = get_docx_bytes(response_text)
                        st.download_button(
                            label="Download Response as Word",
                            data=docx_file_bytes,
                            file_name=f"presales_response_{uuid.uuid4().hex[:8]}.docx",
                            mime="application/vnd.openxmlformats-officedocument.wordprocessingml.document",
                            key=f"download_button_{uuid.uuid4()}" # Use a unique key for each button
                        )
    # Add the anchor point here at the very end of the chat display
    st.markdown("<div id='bottom_anchor'></div>", unsafe_allow_html=True)


def main() -> None:
    """
    Main function to run the Streamlit app.
    """
    init_session_state()

    # Create a placeholder for the login UI.
    # This will hold the output of authenticator.login() and can be cleared later.
    login_ui_placeholder = st.empty()

    with login_ui_placeholder.container():
        # Attempt login. This function returns True if successful, False otherwise.
        # It also renders the login UI within this container.
        is_logged_in = authenticator.login()

    if not is_logged_in:
        # If not logged in, the login form is still visible within `login_ui_placeholder`.
        # We can add a message below it if needed.
        st.info("Please log in to access the chatbot.")
        st.stop() # Stop further execution of the main app content

    # If we reach here, the user is logged in.
    # Clear the login UI placeholder. This will remove the login form and any
    # direct outputs from authenticator.login() (like "ACTIVE") from the main area.
    login_ui_placeholder.empty()

    # Display the "Session Active" flag/message at the top of the main app area
    # st.success(f"Session Active! Welcome, {authenticator.get_username()}")

    st.session_state["user_id"] = authenticator.get_username()

    # Load user's chat sessions and ensure a current chat is selected/created
    load_user_chat_sessions()
    if not st.session_state.current_chat_id: # Check if current_chat_id is None or empty
        if st.session_state.user_chat_sessions:
            # If user has chats but none selected, select the first one
            st.session_state.current_chat_id = list(st.session_state.user_chat_sessions.keys())[0]
            load_chat_history(st.session_state.current_chat_id)
            # st.rerun() # Removed redundant rerun
        else:
            # If no chats at all, create a new one
            create_new_chat_session()
            return # Rerun after creating new chat

    # Load chat history for the current chat ID
    if st.session_state.current_chat_id:
        load_chat_history(st.session_state.current_chat_id)

    st.session_state["last_saved_message_hash"] = None # Reset hash after loading history

    # Render authentication details and model parameters in the sidebar
    model_kwargs, system_prompt, web_local, debug_mode = render_sidebar_auth_and_params()

    # --- Main Chat Application (only runs if logged in) ---
    chat_model = ChatModel(st.session_state["model_name"], st.session_state["model_kwargs"])
    runnable_with_messagehistory = init_runnablewithmessagehistory(
        system_prompt,
        chat_model,
        debug_mode # Pass debug_mode here
    )

    model_config = config["models"][st.session_state["model_name"]]
    image_upload_disabled = (
        True if model_config.get("input_format") == "text" else False
    )

    display_chat_messages(debug_mode=debug_mode) # Pass debug_mode

    # Add the scroll to bottom button here using an <a> tag and inline styles
    if st.session_state.messages: # Only show if there are messages to scroll through
        st.markdown(
            """
            <a href="#bottom_anchor" style="position: fixed; bottom: 120px; right: 20px; z-index: 101; text-decoration: none;">
                <button style="background-color: rgb(255, 68, 68); color: white; padding: 10px 15px; border-radius: 50%; border: none; cursor: pointer; font-size: 24px; width: 50px; height: 50px; display: flex; justify-content: center; align-items: center; box-shadow: 2px 2px 10px rgba(0, 0, 0, 0.3);">
                    &#x2193;
                </button>
            </a>
            """,
            unsafe_allow_html=True
        )

    # Use a container for the input form and apply custom CSS to make it sticky
    with st.container():
        st.markdown('<div class="fixed-bottom-container">', unsafe_allow_html=True) # Start of sticky container

        # --- File Uploader moved above the prompt input ---
        # Initialize uploaded_files here to ensure it's always defined
        uploaded_files = st.file_uploader(
            "Upload BOQ/Files",
            type=["jpg", "jpeg", "png", "txt", "pdf", "csv", "xlsx", "py"],
            accept_multiple_files=True,
            key=st.session_state["file_uploader_key"],
            disabled=image_upload_disabled,
            label_visibility="visible" # Make label visible if it's the main header
        )
        # --- End of File Uploader section ---

        with st.form("chat_form", clear_on_submit=True):
            # Now prompt and send button are in columns within the form
            col_prompt, col_send_button = st.columns([0.8, 0.2]) 
            with col_prompt:
                prompt = st.text_area(
                    "Your message",
                    placeholder="Enter your message here...",
                    key="chat_input",
                    label_visibility="collapsed",
                    height=100, # Adjust height as needed
                )
            with col_send_button:
                # Submit button for the form
                # Add some vertical spacing to align the button with the text area
                st.markdown("<div style='height: 3.5rem;'></div>", unsafe_allow_html=True) # Adjust height as needed
                submitted = st.form_submit_button("Send", type="primary", use_container_width=True)
        st.markdown('</div>', unsafe_allow_html=True) # End of sticky container


    message_images_list = [
        image_id
        for message in st.session_state.messages
        if message["role"] == "user" and "images" in message and message["images"]
        for image_id in message["images"]
    ]

    # --- IMPORTANT: Only proceed with generation if the form was explicitly submitted and there's a prompt ---
    if submitted and prompt:
        original_prompt = prompt
        
        # 1. Process uploaded files for LLM parts and their text content
        # uploaded_llm_parts will contain {"image": ...} dictionaries
        uploaded_text_content, uploaded_llm_parts = process_and_display_uploaded_files(
            uploaded_files, message_images_list
        )

        # 2. Get RAG/Web context using the original_prompt (not the full combined text)
        rag_or_web_context, has_context = web_or_local(original_prompt, st.session_state["web_local"])

        # 3. Assemble the full text prompt for the LLM
        # Priority: RAG/Web Context > Uploaded File Text > Original User Prompt
        assembled_llm_text_prompt = ""
        if rag_or_web_context:
            assembled_llm_text_prompt += rag_or_web_context + "\n\n"
        if uploaded_text_content:
            assembled_llm_text_prompt += uploaded_text_content + "\n\n"
        assembled_llm_text_prompt += original_prompt # Always include original prompt

        # Apply input guardrails to the *final assembled text prompt*
        is_flagged_input, reason_input, moderated_final_text_prompt = app_guardrails.apply_input_guardrails(assembled_llm_text_prompt)

        if is_flagged_input:
            st.error(f"Your input was flagged: {reason_input}. Please modify your query.")
            store_message("user", original_prompt, user_prompt=original_prompt, has_context=False)
            store_message("assistant", f"I cannot process your request because it {reason_input}. Please try a different query.")
            st.rerun() # Rerun to clear the input field and prevent re-triggering
            return

        # 4. Construct the content list for a single HumanMessage
        final_llm_input_content_list = []
        if uploaded_llm_parts:
            # Add images (which are already structured as {"image": ...})
            final_llm_input_content_list.extend(uploaded_llm_parts)
        
        # Add the final assembled text prompt as a text part
        final_llm_input_content_list.append({"type": "text", "text": moderated_final_text_prompt})

        with st.chat_message("user"):
            temp_message = {
                "content": moderated_final_text_prompt, # Store the full text sent to LLM
                "user_prompt": original_prompt, # Store the original user prompt
                "has_context": has_context,
                "images": message_images_list + [file.file_id for file in uploaded_files if file.type.startswith("image/")] # Add new image IDs
            }
            display_user_message(temp_message, debug_mode)

        # Store the user message. The content stored is the full text sent to LLM.
        # For display and history, we can still use the `moderated_final_text_prompt`
        # as the primary content if it's mostly text, or a representation of multimodal.
        # The actual LLM input is `final_llm_input_content_list`.
        store_message("user", moderated_final_text_prompt, user_prompt=original_prompt, has_context=has_context, images=temp_message["images"])


        with st.chat_message("assistant"):
            # Pass the list of content parts to generate_response
            response = generate_response(
                runnable_with_messagehistory,
                final_llm_input_content_list # This is now a list of content parts for the message
            )
            # Display the response
            st.markdown(response)
            store_message("assistant", response)

            # Check if the "Presales Pro" role is selected and offer download
            if st.session_state.get("selected_role") == "Presales Pro":
                docx_file_bytes = get_docx_bytes(response)
                st.download_button(
                    label="Download Response as Word",
                    data=docx_file_bytes,
                    file_name=f"presales_response_{uuid.uuid4().hex[:8]}.docx", # Unique filename
                    mime="application/vnd.openxmlformats-officedocument.wordprocessingml.document",
                    key=f"download_response_doc_{uuid.uuid4()}" # Ensure unique key for the button
                )
        # After successful response generation, rerun to clear the input field and refresh the state
        # This will prevent the "if submitted and prompt" from being true on subsequent, unrelated reruns.
        # The `clear_on_submit=True` on the form handles clearing the prompt.
        st.session_state["file_uploader_key"] = random.randint(1, 1000000) # Reset file uploader to clear selected files
        st.rerun()


    # The auto-scroll on load is still there:
    st.markdown(
        """
    <script>
        // Initial scroll on page load
        function scroll_to_bottom_initial() {
            var elements = document.getElementsByClassName('main');
            if (elements.length > 0) {
                elements[0].scrollTop = elements[0].scrollHeight;
            }
        }
        scroll_to_bottom_initial();
    </script>
    """,
        unsafe_allow_html=True,
    )


if __name__ == "__main__":
    main()
