# auth.py
from supabase import create_client

SUPABASE_URL = "https://eudczjcezpcdkqlpwewo.supabase.co"
SUPABASE_KEY = "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6ImV1ZGN6amNlenBjZGtxbHB3ZXdvIiwicm9sZSI6ImFub24iLCJpYXQiOjE3NDkwMTc2NTcsImV4cCI6MjA2NDU5MzY1N30.j5AeB1QmbMrtbeinXeI8SRQKCuXKJvwm9JW2bCPRecg"

supabase = create_client(SUPABASE_URL, SUPABASE_KEY)

def login(email, password):
    return supabase.auth.sign_in_with_password({"email": email, "password": password})

def sign_up(email, password):
    return supabase.auth.sign_up({"email": email, "password": password})

def get_user_role(email):
    data = supabase.table("profiles").select("role").eq("email", email).execute()
    return data.data[0]["role"] if data.data else None
