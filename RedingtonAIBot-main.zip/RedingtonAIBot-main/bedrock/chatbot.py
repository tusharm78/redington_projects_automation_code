# chatbot.py
import streamlit as st
from auth import login, get_user_role

# Streamlit login UI
email = st.text_input("Email")
password = st.text_input("Password", type="password")

if st.button("Login"):
    try:
        user = login(email, password)
        st.session_state.logged_in = True
        st.session_state.user_email = email
        st.session_state.role = get_user_role(email)
        st.success(f"Logged in as {email} with role {st.session_state.role}")
    except Exception as e:
        st.error(f"Login failed: {e}")
