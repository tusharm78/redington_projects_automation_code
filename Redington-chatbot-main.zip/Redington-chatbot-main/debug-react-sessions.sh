#!/bin/bash

echo "🔍 Debugging React Frontend Session Loading"
echo "==========================================="
echo ""

# Check if both servers are running
echo "🌐 Server Status Check:"
FRONTEND_PID=$(ps aux | grep 'react-scripts start' | grep -v grep | awk '{print $2}')
BACKEND_PID=$(ps aux | grep 'uvicorn main:app' | grep -v grep | awk '{print $2}')

if [ -n "$FRONTEND_PID" ]; then
    echo "✅ Frontend running (PID: $FRONTEND_PID)"
else
    echo "❌ Frontend not running"
fi

if [ -n "$BACKEND_PID" ]; then
    echo "✅ Backend running (PID: $BACKEND_PID)"
else
    echo "❌ Backend not running"
fi
echo ""

# Test backend API directly
echo "🔧 Backend API Test:"
echo "Getting auth token..."
TOKEN=$(curl -s -X POST "http://localhost:8000/api/v1/auth/login" \
  -H "Content-Type: application/json" \
  -d '{"username":"tanmay","password":"Admin@123$"}' | jq -r '.access_token')

if [ "$TOKEN" != "null" ] && [ -n "$TOKEN" ]; then
    echo "✅ Authentication successful"
    echo "Token: ${TOKEN:0:30}..."
    
    echo ""
    echo "Testing sessions endpoint..."
    SESSIONS_RESPONSE=$(curl -s -X GET "http://localhost:8000/api/v1/sessions/" \
      -H "Authorization: Bearer $TOKEN")
    
    SESSION_COUNT=$(echo "$SESSIONS_RESPONSE" | jq '. | length' 2>/dev/null)
    
    if [ "$SESSION_COUNT" -gt 0 ]; then
        echo "✅ Sessions API working - Found $SESSION_COUNT sessions"
        echo "📝 Sample sessions:"
        echo "$SESSIONS_RESPONSE" | jq -r 'to_entries | .[:3] | .[] | "  • \(.key): \(.value)"' 2>/dev/null
    else
        echo "❌ Sessions API error or no sessions found"
        echo "Response: $SESSIONS_RESPONSE"
    fi
else
    echo "❌ Authentication failed"
    exit 1
fi
echo ""

# Test frontend accessibility
echo "🌐 Frontend Accessibility Test:"
if curl -s "http://localhost:3000" > /dev/null 2>&1; then
    echo "✅ Frontend accessible at http://localhost:3000"
else
    echo "❌ Frontend not accessible"
fi
echo ""

# Check React app environment
echo "🔧 React App Configuration:"
echo "Expected API URL: ${REACT_APP_API_URL:-http://localhost:8000/api/v1}"
echo ""

# Instructions for manual testing
echo "🧪 Manual Testing Instructions:"
echo "==============================="
echo ""
echo "1. Open browser and go to: http://localhost:3000"
echo "2. Login with: tanmay / Admin@123$"
echo "3. Open browser DevTools (F12) and go to Console tab"
echo "4. Click the hamburger menu (☰) to open sidebar"
echo "5. Look for debug info showing:"
echo "   - User: tanmay"
echo "   - Sessions: (should show number > 0)"
echo "   - Loading: No"
echo "   - Token: Present"
echo "6. Click the 'Refresh' button and watch console logs"
echo "7. Look for these console messages:"
echo "   - 🔍 Loading conversation history for user: tanmay"
echo "   - 🔑 Auth token exists: true"
echo "   - 📡 Fetching sessions from API..."
echo "   - ✅ Sessions received: {...}"
echo "   - 📊 Number of sessions: X"
echo ""
echo "🐛 If sessions don't load, check for:"
echo "• Network errors in DevTools Network tab"
echo "• CORS errors in console"
echo "• 401/403 authentication errors"
echo "• API endpoint mismatches"
echo ""
echo "🔍 Common Issues & Solutions:"
echo "• No sessions showing: Check if 'Sessions: 0' in debug info"
echo "• Authentication errors: Check if 'Token: Missing' in debug info"
echo "• Network errors: Verify backend is running on port 8000"
echo "• CORS errors: Check backend CORS configuration"
echo ""
echo "📊 Current Status Summary:"
echo "========================="
echo "Backend Sessions Available: $SESSION_COUNT"
echo "Frontend URL: http://localhost:3000"
echo "Backend URL: http://localhost:8000"
echo "Authentication: Working"
echo "Sessions API: Working"
echo ""
echo "🎯 The issue is likely in the React frontend's session loading logic."
echo "Use the browser DevTools to see exactly what's happening!"
