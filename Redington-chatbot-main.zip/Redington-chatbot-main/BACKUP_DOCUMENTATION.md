# Redington AI Bot - Complete Application Backup

**Backup Created**: July 4, 2025 - 10:44:49 UTC
**Backup Location**: `/home/meenal/redington-chatbot-backup-20250704_104449/`

## 📋 **Backup Contents**

### **Application Structure**
```
redington-chatbot-backup/
├── backend/                    # FastAPI Backend
│   ├── enhanced_bedrock_main.py      # Main enhanced backend with Cognito
│   ├── bedrock_streaming_main.py     # Bedrock streaming backend
│   ├── cognito_auth.py               # AWS Cognito authentication
│   ├── session_manager.py            # DynamoDB session management
│   ├── .env                          # Environment configuration
│   ├── requirements.txt              # Python dependencies
│   └── start_enhanced_cognito.sh     # Enhanced backend startup script
├── frontend/                   # React Frontend
│   ├── src/                          # React source code
│   ├── public/                       # Static assets
│   ├── package.json                  # Node.js dependencies
│   └── build/                        # Production build
├── README.md                   # Main documentation
└── Various utility scripts and documentation
```

## 🔧 **System Configuration**

### **Backend Configuration**
- **Framework**: FastAPI 0.104.1
- **Python Version**: 3.x
- **AI Model**: AWS Bedrock Claude 3.7 Sonnet
- **Authentication**: AWS Cognito + Demo fallback
- **Session Storage**: DynamoDB (with memory fallback)
- **Region**: ap-south-1

### **Frontend Configuration**
- **Framework**: React 18.x with TypeScript
- **UI Library**: Material-UI
- **Build Tool**: Create React App
- **Styling**: Custom CSS with Redington branding

### **AWS Services**
- **Bedrock**: Claude 3.7 Sonnet model
- **Cognito**: User pool authentication
- **DynamoDB**: Session and chat history storage
- **Region**: ap-south-1 (Mumbai)

## 🔐 **Authentication Details**

### **Cognito Configuration**
```
Pool ID: ap-south-1_dN18SVYgM
Client ID: 2sscckqddj6vi5ue5big66jefb
Region: ap-south-1
Auth Flow: USER_PASSWORD_AUTH
```

### **Confirmed Users**
- syed (CONFIRMED)
- tanmay (CONFIRMED)
- meenal (CONFIRMED)
- rahuraman (CONFIRMED)

### **Demo Fallback Users**
- demo / demo123
- admin / admin123
- user / password

## 🚀 **Deployment Instructions**

### **Prerequisites**
1. **Python 3.8+** with pip
2. **Node.js 16+** with npm
3. **AWS CLI** configured
4. **AWS Bedrock** access enabled
5. **AWS Cognito** user pool configured

### **Backend Setup**
```bash
cd backend/
python3 -m venv venv
source venv/bin/activate
pip install -r requirements.txt
./start_enhanced_cognito.sh
```

### **Frontend Setup**
```bash
cd frontend/
npm install
npm start
```

### **Environment Variables**
Update `backend/.env` with your AWS configuration:
```env
AWS_DEFAULT_REGION=ap-south-1
POOL_ID=your-cognito-pool-id
APP_CLIENT_ID=your-cognito-client-id
APP_CLIENT_SECRET=your-cognito-client-secret
DYNAMODB_TABLE_NAME=chatbot-conversations
```

## 🎯 **Key Features**

### **AI Capabilities**
- ✅ Real AWS Bedrock Claude 3.7 Sonnet integration
- ✅ Professional Presales Pro proposal format
- ✅ Streaming responses with natural chunking
- ✅ Context-aware conversations

### **Authentication & Security**
- ✅ AWS Cognito integration
- ✅ JWT token management
- ✅ User-specific session isolation
- ✅ Secure API endpoints

### **Session Management**
- ✅ Persistent chat history
- ✅ DynamoDB storage with memory fallback
- ✅ Session creation, update, deletion
- ✅ Cross-session conversation switching

### **User Interface**
- ✅ Modern React interface with Material-UI
- ✅ Responsive design for desktop and mobile
- ✅ Real-time streaming display
- ✅ Side panel session management
- ✅ Redington branding and theming

## 📊 **System Status at Backup**

### **Backend Status**
- Service: redington-enhanced-bedrock-cognito
- Bedrock Status: connected
- Model: us.anthropic.claude-3-7-sonnet-20250219-v1:0
- Cognito: configured and working
- DynamoDB: fallback mode (memory storage)

### **Active Sessions**
- Total Sessions: 6
- Authentication: Working with both Cognito and demo users
- Chat History: Fully functional
- Message Persistence: Working

## 🔄 **Restore Instructions**

### **Quick Restore**
1. Copy backup to desired location
2. Navigate to backend directory
3. Run: `./start_enhanced_cognito.sh`
4. Navigate to frontend directory
5. Run: `npm install && npm start`
6. Access: http://localhost:3000

### **Production Deployment**
1. Set up AWS services (Cognito, DynamoDB, Bedrock)
2. Update environment variables
3. Build frontend: `npm run build`
4. Deploy backend to AWS ECS/Lambda
5. Deploy frontend to S3/CloudFront

## 🧪 **Testing**

### **Authentication Test**
```bash
curl -X POST http://localhost:8000/api/v1/auth/login \
  -H "Content-Type: application/json" \
  -d '{"username": "demo", "password": "demo123"}'
```

### **Health Check**
```bash
curl http://localhost:8000/health
```

### **Frontend Access**
- URL: http://localhost:3000
- Login: demo / demo123 (or Cognito users)

## 📝 **Important Notes**

### **Security Considerations**
- Environment variables contain sensitive information
- Cognito client secret should be rotated regularly
- DynamoDB table should be created for production use
- CORS origins should be restricted in production

### **Performance Optimizations**
- Frontend build should be used for production
- Backend should use production WSGI server (Gunicorn/Uvicorn)
- CDN should be used for static assets
- Database connections should be pooled

### **Monitoring & Logging**
- Backend logs available in enhanced_cognito.log
- Frontend logs in browser console
- AWS CloudWatch for production monitoring
- Error tracking should be implemented

## 🆘 **Troubleshooting**

### **Common Issues**
1. **Port conflicts**: Kill processes on ports 3000/8000
2. **AWS credentials**: Ensure AWS CLI is configured
3. **Cognito errors**: Check region and client configuration
4. **DynamoDB access**: Verify IAM permissions
5. **Node modules**: Delete node_modules and reinstall

### **Support Contacts**
- Technical Issues: Check logs and error messages
- AWS Issues: Verify service configurations
- Authentication: Check Cognito user pool status

---

**This backup contains the complete, working Redington AI Bot application with all features, configurations, and documentation needed for restoration and deployment.**
