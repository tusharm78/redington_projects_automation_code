#!/usr/bin/env python3
"""
Comprehensive Data Migration Solution for Redington Chatbot
===========================================================

This script addresses the data inconsistency issue where users' chat history
is stored in different DynamoDB tables (chat_history vs user_chat_sessions).

Issues Identified:
1. Some users have data only in user_chat_sessions table (akhil, ajit, etc.)
2. Some users have data only in chat_history table (admin, rahuraman)
3. Some users have data in both tables (meenal, tanmay)
4. Backend logic inconsistency causing this split storage

Solution:
1. Migrate all chat data to the primary chat_history table
2. Standardize data format and structure
3. Preserve conversation continuity
4. Clean up duplicate entries
5. Provide backend code fixes
"""

import boto3
import json
from datetime import datetime
from typing import Dict, List, Any
import uuid

class ChatDataMigrator:
    def __init__(self, region='us-east-1'):
        self.dynamodb = boto3.client('dynamodb', region_name=region)
        self.region = region
        
    def scan_table(self, table_name: str) -> List[Dict]:
        """Scan entire table and return all items"""
        try:
            response = self.dynamodb.scan(TableName=table_name)
            items = response.get('Items', [])
            
            # Handle pagination
            while 'LastEvaluatedKey' in response:
                response = self.dynamodb.scan(
                    TableName=table_name,
                    ExclusiveStartKey=response['LastEvaluatedKey']
                )
                items.extend(response.get('Items', []))
            
            return items
        except Exception as e:
            print(f"Error scanning table {table_name}: {e}")
            return []
    
    def convert_dynamodb_to_dict(self, item: Dict) -> Dict:
        """Convert DynamoDB item format to regular dict"""
        result = {}
        for key, value in item.items():
            if 'S' in value:
                result[key] = value['S']
            elif 'N' in value:
                result[key] = float(value['N']) if '.' in value['N'] else int(value['N'])
            elif 'L' in value:
                result[key] = [self.convert_dynamodb_to_dict({'item': v})['item'] for v in value['L']]
            elif 'M' in value:
                result[key] = self.convert_dynamodb_to_dict(value['M'])
            elif 'BOOL' in value:
                result[key] = value['BOOL']
            else:
                result[key] = value
        return result
    
    def convert_dict_to_dynamodb(self, item: Dict) -> Dict:
        """Convert regular dict to DynamoDB item format"""
        result = {}
        for key, value in item.items():
            if isinstance(value, str):
                result[key] = {'S': value}
            elif isinstance(value, (int, float)):
                result[key] = {'N': str(value)}
            elif isinstance(value, bool):
                result[key] = {'BOOL': value}
            elif isinstance(value, list):
                result[key] = {'L': [self.convert_dict_to_dynamodb({'item': v})['item'] for v in value]}
            elif isinstance(value, dict):
                result[key] = {'M': self.convert_dict_to_dynamodb(value)}
            else:
                result[key] = {'S': str(value)}
        return result
    
    def analyze_data_inconsistency(self):
        """Analyze the current data inconsistency"""
        print("=== ANALYZING DATA INCONSISTENCY ===")
        
        # Get data from both tables
        chat_history_data = self.scan_table('chat_history')
        user_chat_sessions_data = self.scan_table('user_chat_sessions')
        
        # Extract user IDs
        chat_history_users = set()
        user_chat_sessions_users = set()
        
        for item in chat_history_data:
            if 'user_id' in item:
                chat_history_users.add(item['user_id']['S'])
        
        for item in user_chat_sessions_data:
            if 'user_id' in item:
                user_chat_sessions_users.add(item['user_id']['S'])
        
        # Analyze overlaps
        only_in_chat_history = chat_history_users - user_chat_sessions_users
        only_in_user_chat_sessions = user_chat_sessions_users - chat_history_users
        in_both_tables = chat_history_users & user_chat_sessions_users
        
        print(f"Users only in chat_history: {sorted(only_in_chat_history)}")
        print(f"Users only in user_chat_sessions: {sorted(only_in_user_chat_sessions)}")
        print(f"Users in both tables: {sorted(in_both_tables)}")
        
        return {
            'chat_history_data': chat_history_data,
            'user_chat_sessions_data': user_chat_sessions_data,
            'only_in_chat_history': only_in_chat_history,
            'only_in_user_chat_sessions': only_in_user_chat_sessions,
            'in_both_tables': in_both_tables
        }
    
    def create_migration_plan(self, analysis_result: Dict):
        """Create detailed migration plan"""
        print("\n=== CREATING MIGRATION PLAN ===")
        
        migration_plan = {
            'migrate_from_user_chat_sessions': [],
            'deduplicate_users': [],
            'preserve_existing': []
        }
        
        # Users to migrate from user_chat_sessions to chat_history
        for user_id in analysis_result['only_in_user_chat_sessions']:
            user_data = [item for item in analysis_result['user_chat_sessions_data'] 
                        if item.get('user_id', {}).get('S') == user_id]
            migration_plan['migrate_from_user_chat_sessions'].append({
                'user_id': user_id,
                'record_count': len(user_data),
                'data': user_data
            })
        
        # Users with data in both tables (need deduplication)
        for user_id in analysis_result['in_both_tables']:
            chat_history_data = [item for item in analysis_result['chat_history_data'] 
                               if item.get('user_id', {}).get('S') == user_id]
            user_sessions_data = [item for item in analysis_result['user_chat_sessions_data'] 
                                if item.get('user_id', {}).get('S') == user_id]
            
            migration_plan['deduplicate_users'].append({
                'user_id': user_id,
                'chat_history_count': len(chat_history_data),
                'user_sessions_count': len(user_sessions_data),
                'chat_history_data': chat_history_data,
                'user_sessions_data': user_sessions_data
            })
        
        # Users to preserve (already in chat_history only)
        for user_id in analysis_result['only_in_chat_history']:
            migration_plan['preserve_existing'].append(user_id)
        
        return migration_plan
    
    def execute_migration(self, migration_plan: Dict, dry_run: bool = True):
        """Execute the migration plan"""
        print(f"\n=== {'DRY RUN' if dry_run else 'EXECUTING'} MIGRATION ===")
        
        migration_results = {
            'migrated_users': [],
            'deduplicated_users': [],
            'errors': []
        }
        
        # Migrate users from user_chat_sessions to chat_history
        for user_migration in migration_plan['migrate_from_user_chat_sessions']:
            user_id = user_migration['user_id']
            print(f"\nMigrating user: {user_id} ({user_migration['record_count']} records)")
            
            try:
                for record in user_migration['data']:
                    # Convert user_chat_sessions format to chat_history format
                    migrated_record = self.convert_user_session_to_chat_history(record)
                    
                    if not dry_run:
                        # Insert into chat_history table
                        self.dynamodb.put_item(
                            TableName='chat_history',
                            Item=migrated_record
                        )
                    
                    print(f"  {'Would migrate' if dry_run else 'Migrated'} record: {migrated_record.get('conversation_id', {}).get('S', 'N/A')}")
                
                migration_results['migrated_users'].append(user_id)
                
            except Exception as e:
                error_msg = f"Error migrating user {user_id}: {e}"
                print(f"  ERROR: {error_msg}")
                migration_results['errors'].append(error_msg)
        
        # Handle users with data in both tables
        for user_dedup in migration_plan['deduplicate_users']:
            user_id = user_dedup['user_id']
            print(f"\nDeduplicating user: {user_id}")
            print(f"  Chat history records: {user_dedup['chat_history_count']}")
            print(f"  User sessions records: {user_dedup['user_sessions_count']}")
            
            try:
                # Strategy: Keep chat_history data, migrate unique user_sessions data
                existing_conversations = set()
                for record in user_dedup['chat_history_data']:
                    conv_id = record.get('conversation_id', {}).get('S')
                    if conv_id:
                        existing_conversations.add(conv_id)
                
                # Migrate unique conversations from user_sessions
                for record in user_dedup['user_sessions_data']:
                    migrated_record = self.convert_user_session_to_chat_history(record)
                    conv_id = migrated_record.get('conversation_id', {}).get('S')
                    
                    if conv_id not in existing_conversations:
                        if not dry_run:
                            self.dynamodb.put_item(
                                TableName='chat_history',
                                Item=migrated_record
                            )
                        print(f"  {'Would migrate' if dry_run else 'Migrated'} unique conversation: {conv_id}")
                    else:
                        print(f"  Skipped duplicate conversation: {conv_id}")
                
                migration_results['deduplicated_users'].append(user_id)
                
            except Exception as e:
                error_msg = f"Error deduplicating user {user_id}: {e}"
                print(f"  ERROR: {error_msg}")
                migration_results['errors'].append(error_msg)
        
        return migration_results
    
    def convert_user_session_to_chat_history(self, user_session_record: Dict) -> Dict:
        """Convert user_chat_sessions record format to chat_history format"""
        # Extract data from user_session_record
        user_id = user_session_record.get('user_id', {}).get('S', '')
        
        # Use chat_id from user_chat_sessions as chat_message_id for chat_history
        chat_message_id = user_session_record.get('chat_id', {}).get('S')
        if not chat_message_id:
            chat_message_id = str(uuid.uuid4())
        
        # Generate conversation_id if not present
        conversation_id = user_session_record.get('conversation_id', {}).get('S')
        if not conversation_id:
            conversation_id = user_session_record.get('session_id', {}).get('S', str(uuid.uuid4()))
        
        # Create chat_history format record with required keys
        chat_history_record = {
            'user_id': {'S': user_id},
            'chat_message_id': {'S': chat_message_id},  # Required range key
            'conversation_id': {'S': conversation_id},
            'timestamp': user_session_record.get('timestamp', {'S': datetime.now().isoformat()}),
            'message': user_session_record.get('message', {'S': ''}),
            'response': user_session_record.get('response', {'S': ''}),
            'model': user_session_record.get('model', {'S': 'Claude 3.7 Sonnet'}),
            'session_id': user_session_record.get('session_id', {'S': conversation_id})
        }
        
        # Copy any additional fields (except chat_id which is now chat_message_id)
        for key, value in user_session_record.items():
            if key not in chat_history_record and key != 'chat_id':
                chat_history_record[key] = value
        
        return chat_history_record
    
    def cleanup_user_chat_sessions(self, migrated_users: List[str], dry_run: bool = True):
        """Clean up migrated data from user_chat_sessions table"""
        print(f"\n=== {'DRY RUN' if dry_run else 'EXECUTING'} CLEANUP ===")
        
        for user_id in migrated_users:
            print(f"{'Would clean up' if dry_run else 'Cleaning up'} user_chat_sessions data for: {user_id}")
            
            if not dry_run:
                # Query and delete all records for this user
                try:
                    response = self.dynamodb.query(
                        TableName='user_chat_sessions',
                        KeyConditionExpression='user_id = :user_id',
                        ExpressionAttributeValues={':user_id': {'S': user_id}}
                    )
                    
                    for item in response.get('Items', []):
                        # Delete each item
                        key = {k: v for k, v in item.items() if k in ['user_id', 'session_id']}  # Adjust based on table schema
                        self.dynamodb.delete_item(
                            TableName='user_chat_sessions',
                            Key=key
                        )
                        
                except Exception as e:
                    print(f"  Error cleaning up user {user_id}: {e}")

def main():
    """Main migration execution"""
    print("REDINGTON CHATBOT DATA MIGRATION TOOL")
    print("=====================================")
    
    migrator = ChatDataMigrator()
    
    # Step 1: Analyze current data inconsistency
    analysis = migrator.analyze_data_inconsistency()
    
    # Step 2: Create migration plan
    plan = migrator.create_migration_plan(analysis)
    
    print(f"\nMIGRATION SUMMARY:")
    print(f"- Users to migrate: {len(plan['migrate_from_user_chat_sessions'])}")
    print(f"- Users to deduplicate: {len(plan['deduplicate_users'])}")
    print(f"- Users to preserve: {len(plan['preserve_existing'])}")
    
    # Step 3: Execute dry run first
    print("\n" + "="*50)
    print("EXECUTING DRY RUN...")
    results = migrator.execute_migration(plan, dry_run=True)
    
    # Step 4: Ask for confirmation for actual migration
    print("\n" + "="*50)
    print("DRY RUN COMPLETED!")
    print(f"Ready to migrate {len(results['migrated_users'])} users")
    print(f"Ready to deduplicate {len(results['deduplicated_users'])} users")
    
    if results['errors']:
        print(f"ERRORS FOUND: {len(results['errors'])}")
        for error in results['errors']:
            print(f"  - {error}")
        print("\nPlease fix errors before proceeding with actual migration.")
        return
    
    # Execute actual migration
    print("\nPROCEEDING WITH ACTUAL MIGRATION...")
    print("EXECUTING ACTUAL MIGRATION...")
    actual_results = migrator.execute_migration(plan, dry_run=False)
    
    if not actual_results['errors']:
        print("MIGRATION COMPLETED SUCCESSFULLY!")
        print(f"✅ Migrated {len(actual_results['migrated_users'])} users successfully")
        print(f"✅ Deduplicated {len(actual_results['deduplicated_users'])} users successfully")
        print("\nMigrated users:", actual_results['migrated_users'])
        print("Deduplicated users:", actual_results['deduplicated_users'])
        
        # Note: Keeping user_chat_sessions data for safety - can be cleaned up later
        print("\nNOTE: Original data in user_chat_sessions table preserved for safety.")
        print("You can clean it up later after confirming migration success.")
    else:
        print("MIGRATION COMPLETED WITH ERRORS:")
        for error in actual_results['errors']:
            print(f"  - {error}")

if __name__ == "__main__":
    main()
