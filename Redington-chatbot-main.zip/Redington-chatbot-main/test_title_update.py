#!/usr/bin/env python3
"""
Test script to check title update issue
"""

import boto3
import json
from boto3.dynamodb.conditions import Key

def check_title_consistency():
    """Check if title fields are consistent"""
    
    print("🔍 Checking Title Update Consistency")
    print("=" * 40)
    
    try:
        # Connect to DynamoDB
        dynamodb = boto3.resource("dynamodb", region_name="us-east-1")
        table = dynamodb.Table("user_chat_sessions")
        
        print("✅ Connected to DynamoDB")
        
        # Get all sessions
        response = table.scan()
        items = response.get('Items', [])
        
        sessions = []
        for item in items:
            chat_id = item.get('chat_id', '')
            if chat_id.startswith('SESSION#'):
                sessions.append(item)
        
        print(f"📊 Found {len(sessions)} sessions")
        print()
        
        # Check title consistency
        inconsistent_sessions = []
        
        for session in sessions:
            session_id = session.get('session_id', 'unknown')
            user_id = session.get('user_id', 'unknown')
            direct_title = session.get('title', '')
            
            if 'session_data' in session:
                try:
                    session_data = json.loads(session['session_data'])
                    json_title = session_data.get('title', '')
                    
                    print(f"Session: {session_id} (User: {user_id})")
                    print(f"  Direct title field: '{direct_title}'")
                    print(f"  JSON title field:   '{json_title}'")
                    
                    if direct_title != json_title:
                        print(f"  ⚠️  INCONSISTENT TITLES!")
                        inconsistent_sessions.append({
                            'session_id': session_id,
                            'user_id': user_id,
                            'direct_title': direct_title,
                            'json_title': json_title
                        })
                    else:
                        print(f"  ✅ Titles are consistent")
                    print()
                    
                except json.JSONDecodeError:
                    print(f"  ❌ Invalid JSON in session_data")
                    print()
            else:
                print(f"Session: {session_id} (User: {user_id})")
                print(f"  Direct title field: '{direct_title}'")
                print(f"  No session_data JSON field")
                print()
        
        if inconsistent_sessions:
            print(f"⚠️  Found {len(inconsistent_sessions)} sessions with inconsistent titles")
            print("This explains why title updates don't persist!")
            return inconsistent_sessions
        else:
            print("✅ All sessions have consistent titles")
            return []
            
    except Exception as e:
        print(f"❌ Error: {e}")
        return None

if __name__ == "__main__":
    result = check_title_consistency()
    
    if result:
        print("\n🔧 ISSUE IDENTIFIED:")
        print("   Title updates only modify the direct 'title' field")
        print("   But session retrieval prioritizes the 'session_data' JSON field")
        print("   This causes title updates to not persist after refresh")
        print("\n💡 SOLUTION:")
        print("   Update both the 'title' field AND the 'session_data' JSON field")
