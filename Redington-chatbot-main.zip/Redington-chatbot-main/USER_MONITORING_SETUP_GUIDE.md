# User Monitoring System Setup Guide

This guide will help you implement the user activity monitoring system for your Redington AI Bot.

## 🎯 Overview

The user monitoring system provides:
- **Real-time tracking** of logged-in users
- **Admin dashboard** to view active users
- **Session management** with activity tracking
- **User statistics** and analytics
- **Force logout** capabilities for admins

## 📋 Prerequisites

- AWS CLI configured with appropriate permissions
- DynamoDB access
- Python 3.8+ and Node.js 16+
- Existing Redington AI Bot setup

## 🚀 Installation Steps

### Step 1: Database Setup

1. **Run the database setup script:**
   ```bash
   cd backend
   python setup_user_monitoring_db.py
   ```

2. **Verify table creation:**
   - Check AWS Console → DynamoDB → Tables
   - Confirm `user_active_sessions` table exists
   - TTL should be enabled on `ttl` attribute

### Step 2: Backend Integration

1. **Install new dependencies (if needed):**
   ```bash
   cd backend
   pip install boto3 python-jose[cryptography] python-multipart
   ```

2. **Replace the main backend file:**
   ```bash
   # Backup current file
   cp enhanced_bedrock_main.py enhanced_bedrock_main.py.backup
   
   # Use the new version with monitoring
   cp enhanced_bedrock_main_with_monitoring.py enhanced_bedrock_main.py
   ```

3. **Configure admin users:**
   Edit `backend/admin_routes.py` and update the `ADMIN_USERS` list:
   ```python
   ADMIN_USERS = [
       "admin",
       "administrator", 
       "redington_admin",
       "your_admin_username",  # Add your admin usernames here
   ]
   ```

4. **Update environment variables:**
   Ensure your `.env` file has all required variables:
   ```env
   AWS_DEFAULT_REGION=us-east-1
   POOL_ID=your-cognito-pool-id
   APP_CLIENT_ID=your-cognito-client-id
   APP_CLIENT_SECRET=your-cognito-client-secret
   SECRET_KEY=your-jwt-secret-key
   ALLOWED_ORIGINS=["http://localhost:3000"]
   ```

### Step 3: Frontend Integration

1. **Update the main App component:**
   ```bash
   cd frontend/src
   
   # Backup current App.tsx
   cp App.tsx App.tsx.backup
   
   # Use the new version with admin dashboard
   cp components/AppWithAdminDashboard.tsx App.tsx
   ```

2. **Install new dependencies (if needed):**
   ```bash
   cd frontend
   npm install @mui/icons-material
   ```

3. **Update admin users list in frontend:**
   Edit the `ADMIN_USERS` array in `App.tsx` to match your backend configuration.

### Step 4: Start the System

1. **Start the backend:**
   ```bash
   cd backend
   python enhanced_bedrock_main.py
   ```

2. **Start the frontend:**
   ```bash
   cd frontend
   npm start
   ```

## 🔧 Configuration

### Admin User Configuration

To make a user an admin, add their username to both:

1. **Backend** (`backend/admin_routes.py`):
   ```python
   ADMIN_USERS = [
       "admin",
       "your_username",  # Add here
   ]
   ```

2. **Frontend** (`frontend/src/App.tsx`):
   ```typescript
   const ADMIN_USERS = [
     'admin',
     'your_username',  // Add here
   ];
   ```

### Database Configuration

The system uses DynamoDB with the following tables:

- **`user_active_sessions`**: Tracks active user sessions
  - Primary Key: `username` (String)
  - TTL: 24 hours (automatic cleanup)
  - Billing: Pay-per-request

- **`user_chat_sessions`**: Existing chat sessions (unchanged)

## 📊 Features

### Admin Dashboard

Accessible to admin users only, provides:

1. **Statistics Cards:**
   - Total active users
   - Total sessions today
   - Average session duration
   - Most active user

2. **Active Users Table:**
   - Username and email
   - Login and last activity times
   - Session duration
   - Chat sessions and messages count
   - User status

3. **Admin Actions:**
   - View detailed user information
   - Force logout specific users
   - Cleanup inactive sessions
   - Real-time refresh (auto-updates every 30 seconds)

### User Activity Tracking

The system automatically tracks:
- User login/logout events
- Last activity timestamps
- Chat message counts
- Session creation counts
- Session duration

### API Endpoints

New admin-only endpoints:

- `GET /api/v1/admin/active-users` - Get active users list
- `GET /api/v1/admin/user-details/{username}` - Get user session details
- `GET /api/v1/admin/stats` - Get comprehensive statistics
- `POST /api/v1/admin/force-logout/{username}` - Force user logout
- `POST /api/v1/admin/cleanup-sessions` - Cleanup inactive sessions
- `GET /api/v1/admin/system-health` - Get system health info

## 🔐 Security

### Access Control

- Admin endpoints require valid JWT token
- Username must be in `ADMIN_USERS` list
- All admin actions are logged
- Session data is encrypted in transit

### Data Privacy

- User session data includes only necessary information
- Automatic cleanup after 24 hours (TTL)
- No sensitive personal data stored
- IP addresses and user agents for security only

## 🚨 Troubleshooting

### Common Issues

1. **"Access denied: Admin privileges required"**
   - Ensure your username is in the `ADMIN_USERS` list
   - Check both backend and frontend configurations

2. **"DynamoDB table not accessible"**
   - Run the database setup script
   - Check AWS credentials and permissions
   - Verify table exists in AWS Console

3. **Admin dashboard not showing**
   - Ensure you're logged in as an admin user
   - Check browser console for errors
   - Verify backend is running and accessible

4. **Users not showing as active**
   - Check if users have logged in recently
   - Verify activity tracking is working
   - Check DynamoDB table for data

### Debug Steps

1. **Check backend logs:**
   ```bash
   # Look for user activity logs
   tail -f backend/backend.log | grep -E "(login|logout|activity)"
   ```

2. **Test admin API directly:**
   ```bash
   # Get your JWT token from browser dev tools, then:
   curl -H "Authorization: Bearer YOUR_JWT_TOKEN" \
        http://localhost:8000/api/v1/admin/active-users
   ```

3. **Verify database:**
   ```bash
   # Check DynamoDB table in AWS Console
   # Look for recent entries in user_active_sessions table
   ```

## 📈 Monitoring and Maintenance

### Regular Tasks

1. **Monitor active users:**
   - Check admin dashboard regularly
   - Review user activity patterns
   - Monitor for unusual activity

2. **Database maintenance:**
   - TTL automatically cleans up old sessions
   - Monitor DynamoDB usage and costs
   - Consider archiving old data if needed

3. **Security reviews:**
   - Regularly review admin user list
   - Monitor admin actions in logs
   - Update access controls as needed

### Performance Optimization

- Active users list refreshes every 30 seconds
- Database queries are optimized for performance
- Memory fallback for high availability
- Automatic cleanup prevents data bloat

## 🎉 Success Verification

After setup, verify the system works by:

1. **Login as admin user** - Should see "Admin Panel" button
2. **Click Admin Panel** - Should open dashboard
3. **View active users** - Should see yourself listed
4. **Test user details** - Click info icon for details
5. **Check statistics** - Should show current metrics

## 📞 Support

If you encounter issues:

1. Check the troubleshooting section above
2. Review backend and frontend logs
3. Verify AWS permissions and table access
4. Ensure all configuration files are updated

The system is designed to be robust with fallbacks, so it should work even if DynamoDB is temporarily unavailable (using memory storage).

---

**🎯 You now have a complete user monitoring system for your Redington AI Bot!**

Admin users can monitor active users, view detailed session information, and manage user sessions in real-time through the intuitive dashboard interface.
