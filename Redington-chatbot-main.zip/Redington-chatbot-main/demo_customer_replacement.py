#!/usr/bin/env python3
"""
Demo script showing customer name replacement feature
"""

import requests
import json
import time

def demo_customer_replacement():
    """Demonstrate the customer name replacement feature"""
    
    print("🎯 REDINGTON CHATBOT - CUSTOMER NAME REPLACEMENT DEMO")
    print("=" * 65)
    print("This demo shows how the chatbot automatically detects customer")
    print("names in prompts and replaces <Customer Name> placeholders.")
    print()
    
    # Login
    print("🔐 Logging in...")
    login_response = requests.post("http://localhost:8000/api/v1/auth/login", json={
        "username": "tanmay",
        "password": "Admin@123$"
    })
    
    if login_response.status_code != 200:
        print("❌ Login failed. Make sure the backend is running.")
        return
    
    token = login_response.json()["access_token"]
    headers = {"Authorization": f"Bearer {token}"}
    print("✅ Login successful\n")
    
    # Demo cases
    demo_cases = [
        {
            "title": "🏢 Corporate Customer",
            "prompt": "Create a cloud migration proposal for Microsoft Corporation",
            "explanation": "Should detect 'Microsoft' and replace all <Customer Name> placeholders"
        },
        {
            "title": "🚀 Tech Startup", 
            "prompt": "Customer name is Tesla Motors, need infrastructure proposal",
            "explanation": "Should detect 'Tesla' from 'customer name is' pattern"
        },
        {
            "title": "🌐 Generic Request",
            "prompt": "Create a general technology modernization proposal",
            "explanation": "No customer name mentioned, placeholders should remain unchanged"
        }
    ]
    
    for i, case in enumerate(demo_cases, 1):
        print(f"{case['title']}")
        print(f"📝 Prompt: \"{case['prompt']}\"")
        print(f"💡 Expected: {case['explanation']}")
        print("🔄 Generating response...")
        
        # Send request
        response = requests.post("http://localhost:8000/api/v1/chat/stream",
            json={
                "message": case["prompt"],
                "session_id": f"demo_session_{i}",
                "model": "claude-3-7-sonnet"
            },
            headers=headers,
            stream=True
        )
        
        if response.status_code != 200:
            print(f"❌ Request failed: {response.status_code}\n")
            continue
        
        # Collect first few chunks to show the result
        chunks_collected = 0
        sample_response = ""
        
        for line in response.iter_lines():
            if line and chunks_collected < 3:  # Get first 3 chunks
                line_str = line.decode('utf-8')
                if line_str.startswith('data: '):
                    try:
                        data = json.loads(line_str[6:])
                        if 'chunk' in data:
                            sample_response += data['chunk']
                            chunks_collected += 1
                    except json.JSONDecodeError:
                        continue
        
        # Show result
        print("📄 Response Preview:")
        print("-" * 50)
        print(sample_response[:300] + "..." if len(sample_response) > 300 else sample_response)
        print("-" * 50)
        
        # Analysis
        if i < 3:  # For cases with customer names
            if any(name in sample_response for name in ["Microsoft", "Tesla"]):
                print("✅ Customer name successfully detected and used!")
            else:
                print("⚠️  Customer name detection may need review")
        else:  # For generic case
            if "<Customer Name>" in sample_response:
                print("✅ Placeholder correctly preserved for generic request!")
            else:
                print("⚠️  Placeholder handling may need review")
        
        print("\n" + "="*65 + "\n")
        time.sleep(2)  # Pause between demos
    
    print("🎉 Demo completed!")
    print("\n💡 Key Benefits:")
    print("   • Automatic customer name detection")
    print("   • Dynamic placeholder replacement") 
    print("   • Maintains all streaming functionality")
    print("   • Professional, personalized proposals")
    print("\n🌐 Access your chatbot at: http://localhost:3000")

if __name__ == "__main__":
    demo_customer_replacement()
