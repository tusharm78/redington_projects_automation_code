#!/usr/bin/env python3

import boto3
from boto3.dynamodb.conditions import Key, Attr
import json

def test_scan_query():
    # Connect to DynamoDB
    dynamodb = boto3.resource('dynamodb', region_name='us-east-1')
    table = dynamodb.Table('user_chat_sessions')
    
    # Test session with known messages
    session_id = "a2f24f96-2552-4d55-bb62-e2f707e4ca0b"
    
    print(f"🔍 Testing different query methods for session: {session_id}")
    
    try:
        # Method 1: Scan with begins_with (current method)
        print(f"\n1. Testing scan with begins_with filter...")
        response1 = table.scan(
            FilterExpression="begins_with(chat_id, :prefix)",
            ExpressionAttributeValues={":prefix": f"MESSAGE#{session_id}#"}
        )
        messages1 = response1.get('Items', [])
        print(f"   Found {len(messages1)} messages")
        
        # Method 2: Scan with contains
        print(f"\n2. Testing scan with contains filter...")
        response2 = table.scan(
            FilterExpression="contains(chat_id, :session_id)",
            ExpressionAttributeValues={":session_id": session_id}
        )
        messages2 = response2.get('Items', [])
        print(f"   Found {len(messages2)} messages")
        
        # Method 3: Query by user_id and filter
        print(f"\n3. Testing query by user_id with filter...")
        try:
            response3 = table.query(
                KeyConditionExpression=Key('user_id').eq('tanmay'),
                FilterExpression="begins_with(chat_id, :prefix)",
                ExpressionAttributeValues={":prefix": f"MESSAGE#{session_id}#"}
            )
            messages3 = response3.get('Items', [])
            print(f"   Found {len(messages3)} messages")
        except Exception as e:
            print(f"   ❌ Error: {e}")
            messages3 = []
        
        # Method 4: Get all messages and filter in Python
        print(f"\n4. Testing get all messages and filter...")
        response4 = table.query(
            KeyConditionExpression=Key('user_id').eq('tanmay')
        )
        all_items = response4.get('Items', [])
        messages4 = [item for item in all_items if item.get('chat_id', '').startswith(f"MESSAGE#{session_id}#")]
        print(f"   Found {len(messages4)} messages")
        
        if messages4:
            print(f"   Sample message:")
            msg = messages4[0]
            print(f"     chat_id: {msg.get('chat_id')}")
            print(f"     role: {msg.get('role')}")
            print(f"     content: {msg.get('content', '')[:50]}...")
        
        # Method 5: Check exact message format
        print(f"\n5. Checking exact message format...")
        all_messages = [item for item in all_items if item.get('chat_id', '').startswith('MESSAGE#')]
        print(f"   Total messages in table: {len(all_messages)}")
        
        session_messages = [msg for msg in all_messages if session_id in msg.get('chat_id', '')]
        print(f"   Messages containing session_id: {len(session_messages)}")
        
        if session_messages:
            print(f"   Sample message chat_ids:")
            for i, msg in enumerate(session_messages[:3]):
                print(f"     {i+1}. {msg.get('chat_id')}")
        
        # Method 6: Full table scan (like the backend does)
        print(f"\n6. Testing full table scan...")
        response6 = table.scan()
        all_scan_items = response6.get('Items', [])
        messages6 = [item for item in all_scan_items if item.get('chat_id', '').startswith(f"MESSAGE#{session_id}#")]
        print(f"   Found {len(messages6)} messages via full scan")
        
        if messages6:
            print(f"   Sample message from scan:")
            msg = messages6[0]
            print(f"     chat_id: {msg.get('chat_id')}")
            print(f"     role: {msg.get('role')}")
            print(f"     content: {msg.get('content', '')[:50]}...")
        
    except Exception as e:
        print(f"❌ Error: {e}")

if __name__ == "__main__":
    test_scan_query()
