#!/usr/bin/env python3

import requests
import json

def test_tanmay_auth():
    """Test authentication and session loading for tanmay user"""
    
    base_url = "http://localhost:8000/api/v1"
    
    print("=== Testing tanmay user authentication ===")
    
    # Test login
    login_data = {
        "username": "tanmay",
        "password": "Admin@123$"
    }
    
    try:
        print("1. Attempting login...")
        response = requests.post(f"{base_url}/auth/login", json=login_data, timeout=10)
        print(f"   Status: {response.status_code}")
        
        if response.status_code == 200:
            token_data = response.json()
            token = token_data.get('access_token')
            print(f"   ✅ Login successful")
            print(f"   Token: {token[:30]}...")
            
            # Test sessions API
            headers = {"Authorization": f"Bearer {token}"}
            print("\n2. Testing sessions API...")
            
            sessions_response = requests.get(f"{base_url}/sessions", headers=headers, timeout=10)
            print(f"   Status: {sessions_response.status_code}")
            
            if sessions_response.status_code == 200:
                sessions = sessions_response.json()
                print(f"   ✅ Sessions loaded: {len(sessions)} sessions")
                print(f"   First 3 sessions:")
                for i, (chat_id, title) in enumerate(list(sessions.items())[:3]):
                    print(f"     {i+1}. {chat_id}: {title}")
            else:
                print(f"   ❌ Sessions failed: {sessions_response.text}")
                
        else:
            print(f"   ❌ Login failed: {response.text}")
            
    except Exception as e:
        print(f"   ❌ Error: {e}")

if __name__ == "__main__":
    test_tanmay_auth()
