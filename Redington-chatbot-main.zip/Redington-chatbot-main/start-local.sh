#!/bin/bash

echo "Starting Redington AI Chatbot..."

# Kill any existing processes
pkill -f "uvicorn main:app" 2>/dev/null || true
pkill -f "node.*react-scripts" 2>/dev/null || true

# Start backend
echo "Starting backend..."
cd /home/meenal/redington-chatbot/backend
source venv/bin/activate
nohup uvicorn main:app --host 0.0.0.0 --port 8000 --reload > backend.log 2>&1 &
BACKEND_PID=$!

# Wait for backend to start
sleep 5

# Check if backend is running
if curl -s http://localhost:8000/health > /dev/null; then
    echo "✅ Backend started successfully on port 8000"
else
    echo "❌ Backend failed to start"
    echo "Check logs: tail -f /home/meenal/redington-chatbot/backend/backend.log"
    exit 1
fi

# Start frontend
echo "Starting frontend..."
cd /home/meenal/redington-chatbot/frontend
nohup npm start > frontend.log 2>&1 &
FRONTEND_PID=$!

# Wait for frontend to start
sleep 10

echo ""
echo "🚀 Redington AI Chatbot is running!"
echo "   Frontend: http://localhost:3000"
echo "   Backend API: http://localhost:8000"
echo ""
echo "Demo Login Credentials:"
echo "   Username: tanmay"
echo "   Password: Admin@123$"
echo ""
echo "Backend PID: $BACKEND_PID"
echo "Frontend PID: $FRONTEND_PID"
echo ""
echo "To stop: pkill -f 'uvicorn main:app' && pkill -f 'node.*react-scripts'"
echo ""
echo "Logs:"
echo "   Backend: tail -f /home/meenal/redington-chatbot/backend/backend.log"
echo "   Frontend: tail -f /home/meenal/redington-chatbot/frontend/frontend.log"
