#!/bin/bash

echo "Starting Redington AI Chatbot..."

# Kill any existing processes
pkill -f "python main.py" 2>/dev/null || true
pkill -f "inotifywait" 2>/dev/null || true
pkill -f 'node.*start' 2>/dev/null || true

# Start backend
echo "Starting backend..."
cd /home/chatbot/Redington-chatbot/backend
source venv/bin/activate
nohup python main.py > ../backend.log 2>&1 &
BACKEND_PID=

# Wait for backend to start
sleep 3

# Check if backend is running
if curl -s http://localhost:8000/health > /dev/null; then
    echo "✅ Backend started successfully on port 8000"
else
    echo "❌ Backend failed to start"
    exit 1
fi

# Start frontend
echo "Starting frontend..."
cd /home/chatbot/Redington-chatbot
./start-frontend.sh

# Reload nginx for frontend
echo "Updating frontend..."
sudo nginx -s reload

# Check if frontend is accessible
if curl -s http://localhost:3001 > /dev/null; then
    echo "✅ Frontend accessible on port 3001"
else
    echo "❌ Frontend not accessible"
fi

echo ""
echo "🚀 Redington AI Chatbot is running!"
echo "   Frontend: http://localhost:3001"
echo "   Backend API: http://localhost:8000"
echo ""
echo "Demo Login Credentials:"
echo "   Username: tanmay"
echo "   Password: Admin@123$"
echo ""
echo "Other demo users:"
echo "   Username: admin, Password: admin123"
echo "   Username: demo, Password: demo123"
echo ""
echo "Backend PID: "
echo "To stop: pkill -f 'python main.py'"
echo ""
echo "Logs:"
echo "   Backend: tail -f /home/chatbot/Redington-chatbot/backend.log"
