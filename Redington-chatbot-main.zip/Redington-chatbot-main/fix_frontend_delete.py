#!/usr/bin/env python3

import re

# Read the original file
with open('/home/chatbot/Redington-chatbot/frontend/src/components/ModernChatInterface.tsx', 'r') as f:
    content = f.read()

# Define the enhanced deleteConversation function
new_delete_function = '''  const deleteConversation = async (chatId: string) => {
    try {
      console.log('🗑️ Deleting conversation:', chatId);
      
      // Call the backend to delete the session
      await sessionsService.deleteSession(chatId);
      console.log('✅ Session deleted from backend');
      
      // Remove from local state immediately
      setConversations(prev => {
        const filtered = prev.filter(conv => conv.id !== chatId);
        console.log('🔄 Updated conversations list, removed:', chatId);
        return filtered;
      });
      
      // If this was the current conversation, clear it completely
      if (conversationId === chatId) {
        console.log('🧹 Clearing current conversation');
        setMessages([]);
        setConversationId('');
        setShowWelcome(true);
        // Clear from localStorage to prevent restoration
        localStorage.removeItem('currentConversationId');
      }
      
      // Force a refresh of the conversations list to ensure it's gone
      setTimeout(() => {
        loadConversationHistory();
      }, 500);
      
    } catch (error) {
      console.error('❌ Error deleting conversation:', error);
      setError('Failed to delete conversation');
    }
  };'''

# Replace the deleteConversation function
pattern = r'  const deleteConversation = async \(chatId: string\) => \{.*?\n  \};'
content = re.sub(pattern, new_delete_function, content, flags=re.DOTALL)

# Write the updated content back to the file
with open('/home/chatbot/Redington-chatbot/frontend/src/components/ModernChatInterface.tsx', 'w') as f:
    f.write(content)

print("✅ Successfully updated deleteConversation function in ModernChatInterface.tsx")
