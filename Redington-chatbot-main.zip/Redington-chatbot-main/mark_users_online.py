#!/usr/bin/env python3
"""
Direct solution to mark Tanmay and Meenal as online based on their recent activity
"""

import boto3
import json
from datetime import datetime, timedelta

def check_and_mark_users_online():
    """Check recent activity and mark users as online"""
    
    print("🔍 Checking user activity in DynamoDB...")
    
    try:
        dynamodb = boto3.resource('dynamodb', region_name='us-east-1')
        table = dynamodb.Table('user_chat_sessions')
        
        # Users to check
        users_to_check = ['tanmay', 'meenal']
        online_users = []
        
        for username in users_to_check:
            print(f"\n👤 Checking {username}...")
            
            try:
                from boto3.dynamodb.conditions import Key
                
                response = table.query(
                    KeyConditionExpression=Key("user_id").eq(username)
                )
                
                sessions = response.get('Items', [])
                print(f"   Found {len(sessions)} session records")
                
                if sessions:
                    latest_activity = None
                    
                    for session in sessions:
                        # Check various timestamp fields
                        for time_field in ['timestamp', 'last_activity', 'created_at']:
                            if time_field in session:
                                activity_time = session[time_field]
                                
                                # Handle different timestamp formats
                                if isinstance(activity_time, (int, float)):
                                    # Unix timestamp in milliseconds
                                    activity_time = datetime.fromtimestamp(activity_time / 1000).isoformat()
                                elif isinstance(activity_time, str):
                                    # ISO string - use as is
                                    pass
                                
                                if not latest_activity or activity_time > latest_activity:
                                    latest_activity = activity_time
                                break
                    
                    if latest_activity:
                        print(f"   Latest activity: {latest_activity}")
                        
                        # Parse timestamp and check if recent
                        try:
                            if '+' in latest_activity:
                                activity_dt = datetime.fromisoformat(latest_activity.replace('Z', '+00:00'))
                            else:
                                activity_dt = datetime.fromisoformat(latest_activity)
                            
                            # Calculate time difference
                            current_time = datetime.utcnow()
                            if activity_dt.tzinfo:
                                activity_dt = activity_dt.replace(tzinfo=None)
                            
                            time_diff = (current_time - activity_dt).total_seconds()
                            minutes_ago = time_diff / 60
                            
                            print(f"   Time since activity: {minutes_ago:.1f} minutes ago")
                            
                            # Mark as online if active within last 2 hours (more lenient for demo)
                            if time_diff < 7200:  # 2 hours
                                online_users.append({
                                    'username': username,
                                    'status': 'online',
                                    'last_activity': latest_activity,
                                    'minutes_ago': minutes_ago
                                })
                                print(f"   ✅ {username} should be ONLINE")
                            else:
                                print(f"   ⚪ {username} should be OFFLINE (too old)")
                                
                        except Exception as e:
                            print(f"   ❌ Error parsing timestamp: {e}")
                    else:
                        print(f"   ⚪ No activity timestamps found")
                else:
                    print(f"   ⚪ No session records found")
                    
            except Exception as e:
                print(f"   ❌ Error querying {username}: {e}")
        
        print(f"\n📊 Summary:")
        print(f"   Online users: {len(online_users)}")
        
        for user in online_users:
            print(f"   - {user['username']}: {user['minutes_ago']:.1f} minutes ago")
        
        return online_users
        
    except Exception as e:
        print(f"❌ Error accessing DynamoDB: {e}")
        return []

def create_online_status_file(online_users):
    """Create a file with online user status for the admin API to read"""
    
    status_data = {
        'timestamp': datetime.utcnow().isoformat(),
        'online_users': online_users
    }
    
    with open('/tmp/online_users_status.json', 'w') as f:
        json.dump(status_data, f, indent=2)
    
    print(f"\n💾 Created status file: /tmp/online_users_status.json")

if __name__ == "__main__":
    print("🚀 Direct Online Status Check")
    print("=" * 40)
    
    online_users = check_and_mark_users_online()
    
    if online_users:
        create_online_status_file(online_users)
        
        print(f"\n🎉 Found {len(online_users)} users who should be online!")
        print(f"📋 Next: Update admin API to use this data")
    else:
        print(f"\n⚠️ No users found with recent activity")
        print(f"   This might be due to timestamp format differences")
