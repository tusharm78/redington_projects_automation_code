#!/usr/bin/env python3
"""
Script to handle password change for new Cognito users
"""
import sys
import os
import boto3
import hmac
import hashlib
import base64
from dotenv import load_dotenv

# Load environment variables
load_dotenv('/home/chatbot/Redington-chatbot/backend/.env')

def calculate_secret_hash(username: str, client_id: str, client_secret: str) -> str:
    """Calculate the secret hash for Cognito authentication"""
    message = username + client_id
    dig = hmac.new(
        client_secret.encode('utf-8'),
        message.encode('utf-8'),
        hashlib.sha256
    ).digest()
    return base64.b64encode(dig).decode()

def change_user_password():
    """Handle password change for new user"""
    
    # Configuration
    username = "shubham"
    current_password = "2NPn74R;"
    new_password = "NewPassword123!"  # You can change this to whatever you want
    
    pool_id = os.getenv('POOL_ID')
    client_id = os.getenv('APP_CLIENT_ID')
    client_secret = os.getenv('APP_CLIENT_SECRET')
    region = os.getenv('AWS_DEFAULT_REGION')
    
    print("=== Cognito Password Change Handler ===")
    print(f"User: {username}")
    print(f"Pool ID: {pool_id}")
    print(f"Region: {region}")
    print()
    
    try:
        # Initialize Cognito client
        cognito_client = boto3.client('cognito-idp', region_name=region)
        
        # Step 1: Initiate authentication to get the challenge
        secret_hash = calculate_secret_hash(username, client_id, client_secret)
        
        print("Step 1: Initiating authentication...")
        auth_response = cognito_client.initiate_auth(
            ClientId=client_id,
            AuthFlow='USER_PASSWORD_AUTH',
            AuthParameters={
                'USERNAME': username,
                'PASSWORD': current_password,
                'SECRET_HASH': secret_hash
            }
        )
        
        if 'ChallengeName' in auth_response and auth_response['ChallengeName'] == 'NEW_PASSWORD_REQUIRED':
            print("✓ Received NEW_PASSWORD_REQUIRED challenge")
            
            # Step 2: Respond to the challenge with new password
            print("Step 2: Setting new password...")
            challenge_response = cognito_client.respond_to_auth_challenge(
                ClientId=client_id,
                ChallengeName='NEW_PASSWORD_REQUIRED',
                Session=auth_response['Session'],
                ChallengeResponses={
                    'USERNAME': username,
                    'NEW_PASSWORD': new_password,
                    'SECRET_HASH': secret_hash
                }
            )
            
            if 'AuthenticationResult' in challenge_response:
                print("✓ Password changed successfully!")
                print(f"New password: {new_password}")
                print()
                print("The user can now log in with:")
                print(f"  Username: {username}")
                print(f"  Password: {new_password}")
                
                # Test the new credentials
                print("\nStep 3: Testing new credentials...")
                test_response = cognito_client.initiate_auth(
                    ClientId=client_id,
                    AuthFlow='USER_PASSWORD_AUTH',
                    AuthParameters={
                        'USERNAME': username,
                        'PASSWORD': new_password,
                        'SECRET_HASH': secret_hash
                    }
                )
                
                if 'AuthenticationResult' in test_response:
                    print("✓ New credentials work perfectly!")
                    return True
                else:
                    print("⚠️  Password changed but test login failed")
                    return False
            else:
                print("✗ Failed to change password")
                print(f"Response: {challenge_response}")
                return False
        else:
            print("✗ Expected NEW_PASSWORD_REQUIRED challenge but got something else")
            print(f"Response: {auth_response}")
            return False
            
    except Exception as e:
        print(f"✗ Error: {str(e)}")
        return False

def set_permanent_password():
    """Alternative method: Set permanent password directly (admin method)"""
    
    username = "shubham"
    new_password = "NewPassword123!"
    
    pool_id = os.getenv('POOL_ID')
    region = os.getenv('AWS_DEFAULT_REGION')
    
    print("=== Alternative: Admin Set Permanent Password ===")
    
    try:
        cognito_client = boto3.client('cognito-idp', region_name=region)
        
        # Set permanent password
        response = cognito_client.admin_set_user_password(
            UserPoolId=pool_id,
            Username=username,
            Password=new_password,
            Permanent=True
        )
        
        print("✓ Permanent password set successfully!")
        print(f"New password: {new_password}")
        print()
        print("The user can now log in with:")
        print(f"  Username: {username}")
        print(f"  Password: {new_password}")
        
        return True
        
    except Exception as e:
        print(f"✗ Error setting permanent password: {str(e)}")
        return False

if __name__ == "__main__":
    print("Redington Chatbot - Password Change Handler")
    print("=" * 50)
    
    print("Choose method:")
    print("1. Handle password change challenge (recommended)")
    print("2. Set permanent password directly (admin method)")
    
    choice = input("\nEnter choice (1 or 2): ").strip()
    
    if choice == "1":
        success = change_user_password()
    elif choice == "2":
        success = set_permanent_password()
    else:
        print("Invalid choice")
        success = False
    
    print("\n" + "=" * 50)
    if success:
        print("✓ Password change completed successfully!")
        print("The user should now be able to log in to the chatbot.")
    else:
        print("✗ Password change failed!")
        print("Please check the error messages above.")
