#!/usr/bin/env python3
"""
Reset temporary password for user varunesh
"""
import sys
import os
import boto3
from dotenv import load_dotenv

# Load environment variables
load_dotenv('/home/chatbot/Redington-chatbot/backend/.env')

def reset_user_password():
    """Reset the temporary password for varunesh"""
    
    username = "varunesh"
    new_temp_password = "TempPass123!"  # New temporary password
    
    pool_id = os.getenv('POOL_ID')
    region = os.getenv('AWS_DEFAULT_REGION')
    
    print("=== Resetting Varunesh Temporary Password ===")
    print(f"User: {username}")
    print(f"Pool ID: {pool_id}")
    print(f"Region: {region}")
    print()
    
    try:
        cognito_client = boto3.client('cognito-idp', region_name=region)
        
        # First, check current user status
        print("Step 1: Checking current user status...")
        user_info = cognito_client.admin_get_user(
            UserPoolId=pool_id,
            Username=username
        )
        
        print(f"Current Status: {user_info.get('UserStatus')}")
        print(f"User Enabled: {user_info.get('Enabled')}")
        
        # Reset the password to a known temporary password
        print("Step 2: Setting new temporary password...")
        response = cognito_client.admin_set_user_password(
            UserPoolId=pool_id,
            Username=username,
            Password=new_temp_password,
            Permanent=False  # This makes it temporary, requiring change on first login
        )
        
        print("✓ Temporary password set successfully!")
        print(f"New temporary password: {new_temp_password}")
        print()
        print("The user can now log in with:")
        print(f"  Username: {username}")
        print(f"  Temporary Password: {new_temp_password}")
        print()
        print("They will be prompted to set a permanent password on first login.")
        
        return True
        
    except Exception as e:
        print(f"✗ Error resetting password: {str(e)}")
        return False

def test_temp_password():
    """Test the new temporary password"""
    
    username = "varunesh"
    temp_password = "TempPass123!"
    
    print("\n=== Testing New Temporary Password ===")
    
    try:
        import hmac
        import hashlib
        import base64
        
        def calculate_secret_hash(username, client_id, client_secret):
            message = username + client_id
            dig = hmac.new(
                client_secret.encode('utf-8'),
                message.encode('utf-8'),
                hashlib.sha256
            ).digest()
            return base64.b64encode(dig).decode()
        
        cognito_client = boto3.client('cognito-idp', region_name=os.getenv('AWS_DEFAULT_REGION'))
        client_id = os.getenv('APP_CLIENT_ID')
        client_secret = os.getenv('APP_CLIENT_SECRET')
        secret_hash = calculate_secret_hash(username, client_id, client_secret)
        
        # Try to initiate auth with the temporary password
        auth_response = cognito_client.initiate_auth(
            ClientId=client_id,
            AuthFlow='USER_PASSWORD_AUTH',
            AuthParameters={
                'USERNAME': username,
                'PASSWORD': temp_password,
                'SECRET_HASH': secret_hash
            }
        )
        
        if 'ChallengeName' in auth_response and auth_response['ChallengeName'] == 'NEW_PASSWORD_REQUIRED':
            print("✓ Temporary password works!")
            print("✓ NEW_PASSWORD_REQUIRED challenge received as expected")
            print(f"Session: {auth_response.get('Session', '')[:50]}...")
            return True
        else:
            print("⚠️  Unexpected response:")
            print(auth_response)
            return False
            
    except Exception as e:
        print(f"✗ Test failed: {str(e)}")
        return False

if __name__ == "__main__":
    print("Varunesh Password Reset Tool")
    print("=" * 40)
    
    # Reset the password
    reset_success = reset_user_password()
    
    if reset_success:
        # Test the new password
        test_success = test_temp_password()
        
        print("\n" + "=" * 40)
        if test_success:
            print("✅ SUCCESS: Password reset and tested successfully!")
            print()
            print("🔑 Login Credentials:")
            print("   Username: varunesh")
            print("   Temporary Password: TempPass123!")
            print()
            print("📝 Next Steps:")
            print("   1. Go to https://bot.redingtonsolutions.org/")
            print("   2. Enter the credentials above")
            print("   3. You'll be prompted to set a new permanent password")
            print("   4. After setting the new password, you can use the chatbot")
        else:
            print("⚠️  Password was reset but testing failed")
    else:
        print("❌ Failed to reset password")
