#!/usr/bin/env python3
import socketio
import asyncio
import sys

sio = socketio.AsyncClient()
received_chunks = []
completed = False

@sio.event
async def connect():
    print("✅ Connected! Sending test message...")
    await sio.emit('send_message', {
        'message': 'Hello Redington',
        'conversation_id': 'test',
        'session_id': 'test'
    })

@sio.event
async def auth_success(data):
    print("✅ Authenticated")

@sio.event
async def chat_start(data):
    print("🚀 Streaming started...")
    print("Response: ", end="", flush=True)

@sio.event
async def chat_chunk(data):
    global completed
    if data.get('is_complete'):
        print(f"\n✅ Complete! Received {len(received_chunks)} chunks")
        completed = True
    else:
        chunk = data.get('chunk', '')
        received_chunks.append(chunk)
        print(chunk, end="", flush=True)

async def main():
    try:
        await sio.connect('http://localhost:8000')
        # Wait for completion or timeout
        for i in range(100):  # 10 second timeout
            if completed:
                break
            await asyncio.sleep(0.1)
        await sio.disconnect()
        return completed
    except Exception as e:
        print(f"Error: {e}")
        return False

if __name__ == "__main__":
    result = asyncio.run(main())
    sys.exit(0 if result else 1)
