#!/bin/bash

# Deployment script for Redington AI Bot User Monitoring System
# This script deploys the user monitoring system with admin dashboard

set -e

echo "🚀 Deploying Redington AI Bot User Monitoring System"
echo "=================================================="

# Colors for output
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
NC='\033[0m' # No Color

# Configuration
BACKEND_DIR="/home/chatbot/Redington-chatbot/backend"
ADMIN_DIR="/home/chatbot/Redington-chatbot/admin-dashboard"
NGINX_SITES="/etc/nginx/sites-available"
NGINX_ENABLED="/etc/nginx/sites-enabled"

# Function to print colored output
print_status() {
    echo -e "${GREEN}✅ $1${NC}"
}

print_warning() {
    echo -e "${YELLOW}⚠️ $1${NC}"
}

print_error() {
    echo -e "${RED}❌ $1${NC}"
}

print_info() {
    echo -e "${BLUE}ℹ️ $1${NC}"
}

# Check if running as root for nginx operations
check_permissions() {
    if [[ $EUID -eq 0 ]]; then
        print_warning "Running as root. This is required for nginx configuration."
    else
        print_info "Not running as root. Nginx configuration will be skipped."
        SKIP_NGINX=true
    fi
}

# Step 1: Setup Database
setup_database() {
    echo -e "\n${BLUE}Step 1: Setting up DynamoDB tables${NC}"
    
    cd "$BACKEND_DIR"
    
    if command -v python3 &> /dev/null; then
        python3 setup_user_monitoring_db.py
        print_status "Database setup completed"
    else
        print_error "Python3 not found. Please install Python3 and try again."
        exit 1
    fi
}

# Step 2: Install Backend Dependencies
install_backend_deps() {
    echo -e "\n${BLUE}Step 2: Installing backend dependencies${NC}"
    
    cd "$BACKEND_DIR"
    
    # Check if virtual environment exists
    if [ ! -d "venv" ]; then
        print_info "Creating virtual environment..."
        python3 -m venv venv
    fi
    
    # Activate virtual environment
    source venv/bin/activate
    
    # Install/upgrade dependencies
    pip install --upgrade pip
    pip install boto3 python-jose[cryptography] python-multipart
    
    print_status "Backend dependencies installed"
}

# Step 3: Backup and Update Backend
update_backend() {
    echo -e "\n${BLUE}Step 3: Updating backend with user monitoring${NC}"
    
    cd "$BACKEND_DIR"
    
    # Create backup of current main file
    if [ -f "enhanced_bedrock_main.py" ]; then
        cp enhanced_bedrock_main.py "enhanced_bedrock_main.py.backup-$(date +%Y%m%d-%H%M%S)"
        print_status "Backend backup created"
    fi
    
    # The updated backend file is already in place
    print_status "Backend updated with user monitoring"
}

# Step 4: Deploy Admin Dashboard
deploy_admin_dashboard() {
    echo -e "\n${BLUE}Step 4: Deploying admin dashboard${NC}"
    
    # Create web directory if it doesn't exist
    WEB_ROOT="/var/www/redington-bot"
    ADMIN_WEB_DIR="$WEB_ROOT/admin"
    
    if [ ! "$SKIP_NGINX" = true ]; then
        # Create directories
        sudo mkdir -p "$ADMIN_WEB_DIR"
        
        # Copy admin dashboard files
        sudo cp -r "$ADMIN_DIR"/* "$ADMIN_WEB_DIR/"
        
        # Set proper permissions
        sudo chown -R www-data:www-data "$WEB_ROOT"
        sudo chmod -R 755 "$WEB_ROOT"
        
        print_status "Admin dashboard deployed to $ADMIN_WEB_DIR"
    else
        print_warning "Skipping admin dashboard deployment (requires root)"
        print_info "Manually copy $ADMIN_DIR/* to your web server's admin directory"
    fi
}

# Step 5: Configure Nginx
configure_nginx() {
    echo -e "\n${BLUE}Step 5: Configuring Nginx${NC}"
    
    if [ "$SKIP_NGINX" = true ]; then
        print_warning "Skipping nginx configuration (requires root)"
        print_info "Manually configure nginx using the provided config file"
        return
    fi
    
    NGINX_CONFIG="redington-bot"
    
    # Copy nginx configuration
    if [ -f "$ADMIN_DIR/nginx-admin.conf" ]; then
        sudo cp "$ADMIN_DIR/nginx-admin.conf" "$NGINX_SITES/$NGINX_CONFIG"
        
        # Enable site
        sudo ln -sf "$NGINX_SITES/$NGINX_CONFIG" "$NGINX_ENABLED/$NGINX_CONFIG"
        
        # Test nginx configuration
        if sudo nginx -t; then
            print_status "Nginx configuration is valid"
            
            # Reload nginx
            sudo systemctl reload nginx
            print_status "Nginx reloaded successfully"
        else
            print_error "Nginx configuration test failed"
            print_warning "Please check the configuration manually"
        fi
    else
        print_warning "Nginx configuration file not found"
    fi
}

# Step 6: Start/Restart Backend
restart_backend() {
    echo -e "\n${BLUE}Step 6: Restarting backend service${NC}"
    
    cd "$BACKEND_DIR"
    
    # Kill existing backend processes
    pkill -f "enhanced_bedrock_main.py" || true
    sleep 2
    
    # Start backend in background
    source venv/bin/activate
    nohup python3 enhanced_bedrock_main.py > backend.log 2>&1 &
    BACKEND_PID=$!
    
    # Save PID
    echo $BACKEND_PID > backend.pid
    
    # Wait a moment and check if it's running
    sleep 3
    if kill -0 $BACKEND_PID 2>/dev/null; then
        print_status "Backend started successfully (PID: $BACKEND_PID)"
    else
        print_error "Backend failed to start. Check backend.log for details."
        exit 1
    fi
}

# Step 7: Verify Deployment
verify_deployment() {
    echo -e "\n${BLUE}Step 7: Verifying deployment${NC}"
    
    # Check backend health
    sleep 5
    if curl -s http://localhost:8000/ > /dev/null; then
        print_status "Backend is responding"
    else
        print_error "Backend is not responding"
    fi
    
    # Check admin API
    if curl -s http://localhost:8000/api/v1/admin/system-health > /dev/null; then
        print_status "Admin API is available"
    else
        print_warning "Admin API may not be fully initialized yet"
    fi
    
    print_status "Deployment verification completed"
}

# Main deployment process
main() {
    check_permissions
    
    echo -e "\n${YELLOW}This script will:${NC}"
    echo "1. Setup DynamoDB tables for user monitoring"
    echo "2. Install backend dependencies"
    echo "3. Update backend with user monitoring features"
    echo "4. Deploy admin dashboard"
    echo "5. Configure Nginx (if running as root)"
    echo "6. Restart backend service"
    echo "7. Verify deployment"
    
    echo -e "\n${YELLOW}Admin users configured: tanmay, meenal, varunesh, admin${NC}"
    
    read -p "Continue with deployment? (y/N): " -n 1 -r
    echo
    if [[ ! $REPLY =~ ^[Yy]$ ]]; then
        echo "Deployment cancelled."
        exit 0
    fi
    
    # Execute deployment steps
    setup_database
    install_backend_deps
    update_backend
    deploy_admin_dashboard
    configure_nginx
    restart_backend
    verify_deployment
    
    echo -e "\n${GREEN}🎉 Deployment completed successfully!${NC}"
    echo -e "\n${BLUE}📋 Access Information:${NC}"
    echo "• Main Chatbot: https://bot.redingtonsolutions.org/"
    echo "• Admin Dashboard: https://bot.redingtonsolutions.org/admin"
    echo "• Backend API: http://localhost:8000/"
    
    echo -e "\n${BLUE}👥 Admin Users:${NC}"
    echo "• tanmay (password: tanmay123)"
    echo "• meenal (password: meenal123)"
    echo "• varunesh (password: varunesh123)"
    echo "• admin (password: admin123)"
    
    echo -e "\n${BLUE}📊 Features Available:${NC}"
    echo "• Real-time user activity monitoring"
    echo "• Active users dashboard with statistics"
    echo "• User session details and management"
    echo "• Force logout capabilities"
    echo "• Session cleanup tools"
    echo "• Auto-refresh every 30 seconds"
    
    echo -e "\n${YELLOW}📝 Next Steps:${NC}"
    echo "1. Test admin login at https://bot.redingtonsolutions.org/admin"
    echo "2. Verify user monitoring is working"
    echo "3. Update SSL certificates if needed"
    echo "4. Monitor backend logs: tail -f $BACKEND_DIR/backend.log"
    
    if [ "$SKIP_NGINX" = true ]; then
        echo -e "\n${YELLOW}⚠️ Manual Steps Required:${NC}"
        echo "1. Copy nginx configuration from $ADMIN_DIR/nginx-admin.conf"
        echo "2. Deploy admin dashboard files to your web server"
        echo "3. Ensure /admin route serves the admin dashboard"
    fi
}

# Run main function
main "$@"
