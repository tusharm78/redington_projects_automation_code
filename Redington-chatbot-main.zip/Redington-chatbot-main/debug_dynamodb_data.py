#!/usr/bin/env python3

import boto3
from boto3.dynamodb.conditions import Key
import json

def debug_dynamodb_data():
    # Connect to DynamoDB
    dynamodb = boto3.resource('dynamodb', region_name='us-east-1')
    table = dynamodb.Table('user_chat_sessions')
    
    print("🔍 Debugging DynamoDB data for user 'tanmay'...")
    
    try:
        # Query all items for user tanmay
        response = table.query(
            KeyConditionExpression=Key('user_id').eq('tanmay')
        )
        
        items = response.get('Items', [])
        print(f"📊 Found {len(items)} total items for user tanmay")
        
        sessions = []
        messages = []
        
        for item in items:
            chat_id = item.get('chat_id', '')
            if chat_id.startswith('SESSION#'):
                sessions.append(item)
            elif chat_id.startswith('MESSAGE#'):
                messages.append(item)
            else:
                print(f"⚠️ Unknown item type: {chat_id}")
        
        print(f"📊 Sessions: {len(sessions)}")
        print(f"📊 Messages: {len(messages)}")
        
        # Show first few sessions
        print(f"\n📋 First 3 sessions:")
        for i, session in enumerate(sessions[:3]):
            session_id = session['chat_id'].replace('SESSION#', '')
            session_name = session.get('chat_title', 'Untitled')
            message_count = session.get('message_count', 0)
            print(f"  {i+1}. {session_name} (ID: {session_id}) - {message_count} messages")
        
        # Show first few messages
        print(f"\n📋 First 3 messages:")
        for i, message in enumerate(messages[:3]):
            chat_id = message['chat_id']
            role = message.get('role', 'unknown')
            content = message.get('content', '')[:50]
            print(f"  {i+1}. {chat_id} - [{role}] {content}...")
        
        # Check if messages exist for a specific session
        if sessions:
            test_session = sessions[0]
            session_id = test_session['chat_id'].replace('SESSION#', '')
            print(f"\n🔍 Looking for messages for session: {session_id}")
            
            session_messages = [m for m in messages if session_id in m['chat_id']]
            print(f"📊 Found {len(session_messages)} messages for this session")
            
            if session_messages:
                for i, msg in enumerate(session_messages[:2]):
                    print(f"  Message {i+1}: {msg['chat_id']} - {msg.get('content', '')[:50]}...")
            else:
                print("  No messages found for this session")
                
                # Check what the message chat_ids look like
                print(f"\n🔍 Sample message chat_ids:")
                for i, msg in enumerate(messages[:5]):
                    print(f"  {i+1}. {msg['chat_id']}")
        
    except Exception as e:
        print(f"❌ Error: {e}")

if __name__ == "__main__":
    debug_dynamodb_data()
