
# System Status Snapshot - Fri Jul  4 10:47:02 IST 2025

## Backend Status
{
  "status": "healthy",
  "service": "redington-enhanced-bedrock-cognito",
  "bedrock_status": "connected",
  "model": "us.anthropic.claude-3-7-sonnet-20250219-v1:0",
  "cognito_configured": true,
  "dynamodb_configured": false
}

## Process Status
```
meenal     87699  0.0  0.0   2896   128 pts/3    T    05:19   0:00 sh -c DANGEROUSLY_DISABLE_HOST_CHECK=true HOST=0.0.0.0 react-scripts start
meenal     87700  0.0  0.0 591452  1144 pts/3    Tl   05:19   0:00 node /home/meenal/redington-chatbot/frontend/node_modules/.bin/react-scripts start
meenal    102912  0.0  0.0   2896  1536 pts/3    S+   09:37   0:00 sh -c DANGEROUSLY_DISABLE_HOST_CHECK=true HOST=0.0.0.0 react-scripts start
meenal    102913  0.0  1.0 591376 39416 pts/3    Sl+  09:37   0:00 node /home/meenal/redington-chatbot/frontend/node_modules/.bin/react-scripts start
meenal    102920  4.5 26.4 45780676 967712 pts/3 Sl+  09:37   3:11 /usr/bin/node /home/meenal/redington-chatbot/frontend/node_modules/react-scripts/scripts/start.js
meenal    104688  0.5  2.0  84952 76688 pts/3    S+   10:38   0:02 python3 enhanced_bedrock_main.py
```

## Port Status
```
COMMAND    PID   USER   FD   TYPE DEVICE SIZE/OFF NODE NAME
node    102920 meenal   20u  IPv4 235821      0t0  TCP *:3000 (LISTEN)
node    102920 meenal   25u  IPv4 247851      0t0  TCP localhost:3000->localhost:56918 (ESTABLISHED)
python3 104688 meenal    8u  IPv4 248919      0t0  TCP *:8000 (LISTEN)
```
