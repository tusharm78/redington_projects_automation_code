#!/usr/bin/env python3

import boto3
from boto3.dynamodb.conditions import Key
import json
from collections import defaultdict

def debug_session_messages():
    # Connect to DynamoDB
    dynamodb = boto3.resource('dynamodb', region_name='us-east-1')
    table = dynamodb.Table('user_chat_sessions')
    
    print("🔍 Debugging session-message relationships...")
    
    try:
        # Query all items for user tanmay
        response = table.query(
            KeyConditionExpression=Key('user_id').eq('tanmay')
        )
        
        items = response.get('Items', [])
        
        # Separate sessions and messages
        sessions = {}
        message_counts = defaultdict(int)
        
        for item in items:
            chat_id = item.get('chat_id', '')
            if chat_id.startswith('SESSION#'):
                session_id = chat_id.replace('SESSION#', '')
                sessions[session_id] = {
                    'name': item.get('chat_title', 'Untitled'),
                    'stored_count': item.get('message_count', 0),
                    'updated_at': item.get('updated_at', '')
                }
            elif chat_id.startswith('MESSAGE#'):
                # Extract session_id from MESSAGE#session_id#message_id
                parts = chat_id.split('#')
                if len(parts) >= 2:
                    session_id = parts[1]
                    message_counts[session_id] += 1
        
        print(f"📊 Found {len(sessions)} sessions and messages for {len(message_counts)} sessions")
        
        # Compare stored counts vs actual counts
        print(f"\n📋 Session comparison (stored vs actual message counts):")
        
        sessions_with_messages = []
        for session_id, session_data in sessions.items():
            stored_count = session_data['stored_count']
            actual_count = message_counts.get(session_id, 0)
            name = session_data['name'][:30]
            
            if actual_count > 0:
                sessions_with_messages.append({
                    'id': session_id,
                    'name': name,
                    'stored_count': stored_count,
                    'actual_count': actual_count
                })
                
            status = "✅" if stored_count == actual_count else "⚠️"
            print(f"  {status} {name} (ID: {session_id[:8]}...)")
            print(f"      Stored: {stored_count}, Actual: {actual_count}")
        
        print(f"\n📊 Sessions with actual messages: {len(sessions_with_messages)}")
        
        # Test the fixed query for a session with messages
        if sessions_with_messages:
            test_session = sessions_with_messages[0]
            session_id = test_session['id']
            print(f"\n🔍 Testing query for session: {session_id}")
            
            # Test the scan query that should work
            scan_response = table.scan(
                FilterExpression="begins_with(chat_id, :prefix)",
                ExpressionAttributeValues={":prefix": f"MESSAGE#{session_id}#"}
            )
            
            found_messages = scan_response.get('Items', [])
            print(f"📊 Scan found {len(found_messages)} messages")
            
            if found_messages:
                for i, msg in enumerate(found_messages[:2]):
                    role = msg.get('role', 'unknown')
                    content = msg.get('content', '')[:50]
                    print(f"  Message {i+1}: [{role}] {content}...")
        
    except Exception as e:
        print(f"❌ Error: {e}")

if __name__ == "__main__":
    debug_session_messages()
