#!/bin/bash

echo "🚀 Smart Update Script for Redington AI Chatbot"

FRONTEND_DIR="/home/chatbot/RedAIBot/react-bedrock-chatbot/frontend"
BACKEND_DIR="/home/chatbot/RedAIBot/react-bedrock-chatbot/backend"

# Function to rebuild frontend with cache busting
rebuild_frontend() {
    echo "🔄 Frontend changes detected. Rebuilding..."
    cd "$FRONTEND_DIR"
    
    # Build the frontend
    npm run build
    
    # Create version file with timestamp for cache busting
    echo "$(date +%s)" > build/version.txt
    
    # Reload nginx with no-cache headers
    sudo nginx -s reload
    
    echo "✅ Frontend updated! Changes will be visible immediately."
    echo "   No browser refresh needed - cache headers updated."
}

# Function to restart backend
restart_backend() {
    echo "🔄 Backend changes detected. Restarting..."
    pkill -f "python main.py" 2>/dev/null || true
    sleep 2
    cd "$BACKEND_DIR"
    source venv/bin/activate
    nohup python -u main.py > backend.log 2>&1 &
    sleep 3
    
    if curl -s http://localhost:8000/health > /dev/null; then
        echo "✅ Backend restarted successfully"
    else
        echo "❌ Backend restart failed"
    fi
}

# Initial setup
echo "🔧 Setting up smart updates..."

# Ensure nginx has proper cache headers
sudo nginx -s reload

# Monitor for changes
echo "👀 Monitoring for changes..."
echo "   Frontend: $FRONTEND_DIR/src"
echo "   Backend: $BACKEND_DIR"
echo ""

# Monitor frontend changes
inotifywait -m -r -e modify,create,delete "$FRONTEND_DIR/src" --format '%w%f %e' |
while read file event; do
    if [[ $file == *.tsx ]] || [[ $file == *.ts ]] || [[ $file == *.css ]] || [[ $file == *.js ]]; then
        rebuild_frontend
    fi
done &

# Monitor backend changes  
inotifywait -m -r -e modify,create,delete "$BACKEND_DIR" --format '%w%f %e' |
while read file event; do
    if [[ $file == *.py ]] && [[ $file != *"__pycache__"* ]] && [[ $file != *".log"* ]]; then
        restart_backend
    fi
done &

echo "✅ Smart update monitoring active!"
echo "   Make changes to your code - updates will apply automatically"
echo "   No manual refresh needed!"
echo ""
echo "Press Ctrl+C to stop monitoring"

# Keep script running
wait
