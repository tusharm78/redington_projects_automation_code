#!/usr/bin/env python3
"""
Continuous System Monitor for Redington Chatbot
Runs continuously and provides real-time monitoring with alerts
"""

import time
import json
import os
import signal
import sys
from datetime import datetime, timedelta
from system_monitor import SystemMonitor
import logging

# Configure logging
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(levelname)s - %(message)s',
    handlers=[
        logging.FileHandler('/home/chatbot/Redington-chatbot/continuous_monitor.log'),
        logging.StreamHandler()
    ]
)
logger = logging.getLogger(__name__)

class ContinuousMonitor:
    def __init__(self, interval: int = 60):
        self.interval = interval
        self.monitor = SystemMonitor()
        self.running = True
        self.alert_history = []
        
        # Set up signal handlers for graceful shutdown
        signal.signal(signal.SIGINT, self.signal_handler)
        signal.signal(signal.SIGTERM, self.signal_handler)
    
    def signal_handler(self, signum, frame):
        """Handle shutdown signals gracefully"""
        logger.info(f"Received signal {signum}, shutting down gracefully...")
        self.running = False
    
    def send_alert(self, alert_message: str):
        """Send alert (can be extended to send emails, Slack notifications, etc.)"""
        timestamp = datetime.now().isoformat()
        alert = {
            'timestamp': timestamp,
            'message': alert_message,
            'severity': 'HIGH' if any(word in alert_message.upper() for word in ['HIGH', 'CRITICAL', 'ERROR']) else 'MEDIUM'
        }
        
        self.alert_history.append(alert)
        
        # Keep only last 100 alerts
        if len(self.alert_history) > 100:
            self.alert_history = self.alert_history[-100:]
        
        # Log the alert
        logger.warning(f"ALERT: {alert_message}")
        
        # Save alert to file
        self.save_alert(alert)
        
        # Here you could add integrations for:
        # - Email notifications
        # - Slack/Teams notifications
        # - AWS SNS notifications
        # - PagerDuty integration
    
    def save_alert(self, alert: dict):
        """Save alert to alerts file"""
        alerts_file = '/home/chatbot/Redington-chatbot/alerts.json'
        
        try:
            if os.path.exists(alerts_file):
                with open(alerts_file, 'r') as f:
                    alerts = json.load(f)
            else:
                alerts = []
            
            alerts.append(alert)
            
            # Keep only last 24 hours of alerts
            cutoff_time = datetime.now() - timedelta(hours=24)
            alerts = [a for a in alerts if datetime.fromisoformat(a['timestamp']) > cutoff_time]
            
            with open(alerts_file, 'w') as f:
                json.dump(alerts, f, indent=2)
                
        except Exception as e:
            logger.error(f"Failed to save alert: {e}")
    
    def check_system_health(self) -> dict:
        """Perform comprehensive system health check"""
        try:
            metrics = self.monitor.get_system_metrics()
            alerts = self.monitor.check_alerts(metrics)
            
            # Additional health checks
            health_status = {
                'timestamp': datetime.now().isoformat(),
                'overall_status': 'HEALTHY',
                'issues': [],
                'metrics': metrics,
                'alerts': alerts
            }
            
            # Check if backend is responding
            backend_processes = metrics['processes']['backend']
            if not backend_processes:
                health_status['issues'].append('No backend processes running')
                health_status['overall_status'] = 'CRITICAL'
            
            # Check for too many processes
            total_processes = metrics['processes']['total_processes']
            if total_processes > 10:
                health_status['issues'].append(f'Too many chatbot processes running: {total_processes}')
                health_status['overall_status'] = 'WARNING'
            
            # Check disk space
            if metrics['disk']['percent'] > 90:
                health_status['issues'].append(f"Disk usage critical: {metrics['disk']['percent']:.1f}%")
                health_status['overall_status'] = 'CRITICAL'
            elif metrics['disk']['percent'] > 80:
                health_status['issues'].append(f"Disk usage high: {metrics['disk']['percent']:.1f}%")
                if health_status['overall_status'] == 'HEALTHY':
                    health_status['overall_status'] = 'WARNING'
            
            # Check memory usage
            if metrics['memory']['percent'] > 90:
                health_status['issues'].append(f"Memory usage critical: {metrics['memory']['percent']:.1f}%")
                health_status['overall_status'] = 'CRITICAL'
            elif metrics['memory']['percent'] > 80:
                health_status['issues'].append(f"Memory usage high: {metrics['memory']['percent']:.1f}%")
                if health_status['overall_status'] == 'HEALTHY':
                    health_status['overall_status'] = 'WARNING'
            
            # Check CPU usage
            if metrics['cpu']['percent'] > 90:
                health_status['issues'].append(f"CPU usage critical: {metrics['cpu']['percent']:.1f}%")
                health_status['overall_status'] = 'CRITICAL'
            elif metrics['cpu']['percent'] > 80:
                health_status['issues'].append(f"CPU usage high: {metrics['cpu']['percent']:.1f}%")
                if health_status['overall_status'] == 'HEALTHY':
                    health_status['overall_status'] = 'WARNING'
            
            # Send alerts for issues
            for alert in alerts:
                self.send_alert(alert)
            
            for issue in health_status['issues']:
                self.send_alert(issue)
            
            return health_status
            
        except Exception as e:
            logger.error(f"Health check failed: {e}")
            return {
                'timestamp': datetime.now().isoformat(),
                'overall_status': 'ERROR',
                'issues': [f'Health check failed: {str(e)}'],
                'metrics': None,
                'alerts': []
            }
    
    def generate_dashboard(self, health_status: dict) -> str:
        """Generate a real-time dashboard display"""
        if not health_status['metrics']:
            return "❌ System monitoring unavailable"
        
        metrics = health_status['metrics']
        status_emoji = {
            'HEALTHY': '🟢',
            'WARNING': '🟡',
            'CRITICAL': '🔴',
            'ERROR': '❌'
        }
        
        dashboard = f"""
╔══════════════════════════════════════════════════════════════════════════════╗
║                    REDINGTON CHATBOT LIVE MONITOR                           ║
║                        {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}                              ║
║                    Status: {status_emoji.get(health_status['overall_status'], '❓')} {health_status['overall_status']}                                    ║
╚══════════════════════════════════════════════════════════════════════════════╝

📊 REAL-TIME METRICS:
├─ CPU: {metrics['cpu']['percent']:5.1f}% │ Memory: {metrics['memory']['percent']:5.1f}% │ Disk: {metrics['disk']['percent']:5.1f}%
├─ Load: {metrics['cpu']['load_avg_1m']:4.2f} │ Available RAM: {metrics['memory']['available_gb']:5.1f}GB │ Free Disk: {metrics['disk']['free_gb']:5.1f}GB
└─ Processes: Backend({len(metrics['processes']['backend'])}) Admin({len(metrics['processes']['admin_apis'])}) Frontend({len(metrics['processes']['frontend'])})

👥 USER CAPACITY:
"""
        
        try:
            capacity = self.monitor.estimate_user_capacity(metrics)
            dashboard += f"├─ Active Users: {capacity['current_active_users']} / {capacity['recommended_max_users']} recommended\n"
            dashboard += f"├─ Utilization: {capacity['current_utilization_percent']:.1f}%\n"
            dashboard += f"└─ Scale at: {int(capacity['scaling_needed_at'])} users\n"
        except Exception as e:
            dashboard += f"└─ Capacity calculation error: {str(e)}\n"
        
        if health_status['issues']:
            dashboard += "\n🚨 CURRENT ISSUES:\n"
            for issue in health_status['issues']:
                dashboard += f"├─ {issue}\n"
        
        if self.alert_history:
            recent_alerts = [a for a in self.alert_history if 
                           datetime.fromisoformat(a['timestamp']) > datetime.now() - timedelta(hours=1)]
            if recent_alerts:
                dashboard += f"\n⚠️  RECENT ALERTS ({len(recent_alerts)} in last hour):\n"
                for alert in recent_alerts[-3:]:  # Show last 3 alerts
                    time_str = datetime.fromisoformat(alert['timestamp']).strftime('%H:%M:%S')
                    dashboard += f"├─ {time_str}: {alert['message']}\n"
        
        dashboard += f"\n📈 Monitoring for {metrics['uptime_hours']:.1f} hours │ Next check in {self.interval}s\n"
        dashboard += "═" * 80 + "\n"
        
        return dashboard
    
    def save_health_status(self, health_status: dict):
        """Save health status to file"""
        status_file = '/home/chatbot/Redington-chatbot/health_status.json'
        
        try:
            with open(status_file, 'w') as f:
                json.dump(health_status, f, indent=2)
        except Exception as e:
            logger.error(f"Failed to save health status: {e}")
    
    def run(self):
        """Run continuous monitoring"""
        logger.info(f"Starting continuous monitoring (interval: {self.interval}s)")
        
        try:
            while self.running:
                # Clear screen for dashboard update
                os.system('clear' if os.name == 'posix' else 'cls')
                
                # Perform health check
                health_status = self.check_system_health()
                
                # Generate and display dashboard
                dashboard = self.generate_dashboard(health_status)
                print(dashboard)
                
                # Save health status
                self.save_health_status(health_status)
                
                # Save metrics for historical analysis
                if health_status['metrics']:
                    self.monitor.save_metrics(health_status['metrics'])
                
                # Wait for next check
                for i in range(self.interval):
                    if not self.running:
                        break
                    time.sleep(1)
                    
        except KeyboardInterrupt:
            logger.info("Monitoring stopped by user")
        except Exception as e:
            logger.error(f"Monitoring error: {e}")
        finally:
            logger.info("Continuous monitoring stopped")

def main():
    import argparse
    
    parser = argparse.ArgumentParser(description='Continuous monitoring for Redington Chatbot')
    parser.add_argument('--interval', type=int, default=60, help='Monitoring interval in seconds (default: 60)')
    
    args = parser.parse_args()
    
    monitor = ContinuousMonitor(args.interval)
    monitor.run()

if __name__ == "__main__":
    main()
