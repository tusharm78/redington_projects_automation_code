#!/bin/bash

# Bedrock Integration System Startup
echo "🚀 Starting Redington AI Bot - Bedrock Integration System"
echo "=========================================================="
echo ""

# Function to check if port is in use
check_port() {
    local port=$1
    if lsof -Pi :$port -sTCP:LISTEN -t >/dev/null ; then
        echo "⚠️  Port $port is already in use"
        return 1
    else
        echo "✅ Port $port is available"
        return 0
    fi
}

# Function to kill processes on specific ports
kill_port() {
    local port=$1
    echo "🔄 Stopping processes on port $port..."
    lsof -ti:$port | xargs kill -9 2>/dev/null || true
    sleep 2
}

# Stop existing processes
echo "🛑 Stopping existing processes..."
kill_port 8000  # Backend
kill_port 3000  # Frontend

# Check AWS credentials
echo ""
echo "🔍 Checking AWS configuration..."
if aws sts get-caller-identity > /dev/null 2>&1; then
    echo "✅ AWS credentials configured - Bedrock integration will be enabled"
    BEDROCK_STATUS="enabled"
else
    echo "⚠️  AWS credentials not found - Will run in enhanced fallback mode"
    echo "💡 To enable Bedrock: Run 'aws configure' with your AWS credentials"
    BEDROCK_STATUS="fallback"
fi

# Check system requirements
echo ""
echo "🔍 Checking system requirements..."

# Check Node.js
if command -v node &> /dev/null; then
    echo "✅ Node.js: $(node --version)"
else
    echo "❌ Node.js not found. Please install Node.js 16+"
    exit 1
fi

# Check Python
if command -v python3 &> /dev/null; then
    echo "✅ Python: $(python3 --version)"
else
    echo "❌ Python3 not found. Please install Python 3.10+"
    exit 1
fi

# Start Backend
echo ""
echo "🔧 Starting Bedrock Integration Backend..."
cd backend

# Check if virtual environment exists
if [ ! -d "venv" ]; then
    echo "📦 Creating Python virtual environment..."
    python3 -m venv venv
fi

# Activate virtual environment and install dependencies
source venv/bin/activate
echo "📚 Installing/updating Python dependencies..."
pip install -q -r requirements.txt

# Start backend in background
echo "🚀 Launching Bedrock Integration Backend..."
nohup python -m uvicorn bedrock_main:app \
    --host 0.0.0.0 \
    --port 8000 \
    --reload \
    --log-level info > bedrock_backend.log 2>&1 &

BACKEND_PID=$!
echo $BACKEND_PID > ../backend.pid
echo "✅ Backend started (PID: $BACKEND_PID)"

# Wait for backend to start
echo "⏳ Waiting for backend to initialize..."
sleep 8

# Check if backend is running
if ! check_port 8000; then
    echo "✅ Backend is running on http://localhost:8000"
else
    echo "❌ Backend failed to start on port 8000"
    echo "📋 Check backend logs: tail -f backend/bedrock_backend.log"
    exit 1
fi

# Start Frontend
echo ""
echo "🎨 Starting Frontend..."
cd ../frontend

# Install/update dependencies
echo "📚 Installing/updating Node.js dependencies..."
npm install --silent

# Set environment variables for Bedrock mode
export REACT_APP_API_URL="http://localhost:8000/api/v1"
export REACT_APP_MODE="bedrock"

# Start frontend in background
echo "🚀 Launching Frontend..."
nohup npm start > frontend_bedrock.log 2>&1 &

FRONTEND_PID=$!
echo $FRONTEND_PID > ../frontend.pid
echo "✅ Frontend started (PID: $FRONTEND_PID)"

# Wait for frontend to start
echo "⏳ Waiting for frontend to initialize..."
sleep 15

# Check if frontend is running
if ! check_port 3000; then
    echo "✅ Frontend is running on http://localhost:3000"
else
    echo "❌ Frontend failed to start on port 3000"
    echo "📋 Check frontend logs: tail -f frontend/frontend_bedrock.log"
    exit 1
fi

# System ready
echo ""
echo "🎉 Bedrock Integration System is Ready!"
echo "======================================"
echo ""
echo "🌐 Frontend: http://localhost:3000"
echo "🔧 Backend:  http://localhost:8000"
echo "📖 API Docs: http://localhost:8000/docs"
echo ""
echo "🤖 AI Integration:"
if [ "$BEDROCK_STATUS" = "enabled" ]; then
    echo "   ✅ AWS Bedrock Claude - ENABLED"
    echo "   🧠 Real AI model for deep, detailed proposals"
    echo "   📊 Advanced technical analysis and recommendations"
else
    echo "   ⚠️  AWS Bedrock - FALLBACK MODE"
    echo "   🔄 Enhanced templates with detailed responses"
    echo "   💡 Configure AWS credentials to enable real AI"
fi
echo ""
echo "✨ Enhanced Features:"
echo "   • Deep Technical Proposals"
echo "   • Comprehensive Business Analysis"
echo "   • Detailed Implementation Roadmaps"
echo "   • Professional Markdown Formatting"
echo "   • Real-time Streaming Responses"
echo ""
echo "🔐 Demo Credentials:"
echo "   Username: demo    Password: demo123"
echo "   Username: admin   Password: admin123"
echo "   Username: user    Password: password"
echo ""
echo "📋 Monitoring Commands:"
echo "   Backend logs:  tail -f backend/bedrock_backend.log"
echo "   Frontend logs: tail -f frontend/frontend_bedrock.log"
echo "   Stop system:   ./stop_bedrock_system.sh"
echo ""
echo "🚀 System Status: RUNNING"
