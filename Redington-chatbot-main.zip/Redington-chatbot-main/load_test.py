#!/usr/bin/env python3
"""
Load Testing Script for Redington Chatbot
Simulates multiple concurrent users to test system performance
"""

import asyncio
import aiohttp
import time
import json
import random
import logging
from datetime import datetime
from typing import List, Dict, Any
import argparse

# Configure logging
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(levelname)s - %(message)s'
)
logger = logging.getLogger(__name__)

class LoadTester:
    def __init__(self, base_url: str = "http://localhost:8000"):
        self.base_url = base_url
        self.results = []
        self.active_sessions = 0
        
    async def simulate_user_session(self, user_id: int, session_duration: int = 300):
        """Simulate a single user session"""
        session_start = time.time()
        session_data = {
            'user_id': user_id,
            'start_time': session_start,
            'requests': [],
            'errors': [],
            'total_requests': 0,
            'successful_requests': 0
        }
        
        self.active_sessions += 1
        logger.info(f"User {user_id} started session (Active sessions: {self.active_sessions})")
        
        try:
            async with aiohttp.ClientSession() as session:
                # Simulate login
                await self.simulate_login(session, user_id, session_data)
                
                # Simulate chat interactions
                end_time = session_start + session_duration
                while time.time() < end_time:
                    await self.simulate_chat_message(session, user_id, session_data)
                    
                    # Random delay between messages (1-10 seconds)
                    await asyncio.sleep(random.uniform(1, 10))
                    
                    # Occasionally upload a file
                    if random.random() < 0.1:  # 10% chance
                        await self.simulate_file_upload(session, user_id, session_data)
                
                # Simulate logout
                await self.simulate_logout(session, user_id, session_data)
                
        except Exception as e:
            session_data['errors'].append(f"Session error: {str(e)}")
            logger.error(f"User {user_id} session error: {e}")
        
        finally:
            self.active_sessions -= 1
            session_data['end_time'] = time.time()
            session_data['duration'] = session_data['end_time'] - session_data['start_time']
            session_data['success_rate'] = (session_data['successful_requests'] / max(1, session_data['total_requests'])) * 100
            
            self.results.append(session_data)
            logger.info(f"User {user_id} ended session (Active sessions: {self.active_sessions})")
    
    async def simulate_login(self, session: aiohttp.ClientSession, user_id: int, session_data: Dict):
        """Simulate user login"""
        try:
            login_data = {
                "username": f"testuser{user_id}",
                "password": "testpassword"
            }
            
            start_time = time.time()
            async with session.post(f"{self.base_url}/api/v1/auth/login", json=login_data) as response:
                response_time = time.time() - start_time
                session_data['requests'].append({
                    'type': 'login',
                    'response_time': response_time,
                    'status': response.status,
                    'timestamp': datetime.now().isoformat()
                })
                session_data['total_requests'] += 1
                
                if response.status == 200:
                    session_data['successful_requests'] += 1
                    # Store auth token for future requests
                    result = await response.json()
                    session_data['auth_token'] = result.get('access_token')
                else:
                    session_data['errors'].append(f"Login failed: {response.status}")
                    
        except Exception as e:
            session_data['errors'].append(f"Login error: {str(e)}")
    
    async def simulate_chat_message(self, session: aiohttp.ClientSession, user_id: int, session_data: Dict):
        """Simulate sending a chat message"""
        try:
            messages = [
                "Hello, can you help me with AWS services?",
                "What is Amazon EC2?",
                "How do I set up a VPC?",
                "Tell me about AWS Lambda",
                "What are the benefits of cloud computing?",
                "How do I optimize costs in AWS?",
                "What is the difference between S3 and EBS?",
                "Can you explain AWS IAM?",
                "How do I set up auto-scaling?",
                "What monitoring tools does AWS provide?"
            ]
            
            message_data = {
                "message": random.choice(messages),
                "model": "Claude 3.7 Sonnet",
                "conversation_id": f"conv_{user_id}_{int(time.time())}"
            }
            
            headers = {}
            if 'auth_token' in session_data:
                headers['Authorization'] = f"Bearer {session_data['auth_token']}"
            
            start_time = time.time()
            async with session.post(f"{self.base_url}/api/v1/chat/message", 
                                  json=message_data, headers=headers) as response:
                response_time = time.time() - start_time
                session_data['requests'].append({
                    'type': 'chat_message',
                    'response_time': response_time,
                    'status': response.status,
                    'timestamp': datetime.now().isoformat()
                })
                session_data['total_requests'] += 1
                
                if response.status == 200:
                    session_data['successful_requests'] += 1
                else:
                    session_data['errors'].append(f"Chat message failed: {response.status}")
                    
        except Exception as e:
            session_data['errors'].append(f"Chat message error: {str(e)}")
    
    async def simulate_file_upload(self, session: aiohttp.ClientSession, user_id: int, session_data: Dict):
        """Simulate file upload"""
        try:
            # Create a dummy text file
            file_content = f"This is a test file from user {user_id} at {datetime.now()}"
            
            headers = {}
            if 'auth_token' in session_data:
                headers['Authorization'] = f"Bearer {session_data['auth_token']}"
            
            data = aiohttp.FormData()
            data.add_field('file', file_content, filename=f'test_file_{user_id}.txt', content_type='text/plain')
            
            start_time = time.time()
            async with session.post(f"{self.base_url}/api/v1/upload", 
                                  data=data, headers=headers) as response:
                response_time = time.time() - start_time
                session_data['requests'].append({
                    'type': 'file_upload',
                    'response_time': response_time,
                    'status': response.status,
                    'timestamp': datetime.now().isoformat()
                })
                session_data['total_requests'] += 1
                
                if response.status == 200:
                    session_data['successful_requests'] += 1
                else:
                    session_data['errors'].append(f"File upload failed: {response.status}")
                    
        except Exception as e:
            session_data['errors'].append(f"File upload error: {str(e)}")
    
    async def simulate_logout(self, session: aiohttp.ClientSession, user_id: int, session_data: Dict):
        """Simulate user logout"""
        try:
            headers = {}
            if 'auth_token' in session_data:
                headers['Authorization'] = f"Bearer {session_data['auth_token']}"
            
            start_time = time.time()
            async with session.post(f"{self.base_url}/api/v1/auth/logout", headers=headers) as response:
                response_time = time.time() - start_time
                session_data['requests'].append({
                    'type': 'logout',
                    'response_time': response_time,
                    'status': response.status,
                    'timestamp': datetime.now().isoformat()
                })
                session_data['total_requests'] += 1
                
                if response.status == 200:
                    session_data['successful_requests'] += 1
                else:
                    session_data['errors'].append(f"Logout failed: {response.status}")
                    
        except Exception as e:
            session_data['errors'].append(f"Logout error: {str(e)}")
    
    async def run_load_test(self, num_users: int, session_duration: int = 300, ramp_up_time: int = 60):
        """Run load test with specified parameters"""
        logger.info(f"Starting load test: {num_users} users, {session_duration}s sessions, {ramp_up_time}s ramp-up")
        
        # Calculate delay between user starts
        user_start_delay = ramp_up_time / num_users if num_users > 0 else 0
        
        # Start users gradually
        tasks = []
        for user_id in range(num_users):
            task = asyncio.create_task(self.simulate_user_session(user_id, session_duration))
            tasks.append(task)
            
            if user_id < num_users - 1:  # Don't wait after the last user
                await asyncio.sleep(user_start_delay)
        
        # Wait for all users to complete
        await asyncio.gather(*tasks)
        
        logger.info("Load test completed")
    
    def generate_report(self) -> str:
        """Generate load test report"""
        if not self.results:
            return "No test results available"
        
        # Calculate overall statistics
        total_users = len(self.results)
        total_requests = sum(r['total_requests'] for r in self.results)
        total_successful = sum(r['successful_requests'] for r in self.results)
        total_errors = sum(len(r['errors']) for r in self.results)
        
        # Response time statistics
        all_response_times = []
        for result in self.results:
            for req in result['requests']:
                all_response_times.append(req['response_time'])
        
        if all_response_times:
            avg_response_time = sum(all_response_times) / len(all_response_times)
            min_response_time = min(all_response_times)
            max_response_time = max(all_response_times)
            all_response_times.sort()
            p95_response_time = all_response_times[int(len(all_response_times) * 0.95)]
        else:
            avg_response_time = min_response_time = max_response_time = p95_response_time = 0
        
        # Success rate
        overall_success_rate = (total_successful / max(1, total_requests)) * 100
        
        # Session duration statistics
        session_durations = [r.get('duration', 0) for r in self.results if 'duration' in r]
        avg_session_duration = sum(session_durations) / len(session_durations) if session_durations else 0
        
        report = f"""
╔══════════════════════════════════════════════════════════════════════════════╗
║                        LOAD TEST RESULTS                                    ║
║                        {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}                              ║
╚══════════════════════════════════════════════════════════════════════════════╝

📊 OVERALL STATISTICS:
├─ Total Users: {total_users}
├─ Total Requests: {total_requests}
├─ Successful Requests: {total_successful}
├─ Failed Requests: {total_requests - total_successful}
├─ Error Count: {total_errors}
└─ Overall Success Rate: {overall_success_rate:.1f}%

⏱️  RESPONSE TIME STATISTICS:
├─ Average Response Time: {avg_response_time:.3f}s
├─ Minimum Response Time: {min_response_time:.3f}s
├─ Maximum Response Time: {max_response_time:.3f}s
└─ 95th Percentile: {p95_response_time:.3f}s

👥 SESSION STATISTICS:
├─ Average Session Duration: {avg_session_duration:.1f}s
└─ Sessions Completed: {len([r for r in self.results if 'duration' in r])}

🔍 REQUEST TYPE BREAKDOWN:
"""
        
        # Request type breakdown
        request_types = {}
        for result in self.results:
            for req in result['requests']:
                req_type = req['type']
                if req_type not in request_types:
                    request_types[req_type] = {'count': 0, 'total_time': 0, 'success': 0}
                request_types[req_type]['count'] += 1
                request_types[req_type]['total_time'] += req['response_time']
                if req['status'] == 200:
                    request_types[req_type]['success'] += 1
        
        for req_type, stats in request_types.items():
            avg_time = stats['total_time'] / stats['count']
            success_rate = (stats['success'] / stats['count']) * 100
            report += f"├─ {req_type}: {stats['count']} requests, {avg_time:.3f}s avg, {success_rate:.1f}% success\n"
        
        # Performance recommendations
        report += "\n💡 PERFORMANCE RECOMMENDATIONS:\n"
        
        if avg_response_time > 2.0:
            report += "├─ 🔴 High average response time - consider optimizing backend or scaling up\n"
        elif avg_response_time > 1.0:
            report += "├─ 🟡 Moderate response time - monitor for performance degradation\n"
        else:
            report += "├─ 🟢 Good response time performance\n"
        
        if overall_success_rate < 95:
            report += "├─ 🔴 Low success rate - investigate error causes\n"
        elif overall_success_rate < 99:
            report += "├─ 🟡 Moderate success rate - monitor for reliability issues\n"
        else:
            report += "├─ 🟢 Excellent success rate\n"
        
        if p95_response_time > 5.0:
            report += "├─ 🔴 High 95th percentile response time - some requests are very slow\n"
        
        # Capacity recommendations
        concurrent_users = max(1, total_users)
        if avg_response_time > 1.0:
            recommended_max = int(concurrent_users * 0.7)
            report += f"├─ 📈 Recommended max concurrent users: {recommended_max}\n"
        else:
            recommended_max = int(concurrent_users * 1.5)
            report += f"├─ 📈 System can likely handle up to {recommended_max} concurrent users\n"
        
        report += "\n" + "═" * 80 + "\n"
        
        return report

async def main():
    parser = argparse.ArgumentParser(description='Load test the Redington Chatbot')
    parser.add_argument('--users', type=int, default=10, help='Number of concurrent users (default: 10)')
    parser.add_argument('--duration', type=int, default=300, help='Session duration in seconds (default: 300)')
    parser.add_argument('--ramp-up', type=int, default=60, help='Ramp-up time in seconds (default: 60)')
    parser.add_argument('--url', type=str, default='http://localhost:8000', help='Base URL (default: http://localhost:8000)')
    
    args = parser.parse_args()
    
    tester = LoadTester(args.url)
    
    try:
        await tester.run_load_test(args.users, args.duration, args.ramp_up)
        report = tester.generate_report()
        print(report)
        
        # Save results to file
        with open('/home/chatbot/Redington-chatbot/load_test_results.json', 'w') as f:
            json.dump(tester.results, f, indent=2)
        
        logger.info("Load test results saved to load_test_results.json")
        
    except Exception as e:
        logger.error(f"Load test failed: {e}")
        print(f"❌ Load test failed: {e}")

if __name__ == "__main__":
    asyncio.run(main())
