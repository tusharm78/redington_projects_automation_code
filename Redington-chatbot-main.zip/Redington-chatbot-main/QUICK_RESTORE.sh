#!/bin/bash

# Redington AI Bot - Quick Restore Script
echo "🔄 Redington AI Bot - Quick Restore"
echo "==================================="

# Check if we're in the backup directory
if [ ! -f "BACKUP_DOCUMENTATION.md" ]; then
    echo "❌ Error: Run this script from the backup directory"
    exit 1
fi

echo "📍 Current directory: $(pwd)"
echo ""

# Function to check if command exists
command_exists() {
    command -v "$1" >/dev/null 2>&1
}

# Check prerequisites
echo "🔍 Checking prerequisites..."
echo "----------------------------"

if command_exists python3; then
    echo "✅ Python3: $(python3 --version)"
else
    echo "❌ Python3 not found"
    exit 1
fi

if command_exists node; then
    echo "✅ Node.js: $(node --version)"
else
    echo "❌ Node.js not found"
    exit 1
fi

if command_exists npm; then
    echo "✅ npm: $(npm --version)"
else
    echo "❌ npm not found"
    exit 1
fi

if command_exists aws; then
    echo "✅ AWS CLI: $(aws --version 2>&1 | head -1)"
else
    echo "⚠️  AWS CLI not found - some features may not work"
fi

echo ""

# Setup backend
echo "🔧 Setting up backend..."
echo "------------------------"
cd backend/

if [ ! -d "venv" ]; then
    echo "📦 Creating virtual environment..."
    python3 -m venv venv
fi

echo "🔄 Activating virtual environment..."
source venv/bin/activate

echo "📥 Installing Python dependencies..."
pip install -q -r requirements.txt

echo "✅ Backend setup complete"
echo ""

# Setup frontend
echo "🔧 Setting up frontend..."
echo "-------------------------"
cd ../frontend/

if [ ! -d "node_modules" ]; then
    echo "📥 Installing Node.js dependencies..."
    npm install --silent
else
    echo "✅ Node modules already installed"
fi

echo "✅ Frontend setup complete"
echo ""

# Start services
echo "🚀 Starting services..."
echo "-----------------------"

# Start backend
cd ../backend/
echo "🔄 Starting backend..."
if [ -f "start_enhanced_cognito.sh" ]; then
    chmod +x start_enhanced_cognito.sh
    ./start_enhanced_cognito.sh &
    BACKEND_PID=$!
    sleep 5
    
    # Check if backend started
    if curl -s http://localhost:8000/health > /dev/null 2>&1; then
        echo "✅ Backend started successfully"
    else
        echo "❌ Backend failed to start"
        exit 1
    fi
else
    echo "❌ Backend startup script not found"
    exit 1
fi

# Start frontend
cd ../frontend/
echo "🔄 Starting frontend..."
npm start > /dev/null 2>&1 &
FRONTEND_PID=$!
sleep 10

# Check if frontend started
if curl -s http://localhost:3000 > /dev/null 2>&1; then
    echo "✅ Frontend started successfully"
else
    echo "❌ Frontend failed to start"
fi

echo ""
echo "🎉 Restore Complete!"
echo "==================="
echo "🔗 Frontend: http://localhost:3000"
echo "🔗 Backend API: http://localhost:8000"
echo "🔗 API Docs: http://localhost:8000/docs"
echo ""
echo "👤 Login Credentials:"
echo "   Demo: demo / demo123"
echo "   Cognito: Use your existing Cognito users"
echo ""
echo "📋 Process IDs:"
echo "   Backend PID: $BACKEND_PID"
echo "   Frontend PID: $FRONTEND_PID"
echo ""
echo "🛑 To stop services:"
echo "   Backend: cd backend && ./stop_enhanced_cognito.sh"
echo "   Frontend: kill $FRONTEND_PID"
