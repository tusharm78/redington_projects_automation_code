#!/usr/bin/env python3

import requests
import json

def test_production_messages():
    base_url = "https://bot.redingtonsolutions.org"
    
    # Login first
    login_data = {"username": "tanmay", "password": "Admin@123$"}
    login_response = requests.post(f"{base_url}/api/v1/auth/login", json=login_data)
    
    if login_response.status_code != 200:
        print("❌ Login failed")
        return
        
    token = login_response.json().get('access_token')
    headers = {'Authorization': f'Bearer {token}', 'Content-Type': 'application/json'}
    
    # Get sessions
    sessions_response = requests.get(f"{base_url}/api/v1/sessions", headers=headers)
    sessions = sessions_response.json().get('sessions', [])
    
    print(f"🔍 Testing messages for multiple sessions...")
    
    # Test first 5 sessions with messages
    sessions_with_messages = [s for s in sessions if s.get('message_count', 0) > 0][:5]
    
    for i, session in enumerate(sessions_with_messages):
        session_id = session['id']
        session_name = session.get('name', 'Untitled')[:30]
        message_count = session.get('message_count', 0)
        
        print(f"\n{i+1}. Testing session: {session_name} (ID: {session_id})")
        print(f"   Expected messages: {message_count}")
        
        # Test messages endpoint
        messages_response = requests.get(f"{base_url}/api/v1/chat/history/{session_id}", headers=headers)
        print(f"   Messages API Status: {messages_response.status_code}")
        
        if messages_response.status_code == 200:
            messages_data = messages_response.json()
            actual_messages = len(messages_data.get('messages', []))
            print(f"   ✅ Actual messages found: {actual_messages}")
            
            if actual_messages > 0:
                # Show first message
                first_msg = messages_data['messages'][0]
                print(f"   First message: [{first_msg.get('role')}] {first_msg.get('content', '')[:50]}...")
                break
            else:
                print(f"   ⚠️ No messages returned despite message_count={message_count}")
        else:
            print(f"   ❌ Messages API failed: {messages_response.text}")

if __name__ == "__main__":
    test_production_messages()
