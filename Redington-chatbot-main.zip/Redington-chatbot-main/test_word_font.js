// Simple test to verify Word document font generation
const { Document, Packer, Paragraph, TextRun, AlignmentType } = require('docx');
const fs = require('fs');

async function testWordFont() {
  const doc = new Document({
    styles: {
      default: {
        document: {
          run: {
            font: {
              name: "Calibri"
            },
            size: 24
          }
        }
      }
    },
    sections: [{
      children: [
        new Paragraph({
          children: [
            new TextRun({
              text: "Test Document - Calibri Font",
              bold: true,
              size: 32,
              font: {
                name: "Calibri"
              }
            })
          ],
          alignment: AlignmentType.CENTER
        }),
        new Paragraph({
          children: [
            new TextRun({
              text: "This is a test paragraph to verify Calibri font is working correctly.",
              font: {
                name: "Calibri"
              },
              size: 24
            })
          ]
        }),
        new Paragraph({
          children: [
            new TextRun({
              text: "Heading Test - 16pt",
              bold: true,
              size: 32,
              font: {
                name: "Calibri"
              }
            })
          ]
        })
      ]
    }]
  });

  const buffer = await Packer.toBuffer(doc);
  fs.writeFileSync('/home/meenal/redington-chatbot/test_calibri_font.docx', buffer);
  console.log('Test Word document created: test_calibri_font.docx');
}

testWordFont().catch(console.error);
