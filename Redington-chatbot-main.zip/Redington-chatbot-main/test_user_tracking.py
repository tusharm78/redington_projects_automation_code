#!/usr/bin/env python3
"""
Test script to verify user session tracking is working
"""

import requests
import json
import time

def test_user_session_tracking():
    """Test the user session tracking functionality"""
    
    base_url = "http://localhost:8000"
    
    print("🧪 TESTING USER SESSION TRACKING")
    print("=" * 40)
    
    # Test login
    print("\n1. Testing Login...")
    login_data = {
        "username": "demo",
        "password": "demo123"
    }
    
    try:
        response = requests.post(f"{base_url}/api/v1/auth/login", json=login_data)
        if response.status_code == 200:
            result = response.json()
            token = result.get('access_token')
            print(f"✅ Login successful for tanmay")
            print(f"   Token: {token[:50]}...")
            
            # Test user info
            print("\n2. Testing User Info...")
            headers = {"Authorization": f"Bearer {token}"}
            response = requests.get(f"{base_url}/api/v1/auth/me", headers=headers)
            if response.status_code == 200:
                user_info = response.json()
                print(f"✅ User info retrieved: {user_info}")
            else:
                print(f"❌ Failed to get user info: {response.status_code}")
            
            # Test chat message (to trigger activity tracking)
            print("\n3. Testing Chat Message...")
            chat_data = {
                "message": "Hello, this is a test message",
                "model": "Claude 3.7 Sonnet",
                "session_id": "default"
            }
            
            response = requests.post(f"{base_url}/api/v1/chat/stream", json=chat_data, headers=headers)
            if response.status_code == 200:
                print("✅ Chat message sent successfully")
            else:
                print(f"❌ Failed to send chat message: {response.status_code}")
            
            # Wait a moment for processing
            time.sleep(2)
            
            # Test logout
            print("\n4. Testing Logout...")
            response = requests.post(f"{base_url}/api/v1/auth/logout", headers=headers)
            if response.status_code == 200:
                print("✅ Logout successful")
            else:
                print(f"❌ Failed to logout: {response.status_code}")
                
        else:
            print(f"❌ Login failed: {response.status_code}")
            print(f"   Response: {response.text}")
            
    except Exception as e:
        print(f"❌ Test error: {e}")

def check_dynamodb_sessions():
    """Check the current state of DynamoDB sessions"""
    
    print("\n\n🔍 CHECKING DYNAMODB SESSIONS")
    print("=" * 40)
    
    import boto3
    
    try:
        dynamodb = boto3.resource('dynamodb', region_name='us-east-1')
        table = dynamodb.Table('user_active_sessions')
        
        response = table.scan()
        items = response.get('Items', [])
        
        print(f"Total active sessions: {len(items)}")
        
        for item in items:
            username = item.get('username', 'Unknown')
            status = item.get('status', 'Unknown')
            login_time = item.get('login_time', 'Unknown')
            last_activity = item.get('last_activity', 'Unknown')
            
            print(f"\n👤 {username}")
            print(f"   Status: {status}")
            print(f"   Login: {login_time}")
            print(f"   Last Activity: {last_activity}")
            
    except Exception as e:
        print(f"❌ Error checking DynamoDB: {e}")

if __name__ == "__main__":
    test_user_session_tracking()
    check_dynamodb_sessions()
