#!/usr/bin/env python3

import re

# Read the original file
with open('/home/chatbot/Redington-chatbot/backend/services/dynamodb_service.py', 'r') as f:
    content = f.read()

# Define the new delete_chat_session function
new_delete_function = '''    def delete_chat_session(self, user_id: str, chat_id: str) -> bool:
        """
        Deletes a chat session and all its messages from DynamoDB
        Enhanced to ensure complete deletion and prevent reappearing sessions
        """
        if not user_id or not chat_id:
            raise ValueError("User ID and Chat ID are required")
        
        try:
            # First, delete all messages for this chat
            self._delete_chat_messages(user_id, chat_id)
            
            # Delete the main chat session metadata
            self.user_chat_sessions_table.delete_item(
                Key={
                    'user_id': user_id,
                    'chat_id': chat_id
                }
            )
            
            # Also check for and delete any SESSION# entries (from session_manager)
            try:
                response = self.user_chat_sessions_table.query(
                    KeyConditionExpression=Key('user_id').eq(user_id)
                )
                
                # Delete any entries that match this session_id
                with self.user_chat_sessions_table.batch_writer() as batch:
                    for item in response.get("Items", []):
                        item_chat_id = item.get("chat_id", "")
                        # Check if this item is related to the session we're deleting
                        if (item_chat_id.startswith(f"SESSION#{chat_id}") or 
                            item.get("session_id") == chat_id or
                            item_chat_id == chat_id):
                            batch.delete_item(
                                Key={
                                    "user_id": user_id,
                                    "chat_id": item_chat_id
                                }
                            )
                            print(f"🗑️ Deleted additional session entry: {item_chat_id}")
                            
            except Exception as e:
                print(f"Warning: Could not clean up additional session entries: {e}")
            
            print(f"✅ Chat session {chat_id} completely deleted for user {user_id}")
            return True
            
        except ClientError as e:
            raise Exception(f"Error deleting chat session: {e.response['Error']['Message']}")'''

# Define the new _delete_chat_messages function
new_delete_messages_function = '''    def _delete_chat_messages(self, user_id: str, chat_id: str):
        """
        Helper function to delete all messages for a specific chat
        Enhanced to handle different message formats
        """
        try:
            # Query all messages for this chat (format: chat_id#timestamp)
            response = self.chat_history_table.query(
                KeyConditionExpression=Key('user_id').eq(user_id) & Key('chat_message_id').begins_with(f"{chat_id}#")
            )
            
            # Delete each message
            with self.chat_history_table.batch_writer() as batch:
                for item in response.get('Items', []):
                    batch.delete_item(
                        Key={
                            'user_id': item['user_id'],
                            'chat_message_id': item['chat_message_id']
                        }
                    )
            
            # Also check for MESSAGE# format entries (from session_manager)
            try:
                response = self.user_chat_sessions_table.query(
                    KeyConditionExpression=Key('user_id').eq(user_id)
                )
                
                with self.user_chat_sessions_table.batch_writer() as batch:
                    for item in response.get("Items", []):
                        item_chat_id = item.get("chat_id", "")
                        if item_chat_id.startswith(f"MESSAGE#{chat_id}"):
                            batch.delete_item(
                                Key={
                                    "user_id": user_id,
                                    "chat_id": item_chat_id
                                }
                            )
                            print(f"🗑️ Deleted message entry: {item_chat_id}")
                            
            except Exception as e:
                print(f"Warning: Could not clean up MESSAGE entries: {e}")
                
        except ClientError as e:
            raise Exception(f"Error deleting chat messages: {e.response['Error']['Message']}")'''

# Replace the delete_chat_session function
pattern = r'    def delete_chat_session\(self, user_id: str, chat_id: str\) -> bool:.*?(?=    def |\Z)'
content = re.sub(pattern, new_delete_function + '\n\n', content, flags=re.DOTALL)

# Replace the _delete_chat_messages function
pattern = r'    def _delete_chat_messages\(self, user_id: str, chat_id: str\):.*?(?=    def |\Z)'
content = re.sub(pattern, new_delete_messages_function + '\n\n', content, flags=re.DOTALL)

# Write the updated content back to the file
with open('/home/chatbot/Redington-chatbot/backend/services/dynamodb_service.py', 'w') as f:
    f.write(content)

print("✅ Successfully updated delete functions in dynamodb_service.py")
