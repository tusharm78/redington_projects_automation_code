#!/usr/bin/env python3
"""
Redington Chatbot System Monitor
Monitors CPU, Memory, Disk usage and provides scaling recommendations
"""

import psutil
import time
import json
import os
import subprocess
import logging
from datetime import datetime, timedelta
from typing import Dict, List, Any
import boto3
from botocore.exceptions import ClientError

# Configure logging
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(levelname)s - %(message)s',
    handlers=[
        logging.FileHandler('/home/chatbot/Redington-chatbot/system_monitor.log'),
        logging.StreamHandler()
    ]
)
logger = logging.getLogger(__name__)

class SystemMonitor:
    def __init__(self):
        self.start_time = time.time()
        self.metrics_history = []
        self.alert_thresholds = {
            'cpu_percent': 80,
            'memory_percent': 85,
            'disk_percent': 90,
            'response_time': 5.0  # seconds
        }
        
    def get_process_info(self) -> Dict[str, Any]:
        """Get information about chatbot processes"""
        processes = {
            'backend': [],
            'frontend': [],
            'admin_apis': [],
            'total_processes': 0
        }
        
        for proc in psutil.process_iter(['pid', 'name', 'cmdline', 'cpu_percent', 'memory_percent', 'memory_info']):
            try:
                cmdline = ' '.join(proc.info['cmdline']) if proc.info['cmdline'] else ''
                
                # Backend processes
                if 'enhanced_bedrock_main' in cmdline or 'uvicorn' in cmdline:
                    processes['backend'].append({
                        'pid': proc.info['pid'],
                        'name': proc.info['name'],
                        'cpu_percent': proc.info['cpu_percent'],
                        'memory_percent': proc.info['memory_percent'],
                        'memory_mb': proc.info['memory_info'].rss / 1024 / 1024,
                        'cmdline': cmdline[:100] + '...' if len(cmdline) > 100 else cmdline
                    })
                
                # Admin API processes
                elif any(api in cmdline for api in ['admin_api.py', 'simple_admin_api.py', 'realtime_admin_api.py', 'secure_admin_api.py']):
                    processes['admin_apis'].append({
                        'pid': proc.info['pid'],
                        'name': proc.info['name'],
                        'cpu_percent': proc.info['cpu_percent'],
                        'memory_percent': proc.info['memory_percent'],
                        'memory_mb': proc.info['memory_info'].rss / 1024 / 1024,
                        'cmdline': cmdline[:100] + '...' if len(cmdline) > 100 else cmdline
                    })
                
                # Frontend processes (Node.js/React)
                elif 'node' in proc.info['name'] and ('react' in cmdline or '3000' in cmdline):
                    processes['frontend'].append({
                        'pid': proc.info['pid'],
                        'name': proc.info['name'],
                        'cpu_percent': proc.info['cpu_percent'],
                        'memory_percent': proc.info['memory_percent'],
                        'memory_mb': proc.info['memory_info'].rss / 1024 / 1024,
                        'cmdline': cmdline[:100] + '...' if len(cmdline) > 100 else cmdline
                    })
                    
            except (psutil.NoSuchProcess, psutil.AccessDenied):
                continue
        
        processes['total_processes'] = len(processes['backend']) + len(processes['frontend']) + len(processes['admin_apis'])
        return processes
    
    def get_system_metrics(self) -> Dict[str, Any]:
        """Get comprehensive system metrics"""
        # CPU metrics
        cpu_percent = psutil.cpu_percent(interval=1)
        cpu_count = psutil.cpu_count()
        load_avg = os.getloadavg()
        
        # Memory metrics
        memory = psutil.virtual_memory()
        swap = psutil.swap_memory()
        
        # Disk metrics
        disk = psutil.disk_usage('/')
        disk_io = psutil.disk_io_counters()
        
        # Network metrics
        network = psutil.net_io_counters()
        
        # Process metrics
        process_info = self.get_process_info()
        
        metrics = {
            'timestamp': datetime.now().isoformat(),
            'uptime_hours': (time.time() - self.start_time) / 3600,
            'cpu': {
                'percent': cpu_percent,
                'count': cpu_count,
                'load_avg_1m': load_avg[0],
                'load_avg_5m': load_avg[1],
                'load_avg_15m': load_avg[2]
            },
            'memory': {
                'total_gb': memory.total / 1024**3,
                'used_gb': memory.used / 1024**3,
                'available_gb': memory.available / 1024**3,
                'percent': memory.percent,
                'swap_used_gb': swap.used / 1024**3 if swap.total > 0 else 0,
                'swap_percent': swap.percent if swap.total > 0 else 0
            },
            'disk': {
                'total_gb': disk.total / 1024**3,
                'used_gb': disk.used / 1024**3,
                'free_gb': disk.free / 1024**3,
                'percent': (disk.used / disk.total) * 100,
                'read_mb': disk_io.read_bytes / 1024**2 if disk_io else 0,
                'write_mb': disk_io.write_bytes / 1024**2 if disk_io else 0
            },
            'network': {
                'bytes_sent_mb': network.bytes_sent / 1024**2,
                'bytes_recv_mb': network.bytes_recv / 1024**2,
                'packets_sent': network.packets_sent,
                'packets_recv': network.packets_recv
            },
            'processes': process_info
        }
        
        return metrics
    
    def check_alerts(self, metrics: Dict[str, Any]) -> List[str]:
        """Check for alert conditions"""
        alerts = []
        
        if metrics['cpu']['percent'] > self.alert_thresholds['cpu_percent']:
            alerts.append(f"HIGH CPU: {metrics['cpu']['percent']:.1f}% (threshold: {self.alert_thresholds['cpu_percent']}%)")
        
        if metrics['memory']['percent'] > self.alert_thresholds['memory_percent']:
            alerts.append(f"HIGH MEMORY: {metrics['memory']['percent']:.1f}% (threshold: {self.alert_thresholds['memory_percent']}%)")
        
        if metrics['disk']['percent'] > self.alert_thresholds['disk_percent']:
            alerts.append(f"HIGH DISK: {metrics['disk']['percent']:.1f}% (threshold: {self.alert_thresholds['disk_percent']}%)")
        
        if metrics['cpu']['load_avg_5m'] > metrics['cpu']['count']:
            alerts.append(f"HIGH LOAD: {metrics['cpu']['load_avg_5m']:.2f} (CPU cores: {metrics['cpu']['count']})")
        
        return alerts
    
    def get_scaling_recommendations(self, metrics: Dict[str, Any]) -> List[str]:
        """Provide scaling recommendations based on current metrics"""
        recommendations = []
        
        # CPU recommendations
        if metrics['cpu']['percent'] > 70:
            recommendations.append("🔴 CPU Usage High: Consider horizontal scaling or upgrading instance type")
        elif metrics['cpu']['percent'] > 50:
            recommendations.append("🟡 CPU Usage Moderate: Monitor for sustained high usage")
        
        # Memory recommendations
        if metrics['memory']['percent'] > 80:
            recommendations.append("🔴 Memory Usage High: Consider adding more RAM or optimizing memory usage")
        elif metrics['memory']['percent'] > 60:
            recommendations.append("🟡 Memory Usage Moderate: Monitor for memory leaks")
        
        # Process recommendations
        total_backend_processes = len(metrics['processes']['backend'])
        total_admin_processes = len(metrics['processes']['admin_apis'])
        
        if total_backend_processes > 3:
            recommendations.append(f"⚠️  Multiple backend processes detected ({total_backend_processes}): Consider consolidating")
        
        if total_admin_processes > 2:
            recommendations.append(f"⚠️  Multiple admin APIs running ({total_admin_processes}): Consider using one unified API")
        
        # Disk recommendations
        if metrics['disk']['percent'] > 85:
            recommendations.append("🔴 Disk Usage High: Clean up logs, temporary files, or add storage")
        
        return recommendations
    
    def estimate_user_capacity(self, metrics: Dict[str, Any]) -> Dict[str, Any]:
        """Estimate how many concurrent users the system can handle"""
        
        # Base estimates (conservative)
        cpu_capacity = max(1, int((100 - metrics['cpu']['percent']) / 5))  # ~5% CPU per user
        memory_capacity = max(1, int((metrics['memory']['available_gb'] * 1024) / 50))  # ~50MB per user
        
        # Consider current load
        current_users = self.get_active_users_count()
        
        capacity_estimate = {
            'current_active_users': current_users,
            'estimated_max_users_cpu': cpu_capacity,
            'estimated_max_users_memory': memory_capacity,
            'recommended_max_users': min(cpu_capacity, memory_capacity),
            'scaling_needed_at': min(cpu_capacity, memory_capacity) * 0.8,  # Scale at 80% capacity
            'current_utilization_percent': (current_users / max(1, min(cpu_capacity, memory_capacity))) * 100
        }
        
        return capacity_estimate
    
    def get_active_users_count(self) -> int:
        """Get count of active users from DynamoDB or estimate from processes"""
        try:
            # Try to get from DynamoDB
            dynamodb = boto3.resource('dynamodb', region_name='us-east-1')
            table = dynamodb.Table('user_active_sessions')
            response = table.scan()
            return len(response.get('Items', []))
        except Exception:
            # Fallback: estimate from process activity
            return max(1, len(self.get_process_info()['backend']))
    
    def generate_report(self) -> str:
        """Generate a comprehensive monitoring report"""
        metrics = self.get_system_metrics()
        alerts = self.check_alerts(metrics)
        recommendations = self.get_scaling_recommendations(metrics)
        capacity = self.estimate_user_capacity(metrics)
        
        report = f"""
╔══════════════════════════════════════════════════════════════════════════════╗
║                    REDINGTON CHATBOT SYSTEM MONITOR                         ║
║                        {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}                              ║
╚══════════════════════════════════════════════════════════════════════════════╝

📊 SYSTEM RESOURCES:
├─ CPU Usage: {metrics['cpu']['percent']:.1f}% ({metrics['cpu']['count']} cores)
├─ Load Average: {metrics['cpu']['load_avg_1m']:.2f}, {metrics['cpu']['load_avg_5m']:.2f}, {metrics['cpu']['load_avg_15m']:.2f}
├─ Memory: {metrics['memory']['used_gb']:.1f}GB / {metrics['memory']['total_gb']:.1f}GB ({metrics['memory']['percent']:.1f}%)
├─ Disk: {metrics['disk']['used_gb']:.1f}GB / {metrics['disk']['total_gb']:.1f}GB ({metrics['disk']['percent']:.1f}%)
└─ Network: ↑{metrics['network']['bytes_sent_mb']:.1f}MB ↓{metrics['network']['bytes_recv_mb']:.1f}MB

🔧 CHATBOT PROCESSES:
├─ Backend Processes: {len(metrics['processes']['backend'])}
├─ Admin API Processes: {len(metrics['processes']['admin_apis'])}
├─ Frontend Processes: {len(metrics['processes']['frontend'])}
└─ Total Chatbot Processes: {metrics['processes']['total_processes']}

👥 USER CAPACITY ANALYSIS:
├─ Current Active Users: {capacity['current_active_users']}
├─ Estimated Max Users (CPU): {capacity['estimated_max_users_cpu']}
├─ Estimated Max Users (Memory): {capacity['estimated_max_users_memory']}
├─ Recommended Max Users: {capacity['recommended_max_users']}
├─ Scale at User Count: {int(capacity['scaling_needed_at'])}
└─ Current Utilization: {capacity['current_utilization_percent']:.1f}%

"""
        
        if alerts:
            report += "🚨 ALERTS:\n"
            for alert in alerts:
                report += f"├─ {alert}\n"
            report += "\n"
        
        if recommendations:
            report += "💡 RECOMMENDATIONS:\n"
            for rec in recommendations:
                report += f"├─ {rec}\n"
            report += "\n"
        
        # Process details
        if metrics['processes']['backend']:
            report += "🖥️  BACKEND PROCESSES:\n"
            for proc in metrics['processes']['backend']:
                report += f"├─ PID {proc['pid']}: CPU {proc['cpu_percent']:.1f}%, RAM {proc['memory_mb']:.1f}MB\n"
            report += "\n"
        
        if metrics['processes']['admin_apis']:
            report += "⚙️  ADMIN API PROCESSES:\n"
            for proc in metrics['processes']['admin_apis']:
                report += f"├─ PID {proc['pid']}: CPU {proc['cpu_percent']:.1f}%, RAM {proc['memory_mb']:.1f}MB\n"
            report += "\n"
        
        report += f"📈 MONITORING UPTIME: {metrics['uptime_hours']:.1f} hours\n"
        report += "═" * 80 + "\n"
        
        return report
    
    def save_metrics(self, metrics: Dict[str, Any]):
        """Save metrics to file for historical analysis"""
        metrics_file = '/home/chatbot/Redington-chatbot/metrics_history.json'
        
        try:
            if os.path.exists(metrics_file):
                with open(metrics_file, 'r') as f:
                    history = json.load(f)
            else:
                history = []
            
            history.append(metrics)
            
            # Keep only last 24 hours of data
            cutoff_time = datetime.now() - timedelta(hours=24)
            history = [m for m in history if datetime.fromisoformat(m['timestamp']) > cutoff_time]
            
            with open(metrics_file, 'w') as f:
                json.dump(history, f, indent=2)
                
        except Exception as e:
            logger.error(f"Failed to save metrics: {e}")

def main():
    monitor = SystemMonitor()
    
    try:
        # Generate and display report
        report = monitor.generate_report()
        print(report)
        
        # Save metrics for historical analysis
        metrics = monitor.get_system_metrics()
        monitor.save_metrics(metrics)
        
        # Log to file
        logger.info("System monitoring report generated successfully")
        
    except Exception as e:
        logger.error(f"Error generating monitoring report: {e}")
        print(f"❌ Error: {e}")

if __name__ == "__main__":
    main()
