#!/usr/bin/env python3

import requests
import json
import sys
import os

sys.path.append('/home/chatbot/Redington-chatbot/backend')

def test_complete_flow():
    """Test the complete session management flow"""
    
    base_url = "http://localhost:8000/api/v1"
    
    print("=== COMPLETE SESSION MANAGEMENT TEST ===\n")
    
    # Test 1: Login to get a valid token
    print("1. Testing Login...")
    login_data = {
        "username": "akhil",
        "password": "akhil123"  # Replace with actual password
    }
    
    try:
        response = requests.post(f"{base_url}/auth/login", json=login_data, timeout=10)
        if response.status_code == 200:
            token_data = response.json()
            token = token_data.get('access_token')
            print(f"✅ Login successful, token: {token[:20]}...")
        else:
            print(f"❌ Login failed: {response.status_code} - {response.text}")
            return
    except Exception as e:
        print(f"❌ Login error: {e}")
        return
    
    headers = {
        "Authorization": f"Bearer {token}",
        "Content-Type": "application/json"
    }
    
    # Test 2: Get sessions
    print("\n2. Testing Get Sessions...")
    try:
        response = requests.get(f"{base_url}/sessions", headers=headers, timeout=10)
        if response.status_code == 200:
            sessions = response.json()
            print(f"✅ Sessions retrieved: {len(sessions)} sessions")
            print(f"   Sessions: {sessions}")
        else:
            print(f"❌ Get sessions failed: {response.status_code} - {response.text}")
            return
    except Exception as e:
        print(f"❌ Get sessions error: {e}")
        return
    
    # Test 3: Create a new session
    print("\n3. Testing Create Session...")
    try:
        create_data = {"title": "Test Session"}
        response = requests.post(f"{base_url}/sessions", json=create_data, headers=headers, timeout=10)
        if response.status_code == 200:
            create_result = response.json()
            new_chat_id = create_result.get('chat_id')
            print(f"✅ Session created: {new_chat_id}")
        else:
            print(f"❌ Create session failed: {response.status_code} - {response.text}")
            return
    except Exception as e:
        print(f"❌ Create session error: {e}")
        return
    
    # Test 4: Get sessions again to verify new session
    print("\n4. Testing Get Sessions After Create...")
    try:
        response = requests.get(f"{base_url}/sessions", headers=headers, timeout=10)
        if response.status_code == 200:
            sessions_after = response.json()
            print(f"✅ Sessions after create: {len(sessions_after)} sessions")
            if new_chat_id in sessions_after:
                print(f"✅ New session found in list: {sessions_after[new_chat_id]}")
            else:
                print(f"❌ New session NOT found in list")
        else:
            print(f"❌ Get sessions after create failed: {response.status_code}")
    except Exception as e:
        print(f"❌ Get sessions after create error: {e}")
    
    # Test 5: Delete the session
    print("\n5. Testing Delete Session...")
    try:
        response = requests.delete(f"{base_url}/sessions/{new_chat_id}", headers=headers, timeout=10)
        if response.status_code == 200:
            print(f"✅ Session deleted successfully")
        else:
            print(f"❌ Delete session failed: {response.status_code} - {response.text}")
    except Exception as e:
        print(f"❌ Delete session error: {e}")
    
    # Test 6: Verify deletion
    print("\n6. Testing Get Sessions After Delete...")
    try:
        response = requests.get(f"{base_url}/sessions", headers=headers, timeout=10)
        if response.status_code == 200:
            sessions_final = response.json()
            print(f"✅ Sessions after delete: {len(sessions_final)} sessions")
            if new_chat_id not in sessions_final:
                print(f"✅ Deleted session NOT found in list (correct)")
            else:
                print(f"❌ Deleted session still found in list")
        else:
            print(f"❌ Get sessions after delete failed: {response.status_code}")
    except Exception as e:
        print(f"❌ Get sessions after delete error: {e}")
    
    print("\n=== TEST COMPLETE ===")

if __name__ == "__main__":
    test_complete_flow()
