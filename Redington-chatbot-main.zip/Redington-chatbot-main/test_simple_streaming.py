#!/usr/bin/env python3
import socketio
import asyncio
import time

# Create a Socket.IO client
sio = socketio.AsyncClient(logger=False, engineio_logger=False)

streaming_content = ""
is_complete = False

@sio.event
async def connect():
    print("🔌 Connected to Redington AI Streaming Server!")
    print("🚀 Testing streaming functionality...")
    print("=" * 60)
    
    # Send a test message
    test_message = "Tell me about Redington"
    print(f"📤 Sending: '{test_message}'")
    print("📥 Streaming response:")
    print("-" * 40)
    
    await sio.emit('send_message', {
        'message': test_message,
        'conversation_id': 'test-conversation',
        'session_id': 'test-session'
    })

@sio.event
async def auth_success(data):
    print(f"✅ Auto-authenticated as: {data.get('user', 'demo-user')}")

@sio.event
async def chat_start(data):
    global streaming_content
    print("🚀 Response started streaming...")
    print("💬 AI: ", end="", flush=True)
    streaming_content = ""

@sio.event
async def chat_chunk(data):
    global streaming_content, is_complete
    
    if data.get('is_complete'):
        print(f"\n\n✅ Streaming complete!")
        print(f"📊 Total characters: {len(streaming_content)}")
        print("=" * 60)
        print("🎉 STREAMING TEST SUCCESSFUL!")
        print("=" * 60)
        is_complete = True
    else:
        chunk = data.get('chunk', '')
        streaming_content += chunk
        print(chunk, end="", flush=True)

@sio.event
async def chat_error(data):
    print(f"\n❌ Error: {data.get('error', 'Unknown error')}")

async def main():
    global is_complete
    print("🤖 Redington AI Streaming Test")
    print("=" * 40)
    
    try:
        await sio.connect('http://localhost:8000')
        
        # Wait for streaming to complete
        while not is_complete and sio.connected:
            await asyncio.sleep(0.1)
            
        await sio.disconnect()
        
    except Exception as e:
        print(f"❌ Test failed: {e}")
        return False
    
    return True

if __name__ == "__main__":
    success = asyncio.run(main())
    if success:
        print("\n🎯 You can now test the web interface!")
        print(f"   Open: file:///home/meenal/redington-chatbot/demo_streaming.html")
        print(f"   Or visit: http://localhost:4001 (React app)")
    else:
        print("\n❌ Test failed. Check if backend is running on port 8000")
