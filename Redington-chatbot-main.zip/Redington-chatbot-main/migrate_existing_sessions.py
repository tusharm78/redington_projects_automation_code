#!/usr/bin/env python3

import boto3
import json
import uuid
from datetime import datetime, timezone
from collections import defaultdict

def migrate_existing_sessions():
    """Migrate existing message records to proper session structure"""
    print("🔄 Starting migration of existing chat data...")
    
    dynamodb = boto3.resource("dynamodb", region_name="us-east-1")
    table = dynamodb.Table("user_chat_sessions")
    
    # Scan for all message records
    print("📊 Scanning for existing message records...")
    response = table.scan(
        FilterExpression="begins_with(chat_id, :prefix)",
        ExpressionAttributeValues={":prefix": "MESSAGE#"}
    )
    
    # Group messages by user and session
    user_sessions = defaultdict(lambda: defaultdict(list))
    
    for item in response["Items"]:
        user_id = item["user_id"]
        session_id = item.get("session_id", "")
        
        if session_id:
            user_sessions[user_id][session_id].append(item)
    
    print(f"📋 Found {len(user_sessions)} users with message data")
    
    # Create session records for each user/session combination
    for user_id, sessions in user_sessions.items():
        print(f"\n👤 Processing user: {user_id}")
        
        for session_id, messages in sessions.items():
            print(f"  📝 Processing session: {session_id} ({len(messages)} messages)")
            
            # Check if session record already exists
            try:
                existing = table.get_item(
                    Key={
                        "user_id": user_id,
                        "chat_id": f"SESSION#{session_id}"
                    }
                )
                
                if "Item" in existing:
                    print(f"    ✅ Session record already exists, skipping")
                    continue
                    
            except Exception as e:
                print(f"    ⚠️ Error checking existing session: {e}")
            
            # Sort messages by timestamp
            messages.sort(key=lambda x: x.get("timestamp", ""))
            
            if not messages:
                continue
                
            # Get session info from messages
            first_message = messages[0]
            last_message = messages[-1]
            
            # Create session title from first user message
            session_title = "Chat Session"
            for msg in messages:
                if msg.get("role") == "user":
                    content = msg.get("content", "")
                    if content:
                        session_title = content[:50] + "..." if len(content) > 50 else content
                        break
            
            # Create session record
            session_data = {
                "session_id": session_id,
                "username": user_id,
                "title": session_title,
                "created_at": first_message.get("timestamp", datetime.now(timezone.utc).isoformat()),
                "updated_at": last_message.get("timestamp", datetime.now(timezone.utc).isoformat()),
                "message_count": len(messages),
                "last_message": last_message.get("content", "")[:100] + "..." if len(last_message.get("content", "")) > 100 else last_message.get("content", "")
            }
            
            try:
                # Create the session record
                table.put_item(
                    Item={
                        "user_id": user_id,
                        "chat_id": f"SESSION#{session_id}",
                        "session_data": json.dumps(session_data),
                        "created_at": session_data["created_at"],
                        "updated_at": session_data["updated_at"],
                        "session_id": session_id,
                        "title": session_data["title"],
                        "message_count": session_data["message_count"],
                        "last_message": session_data["last_message"]
                    }
                )
                print(f"    ✅ Created session record for {session_id}")
                
            except Exception as e:
                print(f"    ❌ Error creating session record: {e}")
    
    print("\n🎉 Migration completed!")

if __name__ == "__main__":
    migrate_existing_sessions()
