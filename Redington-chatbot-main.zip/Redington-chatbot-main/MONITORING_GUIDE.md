# Redington Chatbot Resource Monitoring Guide

## 📊 Current Resource Consumption

Based on the system analysis, here's your chatbot's current resource usage:

### Current System State:
- **CPU Usage**: 0.0% (2 cores available)
- **Memory Usage**: 0.8GB / 7.6GB (14.1%)
- **Disk Usage**: 31.6GB / 47.4GB (66.7%)
- **Active Backend Processes**: 1 (using 82.4MB RAM)
- **Current Active Users**: 4
- **Estimated Max Concurrent Users**: 20

## 🎯 Resource Consumption Breakdown

### Backend (FastAPI + Python)
- **Base Memory**: ~80-100MB per process
- **Per User Memory**: ~50MB additional (for conversation history, file processing)
- **CPU Usage**: 
  - Idle: <5%
  - Per active user: ~5% CPU
  - File processing: 20-50% CPU spikes
- **Disk Usage**:
  - Temporary files: 10-100MB per file upload
  - Logs: 1-10MB per day
  - Model cache: 100-500MB

### Frontend (React)
- **Memory**: 30-50MB per user session
- **CPU**: Minimal (client-side rendering)
- **Network**: 1-5MB per user session

### AWS Services Consumption
- **Bedrock API**: Pay-per-token usage
- **DynamoDB**: Pay-per-request + storage
- **Cognito**: Pay-per-user authentication

## 📈 Scaling Impact Analysis

### With 10 Concurrent Users:
- **Expected CPU**: 25-50%
- **Expected Memory**: 1.5-2.0GB
- **Expected Response Time**: 1-2 seconds

### With 20 Concurrent Users (Current Limit):
- **Expected CPU**: 50-80%
- **Expected Memory**: 2.5-3.0GB
- **Expected Response Time**: 2-3 seconds

### With 50+ Users (Requires Scaling):
- **CPU**: 100%+ (bottleneck)
- **Memory**: 4-6GB
- **Response Time**: 5+ seconds (degraded)

## 🛠️ Monitoring Tools

### 1. Real-time System Monitor
```bash
cd /home/chatbot/Redington-chatbot
python3 system_monitor.py
```

### 2. Continuous Monitoring (Live Dashboard)
```bash
cd /home/chatbot/Redington-chatbot
python3 continuous_monitor.py
```

### 3. Interactive Monitoring Dashboard
```bash
cd /home/chatbot/Redington-chatbot
./monitoring_dashboard.sh
```

### 4. Load Testing
```bash
cd /home/chatbot/Redington-chatbot
# Test with 5 users for 60 seconds
python3 load_test.py --users 5 --duration 60 --ramp-up 30

# Test with 10 users for 5 minutes
python3 load_test.py --users 10 --duration 300 --ramp-up 60
```

## 🚨 Alert Thresholds

The monitoring system will alert when:
- **CPU Usage** > 80%
- **Memory Usage** > 85%
- **Disk Usage** > 90%
- **Response Time** > 5 seconds
- **Load Average** > CPU cores

## 📊 Key Metrics to Monitor

### System Metrics
1. **CPU Utilization**: Should stay below 70% for good performance
2. **Memory Usage**: Should stay below 80% to avoid swapping
3. **Disk Space**: Should stay below 85% for system stability
4. **Load Average**: Should be below number of CPU cores

### Application Metrics
1. **Active Users**: Current number of logged-in users
2. **Response Times**: Average API response time
3. **Error Rates**: Failed requests percentage
4. **Process Count**: Number of running chatbot processes

### Business Metrics
1. **Concurrent Sessions**: Peak concurrent users
2. **Messages per Hour**: Chat activity volume
3. **File Uploads**: File processing load
4. **Session Duration**: Average user session length

## 🔧 Performance Optimization Recommendations

### Current System (Good Performance):
- ✅ CPU usage is very low (0%)
- ✅ Memory usage is healthy (14.1%)
- ⚠️ Disk usage is moderate (66.7%) - monitor growth
- ✅ Single backend process is sufficient

### When to Scale:

#### Vertical Scaling (Upgrade Instance):
- CPU usage consistently > 70%
- Memory usage > 80%
- Response times > 3 seconds

#### Horizontal Scaling (Add Instances):
- Users > 20 concurrent
- Load balancer needed
- Database connection pooling required

#### Optimization Actions:
1. **Memory Optimization**:
   - Implement conversation history limits
   - Add file cleanup routines
   - Use Redis for session storage

2. **CPU Optimization**:
   - Implement async processing for file uploads
   - Add request queuing
   - Cache frequently accessed data

3. **Disk Optimization**:
   - Implement log rotation
   - Clean up temporary files
   - Move large files to S3

## 📈 Monitoring Automation

### Set up Continuous Monitoring:
```bash
# Run in background
nohup python3 continuous_monitor.py > monitor.log 2>&1 &

# Or use systemd service (recommended)
sudo cp monitoring.service /etc/systemd/system/
sudo systemctl enable monitoring.service
sudo systemctl start monitoring.service
```

### Automated Alerts:
The monitoring system can be extended to send:
- Email notifications
- Slack/Teams messages
- AWS SNS notifications
- PagerDuty alerts

## 🎯 Capacity Planning

### Current Capacity:
- **Recommended Max Users**: 20 concurrent
- **Scale Threshold**: 16 users (80% capacity)
- **Current Utilization**: 20% (4/20 users)

### Growth Planning:
- **25-50 users**: Upgrade to larger instance (4-8 CPU cores, 16-32GB RAM)
- **50-100 users**: Implement horizontal scaling with load balancer
- **100+ users**: Multi-region deployment with CDN

## 📋 Daily Monitoring Checklist

### Morning Check:
- [ ] Run system monitor
- [ ] Check alert logs
- [ ] Review overnight metrics
- [ ] Verify all processes running

### During Peak Hours:
- [ ] Monitor real-time dashboard
- [ ] Check response times
- [ ] Monitor active user count
- [ ] Watch for alerts

### End of Day:
- [ ] Review daily metrics
- [ ] Check disk space growth
- [ ] Archive old logs
- [ ] Plan capacity if needed

## 🚀 Quick Commands

### Check System Status:
```bash
# Quick system overview
./monitoring_dashboard.sh

# One-time system check
python3 system_monitor.py

# Check running processes
ps aux | grep -E "(python|bedrock|admin)" | grep -v grep
```

### Performance Testing:
```bash
# Light load test (5 users)
python3 load_test.py --users 5 --duration 60

# Stress test (current capacity)
python3 load_test.py --users 20 --duration 300

# Find breaking point
python3 load_test.py --users 30 --duration 180
```

### Emergency Actions:
```bash
# Kill all monitoring
pkill -f "monitor"

# Restart chatbot services
./monitoring_dashboard.sh  # Option 8

# Check system resources
free -h && df -h && top -bn1 | head -10
```

## 📊 Cost Monitoring

### AWS Costs to Monitor:
1. **EC2 Instance**: Fixed monthly cost
2. **Bedrock API**: Per-token usage
3. **DynamoDB**: Per-request + storage
4. **Data Transfer**: Network usage
5. **CloudWatch**: Monitoring costs

### Cost Optimization:
- Monitor Bedrock token usage
- Implement conversation limits
- Use DynamoDB on-demand pricing
- Optimize file storage

---

## 🎉 Summary

Your Redington chatbot is currently running efficiently with:
- **Low resource usage** (plenty of headroom)
- **Good performance** (sub-second response times)
- **Scalable architecture** (can handle 20 concurrent users)
- **Comprehensive monitoring** (real-time alerts and dashboards)

The monitoring tools provided will help you:
- Track resource consumption in real-time
- Get alerts before issues occur
- Plan capacity for growth
- Optimize performance proactively

Use the monitoring dashboard regularly and set up continuous monitoring for production environments!
