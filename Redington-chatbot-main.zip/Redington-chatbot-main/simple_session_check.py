#!/usr/bin/env python3
"""
Simple diagnostic script to check DynamoDB session issues
"""

import boto3
import json
from boto3.dynamodb.conditions import Key

def check_sessions():
    """Check DynamoDB sessions"""
    
    print("🔍 Checking DynamoDB Sessions")
    print("=" * 40)
    
    try:
        # Connect to DynamoDB
        dynamodb = boto3.resource("dynamodb", region_name="us-east-1")
        table = dynamodb.Table("user_chat_sessions")
        
        print("✅ Connected to DynamoDB")
        
        # Scan all items
        response = table.scan()
        items = response.get('Items', [])
        
        print(f"📊 Total items in table: {len(items)}")
        
        # Separate sessions and messages
        sessions = []
        messages = []
        
        for item in items:
            chat_id = item.get('chat_id', '')
            if chat_id.startswith('SESSION#'):
                sessions.append(item)
            elif chat_id.startswith('MESSAGE#'):
                messages.append(item)
        
        print(f"📊 Sessions: {len(sessions)}")
        print(f"📊 Messages: {len(messages)}")
        print()
        
        # Check for empty sessions
        empty_sessions = 0
        sessions_with_messages = 0
        
        print("📋 Session Analysis:")
        for session in sessions:
            session_id = session.get('session_id', 'unknown')
            title = session.get('title', 'No title')
            message_count = session.get('message_count', 0)
            user_id = session.get('user_id', 'unknown')
            
            print(f"  Session: {session_id}")
            print(f"    User: {user_id}")
            print(f"    Title: {title}")
            print(f"    Message Count: {message_count}")
            
            if message_count == 0:
                empty_sessions += 1
                print(f"    ⚠️  EMPTY SESSION")
            else:
                sessions_with_messages += 1
                print(f"    ✅ Has messages")
            print()
        
        print("📊 Summary:")
        print(f"  Total sessions: {len(sessions)}")
        print(f"  Sessions with messages: {sessions_with_messages}")
        print(f"  Empty sessions: {empty_sessions}")
        
        if empty_sessions > 0:
            print(f"\n⚠️  ISSUE: {empty_sessions} empty sessions found!")
            print("   These sessions appear in the chat panel but have no content")
        
        return {
            'total_sessions': len(sessions),
            'empty_sessions': empty_sessions,
            'sessions_with_messages': sessions_with_messages
        }
        
    except Exception as e:
        print(f"❌ Error: {e}")
        return None

if __name__ == "__main__":
    result = check_sessions()
    
    if result and result['empty_sessions'] > 0:
        print("\n🔧 RECOMMENDATION:")
        print("   The empty sessions are causing sync issues between the chat panel and DynamoDB")
        print("   These sessions should be cleaned up or prevented from being created")
