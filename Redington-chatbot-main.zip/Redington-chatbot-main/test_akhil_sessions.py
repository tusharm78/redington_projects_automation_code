#!/usr/bin/env python3
"""
Test script to verify akhil's sessions are accessible via API
"""

import requests
import json

def test_akhil_sessions():
    """Test if akhil's sessions are accessible via the API"""
    
    # First, let's test the authentication
    auth_url = "http://localhost:8000/api/v1/auth/login"
    auth_data = {
        "username": "akhil.kandari@redingtongroup.com",
        "password": "Akhil@987"
    }
    
    print("Testing authentication...")
    try:
        auth_response = requests.post(auth_url, json=auth_data, timeout=10)
        print(f"Auth response status: {auth_response.status_code}")
        
        if auth_response.status_code == 200:
            auth_result = auth_response.json()
            access_token = auth_result.get('access_token')
            print("✅ Authentication successful!")
            
            # Test sessions endpoint
            sessions_url = "http://localhost:8000/api/v1/sessions"
            headers = {"Authorization": f"Bearer {access_token}"}
            
            print("\nTesting sessions endpoint...")
            sessions_response = requests.get(sessions_url, headers=headers, timeout=10)
            print(f"Sessions response status: {sessions_response.status_code}")
            
            if sessions_response.status_code == 200:
                sessions_result = sessions_response.json()
                sessions = sessions_result.get('sessions', [])
                print(f"✅ Found {len(sessions)} sessions for akhil!")
                
                print("\nSession details:")
                for i, session in enumerate(sessions, 1):
                    print(f"  {i}. {session.get('name', 'Untitled')} (ID: {session.get('id', 'N/A')})")
                    print(f"     Created: {session.get('created_at', 'N/A')}")
                    print(f"     Messages: {session.get('message_count', 0)}")
                    print()
                
                return len(sessions) > 0
            else:
                print(f"❌ Sessions endpoint failed: {sessions_response.text}")
                return False
        else:
            print(f"❌ Authentication failed: {auth_response.text}")
            return False
            
    except requests.exceptions.RequestException as e:
        print(f"❌ Request failed: {e}")
        return False

if __name__ == "__main__":
    print("TESTING AKHIL'S SESSION ACCESS")
    print("==============================")
    
    success = test_akhil_sessions()
    
    if success:
        print("\n🎉 SUCCESS! Akhil should now be able to see his chat history in the left panel!")
    else:
        print("\n❌ FAILED! There may be an issue with the backend or authentication.")
