#!/usr/bin/env python3
import requests
import json
import time

def test_streaming():
    print("🚀 Testing Redington AI Chatbot Streaming on EC2")
    print("=" * 50)
    
    # Test health endpoint
    try:
        health_response = requests.get("http://localhost:8000/health", timeout=5)
        health_data = health_response.json()
        print(f"✅ Backend Status: {health_data.get(service, Unknown)}")
        print(f"✅ Bedrock Status: {health_data.get(bedrock_status, Unknown)}")
        print(f"✅ Model: {health_data.get(model, Unknown)}")
        print(f"✅ Cognito: {health_data.get(cognito_configured, False)}")
        print(f"✅ DynamoDB: {health_data.get(dynamodb_configured, False)}")
        print()
    except Exception as e:
        print(f"❌ Health check failed: {e}")
        return
    
    # Test streaming endpoint (without auth - should get auth error)
    print("🧪 Testing streaming endpoint accessibility...")
    try:
        stream_response = requests.post(
            "http://localhost:8000/api/v1/chat/stream",
            json={"message": "Hello, test streaming"},
            timeout=10
        )
        
        if stream_response.status_code == 401:
            print("✅ Streaming endpoint accessible (correctly requires authentication)")
        elif stream_response.status_code == 200:
            print("✅ Streaming endpoint accessible and responding")
        else:
            print(f"⚠️  Streaming endpoint returned status: {stream_response.status_code}")
            
    except Exception as e:
        print(f"❌ Streaming test failed: {e}")
    
    # Test API documentation
    print("\n📖 Testing API documentation...")
    try:
        docs_response = requests.get("http://localhost:8000/docs", timeout=5)
        if docs_response.status_code == 200:
            print("✅ API documentation accessible at http://3.7.77.93:8000/docs")
        else:
            print(f"⚠️  API docs returned status: {docs_response.status_code}")
    except Exception as e:
        print(f"❌ API docs test failed: {e}")
    
    print("\n🎉 Streaming functionality test completed!")
    print("📱 Access your application at: http://3.7.77.93:3000")
    print("🔧 Backend API at: http://3.7.77.93:8000")
    print("📖 API Documentation: http://3.7.77.93:8000/docs")

if __name__ == "__main__":
    test_streaming()
