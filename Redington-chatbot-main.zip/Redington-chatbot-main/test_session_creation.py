#!/usr/bin/env python3

import asyncio
import sys
import os
sys.path.append('/home/chatbot/Redington-chatbot/backend')

from session_manager import SessionManager

async def test_session_creation():
    """Test session creation and retrieval"""
    print("🧪 Testing session creation and retrieval...")
    
    session_manager = SessionManager()
    
    # Test user
    username = "test_user"
    
    print(f"\n1. Creating session for user: {username}")
    session_id = await session_manager.create_session(username, "Test Chat Session")
    print(f"✅ Created session: {session_id}")
    
    print(f"\n2. Getting user sessions for: {username}")
    sessions = await session_manager.get_user_sessions(username)
    print(f"📋 Found {len(sessions)} sessions:")
    for session in sessions:
        print(f"   - {session}")
    
    print(f"\n3. Adding a test message to session: {session_id}")
    await session_manager.save_message(username, session_id, "user", "Hello, this is a test message")
    await session_manager.save_message(username, session_id, "assistant", "Hello! This is a test response.")
    
    print(f"\n4. Getting user sessions again (should now show session with messages):")
    sessions = await session_manager.get_user_sessions(username)
    print(f"📋 Found {len(sessions)} sessions:")
    for session in sessions:
        print(f"   - {session}")
    
    print(f"\n5. Getting messages for session: {session_id}")
    messages = await session_manager.get_session_messages(session_id)
    print(f"💬 Found {len(messages)} messages:")
    for msg in messages:
        print(f"   - {msg['role']}: {msg['content'][:50]}...")

if __name__ == "__main__":
    asyncio.run(test_session_creation())
