#!/bin/bash

echo "Starting React frontend for public IP access..."

cd frontend

# Set environment variables for public access
export DANGEROUSLY_DISABLE_HOST_CHECK=true
export HOST=0.0.0.0
export PORT=3000

# Start React development server with public access
npm start > frontend.log 2>&1 &

# Get the process ID
FRONTEND_PID=$!

echo "Frontend server started on http://0.0.0.0:3000"
echo "Public access: http://43.204.187.174:3000"
echo "PID: $FRONTEND_PID"
echo "Logs: frontend.log"

# Save PID for later use
echo $FRONTEND_PID > ../frontend.pid
