#!/bin/bash

# Start Frontend Server
cd /home/chatbot/Redington-chatbot/frontend

# Start React development server in background
nohup npm start > frontend.log 2>&1 &

echo "Frontend server started on http://localhost:3000"
echo "PID: $!"
echo "Logs: frontend.log"
