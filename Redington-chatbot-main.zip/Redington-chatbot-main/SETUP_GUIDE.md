# 🚀 Redington AI Chatbot - Complete Setup Guide

## 📦 Package Contents

This zip file contains the complete **Redington AI Chatbot** application with React frontend and FastAPI backend.

### 🎯 **What's Included:**
- ✅ **React Frontend** with TypeScript and Material-UI
- ✅ **FastAPI Backend** with Python
- ✅ **AWS Bedrock Integration** with LangChain
- ✅ **AWS Cognito Authentication**
- ✅ **File Processing** (PDF, DOCX, XLSX, CSV, TXT, Images)
- ✅ **Word Document Export** with professional formatting
- ✅ **Real-time Chat** with streaming responses
- ✅ **Conversation Management** with DynamoDB
- ✅ **RAG (Retrieval Augmented Generation)** support
- ✅ **Modern UI** with enhanced user experience

---

## 🛠️ **Prerequisites**

Before setting up the application, ensure you have:

### **System Requirements:**
- **Python 3.8+** (for backend)
- **Node.js 16+** (for frontend)
- **AWS CLI** configured with appropriate permissions
- **AWS Account** with Bedrock access enabled

### **AWS Services Required:**
- **AWS Bedrock** (for AI models)
- **AWS Cognito** (for authentication)
- **AWS DynamoDB** (for conversation storage)
- **AWS S3** (optional, for file storage)

---

## 📋 **Step-by-Step Setup Instructions**

### **1. Extract the Package**
```bash
# Extract the zip file
unzip Redington-AI-Chatbot-YYYYMMDD.zip
cd react-bedrock-chatbot
```

### **2. Backend Setup**

#### **2.1 Navigate to Backend Directory**
```bash
cd backend
```

#### **2.2 Create Virtual Environment**
```bash
# Create virtual environment
python3 -m venv venv

# Activate virtual environment
# On Linux/Mac:
source venv/bin/activate
# On Windows:
venv\Scripts\activate
```

#### **2.3 Install Dependencies**
```bash
pip install -r requirements.txt
```

#### **2.4 Configure Environment Variables**
Create a `.env` file in the backend directory:
```bash
cp .env.example .env  # If example exists, or create new .env file
```

Edit `.env` file with your AWS configuration:
```env
# AWS Configuration
AWS_DEFAULT_REGION=us-east-1
AWS_ACCESS_KEY_ID=your-access-key-id
AWS_SECRET_ACCESS_KEY=your-secret-access-key

# AWS Cognito Configuration
POOL_ID=your-cognito-pool-id
APP_CLIENT_ID=your-cognito-client-id
APP_CLIENT_SECRET=your-cognito-client-secret

# Application Configuration
SECRET_KEY=your-jwt-secret-key-here
ALLOWED_ORIGINS=["http://localhost:3000"]

# DynamoDB Configuration (optional - will use default table names)
DYNAMODB_TABLE_PREFIX=redington-ai
```

#### **2.5 Start Backend Server**
```bash
# Using the provided script
./start.sh

# Or manually
uvicorn main:app --host 0.0.0.0 --port 8000 --reload
```

**Backend will be available at:** `http://localhost:8000`

### **3. Frontend Setup**

#### **3.1 Navigate to Frontend Directory**
```bash
cd ../frontend  # From backend directory
```

#### **3.2 Install Dependencies**
```bash
npm install
```

#### **3.3 Configure Environment Variables**
Create/edit `.env` file in the frontend directory:
```env
REACT_APP_API_BASE_URL=http://localhost:8000
REACT_APP_ENVIRONMENT=development
```

#### **3.4 Start Frontend Development Server**
```bash
# Using the provided script
./start.sh

# Or manually
npm start
```

**Frontend will be available at:** `http://localhost:3000`

---

## 🔧 **AWS Configuration**

### **1. AWS Bedrock Setup**
1. **Enable Bedrock Models:**
   - Go to AWS Bedrock Console
   - Navigate to "Model access"
   - Request access to required models:
     - Claude 3.7 Sonnet (recommended)
     - Claude 3.5 Haiku
     - Amazon Nova models

2. **Configure Model Settings:**
   - Edit `backend/config/config.yml`
   - Add/modify model configurations as needed

### **2. AWS Cognito Setup**
1. **Create User Pool:**
   - Go to AWS Cognito Console
   - Create a new User Pool
   - Configure authentication settings
   - Note down Pool ID and Client ID

2. **Create Test User:**
   ```bash
   # Using AWS CLI
   aws cognito-idp admin-create-user \
     --user-pool-id your-pool-id \
     --username tanmay \
     --temporary-password TempPass123! \
     --message-action SUPPRESS
   
   # Set permanent password
   aws cognito-idp admin-set-user-password \
     --user-pool-id your-pool-id \
     --username tanmay \
     --password Admin@123$ \
     --permanent
   ```

### **3. AWS DynamoDB Setup**
The application will automatically create required tables:
- `redington-ai-chat-sessions`
- `redington-ai-messages`

---

## 🎮 **Usage Instructions**

### **1. Access the Application**
1. Open browser and go to `http://localhost:3000`
2. Login with credentials:
   - **Username:** `tanmay`
   - **Password:** `Admin@123$`

### **2. Key Features**

#### **Chat Interface:**
- ✅ **Real-time streaming** responses
- ✅ **File upload** support (PDF, DOCX, etc.)
- ✅ **Role selection** (Presales Expert)
- ✅ **New Chat** button in header
- ✅ **Conversation history** in sidebar

#### **Word Document Export:**
- ✅ **Individual message download** (📥 button on each response)
- ✅ **Professional formatting** with tables, headers, lists
- ✅ **Proper timestamps** and branding

#### **Advanced Features:**
- ✅ **Smart timestamps** (Yesterday, 3 days ago, etc.)
- ✅ **Active conversation highlighting**
- ✅ **Conversation editing** and management
- ✅ **RAG integration** for enhanced responses

---

## 🔍 **Troubleshooting**

### **Common Issues:**

#### **1. Backend Won't Start**
```bash
# Check Python version
python3 --version

# Ensure virtual environment is activated
source venv/bin/activate

# Install dependencies again
pip install -r requirements.txt
```

#### **2. Frontend Build Errors**
```bash
# Clear npm cache
npm cache clean --force

# Delete node_modules and reinstall
rm -rf node_modules package-lock.json
npm install
```

#### **3. AWS Authentication Issues**
```bash
# Configure AWS CLI
aws configure

# Test AWS access
aws sts get-caller-identity
```

#### **4. CORS Errors**
- Ensure `ALLOWED_ORIGINS` in backend `.env` includes frontend URL
- Check that both frontend and backend are running

### **5. Port Conflicts**
If ports 3000 or 8000 are in use:
```bash
# Backend - change port in start.sh or run manually:
uvicorn main:app --host 0.0.0.0 --port 8001 --reload

# Frontend - will automatically find next available port
npm start
```

---

## 📁 **Project Structure**

```
react-bedrock-chatbot/
├── backend/                 # FastAPI backend
│   ├── app/
│   │   ├── api/            # API routes
│   │   ├── core/           # Configuration
│   │   ├── models/         # Data models
│   │   ├── services/       # Business logic
│   │   └── utils/          # Utilities
│   ├── config/             # Model configurations
│   ├── requirements.txt    # Python dependencies
│   ├── main.py            # FastAPI app
│   └── start.sh           # Backend startup script
├── frontend/               # React frontend
│   ├── src/
│   │   ├── components/     # React components
│   │   ├── hooks/          # Custom hooks
│   │   ├── services/       # API services
│   │   ├── types/          # TypeScript types
│   │   └── utils/          # Utilities
│   ├── package.json       # Node dependencies
│   └── start.sh           # Frontend startup script
└── README.md              # Project documentation
```

---

## 🚀 **Production Deployment**

### **Backend Deployment Options:**
1. **AWS ECS/Fargate** (Recommended)
2. **AWS Lambda** with Mangum
3. **EC2** with Docker
4. **AWS App Runner**

### **Frontend Deployment Options:**
1. **AWS S3 + CloudFront** (Recommended)
2. **Vercel/Netlify**
3. **AWS Amplify**

### **Environment Variables for Production:**
```env
# Backend
AWS_DEFAULT_REGION=us-east-1
POOL_ID=your-production-pool-id
APP_CLIENT_ID=your-production-client-id
SECRET_KEY=your-production-secret-key
ALLOWED_ORIGINS=["https://your-domain.com"]

# Frontend
REACT_APP_API_BASE_URL=https://your-api-domain.com
REACT_APP_ENVIRONMENT=production
```

---

## 📞 **Support & Contact**

### **For Technical Issues:**
1. Check the troubleshooting section above
2. Review AWS service configurations
3. Check application logs in browser console and backend terminal

### **Key Features Implemented:**
- ✅ **Modern React UI** with Material-UI
- ✅ **FastAPI Backend** with async support
- ✅ **AWS Bedrock Integration** for AI models
- ✅ **Professional Word Export** with proper formatting
- ✅ **Real-time Streaming** responses
- ✅ **File Upload** and processing
- ✅ **Conversation Management** with DynamoDB
- ✅ **Enhanced UX** with smart timestamps and highlighting

---

## 🎯 **Quick Start Commands**

```bash
# 1. Extract and navigate
unzip Redington-AI-Chatbot-YYYYMMDD.zip
cd react-bedrock-chatbot

# 2. Start backend
cd backend
python3 -m venv venv
source venv/bin/activate
pip install -r requirements.txt
# Configure .env file
./start.sh

# 3. Start frontend (in new terminal)
cd frontend
npm install
# Configure .env file
./start.sh

# 4. Access application
# Frontend: http://localhost:3000
# Backend: http://localhost:8000
# Login: tanmay / Admin@123$
```

**🎉 Your Redington AI Chatbot is ready to use!**
