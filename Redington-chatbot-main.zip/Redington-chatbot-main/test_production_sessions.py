#!/usr/bin/env python3

import requests
import json

def test_production_sessions():
    base_url = "https://bot.redingtonsolutions.org"
    
    print("🔍 Testing Production Session Management...")
    
    # Step 1: Login
    print("\n1. Testing Production Login...")
    login_data = {
        "username": "tanmay",
        "password": "Admin@123$"
    }
    
    try:
        login_response = requests.post(f"{base_url}/api/v1/auth/login", json=login_data)
        print(f"Login Status: {login_response.status_code}")
        
        if login_response.status_code == 200:
            login_result = login_response.json()
            print(f"✅ Production login successful!")
            
            token = login_result.get('access_token')
            headers = {
                'Authorization': f'Bearer {token}',
                'Content-Type': 'application/json'
            }
            
            # Step 2: Test sessions
            print("\n2. Testing Production Sessions...")
            sessions_response = requests.get(f"{base_url}/api/v1/sessions", headers=headers)
            print(f"Sessions Status: {sessions_response.status_code}")
            
            if sessions_response.status_code == 200:
                sessions_data = sessions_response.json()
                print(f"✅ Production sessions retrieved!")
                
                sessions = sessions_data.get('sessions', [])
                print(f"📊 Found {len(sessions)} total sessions")
                
                # Count sessions with messages
                sessions_with_messages = [s for s in sessions if s.get('message_count', 0) > 0]
                print(f"📊 Sessions with messages: {len(sessions_with_messages)}")
                
                # Show first few sessions
                for i, session in enumerate(sessions_with_messages[:5]):
                    print(f"  {i+1}. {session.get('name', 'Untitled')[:50]} - {session.get('message_count', 0)} messages")
                
                # Test getting messages for first session
                if sessions_with_messages:
                    first_session = sessions_with_messages[0]
                    session_id = first_session['id']
                    print(f"\n3. Testing Messages for Session: {session_id}")
                    
                    messages_response = requests.get(f"{base_url}/api/v1/chat/history/{session_id}", headers=headers)
                    print(f"Messages Status: {messages_response.status_code}")
                    
                    if messages_response.status_code == 200:
                        messages_data = messages_response.json()
                        messages = messages_data.get('messages', [])
                        print(f"✅ Found {len(messages)} messages in session")
                        
                        # Show first few messages
                        for i, msg in enumerate(messages[:3]):
                            role = msg.get('role', 'unknown')
                            content = msg.get('content', '')[:100]
                            print(f"  Message {i+1}: [{role}] {content}...")
                    else:
                        print(f"❌ Failed to get messages: {messages_response.text}")
                
            else:
                print(f"❌ Production sessions failed: {sessions_response.text}")
                
        else:
            print(f"❌ Production login failed: {login_response.text}")
            
    except Exception as e:
        print(f"❌ Error: {e}")

if __name__ == "__main__":
    test_production_sessions()
