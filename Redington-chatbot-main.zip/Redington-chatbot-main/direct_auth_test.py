#!/usr/bin/env python3
"""
Direct authentication test to isolate the issue
"""
import sys
import os
import asyncio
from dotenv import load_dotenv

# Add backend to path
sys.path.append('/home/chatbot/Redington-chatbot/backend')

# Load environment variables
load_dotenv('/home/chatbot/Redington-chatbot/backend/.env')

from cognito_auth_improved import CognitoAuth

async def direct_auth_test():
    """Test authentication directly"""
    
    username = "varunesh"
    password = "TempPass123!"
    
    print("=== Direct Authentication Test ===")
    print(f"Username: {username}")
    print(f"Password: {password}")
    print()
    
    try:
        # Initialize auth handler
        auth = CognitoAuth()
        print("✓ CognitoAuth initialized")
        
        # Test authentication directly
        print("Calling authenticate_user...")
        result = await auth.authenticate_user(username, password)
        
        print("✓ Authentication successful!")
        print(f"Result: {result}")
        
    except Exception as e:
        print(f"✗ Authentication failed: {str(e)}")
        print(f"Exception type: {type(e)}")
        
        # Print the full traceback
        import traceback
        traceback.print_exc()

if __name__ == "__main__":
    asyncio.run(direct_auth_test())
