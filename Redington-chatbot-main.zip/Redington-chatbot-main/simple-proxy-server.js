const express = require('express');
const { createProxyMiddleware } = require('http-proxy-middleware');
const path = require('path');

const app = express();
const PORT = 3000;

console.log('🚀 Starting simple proxy server...');

// API proxy middleware - must come before static files
const apiProxy = createProxyMiddleware({
  target: 'http://43.204.187.174:8000',
  changeOrigin: true,
  logLevel: 'info'
});

app.use('/api', apiProxy);

// Serve static files from React build
app.use(express.static(path.join(__dirname, 'frontend/build')));

// Handle React routing - serve index.html for all other routes
app.get('*', (req, res) => {
  if (!req.url.startsWith('/api')) {
    res.sendFile(path.join(__dirname, 'frontend/build', 'index.html'));
  }
});

app.listen(PORT, '0.0.0.0', () => {
  console.log(`🚀 Simple proxy server running on http://0.0.0.0:${PORT}`);
  console.log(`🌐 Public access: http://43.204.187.174:${PORT}`);
  console.log(`🔄 Proxying /api/* to http://43.204.187.174:8000`);
});
