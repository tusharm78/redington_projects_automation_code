const express = require('express');
const { createProxyMiddleware } = require('http-proxy-middleware');
const path = require('path');

const app = express();
const PORT = 3000;

// Serve static files from React build
app.use(express.static(path.join(__dirname, 'frontend/build')));

// API proxy middleware
app.use('/api', createProxyMiddleware({
  target: 'http://43.204.187.174:8000',
  changeOrigin: true,
  logLevel: 'info',
  onProxyReq: (proxyReq, req, res) => {
    console.log('🔄 Proxying request:', req.method, req.url, '→', proxyReq.path);
  },
  onProxyRes: (proxyRes, req, res) => {
    console.log('✅ Proxy response:', proxyRes.statusCode, req.url);
  },
  onError: (err, req, res) => {
    console.error('❌ Proxy error:', err.message, 'for', req.url);
  }
}));

// Handle React routing - serve index.html for all non-API routes
app.get('*', (req, res) => {
  res.sendFile(path.join(__dirname, 'frontend/build', 'index.html'));
});

app.listen(PORT, '0.0.0.0', () => {
  console.log(`🚀 Proxy server running on http://0.0.0.0:${PORT}`);
  console.log(`🌐 Public access: http://43.204.187.174:${PORT}`);
  console.log(`🔄 Proxying /api/* to http://43.204.187.174:8000`);
});
