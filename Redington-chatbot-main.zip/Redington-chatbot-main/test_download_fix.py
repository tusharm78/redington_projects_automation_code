#!/usr/bin/env python3
"""
Test script to verify that download functionality includes customer name replacement
"""

import requests
import json
import time

def test_download_customer_replacement():
    """Test that downloads include customer name replacement"""
    
    print("🧪 Testing Download Customer Name Replacement")
    print("=" * 55)
    
    # Login
    print("🔐 Logging in...")
    login_response = requests.post("http://localhost:8000/api/v1/auth/login", json={
        "username": "tanmay",
        "password": "Admin@123$"
    })
    
    if login_response.status_code != 200:
        print(f"❌ Login failed: {login_response.status_code}")
        return
    
    token = login_response.json()["access_token"]
    headers = {"Authorization": f"Bearer {token}"}
    print("✅ Login successful\n")
    
    # Test message with customer name
    test_message = "Create a comprehensive proposal for Tesla Motors Inc"
    session_id = "download_test_session_123"
    
    print(f"📝 Testing message: '{test_message}'")
    print(f"🔗 Session ID: {session_id}")
    print("🔄 Generating response...\n")
    
    # Send chat request
    response = requests.post("http://localhost:8000/api/v1/chat/stream",
        json={
            "message": test_message,
            "session_id": session_id,
            "model": "claude-3-7-sonnet"
        },
        headers=headers,
        stream=True
    )
    
    if response.status_code != 200:
        print(f"❌ Chat request failed: {response.status_code}")
        return
    
    # Collect the complete response
    full_response = ""
    for line in response.iter_lines():
        if line:
            line_str = line.decode('utf-8')
            if line_str.startswith('data: '):
                try:
                    data = json.loads(line_str[6:])
                    if 'chunk' in data:
                        full_response += data['chunk']
                    if data.get('is_complete', False):
                        break
                except json.JSONDecodeError:
                    continue
    
    print(f"✅ Response generated ({len(full_response)} characters)")
    
    # Check if customer name appears in the streaming response
    tesla_count_streaming = full_response.count("Tesla")
    placeholder_count_streaming = full_response.count("<Customer Name>")
    
    print(f"\n📊 Streaming Response Analysis:")
    print(f"   • 'Tesla' mentions: {tesla_count_streaming}")
    print(f"   • '<Customer Name>' placeholders: {placeholder_count_streaming}")
    
    if tesla_count_streaming > 0:
        print("   ✅ Customer name replacement working in streaming")
    else:
        print("   ❌ Customer name replacement NOT working in streaming")
    
    # Now test what would happen in download
    # Simulate the frontend customer name extraction and replacement
    from backend.enhanced_bedrock_main import BedrockStreamingIntegration
    
    # Create instance to test customer name extraction
    bedrock = BedrockStreamingIntegration()
    extracted_name = bedrock._extract_customer_name(test_message)
    
    print(f"\n🔍 Customer Name Extraction Test:")
    print(f"   • Extracted name: '{extracted_name}'")
    
    if extracted_name == "Tesla":
        print("   ✅ Customer name extraction working correctly")
    else:
        print(f"   ❌ Expected 'Tesla', got '{extracted_name}'")
    
    # Test the replacement function
    if extracted_name:
        # Simulate what the download function would do
        processed_content = full_response.replace("<Customer Name>", extracted_name)
        tesla_count_processed = processed_content.count("Tesla")
        placeholder_count_processed = processed_content.count("<Customer Name>")
        
        print(f"\n📄 Download Processing Simulation:")
        print(f"   • 'Tesla' mentions after processing: {tesla_count_processed}")
        print(f"   • '<Customer Name>' placeholders after processing: {placeholder_count_processed}")
        
        if tesla_count_processed >= tesla_count_streaming and placeholder_count_processed == 0:
            print("   ✅ Download processing would work correctly")
        else:
            print("   ❌ Download processing has issues")
    
    print(f"\n🎯 Summary:")
    print(f"   • Streaming customer replacement: {'✅ Working' if tesla_count_streaming > 0 else '❌ Not working'}")
    print(f"   • Customer name extraction: {'✅ Working' if extracted_name == 'Tesla' else '❌ Not working'}")
    print(f"   • Download would be fixed: {'✅ Yes' if extracted_name and tesla_count_streaming > 0 else '❌ No'}")
    
    print(f"\n💡 Instructions for manual testing:")
    print(f"   1. Go to http://localhost:3000")
    print(f"   2. Login with: tanmay / Admin@123$")
    print(f"   3. Send message: '{test_message}'")
    print(f"   4. Wait for complete response")
    print(f"   5. Click download button and check if 'Tesla' appears instead of '<Customer Name>'")

if __name__ == "__main__":
    test_download_customer_replacement()
