#!/bin/bash

# Redington Chatbot Monitoring Dashboard
# Provides quick system overview and monitoring commands

SCRIPT_DIR="/home/chatbot/Redington-chatbot"
LOG_DIR="$SCRIPT_DIR"

# Colors for output
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
NC='\033[0m' # No Color

# Function to display header
show_header() {
    clear
    echo -e "${BLUE}╔══════════════════════════════════════════════════════════════════════════════╗${NC}"
    echo -e "${BLUE}║                    REDINGTON CHATBOT MONITORING DASHBOARD                   ║${NC}"
    echo -e "${BLUE}║                        $(date '+%Y-%m-%d %H:%M:%S')                              ║${NC}"
    echo -e "${BLUE}╚══════════════════════════════════════════════════════════════════════════════╝${NC}"
    echo
}

# Function to show quick system status
show_quick_status() {
    echo -e "${GREEN}📊 QUICK SYSTEM STATUS:${NC}"
    
    # CPU Usage
    cpu_usage=$(top -bn1 | grep "Cpu(s)" | awk '{print $2}' | cut -d'%' -f1)
    echo -e "├─ CPU Usage: ${cpu_usage}%"
    
    # Memory Usage
    memory_info=$(free | grep Mem)
    total_mem=$(echo $memory_info | awk '{print $2}')
    used_mem=$(echo $memory_info | awk '{print $3}')
    mem_percent=$(echo "scale=1; $used_mem * 100 / $total_mem" | bc)
    echo -e "├─ Memory Usage: ${mem_percent}%"
    
    # Disk Usage
    disk_usage=$(df -h / | awk 'NR==2 {print $5}' | cut -d'%' -f1)
    echo -e "├─ Disk Usage: ${disk_usage}%"
    
    # Active Processes
    backend_processes=$(ps aux | grep -E "(enhanced_bedrock_main|uvicorn)" | grep -v grep | wc -l)
    admin_processes=$(ps aux | grep -E "(admin_api|simple_admin_api|realtime_admin_api|secure_admin_api)" | grep -v grep | wc -l)
    echo -e "├─ Backend Processes: ${backend_processes}"
    echo -e "└─ Admin Processes: ${admin_processes}"
    echo
}

# Function to show process details
show_processes() {
    echo -e "${GREEN}🔧 CHATBOT PROCESSES:${NC}"
    
    echo -e "${YELLOW}Backend Processes:${NC}"
    ps aux | grep -E "(enhanced_bedrock_main|uvicorn)" | grep -v grep | while read line; do
        pid=$(echo $line | awk '{print $2}')
        cpu=$(echo $line | awk '{print $3}')
        mem=$(echo $line | awk '{print $4}')
        echo -e "├─ PID: $pid, CPU: ${cpu}%, Memory: ${mem}%"
    done
    
    echo -e "${YELLOW}Admin API Processes:${NC}"
    ps aux | grep -E "(admin_api|simple_admin_api|realtime_admin_api|secure_admin_api)" | grep -v grep | while read line; do
        pid=$(echo $line | awk '{print $2}')
        cpu=$(echo $line | awk '{print $3}')
        mem=$(echo $line | awk '{print $4}')
        cmd=$(echo $line | awk '{for(i=11;i<=NF;i++) printf "%s ", $i; print ""}' | cut -c1-50)
        echo -e "├─ PID: $pid, CPU: ${cpu}%, Memory: ${mem}%, CMD: $cmd"
    done
    echo
}

# Function to show recent logs
show_recent_logs() {
    echo -e "${GREEN}📋 RECENT LOGS:${NC}"
    
    if [ -f "$LOG_DIR/system_monitor.log" ]; then
        echo -e "${YELLOW}System Monitor (last 5 lines):${NC}"
        tail -5 "$LOG_DIR/system_monitor.log" | while read line; do
            echo -e "├─ $line"
        done
        echo
    fi
    
    if [ -f "$LOG_DIR/continuous_monitor.log" ]; then
        echo -e "${YELLOW}Continuous Monitor (last 5 lines):${NC}"
        tail -5 "$LOG_DIR/continuous_monitor.log" | while read line; do
            echo -e "├─ $line"
        done
        echo
    fi
    
    if [ -f "$LOG_DIR/backend.log" ]; then
        echo -e "${YELLOW}Backend Logs (last 3 lines):${NC}"
        tail -3 "$LOG_DIR/backend.log" | while read line; do
            echo -e "├─ $line"
        done
        echo
    fi
}

# Function to show alerts
show_alerts() {
    echo -e "${GREEN}🚨 RECENT ALERTS:${NC}"
    
    if [ -f "$LOG_DIR/alerts.json" ]; then
        # Show last 5 alerts
        python3 -c "
import json
import sys
from datetime import datetime

try:
    with open('$LOG_DIR/alerts.json', 'r') as f:
        alerts = json.load(f)
    
    # Show last 5 alerts
    for alert in alerts[-5:]:
        timestamp = datetime.fromisoformat(alert['timestamp']).strftime('%H:%M:%S')
        severity = alert.get('severity', 'MEDIUM')
        message = alert['message']
        print(f'├─ {timestamp} [{severity}] {message}')
except Exception as e:
    print('├─ No alerts available')
"
    else
        echo -e "├─ No alerts file found"
    fi
    echo
}

# Function to show menu
show_menu() {
    echo -e "${GREEN}🎛️  MONITORING OPTIONS:${NC}"
    echo -e "├─ ${YELLOW}1${NC}) Run System Monitor (one-time)"
    echo -e "├─ ${YELLOW}2${NC}) Start Continuous Monitor"
    echo -e "├─ ${YELLOW}3${NC}) Run Load Test"
    echo -e "├─ ${YELLOW}4${NC}) View Detailed Process Info"
    echo -e "├─ ${YELLOW}5${NC}) View System Logs"
    echo -e "├─ ${YELLOW}6${NC}) View Metrics History"
    echo -e "├─ ${YELLOW}7${NC}) Kill All Monitoring Processes"
    echo -e "├─ ${YELLOW}8${NC}) Restart Chatbot Services"
    echo -e "├─ ${YELLOW}r${NC}) Refresh Dashboard"
    echo -e "└─ ${YELLOW}q${NC}) Quit"
    echo
    echo -n "Select option: "
}

# Function to run system monitor
run_system_monitor() {
    echo -e "${GREEN}Running system monitor...${NC}"
    cd "$SCRIPT_DIR"
    python3 system_monitor.py
    echo
    echo -e "${YELLOW}Press Enter to continue...${NC}"
    read
}

# Function to start continuous monitor
start_continuous_monitor() {
    echo -e "${GREEN}Starting continuous monitor...${NC}"
    echo -e "${YELLOW}Press Ctrl+C to stop${NC}"
    cd "$SCRIPT_DIR"
    python3 continuous_monitor.py
}

# Function to run load test
run_load_test() {
    echo -e "${GREEN}Load Test Configuration:${NC}"
    echo -n "Number of users (default 5): "
    read users
    users=${users:-5}
    
    echo -n "Session duration in seconds (default 60): "
    read duration
    duration=${duration:-60}
    
    echo -n "Ramp-up time in seconds (default 30): "
    read rampup
    rampup=${rampup:-30}
    
    echo -e "${GREEN}Starting load test with $users users...${NC}"
    cd "$SCRIPT_DIR"
    python3 load_test.py --users $users --duration $duration --ramp-up $rampup
    
    echo
    echo -e "${YELLOW}Press Enter to continue...${NC}"
    read
}

# Function to view detailed process info
view_process_info() {
    echo -e "${GREEN}📊 DETAILED PROCESS INFORMATION:${NC}"
    echo
    
    echo -e "${YELLOW}All Python processes:${NC}"
    ps aux | grep python | grep -v grep | head -10
    echo
    
    echo -e "${YELLOW}Memory usage by process:${NC}"
    ps aux --sort=-%mem | head -10
    echo
    
    echo -e "${YELLOW}CPU usage by process:${NC}"
    ps aux --sort=-%cpu | head -10
    echo
    
    echo -e "${YELLOW}Press Enter to continue...${NC}"
    read
}

# Function to view system logs
view_system_logs() {
    echo -e "${GREEN}📋 SYSTEM LOGS:${NC}"
    echo
    
    PS3="Select log to view: "
    options=("System Monitor" "Continuous Monitor" "Backend Log" "Frontend Log" "Alerts" "Back to Menu")
    select opt in "${options[@]}"
    do
        case $opt in
            "System Monitor")
                if [ -f "$LOG_DIR/system_monitor.log" ]; then
                    tail -50 "$LOG_DIR/system_monitor.log"
                else
                    echo "Log file not found"
                fi
                break
                ;;
            "Continuous Monitor")
                if [ -f "$LOG_DIR/continuous_monitor.log" ]; then
                    tail -50 "$LOG_DIR/continuous_monitor.log"
                else
                    echo "Log file not found"
                fi
                break
                ;;
            "Backend Log")
                if [ -f "$LOG_DIR/backend.log" ]; then
                    tail -50 "$LOG_DIR/backend.log"
                else
                    echo "Log file not found"
                fi
                break
                ;;
            "Frontend Log")
                if [ -f "$LOG_DIR/frontend.log" ]; then
                    tail -50 "$LOG_DIR/frontend.log"
                else
                    echo "Log file not found"
                fi
                break
                ;;
            "Alerts")
                if [ -f "$LOG_DIR/alerts.json" ]; then
                    cat "$LOG_DIR/alerts.json" | python3 -m json.tool
                else
                    echo "Alerts file not found"
                fi
                break
                ;;
            "Back to Menu")
                return
                ;;
            *) echo "Invalid option";;
        esac
    done
    
    echo
    echo -e "${YELLOW}Press Enter to continue...${NC}"
    read
}

# Function to view metrics history
view_metrics_history() {
    echo -e "${GREEN}📈 METRICS HISTORY:${NC}"
    
    if [ -f "$LOG_DIR/metrics_history.json" ]; then
        python3 -c "
import json
from datetime import datetime

with open('$LOG_DIR/metrics_history.json', 'r') as f:
    metrics = json.load(f)

print(f'Total metrics entries: {len(metrics)}')
print()

if metrics:
    print('Recent metrics (last 5 entries):')
    for metric in metrics[-5:]:
        timestamp = datetime.fromisoformat(metric['timestamp']).strftime('%H:%M:%S')
        cpu = metric['cpu']['percent']
        memory = metric['memory']['percent']
        disk = metric['disk']['percent']
        processes = metric['processes']['total_processes']
        print(f'{timestamp}: CPU {cpu:.1f}%, Memory {memory:.1f}%, Disk {disk:.1f}%, Processes {processes}')
"
    else
        echo "No metrics history available"
    fi
    
    echo
    echo -e "${YELLOW}Press Enter to continue...${NC}"
    read
}

# Function to kill monitoring processes
kill_monitoring() {
    echo -e "${RED}Killing all monitoring processes...${NC}"
    
    # Kill continuous monitor
    pkill -f "continuous_monitor.py"
    
    # Kill system monitor
    pkill -f "system_monitor.py"
    
    # Kill load test
    pkill -f "load_test.py"
    
    echo -e "${GREEN}Monitoring processes stopped${NC}"
    echo
    echo -e "${YELLOW}Press Enter to continue...${NC}"
    read
}

# Function to restart chatbot services
restart_services() {
    echo -e "${YELLOW}Restarting chatbot services...${NC}"
    
    # Stop existing processes
    pkill -f "enhanced_bedrock_main"
    pkill -f "admin_api"
    sleep 2
    
    # Start backend
    cd "$SCRIPT_DIR/backend"
    nohup python3 enhanced_bedrock_main.py > ../backend.log 2>&1 &
    echo "Backend started"
    
    # Start admin API (if exists)
    if [ -f "secure_admin_api.py" ]; then
        nohup python3 secure_admin_api.py > ../admin_api.log 2>&1 &
        echo "Admin API started"
    fi
    
    echo -e "${GREEN}Services restarted${NC}"
    echo
    echo -e "${YELLOW}Press Enter to continue...${NC}"
    read
}

# Main loop
main() {
    while true; do
        show_header
        show_quick_status
        show_processes
        show_recent_logs
        show_alerts
        show_menu
        
        read choice
        
        case $choice in
            1) run_system_monitor ;;
            2) start_continuous_monitor ;;
            3) run_load_test ;;
            4) view_process_info ;;
            5) view_system_logs ;;
            6) view_metrics_history ;;
            7) kill_monitoring ;;
            8) restart_services ;;
            r|R) continue ;;
            q|Q) 
                echo -e "${GREEN}Goodbye!${NC}"
                exit 0 
                ;;
            *) 
                echo -e "${RED}Invalid option. Press Enter to continue...${NC}"
                read
                ;;
        esac
    done
}

# Check if required files exist
if [ ! -f "$SCRIPT_DIR/system_monitor.py" ]; then
    echo -e "${RED}Error: system_monitor.py not found in $SCRIPT_DIR${NC}"
    exit 1
fi

# Make sure we're in the right directory
cd "$SCRIPT_DIR"

# Start the dashboard
main
