#!/bin/bash

# Auto-update script for React Bedrock Chatbot
echo "Starting auto-update service for React Bedrock Chatbot..."

FRONTEND_DIR="/home/chatbot/RedAIBot/react-bedrock-chatbot/frontend"
BACKEND_DIR="/home/chatbot/RedAIBot/react-bedrock-chatbot/backend"

# Function to rebuild frontend
rebuild_frontend() {
    echo "Changes detected in frontend. Rebuilding..."
    cd "$FRONTEND_DIR"
    npm run build
    sudo nginx -s reload
    echo "Frontend updated and served on port 3001"
}

# Function to restart backend
restart_backend() {
    echo "Changes detected in backend. Restarting..."
    pkill -f "python main.py" 2>/dev/null || true
    sleep 2
    cd "$BACKEND_DIR"
    source venv/bin/activate
    nohup python main.py > backend.log 2>&1 &
    echo "Backend restarted on port 8000"
}

# Monitor frontend changes
inotifywait -m -r -e modify,create,delete "$FRONTEND_DIR/src" --format '%w%f %e' |
while read file event; do
    if [[ $file == *.tsx ]] || [[ $file == *.ts ]] || [[ $file == *.css ]] || [[ $file == *.js ]]; then
        rebuild_frontend
    fi
done &

# Monitor backend changes
inotifywait -m -r -e modify,create,delete "$BACKEND_DIR" --format '%w%f %e' |
while read file event; do
    if [[ $file == *.py ]] && [[ $file != *"__pycache__"* ]] && [[ $file != *".log"* ]]; then
        restart_backend
    fi
done &

echo "Auto-update service is running..."
echo "Frontend: http://localhost:3001"
echo "Backend API: http://localhost:8000"
echo "Press Ctrl+C to stop"

# Keep the script running
wait
