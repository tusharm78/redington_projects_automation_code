#!/usr/bin/env python3
"""
Debug script to test Cognito authentication for the new user
"""
import sys
import os
import asyncio
import boto3
from dotenv import load_dotenv

# Add backend to path
sys.path.append('/home/chatbot/Redington-chatbot/backend')

# Load environment variables
load_dotenv('/home/chatbot/Redington-chatbot/backend/.env')

from cognito_auth_improved import CognitoAuth

async def test_authentication():
    """Test authentication with the new user credentials"""
    
    # Test credentials
    username = "shubham"
    password = "NewPassword123!"
    
    print("=== Cognito Authentication Debug ===")
    print(f"Testing authentication for user: {username}")
    print(f"Pool ID: {os.getenv('POOL_ID')}")
    print(f"Client ID: {os.getenv('APP_CLIENT_ID')}")
    print(f"Region: {os.getenv('AWS_DEFAULT_REGION')}")
    print()
    
    try:
        # Initialize auth handler
        auth = CognitoAuth()
        print("✓ CognitoAuth initialized successfully")
        
        # Test authentication
        print(f"Attempting to authenticate user: {username}")
        result = await auth.authenticate_user(username, password)
        
        print("✓ Authentication successful!")
        print(f"User info: {result.get('user_info', {})}")
        print(f"Token expires in: {result.get('expires_in')} seconds")
        
        return True
        
    except Exception as e:
        print(f"✗ Authentication failed: {str(e)}")
        
        # Additional debugging - check user status directly
        try:
            print("\n=== Additional User Status Check ===")
            cognito_client = boto3.client('cognito-idp', region_name=os.getenv('AWS_DEFAULT_REGION'))
            
            user_info = cognito_client.admin_get_user(
                UserPoolId=os.getenv('POOL_ID'),
                Username=username
            )
            
            print(f"User Status: {user_info.get('UserStatus')}")
            print(f"User Enabled: {user_info.get('Enabled')}")
            print(f"User Attributes: {user_info.get('UserAttributes', [])}")
            
            # Check if user needs password change
            if user_info.get('UserStatus') == 'FORCE_CHANGE_PASSWORD':
                print("\n⚠️  User requires password change!")
                print("This is likely a new user that needs to set a permanent password.")
                
        except Exception as debug_error:
            print(f"Debug check failed: {str(debug_error)}")
        
        return False

def check_aws_credentials():
    """Check if AWS credentials are properly configured"""
    print("=== AWS Credentials Check ===")
    try:
        session = boto3.Session()
        credentials = session.get_credentials()
        
        if credentials:
            print("✓ AWS credentials found")
            print(f"Access Key: {credentials.access_key[:10]}...")
            
            # Test basic AWS access
            sts = boto3.client('sts')
            identity = sts.get_caller_identity()
            print(f"✓ AWS Identity: {identity.get('Arn', 'Unknown')}")
            
        else:
            print("✗ No AWS credentials found")
            print("Please configure AWS credentials using:")
            print("  aws configure")
            print("  or set AWS_ACCESS_KEY_ID and AWS_SECRET_ACCESS_KEY")
            
    except Exception as e:
        print(f"✗ AWS credentials check failed: {str(e)}")

if __name__ == "__main__":
    print("Redington Chatbot - Authentication Debug Tool")
    print("=" * 50)
    
    # Check AWS credentials first
    check_aws_credentials()
    print()
    
    # Test authentication
    result = asyncio.run(test_authentication())
    
    print("\n" + "=" * 50)
    if result:
        print("✓ Authentication test PASSED")
        print("The user should be able to log in to the chatbot.")
    else:
        print("✗ Authentication test FAILED")
        print("Please check the error messages above for troubleshooting steps.")
