#!/usr/bin/env python3
"""
Script to get detailed information about all DynamoDB tables
"""

import boto3
import json
from datetime import datetime

def get_all_table_details():
    """Get detailed information about all DynamoDB tables"""
    
    print("📊 COMPLETE DYNAMODB TABLES ANALYSIS")
    print("=" * 60)
    
    dynamodb = boto3.client('dynamodb', region_name='us-east-1')
    
    try:
        # Get list of all tables
        response = dynamodb.list_tables()
        table_names = response['TableNames']
        
        print(f"Total Tables Found: {len(table_names)}")
        print("=" * 60)
        
        # Categories for organization
        categories = {
            'Chat & Conversation': [],
            'User Management': [],
            'Employee Data': [],
            'Document Processing': [],
            'AWS Amplify': [],
            'Migration Factory': [],
            'Performance Monitoring': [],
            'Testing & Development': [],
            'Business Data': []
        }
        
        table_details = []
        
        for i, table_name in enumerate(sorted(table_names), 1):
            try:
                print(f"\n{i}. Analyzing table: {table_name}")
                
                # Get table description
                table_info = dynamodb.describe_table(TableName=table_name)
                table = table_info['Table']
                
                # Basic info
                creation_date = table['CreationDateTime'].strftime('%Y-%m-%d %H:%M:%S')
                table_status = table['TableStatus']
                item_count = table.get('ItemCount', 0)
                table_size_bytes = table.get('TableSizeBytes', 0)
                table_size_mb = round(table_size_bytes / (1024 * 1024), 2)
                
                # Billing info
                billing_mode = table.get('BillingModeSummary', {}).get('BillingMode', 'PROVISIONED')
                
                # Key schema
                key_schema = []
                for key in table['KeySchema']:
                    key_type = 'Partition Key' if key['KeyType'] == 'HASH' else 'Sort Key'
                    key_schema.append(f"{key['AttributeName']} ({key_type})")
                
                # Categorize table
                category = categorize_table(table_name)
                
                table_detail = {
                    'name': table_name,
                    'status': table_status,
                    'created': creation_date,
                    'item_count': item_count,
                    'size_mb': table_size_mb,
                    'billing_mode': billing_mode,
                    'keys': key_schema,
                    'category': category
                }
                
                table_details.append(table_detail)
                categories[category].append(table_detail)
                
                print(f"   ✅ Status: {table_status}")
                print(f"   📅 Created: {creation_date}")
                print(f"   📊 Items: {item_count:,}")
                print(f"   💾 Size: {table_size_mb} MB")
                print(f"   💰 Billing: {billing_mode}")
                print(f"   🔑 Keys: {', '.join(key_schema)}")
                print(f"   📂 Category: {category}")
                
            except Exception as e:
                print(f"   ❌ Error analyzing {table_name}: {e}")
        
        # Print categorized summary
        print("\n" + "=" * 60)
        print("📋 TABLES BY CATEGORY")
        print("=" * 60)
        
        total_items = 0
        total_size_mb = 0
        
        for category, tables in categories.items():
            if tables:
                print(f"\n🏷️  {category.upper()} ({len(tables)} tables):")
                print("-" * 50)
                
                for table in sorted(tables, key=lambda x: x['name']):
                    total_items += table['item_count']
                    total_size_mb += table['size_mb']
                    
                    print(f"   • {table['name']}")
                    print(f"     Items: {table['item_count']:,} | Size: {table['size_mb']} MB | {table['billing_mode']}")
        
        # Overall statistics
        print("\n" + "=" * 60)
        print("📊 OVERALL STATISTICS")
        print("=" * 60)
        print(f"Total Tables: {len(table_names)}")
        print(f"Total Items: {total_items:,}")
        print(f"Total Size: {total_size_mb:.2f} MB")
        print(f"Active Tables: {len([t for t in table_details if t['status'] == 'ACTIVE'])}")
        
        # Billing breakdown
        pay_per_request = len([t for t in table_details if t['billing_mode'] == 'PAY_PER_REQUEST'])
        provisioned = len([t for t in table_details if t['billing_mode'] == 'PROVISIONED'])
        
        print(f"Pay-per-request: {pay_per_request} tables")
        print(f"Provisioned: {provisioned} tables")
        
        return table_details
        
    except Exception as e:
        print(f"❌ Error: {e}")
        return []

def categorize_table(table_name):
    """Categorize table based on name patterns"""
    
    name_lower = table_name.lower()
    
    if any(keyword in name_lower for keyword in ['chat', 'conversation', 'session']):
        return 'Chat & Conversation'
    elif any(keyword in name_lower for keyword in ['user', 'active']):
        return 'User Management'
    elif any(keyword in name_lower for keyword in ['employee', 'emp', 'attendence', 'register']):
        return 'Employee Data'
    elif any(keyword in name_lower for keyword in ['textract', 'document']):
        return 'Document Processing'
    elif 'amplify' in name_lower:
        return 'AWS Amplify'
    elif 'migration-factory' in name_lower:
        return 'Migration Factory'
    elif 'performance-dashboard' in name_lower:
        return 'Performance Monitoring'
    elif any(keyword in name_lower for keyword in ['test', 'poc']):
        return 'Testing & Development'
    else:
        return 'Business Data'

if __name__ == "__main__":
    get_all_table_details()
