#!/usr/bin/env python3
"""
Test authentication and session loading
"""
import requests
import json

def test_auth_and_sessions():
    base_url = "http://localhost:8000"
    
    print("🧪 Testing Authentication and Sessions...")
    
    # Test 1: Try to access sessions without auth
    print("\n1. Testing sessions without auth:")
    response = requests.get(f"{base_url}/api/v1/sessions")
    print(f"   Status: {response.status_code}")
    print(f"   Response: {response.text}")
    
    # Test 2: Try to login with a known user
    print("\n2. Testing login:")
    login_data = {
        "username": "tanmay",
        "password": "Test@123"  # Common test password
    }
    
    response = requests.post(f"{base_url}/api/v1/auth/login", json=login_data)
    print(f"   Status: {response.status_code}")
    
    if response.status_code == 200:
        auth_data = response.json()
        token = auth_data.get("access_token")
        print(f"   ✅ Login successful, token: {token[:20]}...")
        
        # Test 3: Try sessions with auth
        print("\n3. Testing sessions with auth:")
        headers = {"Authorization": f"Bearer {token}"}
        response = requests.get(f"{base_url}/api/v1/sessions", headers=headers)
        print(f"   Status: {response.status_code}")
        
        if response.status_code == 200:
            sessions_data = response.json()
            sessions = sessions_data.get("sessions", [])
            print(f"   ✅ Found {len(sessions)} sessions")
            for i, session in enumerate(sessions[:3]):
                print(f"      {i+1}. {session.get('name', 'Untitled')[:50]} ({session.get('message_count', 0)} messages)")
        else:
            print(f"   ❌ Sessions failed: {response.text}")
    else:
        print(f"   ❌ Login failed: {response.text}")
        
        # Try with different credentials
        print("\n   Trying alternative credentials...")
        alt_passwords = ["password", "123456", "admin", "tanmay123"]
        for pwd in alt_passwords:
            login_data["password"] = pwd
            response = requests.post(f"{base_url}/api/v1/auth/login", json=login_data)
            if response.status_code == 200:
                print(f"   ✅ Login successful with password: {pwd}")
                break
            else:
                print(f"   ❌ Failed with password: {pwd}")

if __name__ == "__main__":
    test_auth_and_sessions()
