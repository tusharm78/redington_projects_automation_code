#!/usr/bin/env python3
import requests
import socketio
import asyncio

async def test_complete_streaming():
    print("🧪 Testing Complete Streaming Implementation")
    print("=" * 50)
    
    # Step 1: Test authentication
    print("1️⃣ Testing authentication...")
    auth_response = requests.post('http://localhost:8000/api/v1/auth/login', json={
        'username': 'demo',
        'password': 'demo123'
    })
    
    if auth_response.status_code == 200:
        token = auth_response.json()['access_token']
        print("✅ Authentication successful!")
    else:
        print("❌ Authentication failed!")
        return False
    
    # Step 2: Test Socket.IO streaming
    print("2️⃣ Testing Socket.IO streaming...")
    
    sio = socketio.AsyncClient()
    streaming_complete = False
    chunks_received = 0
    
    @sio.event
    async def connect():
        print("✅ Connected to Socket.IO")
        await sio.emit('authenticate', {'token': token})
    
    @sio.event
    async def auth_success(data):
        print(f"✅ Socket.IO authenticated as: {data['user']}")
        await sio.emit('send_message', {
            'message': 'Tell me about Redington services',
            'conversation_id': 'test-conv',
            'session_id': 'test-session'
        })
    
    @sio.event
    async def chat_start(data):
        print("🚀 Streaming started...")
        print("Response: ", end="", flush=True)
    
    @sio.event
    async def chat_chunk(data):
        nonlocal streaming_complete, chunks_received
        if data.get('is_complete'):
            print(f"\n✅ Streaming complete! Received {chunks_received} chunks")
            streaming_complete = True
        else:
            chunk = data.get('chunk', '')
            chunks_received += 1
            print(chunk, end="", flush=True)
    
    try:
        await sio.connect('http://localhost:8000')
        
        # Wait for streaming to complete
        for i in range(200):  # 20 second timeout
            if streaming_complete:
                break
            await asyncio.sleep(0.1)
        
        await sio.disconnect()
        
        if streaming_complete:
            print("🎉 Complete streaming test PASSED!")
            return True
        else:
            print("❌ Streaming test timed out")
            return False
            
    except Exception as e:
        print(f"❌ Socket.IO test failed: {e}")
        return False

if __name__ == "__main__":
    result = asyncio.run(test_complete_streaming())
    if result:
        print("\n🎯 Ready to use!")
        print("   Frontend: http://localhost:4001")
        print("   Demo credentials: demo / demo123")
    else:
        print("\n❌ Test failed")
