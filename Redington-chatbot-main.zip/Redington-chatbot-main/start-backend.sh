#!/bin/bash

# Start Backend Server
cd /home/chatbot/RedAIBot/react-bedrock-chatbot/backend

# Activate virtual environment
source venv/bin/activate

# Start uvicorn server in background
nohup uvicorn main:app --host 0.0.0.0 --port 8000 --reload > backend.log 2>&1 &

echo "Backend server started on http://localhost:8000"
echo "PID: $!"
echo "Logs: backend.log"
