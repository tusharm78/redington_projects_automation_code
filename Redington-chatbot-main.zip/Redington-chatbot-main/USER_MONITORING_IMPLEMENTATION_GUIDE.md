# User Monitoring System - Implementation Guide

## 🎯 Overview

This implementation provides a **separate admin dashboard** for monitoring user activity on your Redington AI Bot. The admin dashboard runs on `https://bot.redingtonsolutions.org/admin` and is completely isolated from the main chatbot interface.

## 👥 Admin Users Configured

The following users have been added to the admin list:
- **tanmay** (password: tanmay123)
- **meenal** (password: meenal123) 
- **varunesh** (password: varunesh123)
- **admin** (password: admin123)

## 🚀 Quick Deployment

### Option 1: Automated Deployment (Recommended)

```bash
cd /home/chatbot/Redington-chatbot
sudo ./deploy_user_monitoring.sh
```

This script will:
- Setup DynamoDB tables
- Install dependencies
- Update backend with monitoring
- Deploy admin dashboard
- Configure Nginx
- Restart services

### Option 2: Manual Deployment

If you prefer manual deployment, follow these steps:

#### 1. Setup Database
```bash
cd backend
python3 setup_user_monitoring_db.py
```

#### 2. Install Dependencies
```bash
cd backend
source venv/bin/activate
pip install boto3 python-jose[cryptography] python-multipart
```

#### 3. Deploy Admin Dashboard
```bash
# Copy admin dashboard to web directory
sudo mkdir -p /var/www/redington-bot/admin
sudo cp -r admin-dashboard/* /var/www/redington-bot/admin/
sudo chown -R www-data:www-data /var/www/redington-bot
```

#### 4. Update Nginx Configuration
```bash
# Copy the nginx configuration
sudo cp admin-dashboard/nginx-admin.conf /etc/nginx/sites-available/redington-bot
sudo ln -sf /etc/nginx/sites-available/redington-bot /etc/nginx/sites-enabled/
sudo nginx -t && sudo systemctl reload nginx
```

#### 5. Restart Backend
```bash
cd backend
pkill -f "enhanced_bedrock_main.py" || true
source venv/bin/activate
nohup python3 enhanced_bedrock_main.py > backend.log 2>&1 &
```

## 📊 Admin Dashboard Features

### 🔐 Secure Login
- Admin-only access with JWT authentication
- Automatic session management
- Secure logout functionality

### 📈 Real-time Statistics
- **Active Users Count**: Currently logged-in users
- **Total Sessions Today**: Chat sessions created
- **Average Session Duration**: Time users spend online
- **Most Active User**: User with most messages

### 👥 User Management
- **Active Users Table**: Real-time list of logged-in users
- **User Details**: Detailed session information
- **Force Logout**: Admin can logout any user
- **Session Cleanup**: Remove inactive sessions

### 🔄 Auto-refresh
- Dashboard updates every 30 seconds
- Real-time activity tracking
- Live user status updates

## 🌐 Access URLs

- **Main Chatbot**: https://bot.redingtonsolutions.org/
- **Admin Dashboard**: https://bot.redingtonsolutions.org/admin
- **Backend API**: http://localhost:8000/

## 🔧 Configuration Files

### Backend Files Added/Modified:
- `user_activity_monitor.py` - Core monitoring functionality
- `admin_routes.py` - Admin API endpoints
- `enhanced_bedrock_main.py` - Updated with monitoring integration
- `setup_user_monitoring_db.py` - Database setup script

### Frontend Files:
- `admin-dashboard/index.html` - Standalone admin dashboard
- `admin-dashboard/nginx-admin.conf` - Nginx configuration

### Admin Users Configuration:
Located in `backend/admin_routes.py`:
```python
ADMIN_USERS = [
    "admin",
    "administrator", 
    "redington_admin",
    "tanmay",
    "meenal", 
    "varunesh"
]
```

## 🛡️ Security Features

### Access Control
- JWT token-based authentication
- Admin privilege verification
- Session timeout management
- Secure API endpoints

### Data Protection
- Encrypted data transmission
- Automatic session cleanup (24-hour TTL)
- No sensitive data storage
- IP and user agent logging for security

### Admin Actions Logging
All admin actions are logged:
- User login/logout events
- Force logout actions
- Session cleanup operations
- Dashboard access attempts

## 📱 User Experience

### For Regular Users
- **No changes** to existing chatbot interface
- Transparent activity tracking
- No performance impact
- Same login/logout process

### For Admin Users
- **Separate admin interface** at `/admin`
- **Real-time monitoring** capabilities
- **User management** tools
- **System health** information

## 🔍 Monitoring Capabilities

### User Activity Tracking
- Login/logout timestamps
- Last activity updates
- Chat message counts
- Session creation tracking
- Duration calculations

### System Metrics
- Active user counts
- Session statistics
- Performance monitoring
- Database health checks

## 🚨 Troubleshooting

### Common Issues

1. **Admin Dashboard Not Loading**
   - Check nginx configuration
   - Verify admin dashboard files are deployed
   - Ensure `/admin` route is configured

2. **"Access Denied" Error**
   - Verify username is in ADMIN_USERS list
   - Check JWT token validity
   - Confirm admin privileges

3. **No Active Users Showing**
   - Check DynamoDB table exists
   - Verify backend monitoring is enabled
   - Test user login/logout flow

4. **Database Connection Issues**
   - Run database setup script
   - Check AWS credentials
   - Verify DynamoDB permissions

### Debug Commands

```bash
# Check backend logs
tail -f backend/backend.log

# Test admin API
curl -H "Authorization: Bearer YOUR_TOKEN" \
     http://localhost:8000/api/v1/admin/active-users

# Check nginx configuration
sudo nginx -t

# Verify DynamoDB table
aws dynamodb describe-table --table-name user_active_sessions
```

## 📈 Performance Considerations

### Database
- **Pay-per-request billing** for cost efficiency
- **TTL enabled** for automatic cleanup
- **Optimized queries** for fast response
- **Memory fallback** for high availability

### Frontend
- **Lightweight HTML/CSS/JS** for fast loading
- **Auto-refresh optimization** (30-second intervals)
- **Responsive design** for mobile access
- **Minimal resource usage**

### Backend
- **Async operations** for non-blocking performance
- **Efficient session management**
- **Optimized API endpoints**
- **Error handling and fallbacks**

## 🔄 Maintenance

### Regular Tasks
1. **Monitor active users** through admin dashboard
2. **Review admin action logs** in backend logs
3. **Check database usage** in AWS Console
4. **Update admin user list** as needed

### Automated Cleanup
- **Session TTL**: 24 hours automatic cleanup
- **Inactive user detection**: 30-minute timeout
- **Memory cleanup**: Automatic garbage collection
- **Log rotation**: Automatic log management

## 🎉 Success Verification

After deployment, verify the system by:

1. **Access admin dashboard**: https://bot.redingtonsolutions.org/admin
2. **Login as admin user**: Use tanmay/tanmay123 or other admin credentials
3. **View dashboard**: Should show statistics and active users
4. **Test user monitoring**: Login as regular user and see them appear
5. **Test admin functions**: Try force logout and session cleanup

## 📞 Support

### Log Locations
- **Backend logs**: `backend/backend.log`
- **Nginx logs**: `/var/log/nginx/redington-bot.*.log`
- **System logs**: `journalctl -u nginx`

### Key Metrics to Monitor
- Active user count trends
- Session duration patterns
- Admin action frequency
- System performance metrics

---

## 🎯 Summary

You now have a complete user monitoring system with:

✅ **Separate admin dashboard** at `/admin`  
✅ **Real-time user tracking** and statistics  
✅ **Admin users configured**: tanmay, meenal, varunesh  
✅ **Secure authentication** and access control  
✅ **User management tools** (force logout, cleanup)  
✅ **Auto-refresh** and live updates  
✅ **Production-ready** deployment  

The system is designed to be robust, secure, and user-friendly while providing comprehensive monitoring capabilities for your Redington AI Bot.
