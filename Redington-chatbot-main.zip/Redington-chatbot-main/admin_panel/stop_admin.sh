#!/bin/bash

# Redington Chatbot Admin Panel Stop Script

PID_FILE="/home/chatbot/Redington-chatbot/admin_panel.pid"

echo "Stopping Redington Chatbot Admin Panel..."

if [ -f "$PID_FILE" ]; then
    PID=$(cat "$PID_FILE")
    
    if ps -p $PID > /dev/null 2>&1; then
        echo "Stopping admin panel (PID: $PID)..."
        kill $PID
        
        # Wait for process to stop
        sleep 3
        
        if ps -p $PID > /dev/null 2>&1; then
            echo "Force killing admin panel..."
            kill -9 $PID
        fi
        
        rm -f "$PID_FILE"
        echo "✅ Admin panel stopped successfully"
    else
        echo "Admin panel is not running"
        rm -f "$PID_FILE"
    fi
else
    echo "PID file not found. Checking for running processes..."
    
    # Kill any running admin panel processes
    pkill -f "admin_panel/app.py"
    
    if [ $? -eq 0 ]; then
        echo "✅ Stopped admin panel processes"
    else
        echo "No admin panel processes found"
    fi
fi
