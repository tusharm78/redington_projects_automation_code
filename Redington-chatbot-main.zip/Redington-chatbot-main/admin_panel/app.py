#!/usr/bin/env python3
"""
Redington Chatbot Admin Panel
Standalone monitoring and administration interface
"""

from flask import Flask, render_template, request, redirect, url_for, session, jsonify, flash
from flask_socketio import SocketIO, emit
import psutil
import json
import os
import time
import boto3
from datetime import datetime, timedelta
from functools import wraps
import hashlib
import threading
import logging
from botocore.exceptions import ClientError

# Configure logging
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

app = Flask(__name__)
app.secret_key = 'redington_admin_secret_key_2024'
socketio = SocketIO(app, cors_allowed_origins="*")

# Admin credentials
ADMIN_USERNAME = "admin"
ADMIN_PASSWORD = "admin123$"

# Configuration
CHATBOT_DIR = "/home/chatbot/Redington-chatbot"
METRICS_FILE = os.path.join(CHATBOT_DIR, "metrics_history.json")
ALERTS_FILE = os.path.join(CHATBOT_DIR, "alerts.json")

class SystemMonitor:
    def __init__(self):
        self.start_time = time.time()
        self.alert_thresholds = {
            'cpu_percent': 80,
            'memory_percent': 85,
            'disk_percent': 90,
            'response_time': 5.0
        }
    
    def get_process_info(self):
        """Get chatbot process information"""
        processes = {
            'backend': [],
            'admin_apis': [],
            'frontend': [],
            'total_processes': 0
        }
        
        for proc in psutil.process_iter(['pid', 'name', 'cmdline', 'cpu_percent', 'memory_percent', 'memory_info', 'create_time']):
            try:
                cmdline = ' '.join(proc.info['cmdline']) if proc.info['cmdline'] else ''
                
                if 'enhanced_bedrock_main' in cmdline or 'uvicorn' in cmdline:
                    processes['backend'].append({
                        'pid': proc.info['pid'],
                        'name': proc.info['name'],
                        'cpu_percent': proc.info['cpu_percent'],
                        'memory_percent': proc.info['memory_percent'],
                        'memory_mb': proc.info['memory_info'].rss / 1024 / 1024,
                        'uptime': time.time() - proc.info['create_time'],
                        'cmdline': cmdline[:100] + '...' if len(cmdline) > 100 else cmdline
                    })
                
                elif any(api in cmdline for api in ['admin_api.py', 'simple_admin_api.py', 'realtime_admin_api.py', 'secure_admin_api.py']):
                    processes['admin_apis'].append({
                        'pid': proc.info['pid'],
                        'name': proc.info['name'],
                        'cpu_percent': proc.info['cpu_percent'],
                        'memory_percent': proc.info['memory_percent'],
                        'memory_mb': proc.info['memory_info'].rss / 1024 / 1024,
                        'uptime': time.time() - proc.info['create_time'],
                        'cmdline': cmdline[:100] + '...' if len(cmdline) > 100 else cmdline
                    })
                
                elif 'node' in proc.info['name'] and ('react' in cmdline or '3000' in cmdline):
                    processes['frontend'].append({
                        'pid': proc.info['pid'],
                        'name': proc.info['name'],
                        'cpu_percent': proc.info['cpu_percent'],
                        'memory_percent': proc.info['memory_percent'],
                        'memory_mb': proc.info['memory_info'].rss / 1024 / 1024,
                        'uptime': time.time() - proc.info['create_time'],
                        'cmdline': cmdline[:100] + '...' if len(cmdline) > 100 else cmdline
                    })
                    
            except (psutil.NoSuchProcess, psutil.AccessDenied):
                continue
        
        processes['total_processes'] = len(processes['backend']) + len(processes['frontend']) + len(processes['admin_apis'])
        return processes
    
    def get_system_metrics(self):
        """Get comprehensive system metrics"""
        cpu_percent = psutil.cpu_percent(interval=1)
        cpu_count = psutil.cpu_count()
        load_avg = os.getloadavg()
        
        memory = psutil.virtual_memory()
        swap = psutil.swap_memory()
        
        disk = psutil.disk_usage('/')
        disk_io = psutil.disk_io_counters()
        
        network = psutil.net_io_counters()
        
        process_info = self.get_process_info()
        
        return {
            'timestamp': datetime.now().isoformat(),
            'uptime_hours': (time.time() - self.start_time) / 3600,
            'cpu': {
                'percent': cpu_percent,
                'count': cpu_count,
                'load_avg_1m': load_avg[0],
                'load_avg_5m': load_avg[1],
                'load_avg_15m': load_avg[2]
            },
            'memory': {
                'total_gb': memory.total / 1024**3,
                'used_gb': memory.used / 1024**3,
                'available_gb': memory.available / 1024**3,
                'percent': memory.percent,
                'swap_used_gb': swap.used / 1024**3 if swap.total > 0 else 0,
                'swap_percent': swap.percent if swap.total > 0 else 0
            },
            'disk': {
                'total_gb': disk.total / 1024**3,
                'used_gb': disk.used / 1024**3,
                'free_gb': disk.free / 1024**3,
                'percent': (disk.used / disk.total) * 100,
                'read_mb': disk_io.read_bytes / 1024**2 if disk_io else 0,
                'write_mb': disk_io.write_bytes / 1024**2 if disk_io else 0
            },
            'network': {
                'bytes_sent_mb': network.bytes_sent / 1024**2,
                'bytes_recv_mb': network.bytes_recv / 1024**2,
                'packets_sent': network.packets_sent,
                'packets_recv': network.packets_recv
            },
            'processes': process_info
        }
    
    def get_active_users_count(self):
        """Get active users from DynamoDB - returns 0 if not available"""
        try:
            dynamodb = boto3.resource('dynamodb', region_name='us-east-1')
            table = dynamodb.Table('user_active_sessions')
            response = table.scan()
            return len(response.get('Items', []))
        except Exception as e:
            logger.warning(f"User tracking not available: {e}")
            return 0
    
    def get_user_sessions(self):
        """Get detailed user session information - returns empty if not available"""
        try:
            dynamodb = boto3.resource('dynamodb', region_name='us-east-1')
            table = dynamodb.Table('user_active_sessions')
            response = table.scan()
            return response.get('Items', [])
        except Exception as e:
            logger.warning(f"User sessions not available: {e}")
            return []
    
    def check_alerts(self, metrics):
        """Check for alert conditions"""
        alerts = []
        
        if metrics['cpu']['percent'] > self.alert_thresholds['cpu_percent']:
            alerts.append(f"HIGH CPU: {metrics['cpu']['percent']:.1f}%")
        
        if metrics['memory']['percent'] > self.alert_thresholds['memory_percent']:
            alerts.append(f"HIGH MEMORY: {metrics['memory']['percent']:.1f}%")
        
        if metrics['disk']['percent'] > self.alert_thresholds['disk_percent']:
            alerts.append(f"HIGH DISK: {metrics['disk']['percent']:.1f}%")
        
        if metrics['cpu']['load_avg_5m'] > metrics['cpu']['count']:
            alerts.append(f"HIGH LOAD: {metrics['cpu']['load_avg_5m']:.2f}")
        
        return alerts

# Initialize monitor
monitor = SystemMonitor()

def login_required(f):
    """Decorator to require login"""
    @wraps(f)
    def decorated_function(*args, **kwargs):
        if 'logged_in' not in session:
            return redirect(url_for('login'))
        return f(*args, **kwargs)
    return decorated_function

@app.route('/')
def root_redirect():
    """Redirect root to admin login"""
    return redirect(url_for('login'))

@app.route('/admin')
def admin_redirect():
    """Redirect /admin to login"""
    return redirect(url_for('login'))

@app.route('/admin/')
def admin_root():
    """Redirect /admin/ to login"""
    return redirect(url_for('login'))

@app.route('/admin/login', methods=['GET', 'POST'])
def login():
    """Admin login page"""
    if request.method == 'POST':
        username = request.form['username']
        password = request.form['password']
        
        if username == ADMIN_USERNAME and password == ADMIN_PASSWORD:
            session['logged_in'] = True
            session['username'] = username
            flash('Successfully logged in!', 'success')
            return redirect(url_for('dashboard'))
        else:
            flash('Invalid credentials!', 'error')
    
    return render_template('login.html')

@app.route('/admin/logout')
def logout():
    """Admin logout"""
    session.clear()
    flash('Successfully logged out!', 'success')
    return redirect(url_for('login'))

@app.route('/admin/dashboard')
@login_required
def dashboard():
    """Main admin dashboard"""
    return render_template('dashboard.html')

@app.route('/admin/api/metrics')
@login_required
def api_metrics():
    """API endpoint for system metrics"""
    try:
        metrics = monitor.get_system_metrics()
        active_users = monitor.get_active_users_count()
        alerts = monitor.check_alerts(metrics)
        
        # Calculate capacity
        cpu_capacity = max(1, int((100 - metrics['cpu']['percent']) / 5))
        memory_capacity = max(1, int((metrics['memory']['available_gb'] * 1024) / 50))
        recommended_max = min(cpu_capacity, memory_capacity)
        
        capacity = {
            'current_active_users': active_users,
            'recommended_max_users': recommended_max,
            'current_utilization_percent': (active_users / max(1, recommended_max)) * 100
        }
        
        return jsonify({
            'success': True,
            'metrics': metrics,
            'capacity': capacity,
            'alerts': alerts
        })
    except Exception as e:
        logger.error(f"Error getting metrics: {e}")
        return jsonify({'success': False, 'error': str(e)})

@app.route('/admin/api/users')
@login_required
def api_users():
    """API endpoint for active users"""
    try:
        users = monitor.get_user_sessions()
        if not users:
            # Return a message indicating user tracking is disabled
            return jsonify({
                'success': True,
                'users': [],
                'message': 'User tracking is currently disabled. Enable user tracking to see active users.'
            })
        return jsonify({
            'success': True,
            'users': users
        })
    except Exception as e:
        logger.error(f"Error getting users: {e}")
        return jsonify({
            'success': False, 
            'error': str(e),
            'message': 'User tracking is not available.'
        })

@app.route('/admin/api/logs')
@login_required
def api_logs():
    """API endpoint for system logs"""
    try:
        logs = []
        log_files = [
            ('Backend', os.path.join(CHATBOT_DIR, 'backend.log')),
            ('Frontend', os.path.join(CHATBOT_DIR, 'frontend.log')),
            ('System Monitor', os.path.join(CHATBOT_DIR, 'system_monitor.log'))
        ]
        
        for log_name, log_file in log_files:
            if os.path.exists(log_file):
                try:
                    with open(log_file, 'r') as f:
                        lines = f.readlines()[-50:]  # Last 50 lines
                        logs.append({
                            'name': log_name,
                            'lines': [line.strip() for line in lines]
                        })
                except Exception as e:
                    logs.append({
                        'name': log_name,
                        'lines': [f'Error reading log: {str(e)}']
                    })
        
        return jsonify({
            'success': True,
            'logs': logs
        })
    except Exception as e:
        logger.error(f"Error getting logs: {e}")
        return jsonify({'success': False, 'error': str(e)})

@app.route('/admin/api/alerts')
@login_required
def api_alerts():
    """API endpoint for alerts"""
    try:
        alerts = []
        if os.path.exists(ALERTS_FILE):
            with open(ALERTS_FILE, 'r') as f:
                alerts = json.load(f)
        
        # Get recent alerts (last 24 hours)
        cutoff_time = datetime.now() - timedelta(hours=24)
        recent_alerts = [
            alert for alert in alerts 
            if datetime.fromisoformat(alert['timestamp']) > cutoff_time
        ]
        
        return jsonify({
            'success': True,
            'alerts': recent_alerts[-50:]  # Last 50 alerts
        })
    except Exception as e:
        logger.error(f"Error getting alerts: {e}")
        return jsonify({'success': False, 'error': str(e)})

@app.route('/admin/api/restart/<service>')
@login_required
def api_restart_service(service):
    """API endpoint to restart services"""
    try:
        if service == 'backend':
            # Kill existing backend processes
            os.system("pkill -f 'enhanced_bedrock_main'")
            time.sleep(2)
            
            # Start backend
            os.system(f"cd {CHATBOT_DIR}/backend && nohup python3 enhanced_bedrock_main.py > ../backend.log 2>&1 &")
            message = "Backend service restarted"
            
        elif service == 'frontend':
            # Kill existing frontend processes
            os.system("pkill -f 'npm start'")
            time.sleep(2)
            
            # Start frontend
            os.system(f"cd {CHATBOT_DIR}/frontend && nohup npm start > ../frontend.log 2>&1 &")
            message = "Frontend service restarted"
            
        else:
            return jsonify({'success': False, 'error': 'Invalid service'})
        
        return jsonify({
            'success': True,
            'message': message
        })
    except Exception as e:
        logger.error(f"Error restarting service: {e}")
        return jsonify({'success': False, 'error': str(e)})

@app.route('/admin/api/force-logout/<username>')
@login_required
def api_force_logout(username):
    """API endpoint to force logout a user"""
    try:
        dynamodb = boto3.resource('dynamodb', region_name='us-east-1')
        table = dynamodb.Table('user_active_sessions')
        
        # Remove user session
        table.delete_item(Key={'username': username})
        
        return jsonify({
            'success': True,
            'message': f'User {username} logged out successfully'
        })
    except Exception as e:
        logger.error(f"Error forcing logout: {e}")
        return jsonify({
            'success': False, 
            'error': 'User tracking is not available. Cannot force logout users.',
            'message': 'User tracking is currently disabled.'
        })

# WebSocket events for real-time updates
@socketio.on('connect')
def handle_connect():
    """Handle WebSocket connection"""
    if 'logged_in' not in session:
        return False
    emit('connected', {'message': 'Connected to admin panel'})

@socketio.on('request_metrics')
def handle_metrics_request():
    """Handle real-time metrics request"""
    if 'logged_in' not in session:
        return False
    
    try:
        metrics = monitor.get_system_metrics()
        active_users = monitor.get_active_users_count()
        alerts = monitor.check_alerts(metrics)
        
        emit('metrics_update', {
            'metrics': metrics,
            'active_users': active_users,
            'alerts': alerts,
            'timestamp': datetime.now().isoformat()
        })
    except Exception as e:
        emit('error', {'message': str(e)})

def background_metrics_sender():
    """Send metrics updates every 30 seconds"""
    while True:
        try:
            time.sleep(30)
            with app.app_context():
                metrics = monitor.get_system_metrics()
                active_users = monitor.get_active_users_count()
                alerts = monitor.check_alerts(metrics)
                
                socketio.emit('metrics_update', {
                    'metrics': metrics,
                    'active_users': active_users,
                    'alerts': alerts,
                    'timestamp': datetime.now().isoformat()
                })
        except Exception as e:
            logger.error(f"Background metrics error: {e}")

if __name__ == '__main__':
    # Start background thread for metrics
    metrics_thread = threading.Thread(target=background_metrics_sender, daemon=True)
    metrics_thread.start()
    
    # Run the app
    socketio.run(app, host='0.0.0.0', port=5001, debug=False, allow_unsafe_werkzeug=True)
