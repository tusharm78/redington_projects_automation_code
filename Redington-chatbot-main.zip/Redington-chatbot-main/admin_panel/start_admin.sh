#!/bin/bash

# Redington Chatbot Admin Panel Startup Script

ADMIN_DIR="/home/chatbot/Redington-chatbot/admin_panel"
LOG_FILE="/home/chatbot/Redington-chatbot/admin_panel.log"
PID_FILE="/home/chatbot/Redington-chatbot/admin_panel.pid"

echo "Starting Redington Chatbot Admin Panel..."

# Check if already running
if [ -f "$PID_FILE" ]; then
    PID=$(cat "$PID_FILE")
    if ps -p $PID > /dev/null 2>&1; then
        echo "Admin panel is already running (PID: $PID)"
        exit 1
    else
        echo "Removing stale PID file"
        rm -f "$PID_FILE"
    fi
fi

# Change to admin directory
cd "$ADMIN_DIR"

# Install dependencies if needed
if [ ! -d "venv" ]; then
    echo "Creating virtual environment..."
    python3 -m venv venv
fi

# Activate virtual environment
source venv/bin/activate

# Install/upgrade dependencies
echo "Installing dependencies..."
pip install -r requirements.txt

# Start the admin panel
echo "Starting admin panel on port 5001..."
nohup python3 app.py > "$LOG_FILE" 2>&1 &

# Save PID
echo $! > "$PID_FILE"

echo "Admin panel started successfully!"
echo "Access it at: https://bot.redingtonsolutions.org/admin"
echo "Login credentials: admin / admin123$"
echo "Log file: $LOG_FILE"
echo "PID file: $PID_FILE"

# Show status
sleep 2
if ps -p $(cat "$PID_FILE") > /dev/null 2>&1; then
    echo "✅ Admin panel is running (PID: $(cat "$PID_FILE"))"
else
    echo "❌ Failed to start admin panel. Check log file: $LOG_FILE"
    exit 1
fi
