#!/usr/bin/env python3

import boto3
import hmac
import hashlib
import base64
import os
from dotenv import load_dotenv

# Load environment variables
load_dotenv('/home/chatbot/Redington-chatbot/backend/.env')

def calculate_secret_hash(username, client_id, client_secret):
    """Calculate the secret hash for Cognito authentication"""
    message = username + client_id
    dig = hmac.new(
        client_secret.encode('utf-8'),
        message.encode('utf-8'),
        hashlib.sha256
    ).digest()
    return base64.b64encode(dig).decode()

def test_cognito_auth():
    pool_id = os.getenv('POOL_ID')
    client_id = os.getenv('APP_CLIENT_ID')
    client_secret = os.getenv('APP_CLIENT_SECRET')
    region = pool_id.split('_')[0] if pool_id and '_' in pool_id else 'us-east-1'
    
    print(f"Pool ID: {pool_id}")
    print(f"Client ID: {client_id}")
    print(f"Region: {region}")
    
    cognito_client = boto3.client('cognito-idp', region_name=region)
    
    username = "meenal"
    password = "Tushita@01"
    
    try:
        secret_hash = calculate_secret_hash(username, client_id, client_secret)
        print(f"Secret hash calculated for user: {username}")
        
        response = cognito_client.initiate_auth(
            ClientId=client_id,
            AuthFlow='USER_PASSWORD_AUTH',
            AuthParameters={
                'USERNAME': username,
                'PASSWORD': password,
                'SECRET_HASH': secret_hash
            }
        )
        
        print("Authentication successful!")
        print(f"Response: {response}")
        
    except Exception as e:
        print(f"Authentication failed: {e}")
        print(f"Exception type: {type(e).__name__}")
        
        # Check if it's a password change required error
        if hasattr(e, 'response') and e.response:
            error_code = e.response.get('Error', {}).get('Code', '')
            print(f"Error code: {error_code}")
            
            if error_code == 'PasswordResetRequiredException':
                print("User needs to reset password")
            elif error_code == 'UserNotConfirmedException':
                print("User account not confirmed")
            elif error_code == 'NotAuthorizedException':
                print("Invalid credentials or user status issue")

if __name__ == "__main__":
    test_cognito_auth()
