#!/bin/bash
echo "🔍 Verifying No INR References in Redington Chatbot"
echo "================================================="

echo "\n1. Checking backend Python files..."
INR_BACKEND=$(find /home/chatbot/Redington-chatbot/backend -name '*.py' -not -path '*/venv/*' -exec grep -l 'INR\|₹' {} \; 2>/dev/null)
if [ -z "$INR_BACKEND" ]; then
    echo "✅ No INR references found in backend files"
else
    echo "❌ INR references found in: $INR_BACKEND"
fi

echo "\n2. Checking frontend source files..."
INR_FRONTEND=$(find /home/chatbot/Redington-chatbot/frontend/src -name '*.js' -o -name '*.jsx' -o -name '*.ts' -o -name '*.tsx' 2>/dev/null | xargs grep -l 'INR\|₹' 2>/dev/null)
if [ -z "$INR_FRONTEND" ]; then
    echo "✅ No INR references found in frontend source files"
else
    echo "❌ INR references found in: $INR_FRONTEND"
fi

echo "\n3. Checking main enhanced_bedrock_main.py..."
if grep -q 'INR\|₹' /home/chatbot/Redington-chatbot/backend/enhanced_bedrock_main.py; then
    echo "❌ INR references found in main backend file"
    grep -n 'INR\|₹' /home/chatbot/Redington-chatbot/backend/enhanced_bedrock_main.py
else
    echo "✅ No INR references in main backend file"
fi

echo "\n4. Checking commercial cost function uses USD..."
if grep -q 'formatted_cost.*\$' /home/chatbot/Redington-chatbot/backend/enhanced_bedrock_main.py; then
    echo "✅ Commercial cost function uses USD formatting"
else
    echo "❌ Commercial cost function may not be using USD"
fi

echo "\n5. Checking system prompt uses USD..."
if grep -q 'Duration(weeks) × 8 × 5 × 25 (in USD)' /home/chatbot/Redington-chatbot/backend/enhanced_bedrock_main.py; then
    echo "✅ System prompt specifies USD currency"
else
    echo "❌ System prompt may not specify USD"
fi

echo "\n📋 Verification Complete"
echo "========================"
