#!/usr/bin/env python3
"""
Backend Code Fixes for Redington Chatbot
=========================================

This file contains the necessary backend modifications to ensure consistent
chat history storage in the chat_history table only.

Issues to Fix:
1. Inconsistent table usage (chat_history vs user_chat_sessions)
2. Multiple code paths storing data in different tables
3. Need to standardize on single table (chat_history)
4. Ensure proper data structure consistency

Backend Files to Modify:
- app/services/chat_service.py
- app/api/chat.py
- app/models/chat.py
- app/utils/database.py
"""

# =============================================================================
# 1. STANDARDIZED CHAT SERVICE (app/services/chat_service.py)
# =============================================================================

CHAT_SERVICE_CODE = '''
import boto3
import uuid
from datetime import datetime
from typing import List, Dict, Any, Optional
from app.core.config import settings

class ChatService:
    """Standardized chat service that uses only chat_history table"""
    
    def __init__(self):
        self.dynamodb = boto3.client('dynamodb', region_name=settings.AWS_DEFAULT_REGION)
        self.table_name = 'chat_history'  # SINGLE SOURCE OF TRUTH
    
    def save_chat_message(self, user_id: str, message: str, response: str, 
                         model: str, conversation_id: Optional[str] = None) -> str:
        """Save chat message to chat_history table ONLY"""
        
        if not conversation_id:
            conversation_id = str(uuid.uuid4())
        
        timestamp = datetime.now().isoformat()
        
        # Standardized item structure
        item = {
            'user_id': {'S': user_id},
            'conversation_id': {'S': conversation_id},
            'timestamp': {'S': timestamp},
            'message': {'S': message},
            'response': {'S': response},
            'model': {'S': model},
            'session_id': {'S': conversation_id}  # For backward compatibility
        }
        
        try:
            self.dynamodb.put_item(
                TableName=self.table_name,
                Item=item
            )
            return conversation_id
        except Exception as e:
            print(f"Error saving chat message: {e}")
            raise
    
    def get_user_chat_history(self, user_id: str, limit: int = 50) -> List[Dict]:
        """Get user's chat history from chat_history table ONLY"""
        
        try:
            response = self.dynamodb.query(
                TableName=self.table_name,
                KeyConditionExpression='user_id = :user_id',
                ExpressionAttributeValues={
                    ':user_id': {'S': user_id}
                },
                ScanIndexForward=False,  # Most recent first
                Limit=limit
            )
            
            # Convert DynamoDB format to regular dict
            items = []
            for item in response.get('Items', []):
                converted_item = self._convert_dynamodb_item(item)
                items.append(converted_item)
            
            return items
            
        except Exception as e:
            print(f"Error retrieving chat history: {e}")
            return []
    
    def get_conversation_history(self, user_id: str, conversation_id: str) -> List[Dict]:
        """Get specific conversation history"""
        
        try:
            response = self.dynamodb.query(
                TableName=self.table_name,
                KeyConditionExpression='user_id = :user_id',
                FilterExpression='conversation_id = :conv_id',
                ExpressionAttributeValues={
                    ':user_id': {'S': user_id},
                    ':conv_id': {'S': conversation_id}
                },
                ScanIndexForward=True  # Chronological order
            )
            
            items = []
            for item in response.get('Items', []):
                converted_item = self._convert_dynamodb_item(item)
                items.append(converted_item)
            
            return items
            
        except Exception as e:
            print(f"Error retrieving conversation history: {e}")
            return []
    
    def _convert_dynamodb_item(self, item: Dict) -> Dict:
        """Convert DynamoDB item to regular dict"""
        result = {}
        for key, value in item.items():
            if 'S' in value:
                result[key] = value['S']
            elif 'N' in value:
                result[key] = float(value['N']) if '.' in value['N'] else int(value['N'])
            elif 'BOOL' in value:
                result[key] = value['BOOL']
            else:
                result[key] = str(value)
        return result

# Global instance
chat_service = ChatService()
'''

# =============================================================================
# 2. UPDATED CHAT API ENDPOINTS (app/api/chat.py)
# =============================================================================

CHAT_API_CODE = '''
from fastapi import APIRouter, Depends, HTTPException, status
from fastapi.responses import StreamingResponse
from app.services.chat_service import chat_service
from app.services.bedrock_service import bedrock_service
from app.models.chat import ChatMessage, ChatResponse
from app.core.auth import get_current_user
from typing import List

router = APIRouter()

@router.post("/message", response_model=ChatResponse)
async def send_message(
    chat_message: ChatMessage,
    current_user: dict = Depends(get_current_user)
):
    """Send chat message and get response"""
    
    try:
        user_id = current_user.get('username')
        
        # Get AI response from Bedrock
        ai_response = await bedrock_service.generate_response(
            message=chat_message.message,
            model=chat_message.model,
            user_id=user_id
        )
        
        # Save to chat_history table ONLY
        conversation_id = chat_service.save_chat_message(
            user_id=user_id,
            message=chat_message.message,
            response=ai_response,
            model=chat_message.model,
            conversation_id=chat_message.conversation_id
        )
        
        return ChatResponse(
            response=ai_response,
            conversation_id=conversation_id,
            model=chat_message.model
        )
        
    except Exception as e:
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail=f"Error processing message: {str(e)}"
        )

@router.get("/history/{conversation_id}")
async def get_conversation_history(
    conversation_id: str,
    current_user: dict = Depends(get_current_user)
):
    """Get conversation history"""
    
    try:
        user_id = current_user.get('username')
        
        # Get from chat_history table ONLY
        history = chat_service.get_conversation_history(user_id, conversation_id)
        
        return {"history": history}
        
    except Exception as e:
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail=f"Error retrieving history: {str(e)}"
        )

@router.get("/history")
async def get_user_chat_history(
    limit: int = 50,
    current_user: dict = Depends(get_current_user)
):
    """Get user's complete chat history"""
    
    try:
        user_id = current_user.get('username')
        
        # Get from chat_history table ONLY
        history = chat_service.get_user_chat_history(user_id, limit)
        
        return {"history": history}
        
    except Exception as e:
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail=f"Error retrieving user history: {str(e)}"
        )
'''

# =============================================================================
# 3. STANDARDIZED CHAT MODELS (app/models/chat.py)
# =============================================================================

CHAT_MODELS_CODE = '''
from pydantic import BaseModel
from typing import Optional, List
from datetime import datetime

class ChatMessage(BaseModel):
    """Standardized chat message model"""
    message: str
    model: str = "Claude 3.7 Sonnet"
    conversation_id: Optional[str] = None

class ChatResponse(BaseModel):
    """Standardized chat response model"""
    response: str
    conversation_id: str
    model: str
    timestamp: Optional[str] = None

class ChatHistoryItem(BaseModel):
    """Standardized chat history item"""
    user_id: str
    conversation_id: str
    timestamp: str
    message: str
    response: str
    model: str
    session_id: Optional[str] = None  # For backward compatibility

class ConversationHistory(BaseModel):
    """Complete conversation history"""
    conversation_id: str
    messages: List[ChatHistoryItem]
    created_at: str
    updated_at: str
'''

# =============================================================================
# 4. DATABASE UTILITY FUNCTIONS (app/utils/database.py)
# =============================================================================

DATABASE_UTILS_CODE = '''
import boto3
from typing import Dict, List, Any
from app.core.config import settings

class DatabaseUtils:
    """Utility functions for database operations"""
    
    def __init__(self):
        self.dynamodb = boto3.client('dynamodb', region_name=settings.AWS_DEFAULT_REGION)
    
    def ensure_single_table_usage(self):
        """Ensure all chat operations use chat_history table only"""
        
        # This function can be used to validate that no code is using user_chat_sessions
        # for new chat storage operations
        
        ALLOWED_CHAT_TABLE = 'chat_history'
        DEPRECATED_TABLES = ['user_chat_sessions', 'user_active_sessions']
        
        return {
            'primary_table': ALLOWED_CHAT_TABLE,
            'deprecated_tables': DEPRECATED_TABLES,
            'migration_required': True
        }
    
    def validate_chat_record(self, record: Dict) -> bool:
        """Validate chat record structure"""
        
        required_fields = ['user_id', 'conversation_id', 'timestamp', 'message', 'response', 'model']
        
        for field in required_fields:
            if field not in record:
                return False
        
        return True
    
    def convert_legacy_record(self, legacy_record: Dict) -> Dict:
        """Convert legacy user_chat_sessions record to chat_history format"""
        
        # This function helps convert any remaining legacy records
        standardized_record = {
            'user_id': legacy_record.get('user_id'),
            'conversation_id': legacy_record.get('conversation_id', legacy_record.get('session_id')),
            'timestamp': legacy_record.get('timestamp'),
            'message': legacy_record.get('message', legacy_record.get('query')),
            'response': legacy_record.get('response', legacy_record.get('answer')),
            'model': legacy_record.get('model', 'Claude 3.7 Sonnet'),
            'session_id': legacy_record.get('session_id')
        }
        
        return standardized_record

# Global instance
db_utils = DatabaseUtils()
'''

# =============================================================================
# 5. CONFIGURATION UPDATES (app/core/config.py)
# =============================================================================

CONFIG_UPDATES = '''
# Add these settings to your config.py file

class Settings:
    # ... existing settings ...
    
    # Chat Configuration
    PRIMARY_CHAT_TABLE: str = "chat_history"
    DEPRECATED_CHAT_TABLES: List[str] = ["user_chat_sessions", "user_active_sessions"]
    
    # Migration Settings
    ENABLE_LEGACY_SUPPORT: bool = False  # Set to False after migration
    MIGRATION_COMPLETED: bool = False    # Set to True after migration
    
    # Data Validation
    VALIDATE_CHAT_RECORDS: bool = True
    ENFORCE_SINGLE_TABLE: bool = True
'''

def generate_backend_fix_summary():
    """Generate summary of backend fixes"""
    
    summary = """
BACKEND FIXES SUMMARY
====================

Files to Update:
1. app/services/chat_service.py - Standardized chat service using only chat_history table
2. app/api/chat.py - Updated API endpoints to use single table
3. app/models/chat.py - Standardized data models
4. app/utils/database.py - Database utility functions
5. app/core/config.py - Configuration updates

Key Changes:
- All chat operations now use chat_history table exclusively
- Removed references to user_chat_sessions for new data
- Standardized data structure across all operations
- Added validation and conversion utilities
- Implemented backward compatibility during transition

Implementation Steps:
1. Run data migration script first (data_migration_solution.py)
2. Update backend code with the fixes above
3. Test thoroughly in development environment
4. Deploy to production
5. Monitor for any issues
6. Clean up deprecated tables after confirmation

Critical Points:
- NEVER store new chat data in user_chat_sessions table
- Always use chat_service.save_chat_message() for new messages
- Validate all chat records before storage
- Maintain conversation_id consistency
- Preserve backward compatibility during transition
"""
    
    return summary

if __name__ == "__main__":
    print(generate_backend_fix_summary())
