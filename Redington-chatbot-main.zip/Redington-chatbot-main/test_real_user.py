#!/usr/bin/env python3

import asyncio
import sys
import os
sys.path.append('/home/chatbot/Redington-chatbot/backend')

from session_manager import SessionManager

async def test_real_user():
    """Test session retrieval for real user"""
    print("🧪 Testing session retrieval for real user...")
    
    session_manager = SessionManager()
    
    # Test real user
    username = "subashini"
    
    print(f"\n1. Getting user sessions for: {username}")
    sessions = await session_manager.get_user_sessions(username)
    print(f"📋 Found {len(sessions)} sessions:")
    for session in sessions:
        print(f"   - ID: {session['id']}")
        print(f"     Title: {session['name']}")
        print(f"     Messages: {session['message_count']}")
        print(f"     Last: {session['last_message'][:50]}...")
        print()
    
    if sessions:
        session_id = sessions[0]['id']
        print(f"\n2. Getting messages for session: {session_id}")
        messages = await session_manager.get_session_messages(session_id)
        print(f"💬 Found {len(messages)} messages:")
        for i, msg in enumerate(messages[:5]):  # Show first 5 messages
            print(f"   {i+1}. {msg['role']}: {msg['content'][:50]}...")

if __name__ == "__main__":
    asyncio.run(test_real_user())
