#!/bin/bash

echo "🔍 Redington AI Chatbot - Server Status Check"
echo "=============================================="

# Check if processes are running
BACKEND_PROC=$(ps aux | grep "uvicorn main:app" | grep -v grep | wc -l)
FRONTEND_PROC=$(ps aux | grep "react-scripts start" | grep -v grep | wc -l)

echo "Process Status:"
echo "Backend processes: $BACKEND_PROC"
echo "Frontend processes: $FRONTEND_PROC"
echo ""

# Check HTTP status
BACKEND_HTTP=$(curl -s -o /dev/null -w "%{http_code}" http://localhost:8000 2>/dev/null || echo "000")
FRONTEND_HTTP=$(curl -s -o /dev/null -w "%{http_code}" http://localhost:3000 2>/dev/null || echo "000")

echo "HTTP Status:"
echo "Backend (8000): $([[ $BACKEND_HTTP == "200" ]] && echo "✅ $BACKEND_HTTP" || echo "❌ $BACKEND_HTTP")"
echo "Frontend (3000): $([[ $FRONTEND_HTTP == "200" ]] && echo "✅ $FRONTEND_HTTP" || echo "❌ $FRONTEND_HTTP")"
echo ""

# Test authentication
echo "Authentication Test:"
AUTH_RESULT=$(curl -X POST "http://localhost:8000/api/v1/auth/login" \
     -H "Content-Type: application/json" \
     -d '{"username": "tanmay", "password": "Admin@123$"}' \
     -s -w "%{http_code}" -o /tmp/auth_test.json 2>/dev/null)

if [[ $AUTH_RESULT == "200" ]]; then
    echo "✅ Authentication working"
else
    echo "❌ Authentication failed (HTTP: $AUTH_RESULT)"
fi

echo ""
echo "=== Quick Access ==="
echo "🌐 Frontend: http://localhost:3000"
echo "🔧 Backend: http://localhost:8000"
echo "📚 API Docs: http://localhost:8000/docs"
echo ""
echo "Login: tanmay / Admin@123$"
