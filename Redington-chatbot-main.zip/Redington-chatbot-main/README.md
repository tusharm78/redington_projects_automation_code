# Redington AI Bot - React + FastAPI

A high-performance chatbot application built with React frontend and FastAPI backend, migrated from the original Streamlit implementation for better performance and scalability.

## Architecture

- **Frontend**: React with TypeScript, Material-UI
- **Backend**: FastAPI with Python
- **AI Models**: AWS Bedrock with LangChain
- **Authentication**: AWS Cognito
- **File Processing**: Support for PDF, DOCX, XLSX, CSV, TXT, and Images

## Features

- 🚀 **High Performance**: Separated frontend and backend for optimal performance
- 🔐 **Secure Authentication**: AWS Cognito integration
- 💬 **Real-time Chat**: WebSocket support for streaming responses
- 📁 **File Upload**: Support for multiple file formats
- 🤖 **Multiple AI Models**: Support for various Bedrock models
- 📱 **Responsive Design**: Works on desktop and mobile devices
- 🎨 **Modern UI**: Material-UI components with clean design

## Project Structure

```
react-bedrock-chatbot/
├── backend/
│   ├── app/
│   │   ├── api/          # API routes
│   │   ├── core/         # Configuration
│   │   ├── models/       # Pydantic models and Bedrock models
│   │   ├── services/     # Business logic
│   │   └── utils/        # Utility functions
│   ├── config/           # Configuration files
│   ├── requirements.txt  # Python dependencies
│   ├── main.py          # FastAPI application
│   └── start.sh         # Backend startup script
├── frontend/
│   ├── src/
│   │   ├── components/   # React components
│   │   ├── hooks/        # Custom React hooks
│   │   ├── pages/        # Page components
│   │   ├── services/     # API services
│   │   ├── types/        # TypeScript types
│   │   └── utils/        # Utility functions
│   ├── package.json     # Node.js dependencies
│   └── start.sh         # Frontend startup script
└── README.md
```

## Setup Instructions

### Prerequisites

- Python 3.8+
- Node.js 16+
- AWS CLI configured with appropriate permissions
- AWS Bedrock access enabled

### Backend Setup

1. Navigate to the backend directory:
   ```bash
   cd backend
   ```

2. Create and activate a virtual environment:
   ```bash
   python3 -m venv venv
   source venv/bin/activate  # On Windows: venv\Scripts\activate
   ```

3. Install dependencies:
   ```bash
   pip install -r requirements.txt
   ```

4. Configure environment variables:
   - Copy `.env.example` to `.env`
   - Update the values with your AWS Cognito configuration

5. Start the backend server:
   ```bash
   ./start.sh
   # Or manually: uvicorn main:app --host 0.0.0.0 --port 8000 --reload
   ```

The backend will be available at `http://localhost:8000`

### Frontend Setup

1. Navigate to the frontend directory:
   ```bash
   cd frontend
   ```

2. Install dependencies:
   ```bash
   npm install
   ```

3. Start the development server:
   ```bash
   ./start.sh
   # Or manually: npm start
   ```

The frontend will be available at `http://localhost:3000`

## Configuration

### Backend Configuration

Update the `.env` file in the backend directory:

```env
AWS_DEFAULT_REGION=us-east-1
POOL_ID=your-cognito-pool-id
APP_CLIENT_ID=your-cognito-client-id
APP_CLIENT_SECRET=your-cognito-client-secret
SECRET_KEY=your-jwt-secret-key
ALLOWED_ORIGINS=["http://localhost:3000"]
```

### Model Configuration

Update `config/config.yml` to add or modify AI models:

```yaml
models:
  Claude 3.7 Sonnet:
    model_id: "us.anthropic.claude-3-7-sonnet-20250219-v1:0"
    input_format: "multimodal"
    thinking: 0
    temperature: 1.0
    top_p: 1.0
    top_k: 500
    max_tokens: 64000
    memory_window: 10
    max_top_k: 500
```

## API Endpoints

### Authentication
- `POST /api/v1/auth/login` - User login
- `GET /api/v1/auth/me` - Get current user info
- `POST /api/v1/auth/logout` - User logout

### Chat
- `POST /api/v1/chat/message` - Send chat message
- `POST /api/v1/chat/stream` - Stream chat response
- `GET /api/v1/chat/history/{conversation_id}` - Get conversation history
- `GET /api/v1/chat/models` - Get available models

## Key Improvements Over Streamlit Version

1. **Performance**: 
   - Separated frontend and backend for better resource utilization
   - Async processing for non-blocking operations
   - Efficient state management

2. **Scalability**:
   - RESTful API design
   - Stateless backend architecture
   - Easy to deploy and scale horizontally

3. **User Experience**:
   - Real-time streaming responses
   - Better file upload handling
   - Responsive design
   - Modern UI components

4. **Developer Experience**:
   - TypeScript for better code quality
   - Modular architecture
   - Clear separation of concerns
   - Easy to test and maintain

## Deployment

### Backend Deployment

For production deployment, consider using:
- **AWS ECS/Fargate**: Container-based deployment
- **AWS Lambda**: Serverless deployment with Mangum
- **EC2**: Traditional server deployment

### Frontend Deployment

For production deployment:
- **AWS S3 + CloudFront**: Static site hosting
- **Vercel/Netlify**: Easy deployment platforms
- **AWS Amplify**: Full-stack deployment

## Migration Notes

The following components were successfully migrated from the original Streamlit version:

- ✅ AWS Bedrock integration with LangChain
- ✅ AWS Cognito authentication
- ✅ File upload and processing (PDF, DOCX, XLSX, CSV, TXT, Images)
- ✅ Multiple AI model support
- ✅ Conversation history
- ✅ Role-based prompting
- ✅ Guardrails integration

## Troubleshooting

### Common Issues

1. **CORS Errors**: Ensure `ALLOWED_ORIGINS` in backend `.env` includes your frontend URL
2. **Authentication Issues**: Verify AWS Cognito configuration
3. **File Upload Issues**: Check file size limits and supported formats
4. **Model Access**: Ensure AWS Bedrock model access is enabled in your region

### Logs

- Backend logs: Check the FastAPI server console
- Frontend logs: Check browser developer console
- AWS logs: Check CloudWatch for Bedrock and Cognito logs

## Contributing

1. Fork the repository
2. Create a feature branch
3. Make your changes
4. Add tests if applicable
5. Submit a pull request

## License

This project is licensed under the MIT License.
