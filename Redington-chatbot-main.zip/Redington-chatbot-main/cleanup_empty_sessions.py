#!/usr/bin/env python3
"""
Script to clean up empty sessions from DynamoDB
"""

import boto3
from boto3.dynamodb.conditions import Key

def cleanup_empty_sessions():
    """Remove empty sessions from DynamoDB"""
    
    print("🧹 Cleaning up empty sessions from DynamoDB")
    print("=" * 50)
    
    try:
        # Connect to DynamoDB
        dynamodb = boto3.resource("dynamodb", region_name="us-east-1")
        table = dynamodb.Table("user_chat_sessions")
        
        print("✅ Connected to DynamoDB")
        
        # Scan for sessions
        response = table.scan()
        items = response.get('Items', [])
        
        empty_sessions = []
        
        for item in items:
            chat_id = item.get('chat_id', '')
            if chat_id.startswith('SESSION#'):
                message_count = item.get('message_count', 0)
                if message_count == 0:
                    empty_sessions.append(item)
        
        print(f"📊 Found {len(empty_sessions)} empty sessions")
        
        if not empty_sessions:
            print("✅ No empty sessions to clean up")
            return
        
        # Show what will be deleted
        print("\n🗑️  Empty sessions to be deleted:")
        for session in empty_sessions:
            session_id = session.get('session_id', 'unknown')
            user_id = session.get('user_id', 'unknown')
            title = session.get('title', 'No title')
            print(f"  - {session_id} (User: {user_id}, Title: '{title}')")
        
        # Confirm deletion
        confirm = input(f"\n❓ Delete {len(empty_sessions)} empty sessions? (y/N): ")
        if confirm.lower() != 'y':
            print("❌ Cleanup cancelled")
            return
        
        # Delete empty sessions
        deleted_count = 0
        for session in empty_sessions:
            try:
                user_id = session.get('user_id')
                chat_id = session.get('chat_id')
                
                if user_id and chat_id:
                    table.delete_item(
                        Key={
                            'user_id': user_id,
                            'chat_id': chat_id
                        }
                    )
                    deleted_count += 1
                    session_id = session.get('session_id', 'unknown')
                    print(f"✅ Deleted session: {session_id}")
                
            except Exception as e:
                print(f"❌ Error deleting session: {e}")
        
        print(f"\n🎉 Cleanup complete! Deleted {deleted_count} empty sessions")
        
        # Verify cleanup
        print("\n🔍 Verifying cleanup...")
        response = table.scan()
        items = response.get('Items', [])
        
        remaining_empty = 0
        for item in items:
            chat_id = item.get('chat_id', '')
            if chat_id.startswith('SESSION#'):
                message_count = item.get('message_count', 0)
                if message_count == 0:
                    remaining_empty += 1
        
        if remaining_empty == 0:
            print("✅ All empty sessions successfully removed")
        else:
            print(f"⚠️  {remaining_empty} empty sessions still remain")
        
    except Exception as e:
        print(f"❌ Error: {e}")

if __name__ == "__main__":
    cleanup_empty_sessions()
