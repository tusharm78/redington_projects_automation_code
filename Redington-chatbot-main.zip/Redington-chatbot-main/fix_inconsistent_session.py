#!/usr/bin/env python3
"""
Script to fix the existing inconsistent session title
"""

import boto3
import json

def fix_inconsistent_session():
    """Fix the session with inconsistent title"""
    
    print("🔧 Fixing Inconsistent Session Title")
    print("=" * 40)
    
    try:
        # Connect to DynamoDB
        dynamodb = boto3.resource("dynamodb", region_name="us-east-1")
        table = dynamodb.Table("user_chat_sessions")
        
        print("✅ Connected to DynamoDB")
        
        # The inconsistent session we found
        session_id = "d4889578-4020-4a80-8601-0dd29c7b765a"
        user_id = "tanmay"
        
        print(f"🎯 Fixing session: {session_id}")
        
        # Get the current session
        response = table.get_item(
            Key={
                "user_id": user_id,
                "chat_id": f"SESSION#{session_id}"
            }
        )
        
        if "Item" not in response:
            print(f"❌ Session not found: {session_id}")
            return
        
        item = response["Item"]
        direct_title = item.get('title', '')
        
        print(f"📋 Current direct title: '{direct_title}'")
        
        if 'session_data' in item:
            session_data = json.loads(item['session_data'])
            json_title = session_data.get('title', '')
            print(f"📋 Current JSON title: '{json_title}'")
            
            if direct_title != json_title:
                print(f"⚠️  Titles are inconsistent!")
                print(f"🔧 Updating JSON title to match direct title: '{direct_title}'")
                
                # Update the session_data JSON to match the direct title
                session_data['title'] = direct_title
                session_data['updated_at'] = item.get('updated_at', '')
                
                # Update the session_data in DynamoDB
                table.update_item(
                    Key={
                        "user_id": user_id,
                        "chat_id": f"SESSION#{session_id}"
                    },
                    UpdateExpression="SET session_data = :session_data",
                    ExpressionAttributeValues={
                        ":session_data": json.dumps(session_data)
                    }
                )
                
                print(f"✅ Fixed session title consistency!")
                
                # Verify the fix
                verify_response = table.get_item(
                    Key={
                        "user_id": user_id,
                        "chat_id": f"SESSION#{session_id}"
                    }
                )
                
                if "Item" in verify_response:
                    verify_item = verify_response["Item"]
                    verify_direct = verify_item.get('title', '')
                    verify_json_data = json.loads(verify_item['session_data'])
                    verify_json = verify_json_data.get('title', '')
                    
                    print(f"🔍 Verification:")
                    print(f"  Direct title: '{verify_direct}'")
                    print(f"  JSON title:   '{verify_json}'")
                    
                    if verify_direct == verify_json:
                        print(f"✅ Session title is now consistent!")
                    else:
                        print(f"❌ Session title is still inconsistent!")
                
            else:
                print(f"✅ Titles are already consistent")
        else:
            print(f"⚠️  No session_data JSON field found")
            
    except Exception as e:
        print(f"❌ Error: {e}")

if __name__ == "__main__":
    fix_inconsistent_session()
