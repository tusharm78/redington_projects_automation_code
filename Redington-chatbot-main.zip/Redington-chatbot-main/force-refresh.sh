#!/bin/bash

echo "🔄 Forcing frontend refresh..."

cd /home/chatbot/RedAIBot/react-bedrock-chatbot/frontend

# Rebuild with new timestamp
npm run build

# Update version file for cache busting
echo "$(date +%s)" > build/version.txt

# Reload nginx
sudo nginx -s reload

echo "✅ Frontend refreshed! New changes are now live."
echo "   Visit: http://localhost:3001"
echo "   The updated formatting should now be visible immediately."
