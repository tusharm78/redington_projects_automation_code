#!/usr/bin/env python3
"""
Setup script for DynamoDB tables required for user activity monitoring
"""

import boto3
import os
import sys
from dotenv import load_dotenv
import logging
import asyncio

# Load environment variables
load_dotenv()

# Setup logging
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

def create_user_active_sessions_table():
    """Create the user_active_sessions table for tracking active user sessions"""
    
    try:
        # Initialize DynamoDB client
        dynamodb = boto3.resource('dynamodb', region_name='us-east-1')
        
        table_name = 'user_active_sessions'
        
        # Check if table already exists
        try:
            table = dynamodb.Table(table_name)
            table.load()
            logger.info(f"✅ Table '{table_name}' already exists")
            return True
        except dynamodb.meta.client.exceptions.ResourceNotFoundException:
            logger.info(f"📝 Creating table '{table_name}'...")
        
        # Create table
        table = dynamodb.create_table(
            TableName=table_name,
            KeySchema=[
                {
                    'AttributeName': 'username',
                    'KeyType': 'HASH'  # Partition key
                }
            ],
            AttributeDefinitions=[
                {
                    'AttributeName': 'username',
                    'AttributeType': 'S'
                }
            ],
            BillingMode='PAY_PER_REQUEST',  # On-demand billing
            Tags=[
                {
                    'Key': 'Application',
                    'Value': 'RedingtonChatbot'
                },
                {
                    'Key': 'Purpose',
                    'Value': 'UserActivityMonitoring'
                }
            ]
        )
        
        # Wait for table to be created
        logger.info("⏳ Waiting for table to be created...")
        table.wait_until_exists()
        
        # Enable TTL on the table (optional - for automatic cleanup)
        try:
            dynamodb_client = boto3.client('dynamodb', region_name='us-east-1')
            dynamodb_client.update_time_to_live(
                TableName=table_name,
                TimeToLiveSpecification={
                    'AttributeName': 'ttl',
                    'Enabled': True
                }
            )
            logger.info("✅ TTL enabled for automatic session cleanup")
        except Exception as ttl_error:
            logger.warning(f"⚠️ Could not enable TTL: {ttl_error}")
        
        logger.info(f"✅ Table '{table_name}' created successfully!")
        
        # Print table information
        print(f"\n📊 Table Information:")
        print(f"   Table Name: {table_name}")
        print(f"   Table ARN: {table.table_arn}")
        print(f"   Table Status: {table.table_status}")
        print(f"   Billing Mode: Pay-per-request")
        print(f"   TTL Enabled: Yes (ttl attribute)")
        
        return True
        
    except Exception as e:
        logger.error(f"❌ Error creating table: {e}")
        return False

def verify_existing_tables():
    """Verify that existing tables are accessible"""
    
    try:
        dynamodb = boto3.resource('dynamodb', region_name='us-east-1')
        
        # Check user_chat_sessions table (should already exist)
        existing_tables = ['user_chat_sessions']
        
        for table_name in existing_tables:
            try:
                table = dynamodb.Table(table_name)
                table.load()
                logger.info(f"✅ Existing table '{table_name}' is accessible")
            except Exception as e:
                logger.warning(f"⚠️ Existing table '{table_name}' not accessible: {e}")
        
        return True
        
    except Exception as e:
        logger.error(f"❌ Error verifying existing tables: {e}")
        return False

async def test_table_operations():
    """Test basic operations on the user activity monitoring table"""
    
    try:
        from user_activity_monitor import UserActivityMonitor
        
        logger.info("🧪 Testing user activity monitor...")
        
        # Initialize monitor
        monitor = UserActivityMonitor()
        
        # Test user login
        test_user = "test_user"
        test_user_info = {
            "username": test_user,
            "email": "test@example.com",
            "ip_address": "127.0.0.1",
            "user_agent": "Test Agent"
        }
        
        session_id = await monitor.user_login(test_user, test_user_info, "test_token")
        logger.info(f"✅ Test login successful: {session_id}")
        
        # Test activity update
        await monitor.update_user_activity(test_user, "chat_message")
        logger.info("✅ Test activity update successful")
        
        # Test get active users
        active_users = await monitor.get_active_users()
        logger.info(f"✅ Test get active users successful: {len(active_users)} users")
        
        # Test logout
        await monitor.user_logout(test_user)
        logger.info("✅ Test logout successful")
        
        logger.info("🎉 All tests passed!")
        return True
        
    except Exception as e:
        logger.error(f"❌ Test failed: {e}")
        return False

def main():
    """Main setup function"""
    
    print("🚀 Setting up User Activity Monitoring Database")
    print("=" * 50)
    
    # Check AWS credentials
    try:
        boto3.client('sts').get_caller_identity()
        logger.info("✅ AWS credentials are configured")
    except Exception as e:
        logger.error(f"❌ AWS credentials not configured: {e}")
        print("\n💡 Please configure AWS credentials using:")
        print("   aws configure")
        print("   or set AWS_ACCESS_KEY_ID and AWS_SECRET_ACCESS_KEY environment variables")
        sys.exit(1)
    
    # Verify existing tables
    print("\n1. Verifying existing tables...")
    if not verify_existing_tables():
        logger.warning("⚠️ Some existing tables may not be accessible")
    
    # Create user activity monitoring table
    print("\n2. Creating user activity monitoring table...")
    if not create_user_active_sessions_table():
        logger.error("❌ Failed to create user activity monitoring table")
        sys.exit(1)
    
    # Test operations (optional)
    test_operations = input("\n3. Would you like to test table operations? (y/N): ").lower().strip()
    if test_operations == 'y':
        print("\n   Testing table operations...")
        if not asyncio.run(test_table_operations()):
            logger.warning("⚠️ Some tests failed, but table should still work")
    
    print("\n🎉 Setup completed successfully!")
    print("\n📋 Next steps:")
    print("   1. Deploy the updated backend with user monitoring")
    print("   2. Copy admin dashboard to your web server")
    print("   3. Update nginx configuration for /admin route")
    print("   4. Access admin dashboard at https://bot.redingtonsolutions.org/admin")
    
    print(f"\n🔧 Configuration:")
    print(f"   Region: us-east-1")
    print(f"   Table: user_active_sessions")
    print(f"   Billing: Pay-per-request")
    print(f"   TTL: Enabled (24 hours)")
    print(f"   Admin Users: tanmay, meenal, varunesh, admin")

if __name__ == "__main__":
    main()
