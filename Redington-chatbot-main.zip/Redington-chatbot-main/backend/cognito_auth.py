import boto3
from botocore.exceptions import ClientError
import hmac
import hashlib
import base64
import json
import os
import logging
from dotenv import load_dotenv
from typing import Optional, Dict, Any
from datetime import datetime, timedelta
import jwt
from jwt.exceptions import ExpiredSignatureError, InvalidTokenError
from fastapi import HTTPException, status

# Load environment variables
load_dotenv()

# Set up logging
logger = logging.getLogger(__name__)

class CognitoAuth:
    """AWS Cognito Authentication Handler"""
    
    def __init__(self):
        self.pool_id = os.getenv('POOL_ID')
        self.client_id = os.getenv('APP_CLIENT_ID')
        self.client_secret = os.getenv('APP_CLIENT_SECRET')
        
        # Extract region from pool_id (format: region_poolname)
        if self.pool_id and '_' in self.pool_id:
            self.region = self.pool_id.split('_')[0]
        else:
            self.region = os.getenv('AWS_DEFAULT_REGION', 'us-east-1')
        
        if not all([self.pool_id, self.client_id, self.client_secret]):
            raise ValueError("Missing Cognito configuration. Check POOL_ID, APP_CLIENT_ID, APP_CLIENT_SECRET")
        
        self.cognito_client = boto3.client('cognito-idp', region_name=self.region)
        self.secret_key = os.getenv('SECRET_KEY', 'fallback-secret-key')
        
    def _calculate_secret_hash(self, username: str) -> str:
        """Calculate the secret hash for Cognito authentication"""
        message = username + self.client_id
        dig = hmac.new(
            self.client_secret.encode('utf-8'),
            message.encode('utf-8'),
            hashlib.sha256
        ).digest()
        return base64.b64encode(dig).decode()
    
    async def authenticate_user(self, username: str, password: str) -> Dict[str, Any]:
        """Authenticate user with AWS Cognito with improved challenge handling"""
        try:
            secret_hash = self._calculate_secret_hash(username)
            
            response = self.cognito_client.initiate_auth(
                ClientId=self.client_id,
                AuthFlow='USER_PASSWORD_AUTH',
                AuthParameters={
                    'USERNAME': username,
                    'PASSWORD': password,
                    'SECRET_HASH': secret_hash
                }
            )
            
            # Handle challenge responses (like NEW_PASSWORD_REQUIRED)
            if 'ChallengeName' in response:
                challenge_name = response['ChallengeName']
                if challenge_name == 'NEW_PASSWORD_REQUIRED':
                    raise HTTPException(
                        status_code=status.HTTP_400_BAD_REQUEST,
                        detail={
                            "error": "password_change_required",
                            "message": "User must change password before first login",
                            "challenge_name": challenge_name,
                            "session": response.get('Session', '')
                        }
                    )
                else:
                    raise HTTPException(
                        status_code=status.HTTP_400_BAD_REQUEST,
                        detail={
                            "error": "challenge_required",
                            "message": f"Authentication challenge required: {challenge_name}",
                            "challenge_name": challenge_name
                        }
                    )
            
            # Only access AuthenticationResult if there's no challenge
            if 'AuthenticationResult' not in response:
                raise HTTPException(
                    status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
                    detail="Unexpected authentication response format"
                )
            
            # Extract tokens
            auth_result = response['AuthenticationResult']
            access_token = auth_result['AccessToken']
            id_token = auth_result['IdToken']
            refresh_token = auth_result['RefreshToken']
            
            # Get user info from ID token
            user_info = self._decode_token(id_token)
            
            return {
                'access_token': access_token,
                'id_token': id_token,
                'refresh_token': refresh_token,
                'user_info': user_info,
                'expires_in': auth_result.get('ExpiresIn', 3600)
            }
            
        except HTTPException:
            # Re-raise HTTPExceptions (like password change challenges)
            raise
        except self.cognito_client.exceptions.NotAuthorizedException:
            raise HTTPException(
                status_code=status.HTTP_401_UNAUTHORIZED,
                detail="Invalid username or password"
            )
        except self.cognito_client.exceptions.UserNotConfirmedException:
            raise HTTPException(
                status_code=status.HTTP_401_UNAUTHORIZED,
                detail="User account not confirmed"
            )
        except Exception as e:
            print(f"Cognito authentication error: {e}")
            raise HTTPException(
                status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
                detail="Authentication service error"
            )
    
    def _decode_token(self, token: str) -> Dict[str, Any]:
        """Decode JWT token without verification (for user info extraction)"""
        try:
            # Decode without verification to get user info
            decoded = jwt.decode(token, options={"verify_signature": False})
            return {
                'username': decoded.get('cognito:username', ''),
                'email': decoded.get('email', ''),
                'sub': decoded.get('sub', ''),
                'exp': decoded.get('exp', 0)
            }
        except Exception as e:
            print(f"Token decode error: {e}")
            return {}
    
    async def verify_token(self, token: str) -> Dict[str, Any]:
        """Verify Cognito access token"""
        try:
            # For production, you should verify the token signature with Cognito's public keys
            # For now, we'll do basic validation
            response = self.cognito_client.get_user(AccessToken=token)
            
            # Extract user attributes
            user_attributes = {}
            for attr in response.get('UserAttributes', []):
                user_attributes[attr['Name']] = attr['Value']
            
            return {
                'username': response.get('Username', ''),
                'email': user_attributes.get('email', ''),
                'sub': user_attributes.get('sub', ''),
                'attributes': user_attributes
            }
            
        except self.cognito_client.exceptions.NotAuthorizedException:
            raise HTTPException(
                status_code=status.HTTP_401_UNAUTHORIZED,
                detail="Invalid or expired token"
            )
        except Exception as e:
            print(f"Token verification error: {e}")
            raise HTTPException(
                status_code=status.HTTP_401_UNAUTHORIZED,
                detail="Token verification failed"
            )
    
    async def handle_new_password_challenge(self, username: str, new_password: str, session: str) -> Dict[str, Any]:
        """Handle NEW_PASSWORD_REQUIRED challenge"""
        try:
            secret_hash = self._calculate_secret_hash(username)
            
            response = self.cognito_client.respond_to_auth_challenge(
                ClientId=self.client_id,
                ChallengeName='NEW_PASSWORD_REQUIRED',
                Session=session,
                ChallengeResponses={
                    'USERNAME': username,
                    'NEW_PASSWORD': new_password,
                    'SECRET_HASH': secret_hash
                }
            )
            
            # Check if authentication is successful
            if 'AuthenticationResult' in response:
                auth_result = response['AuthenticationResult']
                
                # Extract user info from the access token
                user_info = self._decode_token(auth_result['AccessToken'])
                
                return {
                    'access_token': auth_result['AccessToken'],
                    'refresh_token': auth_result.get('RefreshToken'),
                    'expires_in': auth_result.get('ExpiresIn', 3600),
                    'user_info': {
                        'username': username,
                        'email': user_info.get('email', ''),
                        'name': user_info.get('name', username),
                        'sub': user_info.get('sub', '')
                    }
                }
            else:
                # Handle any additional challenges
                if 'ChallengeName' in response:
                    raise HTTPException(
                        status_code=status.HTTP_400_BAD_REQUEST,
                        detail={
                            "error": "additional_challenge_required",
                            "message": f"Additional challenge required: {response['ChallengeName']}",
                            "challenge_name": response['ChallengeName'],
                            "session": response.get('Session', '')
                        }
                    )
                else:
                    raise HTTPException(
                        status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
                        detail="Unexpected response from Cognito"
                    )
                    
        except ClientError as e:
            error_code = e.response['Error']['Code']
            error_message = e.response['Error']['Message']
            
            logger.error(f"Cognito password change error: {error_code} - {error_message}")
            
            if error_code == 'InvalidPasswordException':
                raise HTTPException(
                    status_code=status.HTTP_400_BAD_REQUEST,
                    detail="Password does not meet requirements"
                )
            elif error_code == 'InvalidParameterException':
                raise HTTPException(
                    status_code=status.HTTP_400_BAD_REQUEST,
                    detail="Invalid parameters provided"
                )
            elif error_code == 'NotAuthorizedException':
                raise HTTPException(
                    status_code=status.HTTP_401_UNAUTHORIZED,
                    detail="Session expired or invalid"
                )
            else:
                raise HTTPException(
                    status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
                    detail=f"Password change failed: {error_message}"
                )
        except Exception as e:
            logger.error(f"Unexpected error during password change: {e}")
            raise HTTPException(
                status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
                detail="Password change failed"
            )
    
    async def refresh_access_token(self, refresh_token: str, username: str) -> Dict[str, Any]:
        """Refresh access token using refresh token"""
        try:
            secret_hash = self._calculate_secret_hash(username)
            
            response = self.cognito_client.initiate_auth(
                ClientId=self.client_id,
                AuthFlow='REFRESH_TOKEN_AUTH',
                AuthParameters={
                    'REFRESH_TOKEN': refresh_token,
                    'SECRET_HASH': secret_hash
                }
            )
            
            auth_result = response['AuthenticationResult']
            return {
                'access_token': auth_result['AccessToken'],
                'id_token': auth_result['IdToken'],
                'expires_in': auth_result.get('ExpiresIn', 3600)
            }
            
        except Exception as e:
            print(f"Token refresh error: {e}")
            raise HTTPException(
                status_code=status.HTTP_401_UNAUTHORIZED,
                detail="Token refresh failed"
            )
    
    def create_fallback_token(self, username: str) -> str:
        """Create fallback JWT token for demo purposes"""
        expire = datetime.utcnow() + timedelta(hours=24)
        payload = {
            "username": username,
            "exp": expire,
            "iat": datetime.utcnow(),
            "iss": "redington-demo"
        }
        return jwt.encode(payload, self.secret_key, algorithm="HS256")
    
    def verify_fallback_token(self, token: str) -> Dict[str, Any]:
        """Verify fallback JWT token"""
        try:
            payload = jwt.decode(token, self.secret_key, algorithms=["HS256"])
            return {
                'username': payload.get('username', ''),
                'exp': payload.get('exp', 0)
            }
        except ExpiredSignatureError:
            raise HTTPException(
                status_code=status.HTTP_401_UNAUTHORIZED,
                detail="Token expired"
            )
        except InvalidTokenError:
            raise HTTPException(
                status_code=status.HTTP_401_UNAUTHORIZED,
                detail="Invalid token"
            )
