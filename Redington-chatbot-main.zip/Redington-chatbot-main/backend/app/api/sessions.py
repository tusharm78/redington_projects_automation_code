from fastapi import APIRouter, HTTPException, Depends, status
from fastapi.security import HTTPBearer, HTTPAuthorizationCredentials
from typing import List, Dict, Any, Optional
from pydantic import BaseModel
from app.services.auth_service import AuthService
from services.dynamodb_service import dynamodb_service

router = APIRouter(prefix="/sessions", tags=["sessions"])
security = HTTPBearer()
auth_service = AuthService()

# Pydantic models for request/response
class CreateSessionRequest(BaseModel):
    chat_title: Optional[str] = None

class UpdateSessionRequest(BaseModel):
    chat_title: str

class SessionResponse(BaseModel):
    chat_id: str
    chat_title: str
    created_at: Optional[int] = None
    updated_at: Optional[int] = None

class MessageResponse(BaseModel):
    message_id: str
    role: str
    content: str
    timestamp: int
    has_context: bool = False
    user_prompt: Optional[str] = None
    images: Optional[List[str]] = None

async def get_current_user(credentials: HTTPAuthorizationCredentials = Depends(security)):
    """Get current user from token"""
    try:
        token = credentials.credentials
        payload = auth_service.verify_token(token)
        return payload.get("username", "anonymous")
    except Exception:
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail="Invalid authentication credentials"
        )

@router.get("/", response_model=Dict[str, str])
@router.get("", response_model=Dict[str, str])  # Handle both with and without trailing slash
async def get_user_sessions(current_user: str = Depends(get_current_user)):
    """Get all chat sessions for the current user"""
    try:
        sessions = dynamodb_service.get_user_chat_sessions(current_user)
        return sessions
    except Exception as e:
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail=f"Error retrieving sessions: {str(e)}"
        )

@router.post("/", response_model=Dict[str, str])
@router.post("", response_model=Dict[str, str])  # Handle both with and without trailing slash
async def create_session(
    request: CreateSessionRequest,
    current_user: str = Depends(get_current_user)
):
    """Create a new chat session"""
    try:
        chat_id = dynamodb_service.create_new_chat_session(
            user_id=current_user,
            chat_title=request.chat_title
        )
        return {"chat_id": chat_id, "message": "Session created successfully"}
    except Exception as e:
        if "Maximum of" in str(e):
            raise HTTPException(
                status_code=status.HTTP_400_BAD_REQUEST,
                detail=str(e)
            )
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail=f"Error creating session: {str(e)}"
        )

@router.delete("/{chat_id}")
async def delete_session(
    chat_id: str,
    current_user: str = Depends(get_current_user)
):
    """Delete a chat session and all its messages"""
    try:
        success = dynamodb_service.delete_chat_session(current_user, chat_id)
        if success:
            return {"message": "Session deleted successfully"}
        else:
            raise HTTPException(
                status_code=status.HTTP_404_NOT_FOUND,
                detail="Session not found"
            )
    except Exception as e:
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail=f"Error deleting session: {str(e)}"
        )

@router.put("/{chat_id}/title")
async def update_session_title(
    chat_id: str,
    request: UpdateSessionRequest,
    current_user: str = Depends(get_current_user)
):
    """Update the title of a chat session"""
    try:
        success = dynamodb_service.update_chat_title(
            user_id=current_user,
            chat_id=chat_id,
            new_title=request.chat_title
        )
        if success:
            return {"message": "Session title updated successfully"}
        else:
            raise HTTPException(
                status_code=status.HTTP_404_NOT_FOUND,
                detail="Session not found"
            )
    except Exception as e:
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail=f"Error updating session title: {str(e)}"
        )

@router.get("/{chat_id}/messages", response_model=List[MessageResponse])
async def get_session_messages(
    chat_id: str,
    current_user: str = Depends(get_current_user)
):
    """Get all messages for a specific chat session"""
    try:
        messages = dynamodb_service.load_chat_history(current_user, chat_id)
        return [MessageResponse(**msg) for msg in messages]
    except Exception as e:
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail=f"Error retrieving messages: {str(e)}"
        )

@router.get("/{chat_id}/info", response_model=Optional[SessionResponse])
async def get_session_info(
    chat_id: str,
    current_user: str = Depends(get_current_user)
):
    """Get information about a specific chat session"""
    try:
        session_info = dynamodb_service.get_chat_session_info(current_user, chat_id)
        if session_info:
            return SessionResponse(**session_info)
        else:
            raise HTTPException(
                status_code=status.HTTP_404_NOT_FOUND,
                detail="Session not found"
            )
    except Exception as e:
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail=f"Error retrieving session info: {str(e)}"
        )
