from fastapi import APIRouter, Depends, HTTPException, UploadFile, File, Form
from fastapi.security import HTTPBearer
from typing import List, Dict, Any, Optional
import base64
import os

from app.services.auth_service import get_current_user
from app.services.rag_service import rag_service
from app.models.schemas import UserInfo

router = APIRouter()
security = HTTPBearer()

@router.post("/initialize")
async def initialize_rag_index(
    force_rebuild: bool = False,
    current_user: UserInfo = Depends(get_current_user)
):
    """Initialize or rebuild the FAISS RAG index"""
    try:
        success = await rag_service.initialize_vector_store(force_rebuild=force_rebuild)
        
        if success:
            stats = await rag_service.get_index_stats()
            return {
                "success": True,
                "message": "RAG index initialized successfully",
                "stats": stats
            }
        else:
            raise HTTPException(status_code=500, detail="Failed to initialize RAG index")
            
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Error initializing RAG index: {str(e)}")

@router.get("/stats")
async def get_rag_stats(current_user: UserInfo = Depends(get_current_user)):
    """Get RAG index statistics"""
    try:
        stats = await rag_service.get_index_stats()
        return stats
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Error getting RAG stats: {str(e)}")

@router.post("/upload-document")
async def upload_document_to_rag(
    file: UploadFile = File(...),
    current_user: UserInfo = Depends(get_current_user)
):
    """Upload a document to the RAG knowledge base"""
    try:
        # Validate file type
        allowed_extensions = ['.pdf', '.doc', '.docx', '.txt', '.csv', '.md']
        file_extension = os.path.splitext(file.filename)[1].lower()
        
        if file_extension not in allowed_extensions:
            raise HTTPException(
                status_code=400, 
                detail=f"Unsupported file type. Allowed: {', '.join(allowed_extensions)}"
            )
        
        # Read file content
        file_content = await file.read()
        
        # Add to RAG index
        success = await rag_service.add_document_to_index(
            file_content=file_content,
            filename=file.filename,
            file_type=file_extension[1:]  # Remove the dot
        )
        
        if success:
            return {
                "success": True,
                "message": f"Document '{file.filename}' added to knowledge base successfully",
                "filename": file.filename,
                "file_size": len(file_content)
            }
        else:
            raise HTTPException(status_code=500, detail="Failed to add document to knowledge base")
            
    except HTTPException:
        raise
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Error uploading document: {str(e)}")

@router.post("/search")
async def search_knowledge_base(
    query: str = Form(...),
    max_results: int = Form(5),
    current_user: UserInfo = Depends(get_current_user)
):
    """Search the RAG knowledge base"""
    try:
        results = await rag_service.search_with_scores(query, k=max_results)
        
        formatted_results = []
        for doc, score in results:
            formatted_results.append({
                "content": doc.page_content,
                "metadata": doc.metadata,
                "similarity_score": float(score)
            })
        
        return {
            "query": query,
            "results": formatted_results,
            "total_results": len(formatted_results)
        }
        
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Error searching knowledge base: {str(e)}")

@router.post("/rebuild-index")
async def rebuild_rag_index(current_user: UserInfo = Depends(get_current_user)):
    """Rebuild the entire RAG index from S3"""
    try:
        success = await rag_service.rebuild_index()
        
        if success:
            stats = await rag_service.get_index_stats()
            return {
                "success": True,
                "message": "RAG index rebuilt successfully",
                "stats": stats
            }
        else:
            raise HTTPException(status_code=500, detail="Failed to rebuild RAG index")
            
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Error rebuilding RAG index: {str(e)}")

@router.get("/test-context/{query}")
async def test_rag_context(
    query: str,
    max_chunks: int = 5,
    current_user: UserInfo = Depends(get_current_user)
):
    """Test RAG context retrieval for a query"""
    try:
        context = await rag_service.get_rag_context(query, max_chunks=max_chunks)
        
        return {
            "query": query,
            "context": context,
            "context_length": len(context),
            "has_context": bool(context.strip())
        }
        
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Error testing RAG context: {str(e)}")

@router.post("/batch-upload")
async def batch_upload_documents(
    files: List[UploadFile] = File(...),
    current_user: UserInfo = Depends(get_current_user)
):
    """Upload multiple documents to the RAG knowledge base"""
    try:
        results = []
        allowed_extensions = ['.pdf', '.doc', '.docx', '.txt', '.csv', '.md']
        
        for file in files:
            try:
                # Validate file type
                file_extension = os.path.splitext(file.filename)[1].lower()
                
                if file_extension not in allowed_extensions:
                    results.append({
                        "filename": file.filename,
                        "success": False,
                        "error": f"Unsupported file type: {file_extension}"
                    })
                    continue
                
                # Read file content
                file_content = await file.read()
                
                # Add to RAG index
                success = await rag_service.add_document_to_index(
                    file_content=file_content,
                    filename=file.filename,
                    file_type=file_extension[1:]  # Remove the dot
                )
                
                results.append({
                    "filename": file.filename,
                    "success": success,
                    "file_size": len(file_content),
                    "error": None if success else "Failed to process document"
                })
                
            except Exception as e:
                results.append({
                    "filename": file.filename,
                    "success": False,
                    "error": str(e)
                })
        
        successful_uploads = sum(1 for r in results if r["success"])
        
        return {
            "total_files": len(files),
            "successful_uploads": successful_uploads,
            "failed_uploads": len(files) - successful_uploads,
            "results": results
        }
        
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Error in batch upload: {str(e)}")

@router.delete("/clear-index")
async def clear_rag_index(current_user: UserInfo = Depends(get_current_user)):
    """Clear the RAG index (use with caution)"""
    try:
        # Reset the vector store
        rag_service.vector_store = None
        rag_service.index_metadata = {}
        
        return {
            "success": True,
            "message": "RAG index cleared successfully"
        }
        
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Error clearing RAG index: {str(e)}")

@router.get("/health")
async def rag_health_check():
    """Health check for RAG service"""
    try:
        stats = await rag_service.get_index_stats()
        
        return {
            "status": "healthy",
            "rag_initialized": stats.get("index_initialized", False),
            "s3_bucket": stats.get("s3_bucket"),
            "timestamp": stats.get("metadata", {}).get("last_updated")
        }
        
    except Exception as e:
        return {
            "status": "unhealthy",
            "error": str(e)
        }
