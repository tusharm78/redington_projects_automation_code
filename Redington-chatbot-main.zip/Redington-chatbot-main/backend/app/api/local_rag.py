from fastapi import APIRouter, Depends, HTTPException, Form
from fastapi.security import HTTPBearer, HTTPAuthorizationCredentials
from typing import List, Dict, Any

from app.services.local_rag_service import local_rag_service
from app.services.auth_service import AuthService

router = APIRouter()
security = HTTPBearer()
auth_service = AuthService()

async def get_current_user(credentials: HTTPAuthorizationCredentials = Depends(security)):
    """Get current user from token"""
    try:
        token = credentials.credentials
        payload = auth_service.verify_token(token)
        return payload.get("username", "anonymous")
    except Exception:
        raise HTTPException(
            status_code=401,
            detail="Invalid authentication credentials",
            headers={"WWW-Authenticate": "Bearer"},
        )

@router.get("/health")
async def rag_health_check():
    """Health check for local RAG service"""
    try:
        stats = local_rag_service.get_stats()
        return {
            "status": "healthy" if stats.get("initialized", False) else "not_initialized",
            "stats": stats
        }
    except Exception as e:
        return {
            "status": "unhealthy",
            "error": str(e)
        }

@router.get("/stats")
async def get_rag_stats(current_user: str = Depends(get_current_user)):
    """Get local RAG statistics"""
    try:
        stats = local_rag_service.get_stats()
        return stats
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Error getting RAG stats: {str(e)}")

@router.post("/initialize")
async def initialize_rag(current_user: str = Depends(get_current_user)):
    """Initialize the local RAG service"""
    try:
        success = await local_rag_service.initialize()
        
        if success:
            stats = local_rag_service.get_stats()
            return {
                "success": True,
                "message": "Local RAG service initialized successfully",
                "stats": stats
            }
        else:
            raise HTTPException(status_code=500, detail="Failed to initialize local RAG service")
            
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Error initializing RAG: {str(e)}")

@router.post("/search")
async def search_knowledge_base(
    query: str = Form(...),
    max_results: int = Form(5),
    current_user: str = Depends(get_current_user)
):
    """Search the local knowledge base"""
    try:
        # Get documents with scores
        results = await local_rag_service.search_with_scores(query, k=max_results)
        
        formatted_results = []
        for doc, score in results:
            formatted_results.append({
                "content": doc.page_content[:500] + "..." if len(doc.page_content) > 500 else doc.page_content,
                "metadata": doc.metadata,
                "similarity_score": float(score)
            })
        
        return {
            "query": query,
            "results": formatted_results,
            "total_results": len(formatted_results)
        }
        
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Error searching knowledge base: {str(e)}")

@router.get("/test-context/{query}")
async def test_rag_context(
    query: str,
    max_chunks: int = 5,
    current_user: str = Depends(get_current_user)
):
    """Test RAG context retrieval for a query"""
    try:
        context = await local_rag_service.get_rag_context(query, k=max_chunks)
        
        return {
            "query": query,
            "context": context,
            "context_length": len(context),
            "has_context": bool(context.strip())
        }
        
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Error testing RAG context: {str(e)}")

@router.get("/info")
async def get_rag_info():
    """Get information about the RAG system"""
    return {
        "type": "Local FAISS-based RAG",
        "description": "Uses local FAISS index created from Streamlit application",
        "embedding_model": "amazon.titan-embed-text-v2:0",
        "index_location": "backend/faiss_index/",
        "features": [
            "Local FAISS vector store",
            "Amazon Bedrock embeddings",
            "Similarity search with scores",
            "Context retrieval for chat"
        ]
    }
