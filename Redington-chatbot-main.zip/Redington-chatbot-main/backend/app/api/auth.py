from fastapi import APIRouter, HTTPException, Depends, status
from fastapi.security import HTTPBearer, HTTPAuthorizationCredentials
from app.models.schemas import AuthRequest, AuthResponse, UserInfo
from app.services.demo_auth_service import DemoAuthService

router = APIRouter(prefix="/auth", tags=["authentication"])
security = HTTPBearer()
auth_service = DemoAuthService()

@router.post("/login", response_model=AuthResponse)
async def login(auth_request: AuthRequest):
    """Authenticate user with demo credentials"""
    try:
        result = await auth_service.authenticate_user(
            auth_request.username, 
            auth_request.password
        )
        
        return AuthResponse(
            access_token=result['access_token'],
            token_type="bearer",
            expires_in=result['expires_in']
        )
    except Exception as e:
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail=str(e)
        )

@router.get("/me", response_model=UserInfo)
async def get_current_user(credentials: HTTPAuthorizationCredentials = Depends(security)):
    """Get current user information"""
    try:
        token = credentials.credentials
        payload = auth_service.verify_token(token)
        
        # Get username from token
        username = payload.get("username", "")
        
        # Get user info from demo service
        if username in auth_service.demo_users:
            user_data = auth_service.demo_users[username]
            email = user_data.get("email", "")
        else:
            email = ""
        
        return UserInfo(
            username=username,
            email=email,
            is_authenticated=True
        )
    except Exception as e:
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail="Could not validate credentials"
        )

@router.post("/logout")
async def logout():
    """Logout user"""
    return {"message": "Successfully logged out"}
