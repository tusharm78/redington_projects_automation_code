from fastapi import APIRouter, HTTPException, Depends, status
from fastapi.security import HTTPBearer, HTTPAuthorizationCredentials
from fastapi.responses import StreamingResponse
from typing import List, Dict, Any
from app.models.schemas import ChatRequest, ChatResponse, ChatMessage
from app.services.chat_service import ChatService
from app.services.auth_service import AuthService

router = APIRouter(prefix="/chat", tags=["chat"])
security = HTTPBearer()
chat_service = ChatService()
auth_service = AuthService()

async def get_current_user(credentials: HTTPAuthorizationCredentials = Depends(security)):
    """Get current user from token"""
    try:
        token = credentials.credentials
        payload = auth_service.verify_token(token)
        return payload.get("username", "anonymous")
    except Exception:
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail="Invalid authentication credentials"
        )

@router.post("/message", response_model=ChatResponse)
async def send_message(
    request: ChatRequest,
    current_user: str = Depends(get_current_user)
):
    """Send a chat message and get response"""
    try:
        response = await chat_service.process_chat_message(request, current_user)
        return response
    except Exception as e:
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail=f"Error processing message: {str(e)}"
        )

@router.post("/stream")
async def stream_message(
    request: ChatRequest,
    current_user: str = Depends(get_current_user)
):
    """Stream chat response for real-time updates"""
    try:
        return StreamingResponse(
            chat_service.stream_chat_response(request, current_user),
            media_type="text/plain",
            headers={
                "Cache-Control": "no-cache",
                "Connection": "keep-alive",
                "Content-Type": "text/event-stream"
            }
        )
    except Exception as e:
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail=f"Error streaming message: {str(e)}"
        )

@router.get("/history/{conversation_id}", response_model=List[ChatMessage])
async def get_conversation_history(
    conversation_id: str,
    current_user: str = Depends(get_current_user)
):
    """Get conversation history"""
    try:
        history = chat_service.get_conversation_history(conversation_id, current_user)
        return history
    except Exception as e:
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail=f"Error retrieving history: {str(e)}"
        )

@router.get("/models", response_model=Dict[str, Any])
async def get_available_models(current_user: str = Depends(get_current_user)):
    """Get available AI models"""
    try:
        models = chat_service.get_available_models()
        return models
    except Exception as e:
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail=f"Error retrieving models: {str(e)}"
        )
