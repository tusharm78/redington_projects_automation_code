import os
import boto3
import pickle
import uuid
import asyncio
from typing import List, Dict, Any, Optional, Tuple
from datetime import datetime
import numpy as np

from langchain_aws import BedrockEmbeddings
from langchain_community.vectorstores import FAISS
from langchain_core.documents import Document
from langchain.text_splitter import RecursiveCharacterTextSplitter
from langchain_community.document_loaders import (
    S3DirectoryLoader,
    S3FileLoader,
    TextLoader,
    PyPDFLoader,
    UnstructuredWordDocumentLoader,
    CSVLoader
)

from app.core.config import settings
from app.services.document_service import DocumentService

class RAGService:
    def __init__(self):
        self.document_service = DocumentService()
        
        # Initialize AWS S3 client
        self.s3_client = boto3.client(
            's3',
            region_name=settings.aws_default_region
        )
        
        # Initialize Bedrock embeddings
        self.embeddings = BedrockEmbeddings(
            model_id="amazon.titan-embed-text-v1",
            region_name=settings.aws_default_region
        )
        
        # Text splitter for chunking documents
        self.text_splitter = RecursiveCharacterTextSplitter(
            chunk_size=1000,
            chunk_overlap=200,
            length_function=len,
            separators=["\n\n", "\n", " ", ""]
        )
        
        # FAISS index storage
        self.vector_store = None
        self.index_metadata = {}
        
        # S3 configuration
        self.s3_bucket = os.getenv('RAG_S3_BUCKET', 'redington-rag-documents')
        self.faiss_index_key = 'faiss_indexes/'
        
    async def initialize_vector_store(self, force_rebuild: bool = False) -> bool:
        """Initialize or load existing FAISS vector store"""
        try:
            if not force_rebuild:
                # Try to load existing index from S3
                success = await self.load_faiss_index_from_s3()
                if success:
                    print("✅ Loaded existing FAISS index from S3")
                    return True
            
            # Create new index if loading failed or force rebuild
            print("🔄 Creating new FAISS index...")
            await self.build_faiss_index_from_s3()
            return True
            
        except Exception as e:
            print(f"❌ Error initializing vector store: {str(e)}")
            return False
    
    async def load_faiss_index_from_s3(self) -> bool:
        """Load FAISS index from S3"""
        try:
            # Download index files from S3
            index_file = f"{self.faiss_index_key}faiss_index.pkl"
            metadata_file = f"{self.faiss_index_key}index_metadata.pkl"
            
            # Check if files exist in S3
            try:
                self.s3_client.head_object(Bucket=self.s3_bucket, Key=index_file)
                self.s3_client.head_object(Bucket=self.s3_bucket, Key=metadata_file)
            except:
                print("📁 No existing FAISS index found in S3")
                return False
            
            # Download and load index
            local_index_path = "/tmp/faiss_index.pkl"
            local_metadata_path = "/tmp/index_metadata.pkl"
            
            self.s3_client.download_file(self.s3_bucket, index_file, local_index_path)
            self.s3_client.download_file(self.s3_bucket, metadata_file, local_metadata_path)
            
            # Load the vector store
            with open(local_index_path, 'rb') as f:
                self.vector_store = pickle.load(f)
            
            with open(local_metadata_path, 'rb') as f:
                self.index_metadata = pickle.load(f)
            
            # Clean up temp files
            os.remove(local_index_path)
            os.remove(local_metadata_path)
            
            print(f"✅ Loaded FAISS index with {len(self.index_metadata)} documents")
            return True
            
        except Exception as e:
            print(f"❌ Error loading FAISS index from S3: {str(e)}")
            return False
    
    async def save_faiss_index_to_s3(self) -> bool:
        """Save FAISS index to S3"""
        try:
            if not self.vector_store:
                print("❌ No vector store to save")
                return False
            
            # Save to temporary files
            local_index_path = "/tmp/faiss_index.pkl"
            local_metadata_path = "/tmp/index_metadata.pkl"
            
            with open(local_index_path, 'wb') as f:
                pickle.dump(self.vector_store, f)
            
            with open(local_metadata_path, 'wb') as f:
                pickle.dump(self.index_metadata, f)
            
            # Upload to S3
            index_file = f"{self.faiss_index_key}faiss_index.pkl"
            metadata_file = f"{self.faiss_index_key}index_metadata.pkl"
            
            self.s3_client.upload_file(local_index_path, self.s3_bucket, index_file)
            self.s3_client.upload_file(local_metadata_path, self.s3_bucket, metadata_file)
            
            # Clean up temp files
            os.remove(local_index_path)
            os.remove(local_metadata_path)
            
            print(f"✅ Saved FAISS index to S3 with {len(self.index_metadata)} documents")
            return True
            
        except Exception as e:
            print(f"❌ Error saving FAISS index to S3: {str(e)}")
            return False
    
    async def build_faiss_index_from_s3(self) -> bool:
        """Build FAISS index from documents in S3 bucket"""
        try:
            # List all documents in S3 bucket
            documents = await self.load_documents_from_s3()
            
            if not documents:
                print("📁 No documents found in S3 bucket")
                return False
            
            print(f"📚 Processing {len(documents)} documents from S3...")
            
            # Split documents into chunks
            all_chunks = []
            for doc in documents:
                chunks = self.text_splitter.split_documents([doc])
                all_chunks.extend(chunks)
            
            print(f"📄 Created {len(all_chunks)} text chunks")
            
            # Create FAISS vector store
            if all_chunks:
                self.vector_store = await asyncio.to_thread(
                    FAISS.from_documents,
                    all_chunks,
                    self.embeddings
                )
                
                # Update metadata
                self.index_metadata = {
                    'total_documents': len(documents),
                    'total_chunks': len(all_chunks),
                    'last_updated': datetime.utcnow().isoformat(),
                    'document_sources': [doc.metadata.get('source', 'unknown') for doc in documents]
                }
                
                # Save to S3
                await self.save_faiss_index_to_s3()
                
                print(f"✅ Built FAISS index with {len(all_chunks)} chunks from {len(documents)} documents")
                return True
            
            return False
            
        except Exception as e:
            print(f"❌ Error building FAISS index: {str(e)}")
            return False
    
    async def load_documents_from_s3(self) -> List[Document]:
        """Load documents from S3 bucket"""
        try:
            documents = []
            
            # List objects in S3 bucket
            response = self.s3_client.list_objects_v2(Bucket=self.s3_bucket)
            
            if 'Contents' not in response:
                print(f"📁 S3 bucket '{self.s3_bucket}' is empty or doesn't exist")
                return documents
            
            for obj in response['Contents']:
                key = obj['Key']
                
                # Skip index files and directories
                if key.startswith(self.faiss_index_key) or key.endswith('/'):
                    continue
                
                try:
                    # Download file to temp location
                    local_path = f"/tmp/{os.path.basename(key)}"
                    self.s3_client.download_file(self.s3_bucket, key, local_path)
                    
                    # Load document based on file type
                    doc = await self.load_document_by_type(local_path, key)
                    if doc:
                        documents.extend(doc)
                    
                    # Clean up temp file
                    os.remove(local_path)
                    
                except Exception as e:
                    print(f"⚠️ Error processing {key}: {str(e)}")
                    continue
            
            return documents
            
        except Exception as e:
            print(f"❌ Error loading documents from S3: {str(e)}")
            return []
    
    async def load_document_by_type(self, file_path: str, s3_key: str) -> List[Document]:
        """Load document based on file type"""
        try:
            file_extension = os.path.splitext(file_path)[1].lower()
            
            if file_extension == '.pdf':
                loader = PyPDFLoader(file_path)
            elif file_extension in ['.doc', '.docx']:
                loader = UnstructuredWordDocumentLoader(file_path)
            elif file_extension == '.csv':
                loader = CSVLoader(file_path)
            elif file_extension in ['.txt', '.md']:
                loader = TextLoader(file_path)
            else:
                print(f"⚠️ Unsupported file type: {file_extension}")
                return []
            
            documents = await asyncio.to_thread(loader.load)
            
            # Add metadata
            for doc in documents:
                doc.metadata.update({
                    'source': s3_key,
                    'file_type': file_extension,
                    'loaded_at': datetime.utcnow().isoformat()
                })
            
            return documents
            
        except Exception as e:
            print(f"❌ Error loading document {file_path}: {str(e)}")
            return []
    
    async def add_document_to_index(self, file_content: bytes, filename: str, file_type: str) -> bool:
        """Add a new document to the FAISS index"""
        try:
            # Save file to S3 first
            s3_key = f"documents/{filename}"
            
            self.s3_client.put_object(
                Bucket=self.s3_bucket,
                Key=s3_key,
                Body=file_content,
                ContentType=self.get_content_type(file_type)
            )
            
            # Process the document
            temp_path = f"/tmp/{filename}"
            with open(temp_path, 'wb') as f:
                f.write(file_content)
            
            documents = await self.load_document_by_type(temp_path, s3_key)
            os.remove(temp_path)
            
            if not documents:
                return False
            
            # Split into chunks
            chunks = self.text_splitter.split_documents(documents)
            
            if not chunks:
                return False
            
            # Add to existing vector store or create new one
            if self.vector_store:
                # Add to existing index
                await asyncio.to_thread(self.vector_store.add_documents, chunks)
            else:
                # Create new index
                self.vector_store = await asyncio.to_thread(
                    FAISS.from_documents,
                    chunks,
                    self.embeddings
                )
            
            # Update metadata
            if not self.index_metadata:
                self.index_metadata = {
                    'total_documents': 0,
                    'total_chunks': 0,
                    'document_sources': []
                }
            
            self.index_metadata['total_documents'] += len(documents)
            self.index_metadata['total_chunks'] += len(chunks)
            self.index_metadata['last_updated'] = datetime.utcnow().isoformat()
            self.index_metadata['document_sources'].append(s3_key)
            
            # Save updated index to S3
            await self.save_faiss_index_to_s3()
            
            print(f"✅ Added document {filename} to FAISS index ({len(chunks)} chunks)")
            return True
            
        except Exception as e:
            print(f"❌ Error adding document to index: {str(e)}")
            return False
    
    async def search_similar_documents(self, query: str, k: int = 5) -> List[Document]:
        """Search for similar documents using FAISS"""
        try:
            if not self.vector_store:
                print("❌ Vector store not initialized")
                return []
            
            # Perform similarity search
            results = await asyncio.to_thread(
                self.vector_store.similarity_search,
                query,
                k=k
            )
            
            return results
            
        except Exception as e:
            print(f"❌ Error searching documents: {str(e)}")
            return []
    
    async def search_with_scores(self, query: str, k: int = 5) -> List[Tuple[Document, float]]:
        """Search for similar documents with similarity scores"""
        try:
            if not self.vector_store:
                print("❌ Vector store not initialized")
                return []
            
            # Perform similarity search with scores
            results = await asyncio.to_thread(
                self.vector_store.similarity_search_with_score,
                query,
                k=k
            )
            
            return results
            
        except Exception as e:
            print(f"❌ Error searching documents with scores: {str(e)}")
            return []
    
    async def get_rag_context(self, query: str, max_chunks: int = 5) -> str:
        """Get relevant context for RAG from FAISS index"""
        try:
            # Search for relevant documents
            results = await self.search_similar_documents(query, k=max_chunks)
            
            if not results:
                return ""
            
            # Combine relevant chunks into context
            context_parts = []
            for i, doc in enumerate(results, 1):
                source = doc.metadata.get('source', 'Unknown')
                content = doc.page_content.strip()
                
                context_parts.append(f"[Source {i}: {source}]\n{content}")
            
            context = "\n\n".join(context_parts)
            
            return f"RELEVANT CONTEXT FROM KNOWLEDGE BASE:\n\n{context}\n\n"
            
        except Exception as e:
            print(f"❌ Error getting RAG context: {str(e)}")
            return ""
    
    def get_content_type(self, file_type: str) -> str:
        """Get content type for S3 upload"""
        content_types = {
            'pdf': 'application/pdf',
            'doc': 'application/msword',
            'docx': 'application/vnd.openxmlformats-officedocument.wordprocessingml.document',
            'txt': 'text/plain',
            'csv': 'text/csv',
            'md': 'text/markdown'
        }
        return content_types.get(file_type.lower(), 'application/octet-stream')
    
    async def get_index_stats(self) -> Dict[str, Any]:
        """Get statistics about the FAISS index"""
        try:
            stats = {
                'index_initialized': self.vector_store is not None,
                'metadata': self.index_metadata,
                's3_bucket': self.s3_bucket
            }
            
            if self.vector_store:
                stats['vector_count'] = self.vector_store.index.ntotal
            
            return stats
            
        except Exception as e:
            print(f"❌ Error getting index stats: {str(e)}")
            return {'error': str(e)}
    
    async def rebuild_index(self) -> bool:
        """Rebuild the entire FAISS index from S3"""
        try:
            print("🔄 Rebuilding FAISS index from S3...")
            return await self.build_faiss_index_from_s3()
        except Exception as e:
            print(f"❌ Error rebuilding index: {str(e)}")
            return False

# Global RAG service instance
rag_service = RAGService()
