import boto3
from jose import jwt
from datetime import datetime, timedelta
from typing import Optional
from fastapi import HTTPException, status
from botocore.exceptions import ClientError
from app.core.config import settings

class AuthService:
    def __init__(self):
        self.cognito_client = boto3.client(
            'cognito-idp',
            region_name=settings.aws_default_region
        )
        self.user_pool_id = settings.pool_id
        self.client_id = settings.app_client_id
        self.client_secret = settings.app_client_secret

    async def authenticate_user(self, username: str, password: str) -> dict:
        """Authenticate user with AWS Cognito"""
        try:
            # Calculate SECRET_HASH
            import hmac
            import hashlib
            import base64
            
            message = username + self.client_id
            dig = hmac.new(
                self.client_secret.encode('utf-8'),
                message.encode('utf-8'),
                hashlib.sha256
            ).digest()
            secret_hash = base64.b64encode(dig).decode()

            response = self.cognito_client.initiate_auth(
                ClientId=self.client_id,
                AuthFlow='USER_PASSWORD_AUTH',
                AuthParameters={
                    'USERNAME': username,
                    'PASSWORD': password,
                    'SECRET_HASH': secret_hash
                }
            )
            
            # Extract tokens
            auth_result = response['AuthenticationResult']
            access_token = auth_result['AccessToken']
            id_token = auth_result['IdToken']
            refresh_token = auth_result['RefreshToken']
            
            # Get user info
            user_info = self.cognito_client.get_user(AccessToken=access_token)
            
            return {
                'access_token': access_token,
                'id_token': id_token,
                'refresh_token': refresh_token,
                'user_info': user_info,
                'expires_in': auth_result.get('ExpiresIn', 3600)
            }
            
        except ClientError as e:
            error_code = e.response['Error']['Code']
            if error_code == 'NotAuthorizedException':
                raise HTTPException(
                    status_code=status.HTTP_401_UNAUTHORIZED,
                    detail="Invalid username or password"
                )
            elif error_code == 'UserNotConfirmedException':
                raise HTTPException(
                    status_code=status.HTTP_401_UNAUTHORIZED,
                    detail="User account not confirmed"
                )
            else:
                raise HTTPException(
                    status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
                    detail=f"Authentication error: {str(e)}"
                )

    def create_access_token(self, data: dict, expires_delta: Optional[timedelta] = None):
        """Create JWT access token"""
        to_encode = data.copy()
        if expires_delta:
            expire = datetime.utcnow() + expires_delta
        else:
            expire = datetime.utcnow() + timedelta(minutes=settings.access_token_expire_minutes)
        
        to_encode.update({"exp": expire})
        encoded_jwt = jwt.encode(to_encode, settings.secret_key, algorithm=settings.algorithm)
        return encoded_jwt

    def verify_token(self, token: str) -> dict:
        """Verify Cognito JWT token"""
        try:
            # For Cognito tokens, we can decode without verification for now
            # In production, you should verify against Cognito's public keys
            import json
            import base64
            
            # Decode the token payload (without verification for simplicity)
            parts = token.split('.')
            if len(parts) != 3:
                raise ValueError("Invalid token format")
            
            # Decode the payload
            payload_encoded = parts[1]
            # Add padding if needed
            payload_encoded += '=' * (4 - len(payload_encoded) % 4)
            payload_bytes = base64.urlsafe_b64decode(payload_encoded)
            payload = json.loads(payload_bytes.decode('utf-8'))
            
            # Check if token is expired
            import time
            current_time = int(time.time())
            if payload.get('exp', 0) < current_time:
                raise ValueError("Token expired")
            
            return payload
        except Exception as e:
            raise HTTPException(
                status_code=status.HTTP_401_UNAUTHORIZED,
                detail="Could not validate credentials"
            )
