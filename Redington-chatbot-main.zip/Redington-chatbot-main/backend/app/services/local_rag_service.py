import os
import asyncio
from typing import List, Optional
from langchain_aws import BedrockEmbeddings
from langchain_community.vectorstores import FAISS
from langchain_core.documents import Document

from app.core.config import settings

class LocalRAGService:
    def __init__(self):
        self.embeddings = None
        self.vectorstore = None
        self.index_directory = os.path.join(os.path.dirname(__file__), "../../faiss_index")
        self.is_initialized = False
        
    async def initialize(self) -> bool:
        """Initialize the FAISS vector store from local index"""
        try:
            print(f"🔍 Initializing RAG service from: {self.index_directory}")
            
            # Check if index directory exists
            if not os.path.exists(self.index_directory):
                print(f"❌ FAISS index directory not found: {self.index_directory}")
                return False
            
            # Check if index files exist
            index_file = os.path.join(self.index_directory, "index.faiss")
            pkl_file = os.path.join(self.index_directory, "index.pkl")
            
            if not os.path.exists(index_file) or not os.path.exists(pkl_file):
                print(f"❌ FAISS index files not found in: {self.index_directory}")
                return False
            
            # Initialize Bedrock embeddings (same as your Streamlit app)
            self.embeddings = BedrockEmbeddings(
                model_id="amazon.titan-embed-text-v2:0",
                region_name=settings.aws_default_region
            )
            print("✅ Bedrock embeddings initialized")
            
            # Load FAISS index (same as your Streamlit app)
            self.vectorstore = await asyncio.to_thread(
                FAISS.load_local,
                self.index_directory,
                self.embeddings,
                allow_dangerous_deserialization=True  # Same as your Streamlit app
            )
            
            print(f"✅ FAISS index loaded successfully with {self.vectorstore.index.ntotal} vectors")
            self.is_initialized = True
            return True
            
        except Exception as e:
            print(f"❌ Error initializing RAG service: {str(e)}")
            return False
    
    async def get_rag_context(self, query: str, k: int = 5) -> str:
        """
        Get RAG context for a query (same logic as your Streamlit app)
        This matches your web_or_local function behavior
        """
        try:
            if not self.is_initialized or not self.vectorstore:
                print("⚠️ RAG service not initialized")
                return ""
            
            # Truncate query if too long (same as your Streamlit app)
            max_query_length = 1000  # Adjust as needed
            truncated_query = query[:max_query_length] if len(query) > max_query_length else query
            
            # Perform similarity search (same as your Streamlit app)
            docs = await asyncio.to_thread(
                self.vectorstore.similarity_search,
                truncated_query,
                k=k
            )
            
            # Join document content (same as your Streamlit app)
            rag_context = "\n\n".join(doc.page_content for doc in docs)
            
            print(f"✅ RAG context retrieved: {len(rag_context)} characters from {len(docs)} documents")
            return rag_context
            
        except Exception as e:
            print(f"❌ Error during RAG search: {str(e)}")
            return ""
    
    async def search_documents(self, query: str, k: int = 5) -> List[Document]:
        """Search for similar documents and return them with metadata"""
        try:
            if not self.is_initialized or not self.vectorstore:
                return []
            
            docs = await asyncio.to_thread(
                self.vectorstore.similarity_search,
                query,
                k=k
            )
            
            return docs
            
        except Exception as e:
            print(f"❌ Error searching documents: {str(e)}")
            return []
    
    async def search_with_scores(self, query: str, k: int = 5) -> List[tuple]:
        """Search for similar documents with similarity scores"""
        try:
            if not self.is_initialized or not self.vectorstore:
                return []
            
            results = await asyncio.to_thread(
                self.vectorstore.similarity_search_with_score,
                query,
                k=k
            )
            
            return results
            
        except Exception as e:
            print(f"❌ Error searching documents with scores: {str(e)}")
            return []
    
    def get_stats(self) -> dict:
        """Get statistics about the loaded FAISS index"""
        try:
            if not self.is_initialized or not self.vectorstore:
                return {
                    "initialized": False,
                    "error": "RAG service not initialized"
                }
            
            return {
                "initialized": True,
                "total_vectors": self.vectorstore.index.ntotal,
                "index_directory": self.index_directory,
                "embedding_model": "amazon.titan-embed-text-v2:0"
            }
            
        except Exception as e:
            return {
                "initialized": False,
                "error": str(e)
            }

# Global instance (similar to your Streamlit app approach)
local_rag_service = LocalRAGService()
