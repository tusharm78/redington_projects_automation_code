import base64
import io
import uuid
from typing import List, Dict, Any
from PIL import Image
import pdfplumber
import pandas as pd
from docx import Document
import PyPDF2

class DocumentService:
    def __init__(self):
        self.supported_formats = {
            'pdf': self._process_pdf,
            'txt': self._process_text,
            'docx': self._process_docx,
            'xlsx': self._process_excel,
            'csv': self._process_csv,
            'jpg': self._process_image,
            'jpeg': self._process_image,
            'png': self._process_image,
            'gif': self._process_image
        }
    
    async def process_files(self, files: List[str]) -> str:
        """Process uploaded files and extract content"""
        all_content = []
        
        for file_data in files:
            try:
                # Decode base64 file data
                file_content = base64.b64decode(file_data)
                
                # Detect file type (you might want to pass this from frontend)
                file_type = self._detect_file_type(file_content)
                
                if file_type in self.supported_formats:
                    content = await self.supported_formats[file_type](file_content)
                    all_content.append(content)
                else:
                    all_content.append(f"Unsupported file type: {file_type}")
                    
            except Exception as e:
                all_content.append(f"Error processing file: {str(e)}")
        
        return "\n\n".join(all_content)
    
    def _detect_file_type(self, file_content: bytes) -> str:
        """Detect file type from content"""
        # Simple file type detection based on magic bytes
        if file_content.startswith(b'%PDF'):
            return 'pdf'
        elif file_content.startswith(b'PK'):  # ZIP-based formats
            if b'word/' in file_content[:1000]:
                return 'docx'
            elif b'xl/' in file_content[:1000]:
                return 'xlsx'
        elif file_content.startswith(b'\xff\xd8\xff'):
            return 'jpg'
        elif file_content.startswith(b'\x89PNG'):
            return 'png'
        elif file_content.startswith(b'GIF'):
            return 'gif'
        else:
            return 'txt'  # Default to text
    
    async def _process_pdf(self, file_content: bytes) -> str:
        """Process PDF file"""
        try:
            with io.BytesIO(file_content) as pdf_file:
                with pdfplumber.open(pdf_file) as pdf:
                    text = ""
                    for page in pdf.pages:
                        text += page.extract_text() or ""
                    return f"PDF Content:\n{text}"
        except Exception as e:
            return f"Error processing PDF: {str(e)}"
    
    async def _process_text(self, file_content: bytes) -> str:
        """Process text file"""
        try:
            text = file_content.decode('utf-8')
            return f"Text Content:\n{text}"
        except Exception as e:
            return f"Error processing text file: {str(e)}"
    
    async def _process_docx(self, file_content: bytes) -> str:
        """Process DOCX file"""
        try:
            with io.BytesIO(file_content) as docx_file:
                doc = Document(docx_file)
                text = ""
                for paragraph in doc.paragraphs:
                    text += paragraph.text + "\n"
                return f"DOCX Content:\n{text}"
        except Exception as e:
            return f"Error processing DOCX: {str(e)}"
    
    async def _process_excel(self, file_content: bytes) -> str:
        """Process Excel file"""
        try:
            with io.BytesIO(file_content) as excel_file:
                df = pd.read_excel(excel_file)
                return f"Excel Content:\n{df.to_string()}"
        except Exception as e:
            return f"Error processing Excel: {str(e)}"
    
    async def _process_csv(self, file_content: bytes) -> str:
        """Process CSV file"""
        try:
            with io.BytesIO(file_content) as csv_file:
                df = pd.read_csv(csv_file)
                return f"CSV Content:\n{df.to_string()}"
        except Exception as e:
            return f"Error processing CSV: {str(e)}"
    
    async def _process_image(self, file_content: bytes) -> str:
        """Process image file"""
        try:
            with io.BytesIO(file_content) as img_file:
                img = Image.open(img_file)
                return f"Image processed: {img.format} format, Size: {img.size}"
        except Exception as e:
            return f"Error processing image: {str(e)}"
