from jose import jwt
from datetime import datetime, timedelta
from typing import Optional
from fastapi import HTTPException, status
from app.core.config import settings

class DemoAuthService:
    """Demo authentication service for testing without AWS Cognito"""
    
    def __init__(self):
        # Demo users for testing
        self.demo_users = {
            "tanmay": {
                "password": "Admin@123$",
                "email": "tanmay@redington.com",
                "full_name": "Tanmay Demo User"
            },
            "admin": {
                "password": "admin123",
                "email": "admin@redington.com", 
                "full_name": "Admin User"
            },
            "demo": {
                "password": "demo123",
                "email": "demo@redington.com",
                "full_name": "Demo User"
            }
        }

    async def authenticate_user(self, username: str, password: str) -> dict:
        """Authenticate user with demo credentials"""
        try:
            # Check if user exists in demo users
            if username not in self.demo_users:
                raise HTTPException(
                    status_code=status.HTTP_401_UNAUTHORIZED,
                    detail="Invalid username or password"
                )
            
            user = self.demo_users[username]
            
            # Check password
            if user["password"] != password:
                raise HTTPException(
                    status_code=status.HTTP_401_UNAUTHORIZED,
                    detail="Invalid username or password"
                )
            
            # Create access token
            access_token = self.create_access_token(
                data={"sub": username, "username": username}
            )
            
            return {
                'access_token': access_token,
                'id_token': access_token,  # Using same token for demo
                'refresh_token': access_token,  # Using same token for demo
                'user_info': {
                    'Username': username,
                    'UserAttributes': [
                        {'Name': 'email', 'Value': user['email']},
                        {'Name': 'name', 'Value': user['full_name']}
                    ]
                },
                'expires_in': 3600
            }
            
        except HTTPException:
            raise
        except Exception as e:
            raise HTTPException(
                status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
                detail=f"Authentication error: {str(e)}"
            )

    def create_access_token(self, data: dict, expires_delta: Optional[timedelta] = None):
        """Create JWT access token"""
        to_encode = data.copy()
        if expires_delta:
            expire = datetime.utcnow() + expires_delta
        else:
            expire = datetime.utcnow() + timedelta(minutes=settings.access_token_expire_minutes)
        
        to_encode.update({"exp": expire})
        encoded_jwt = jwt.encode(to_encode, settings.secret_key, algorithm=settings.algorithm)
        return encoded_jwt

    def verify_token(self, token: str) -> dict:
        """Verify JWT token"""
        try:
            payload = jwt.decode(token, settings.secret_key, algorithms=[settings.algorithm])
            username: str = payload.get("sub")
            if username is None:
                raise HTTPException(
                    status_code=status.HTTP_401_UNAUTHORIZED,
                    detail="Could not validate credentials"
                )
            return payload
        except jwt.ExpiredSignatureError:
            raise HTTPException(
                status_code=status.HTTP_401_UNAUTHORIZED,
                detail="Token expired"
            )
        except jwt.JWTError:
            raise HTTPException(
                status_code=status.HTTP_401_UNAUTHORIZED,
                detail="Could not validate credentials"
            )
