import uuid
import asyncio
from datetime import datetime
from typing import List, Dict, Any, Optional, AsyncGenerator
from langchain.prompts.chat import ChatPromptTemplate, MessagesPlaceholder
from langchain_core.messages import HumanMessage, AIMessage, SystemMessage
from langchain_aws import BedrockEmbeddings
from langchain_community.vectorstores import FAISS

from app.models.bedrock_models import ChatModel
from app.models.schemas import ChatMessage, ChatRequest, ChatResponse
from app.services.document_service import DocumentService
from app.services.local_rag_service import local_rag_service
from app.core.config import settings, model_config
from services.dynamodb_service import dynamodb_service

class ChatService:
    def __init__(self):
        self.document_service = DocumentService()
        # Don't initialize RAG on startup to avoid async issues
        self._rag_initialized = False
        
    async def _ensure_rag_initialized(self):
        """Ensure RAG service is initialized (lazy initialization)"""
        if not self._rag_initialized:
            try:
                await local_rag_service.initialize()
                self._rag_initialized = True
                print("✅ RAG service initialized successfully")
            except Exception as e:
                print(f"⚠️ Failed to initialize RAG service: {str(e)}")
                self._rag_initialized = False
        
    def get_system_prompt(self, user_id: str) -> str:
        """Get role-based system prompt for the user"""
        # For now, we'll use a simple role detection based on username
        # In a real implementation, you'd get this from user profile/database
        
        presales_prompt = """You are an expert Presales Professional AI assistant for Redington, a leading technology distribution company. Your role is to help create comprehensive, professional proposals for technology solutions.

Key Responsibilities:
- Create detailed technical proposals for IT infrastructure, cloud solutions, and enterprise technology
- Provide competitive analysis and positioning
- Generate executive summaries and business justifications
- Suggest appropriate technology stacks and architectures
- Calculate ROI and business value propositions
- Create implementation timelines and project plans

Guidelines:
- Always structure responses with clear headings and bullet points
- Include technical specifications when relevant
- Provide cost-benefit analysis where applicable
- Suggest multiple solution options (good, better, best)
- Include risk mitigation strategies
- Format responses for easy copy-paste into proposal documents
- Use professional business language
- Include relevant industry standards and compliance considerations
- When relevant context is provided from the knowledge base, reference it appropriately and use it to enhance your proposals
- Use information from uploaded documents and knowledge base to create more accurate and detailed proposals

Focus Areas:
- Cloud Migration and Modernization
- Cybersecurity Solutions
- Data Center Infrastructure
- Digital Transformation
- Enterprise Software Solutions
- Networking and Connectivity
- Backup and Disaster Recovery

Always provide actionable, detailed responses that can be directly used in customer proposals."""

        solution_architect_prompt = """You are an expert Solution Architect AI assistant for Redington, specializing in designing comprehensive technology solutions for enterprise clients.

Key Responsibilities:
- Design end-to-end technology architectures
- Create detailed technical specifications and diagrams
- Provide integration strategies and implementation roadmaps
- Analyze technical requirements and constraints
- Recommend best practices and industry standards
- Design scalable, secure, and cost-effective solutions

Guidelines:
- Structure responses with clear technical sections
- Include architecture diagrams descriptions when relevant
- Provide detailed technical specifications
- Consider scalability, security, and performance requirements
- Include integration points and data flows
- Format responses for technical documentation
- Use precise technical terminology
- Include capacity planning and sizing recommendations
- Reference knowledge base information when available to provide proven architectural patterns
- Incorporate insights from uploaded technical documents and organizational standards

Technical Focus Areas:
- Cloud Architecture (AWS, Azure, Google Cloud)
- Enterprise Integration Patterns
- Microservices and API Design
- Security Architecture and Zero Trust
- Data Architecture and Analytics
- DevOps and CI/CD Pipelines
- Infrastructure as Code
- Monitoring and Observability

Always provide detailed, technically accurate solutions that can be implemented by development and infrastructure teams."""

        # Simple role detection - you can enhance this based on your user management system
        if "architect" in user_id.lower() or "solution" in user_id.lower():
            return solution_architect_prompt
        else:
            return presales_prompt
        
    async def process_chat_message(self, request: ChatRequest, user_id: str) -> ChatResponse:
        """Process a chat message and return response with DynamoDB persistence and local RAG"""
        try:
            # Ensure RAG is initialized
            await self._ensure_rag_initialized()
            
            # Get or create conversation
            conversation_id = request.conversation_id
            if not conversation_id:
                # Create new session if none provided
                conversation_id = dynamodb_service.create_new_chat_session(
                    user_id=user_id,
                    chat_title=request.message[:50] + "..." if len(request.message) > 50 else request.message
                )
            
            # Create chat model
            chat_model = ChatModel(request.model_name, request.model_kwargs)
            
            # Process uploaded files if any
            context_content = ""
            has_context = False
            if request.files:
                context_content = await self.document_service.process_files(request.files)
                has_context = True
            
            # Get RAG context from local FAISS index (same as Streamlit app)
            rag_context = ""
            if self._rag_initialized:
                try:
                    rag_context = await local_rag_service.get_rag_context(request.message, k=5)
                    if rag_context:
                        has_context = True
                        print(f"✅ RAG context retrieved: {len(rag_context)} characters")
                except Exception as e:
                    print(f"⚠️ RAG context retrieval failed: {str(e)}")
            
            # Load conversation history from DynamoDB
            history_messages = dynamodb_service.load_chat_history(user_id, conversation_id)
            
            # Build conversation history for LangChain with system prompt
            messages = []
            
            # Add system prompt at the beginning
            system_prompt = request.system_prompt if request.system_prompt else self.get_system_prompt(user_id)
            messages.append(SystemMessage(content=system_prompt))
            
            for msg in history_messages:
                if msg['role'] == "user":
                    messages.append(HumanMessage(content=msg['content']))
                else:
                    messages.append(AIMessage(content=msg['content']))
            
            # Add current message with context (files + RAG) - similar to Streamlit approach
            current_message = request.message
            if context_content or rag_context:
                message_parts = []
                
                if rag_context:
                    message_parts.append(f"RELEVANT CONTEXT FROM KNOWLEDGE BASE:\n{rag_context}")
                
                if context_content:
                    message_parts.append(f"UPLOADED FILES CONTENT:\n{context_content}")
                
                message_parts.append(f"USER QUESTION: {request.message}")
                current_message = "\n\n".join(message_parts)
            
            messages.append(HumanMessage(content=current_message))
            
            # Generate response
            response = await asyncio.to_thread(chat_model.llm.invoke, messages)
            
            # Handle different response formats
            if hasattr(response, 'content'):
                if isinstance(response.content, str):
                    response_content = response.content
                elif isinstance(response.content, list):
                    # Handle structured responses (e.g., from reasoning models)
                    response_content = ""
                    for item in response.content:
                        if isinstance(item, dict):
                            if item.get('type') == 'text':
                                response_content += item.get('text', '')
                            elif item.get('type') == 'reasoning_content':
                                # Skip reasoning content, we only want the final response
                                continue
                            elif 'text' in item:
                                response_content += item['text']
                            else:
                                # Fallback: convert dict to string
                                response_content += str(item)
                        else:
                            response_content += str(item)
                else:
                    response_content = str(response.content)
            else:
                response_content = str(response)
            
            # Clean up response content - remove reasoning artifacts
            if "{'type': 'reasoning_content'" in response_content:
                # Extract only the text after the reasoning content
                parts = response_content.split("}")
                for part in parts:
                    if part.strip() and not part.startswith("{'type': 'reasoning_content'") and not "reasoning_content" in part:
                        response_content = part.strip()
                        break
            
            # Store user message in DynamoDB
            user_message_id = dynamodb_service.store_message(
                user_id=user_id,
                chat_id=conversation_id,
                role="user",
                content=request.message,
                user_prompt=request.message,
                has_context=has_context,
                images=request.files if request.files else None
            )
            
            # Store AI response in DynamoDB
            ai_message_id = dynamodb_service.store_message(
                user_id=user_id,
                chat_id=conversation_id,
                role="assistant",
                content=response_content,
                user_prompt=request.message,
                has_context=has_context
            )
            
            return ChatResponse(
                response=response_content,
                conversation_id=conversation_id,
                message_id=ai_message_id,
                model_used=request.model_name,
                timestamp=datetime.utcnow()
            )
            
        except Exception as e:
            raise Exception(f"Error processing chat message: {str(e)}")
    
    async def stream_chat_response(self, request: ChatRequest, user_id: str) -> AsyncGenerator[str, None]:
        """Stream chat response for real-time updates with DynamoDB persistence and local RAG"""
        try:
            # Ensure RAG is initialized
            await self._ensure_rag_initialized()
            
            # Get or create conversation
            conversation_id = request.conversation_id
            if not conversation_id:
                conversation_id = dynamodb_service.create_new_chat_session(
                    user_id=user_id,
                    chat_title=request.message[:50] + "..." if len(request.message) > 50 else request.message
                )
            
            chat_model = ChatModel(request.model_name, request.model_kwargs)
            
            # Process files if any
            context_content = ""
            has_context = False
            if request.files:
                context_content = await self.document_service.process_files(request.files)
                has_context = True
            
            # Get RAG context from local FAISS index (same as Streamlit app)
            rag_context = ""
            if self._rag_initialized:
                try:
                    rag_context = await local_rag_service.get_rag_context(request.message, k=5)
                    if rag_context:
                        has_context = True
                        print(f"✅ RAG context retrieved for streaming: {len(rag_context)} characters")
                except Exception as e:
                    print(f"⚠️ RAG context retrieval failed: {str(e)}")
            
            # Load conversation history from DynamoDB
            history_messages = dynamodb_service.load_chat_history(user_id, conversation_id)
            
            # Build messages for LangChain with system prompt
            messages = []
            
            # Add system prompt at the beginning
            system_prompt = request.system_prompt if request.system_prompt else self.get_system_prompt(user_id)
            messages.append(SystemMessage(content=system_prompt))
            
            for msg in history_messages:
                if msg['role'] == "user":
                    messages.append(HumanMessage(content=msg['content']))
                else:
                    messages.append(AIMessage(content=msg['content']))
            
            # Add current message with context (files + RAG) - similar to Streamlit approach
            current_message = request.message
            if context_content or rag_context:
                message_parts = []
                
                if rag_context:
                    message_parts.append(f"RELEVANT CONTEXT FROM KNOWLEDGE BASE:\n{rag_context}")
                
                if context_content:
                    message_parts.append(f"UPLOADED FILES CONTENT:\n{context_content}")
                
                message_parts.append(f"USER QUESTION: {request.message}")
                current_message = "\n\n".join(message_parts)
            
            messages.append(HumanMessage(content=current_message))
            
            # Stream response
            full_response = ""
            async for chunk in chat_model.llm.astream(messages):
                if hasattr(chunk, 'content') and chunk.content:
                    # Handle different chunk content formats
                    chunk_content = ""
                    if isinstance(chunk.content, str):
                        chunk_content = chunk.content
                    elif isinstance(chunk.content, list):
                        for item in chunk.content:
                            if isinstance(item, dict):
                                if item.get('type') == 'text':
                                    chunk_content += item.get('text', '')
                                elif item.get('type') == 'reasoning_content':
                                    # Skip reasoning content in streaming
                                    continue
                                elif 'text' in item:
                                    chunk_content += item['text']
                            else:
                                chunk_content += str(item)
                    else:
                        chunk_content = str(chunk.content)
                    
                    # Clean up chunk content
                    if "{'type': 'reasoning_content'" in chunk_content:
                        # Skip chunks that contain reasoning content
                        continue
                    
                    full_response += chunk_content
                    if chunk_content.strip():  # Only yield non-empty chunks
                        yield f"data: {chunk_content}\n\n"
            
            # Store user message in DynamoDB
            user_message_id = dynamodb_service.store_message(
                user_id=user_id,
                chat_id=conversation_id,
                role="user",
                content=request.message,
                user_prompt=request.message,
                has_context=has_context,
                images=request.files if request.files else None
            )
            
            # Store AI response in DynamoDB
            ai_message_id = dynamodb_service.store_message(
                user_id=user_id,
                chat_id=conversation_id,
                role="assistant",
                content=full_response,
                user_prompt=request.message,
                has_context=has_context
            )
            
            # Send conversation ID and completion signal
            yield f"data: [CONVERSATION_ID]{conversation_id}\n\n"
            yield f"data: [DONE]\n\n"
            
        except Exception as e:
            yield f"data: Error: {str(e)}\n\n"
    
    def get_conversation_history(self, conversation_id: str, user_id: str = None) -> List[ChatMessage]:
        """Get conversation history from DynamoDB"""
        if not user_id:
            return []
        
        try:
            history_messages = dynamodb_service.load_chat_history(user_id, conversation_id)
            
            # Convert to ChatMessage objects
            chat_messages = []
            for msg in history_messages:
                chat_message = ChatMessage(
                    role=msg['role'],
                    content=msg['content'],
                    timestamp=datetime.fromtimestamp(msg['timestamp'] / 1000),
                    message_id=msg['message_id']
                )
                chat_messages.append(chat_message)
            
            return chat_messages
        except Exception as e:
            raise Exception(f"Error loading conversation history: {str(e)}")
    
    def get_available_models(self) -> Dict[str, Any]:
        """Get available models from config"""
        return model_config["models"]
