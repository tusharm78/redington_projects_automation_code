import os
import yaml
from typing import List
from pydantic_settings import BaseSettings

class Settings(BaseSettings):
    # AWS Configuration
    aws_default_region: str = "us-east-1"
    pool_id: str
    app_client_id: str
    app_client_secret: str
    
    # FastAPI Configuration
    secret_key: str
    algorithm: str = "HS256"
    access_token_expire_minutes: int = 30
    
    # CORS Configuration
    allowed_origins: List[str] = ["http://localhost:3000"]
    
    # Database Configuration
    dynamodb_table_name: str = "chatbot-conversations"
    
    class Config:
        env_file = ".env"

def load_model_config():
    """Load model configuration from YAML file"""
    config_path = os.path.join(os.path.dirname(__file__), "../../config/config.yml")
    with open(config_path, 'r') as file:
        return yaml.safe_load(file)

settings = Settings()
model_config = load_model_config()
