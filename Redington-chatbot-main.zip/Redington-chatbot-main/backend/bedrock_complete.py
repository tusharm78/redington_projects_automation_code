import asyncio
import time
import json
import boto3
from fastapi import FastAPI, HTTPException, Depends, status
from fastapi.middleware.cors import CORSMiddleware
from fastapi.security import HTTPBearer, HTTPAuthorizationCredentials
from fastapi.responses import StreamingResponse
from pydantic import BaseModel
import logging
import jwt
from jwt.exceptions import ExpiredSignatureError, InvalidTokenError
from datetime import datetime, timedelta
from typing import AsyncGenerator, Dict, List, Optional

# Setup logging
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

# Create FastAPI application
app = FastAPI(
    title="Redington AI Bot - Bedrock Integration",
    description="Enhanced streaming with AWS Bedrock Claude integration",
    version="3.0.0"
)

# Add CORS middleware
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# Security
security = HTTPBearer()
SECRET_KEY = "demo-secret-key-for-bedrock-streaming"

# Pydantic models
class AuthRequest(BaseModel):
    username: str
    password: str

class AuthResponse(BaseModel):
    access_token: str
    token_type: str
    expires_in: int

class UserInfo(BaseModel):
    username: str
    email: str = ""

class ChatRequest(BaseModel):
    message: str
    conversation_id: str = "default"
    session_id: str = "default"
    model: str = "claude-3-sonnet"

class StreamChunk(BaseModel):
    chunk: str
    is_complete: bool = False
    metadata: Optional[Dict] = None

# Demo users
demo_users = {
    "demo": "demo123",
    "admin": "admin123",
    "user": "password"
}

def create_access_token(username: str):
    """Create a JWT token for demo purposes"""
    expire = datetime.utcnow() + timedelta(hours=24)
    payload = {
        "username": username,
        "exp": expire,
        "iat": datetime.utcnow()
    }
    return jwt.encode(payload, SECRET_KEY, algorithm="HS256")

def verify_token(token: str):
    """Verify JWT token"""
    try:
        payload = jwt.decode(token, SECRET_KEY, algorithms=["HS256"])
        return payload
    except ExpiredSignatureError:
        raise HTTPException(status_code=401, detail="Token expired")
    except InvalidTokenError:
        raise HTTPException(status_code=401, detail="Invalid token")

async def get_current_user(credentials: HTTPAuthorizationCredentials = Depends(security)):
    """Get current user from token"""
    payload = verify_token(credentials.credentials)
    return payload.get("username")

class BedrockClaudeIntegration:
    """AWS Bedrock Claude integration for real AI responses"""
    
    def __init__(self):
        self.bedrock_client = None
        self.model_configs = {
            "claude-3-sonnet": {
                "model_id": "anthropic.claude-3-sonnet-20240229-v1:0",
                "max_tokens": 4000,
                "temperature": 0.7,
                "top_p": 0.9
            },
            "claude-3-haiku": {
                "model_id": "anthropic.claude-3-haiku-20240307-v1:0",
                "max_tokens": 4000,
                "temperature": 0.7,
                "top_p": 0.9
            }
        }
        self.system_prompt = self._load_system_prompt()
        self._initialize_bedrock()
    
    def _initialize_bedrock(self):
        """Initialize AWS Bedrock client"""
        try:
            # Try to initialize Bedrock client
            self.bedrock_client = boto3.client(
                'bedrock-runtime',
                region_name='us-east-1'  # Change to your preferred region
            )
            logger.info("✅ AWS Bedrock client initialized successfully")
        except Exception as e:
            logger.warning(f"⚠️ AWS Bedrock not available: {e}")
            logger.info("🔄 Falling back to enhanced demo mode")
            self.bedrock_client = None
    
    def _load_system_prompt(self) -> str:
        """Load system prompt for Redington AI"""
        return """You are an expert AI assistant for Redington, a leading technology distributor and solutions provider in the Asia-Pacific region. 

Your role is to provide comprehensive, professional, and detailed information about Redington's technology solutions and services. When generating proposals or detailed responses, always:

1. **Structure your responses professionally** with clear headings, sections, and formatting
2. **Provide detailed technical information** including specifications, benefits, and implementation details
3. **Include business value propositions** with ROI considerations and competitive advantages
4. **Use proper markdown formatting** for headers, lists, code blocks, and tables
5. **Be comprehensive and thorough** - provide in-depth analysis and recommendations
6. **Customize responses** based on the specific query and context provided

**Redington's Core Services:**
- Cloud Computing Solutions (IaaS, PaaS, SaaS)
- Advanced Cybersecurity Services (SOC, threat detection, identity management)
- Data Analytics & Business Intelligence (ML, AI, predictive analytics)
- Digital Transformation Consulting (modernization, automation, process optimization)
- Enterprise Software Solutions (productivity, collaboration, ERP)
- Infrastructure Solutions (networking, storage, compute)
- Professional Services (implementation, training, support)

**Key Industries Served:**
- Financial Services & Banking
- Healthcare & Life Sciences
- Manufacturing & Industrial
- Retail & E-commerce
- Government & Public Sector
- Education & Research
- Telecommunications
- Media & Entertainment

When creating proposals, include:
- Executive Summary
- Technical Requirements Analysis
- Detailed Solution Architecture
- Implementation Timeline
- Pricing Considerations (when appropriate)
- Risk Assessment & Mitigation
- Success Metrics & KPIs
- Next Steps & Recommendations

Always maintain a professional, consultative tone and provide actionable insights."""

    async def generate_streaming_response(
        self, 
        user_message: str, 
        username: str, 
        model: str = "claude-3-sonnet"
    ) -> AsyncGenerator[str, None]:
        """Generate streaming response using AWS Bedrock Claude"""
        
        try:
            if self.bedrock_client is None:
                # Fallback to enhanced demo mode
                async for chunk in self._generate_demo_response(user_message, username):
                    yield chunk
                return
            
            # Prepare the request for Claude
            model_config = self.model_configs.get(model, self.model_configs["claude-3-sonnet"])
            
            # Create the prompt
            full_prompt = f"""Human: {self.system_prompt}

User Query: {user_message}
User: {username}

Please provide a comprehensive, well-structured response with proper markdown formatting. Focus on delivering detailed, professional information that would be valuable for business decision-making.
