#!/usr/bin/env python3
"""
Simple Admin API - Shows correct online/offline status for users
"""

import asyncio
import json
import boto3
import os
from datetime import datetime, timedelta
from typing import Dict, List, Optional
from fastapi import FastAPI, HTTPException, Depends, status
from fastapi.middleware.cors import CORSMiddleware
from fastapi.security import HTTPBearer, HTTPAuthorizationCredentials
from pydantic import BaseModel
import jwt
from dotenv import load_dotenv
import logging
from decimal import Decimal

# Load environment variables
load_dotenv()

# Setup logging
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

# Create FastAPI app
app = FastAPI(
    title="Simple Admin API",
    description="Simple admin API with correct online status",
    version="1.0.0"
)

# Add CORS middleware
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# Security
security = HTTPBearer()

# Pydantic models
class AdminLoginRequest(BaseModel):
    username: str
    password: str

class AdminLoginResponse(BaseModel):
    access_token: str
    token_type: str
    expires_in: int
    user_info: Dict

# Admin users
ADMIN_USERS = {
    "admin": "admin123",
    "tanmay": "tanmay123", 
    "meenal": "meenal123",
    "varunesh": "varunesh123"
}

# JWT Secret
SECRET_KEY = os.getenv("SECRET_KEY", "your-secret-key-change-in-production")

# Cognito Configuration
COGNITO_USER_POOL_ID = os.getenv("POOL_ID")
COGNITO_REGION = os.getenv("AWS_DEFAULT_REGION", "us-east-1")

class SimpleAdminAPI:
    def __init__(self):
        self.cognito_client = None
        self.dynamodb = None
        self.session_table = None
        self.init_aws_clients()
    
    def init_aws_clients(self):
        """Initialize AWS clients"""
        try:
            # Initialize Cognito client
            self.cognito_client = boto3.client('cognito-idp', region_name=COGNITO_REGION)
            logger.info("✅ Connected to AWS Cognito")
            
            # Initialize DynamoDB
            self.dynamodb = boto3.resource('dynamodb', region_name=COGNITO_REGION)
            self.session_table = self.dynamodb.Table('user_chat_sessions')
            logger.info("✅ Connected to DynamoDB")
            
        except Exception as e:
            logger.error(f"❌ Failed to connect to AWS services: {e}")
    
    def create_admin_token(self, username: str) -> str:
        """Create JWT token for admin"""
        payload = {
            "username": username,
            "role": "admin",
            "exp": datetime.utcnow() + timedelta(hours=8)
        }
        return jwt.encode(payload, SECRET_KEY, algorithm="HS256")
    
    def verify_admin_token(self, token: str) -> Dict:
        """Verify admin JWT token"""
        try:
            payload = jwt.decode(token, SECRET_KEY, algorithms=["HS256"])
            username = payload.get("username")
            
            if username not in ADMIN_USERS:
                raise HTTPException(
                    status_code=status.HTTP_403_FORBIDDEN,
                    detail="Access denied"
                )
            
            return payload
        except jwt.ExpiredSignatureError:
            raise HTTPException(
                status_code=status.HTTP_401_UNAUTHORIZED,
                detail="Token expired"
            )
        except jwt.InvalidTokenError:
            raise HTTPException(
                status_code=status.HTTP_401_UNAUTHORIZED,
                detail="Invalid token"
            )
    
    async def get_cognito_users(self) -> List[Dict]:
        """Get real users from AWS Cognito with correct online status"""
        if not self.cognito_client or not COGNITO_USER_POOL_ID:
            return []
        
        try:
            users = []
            paginator = self.cognito_client.get_paginator('list_users')
            
            # Get all users from Cognito
            for page in paginator.paginate(UserPoolId=COGNITO_USER_POOL_ID):
                for user in page.get('Users', []):
                    user_data = self._process_cognito_user(user)
                    if user_data:
                        users.append(user_data)
            
            # Check session activity for online status
            users = await self._check_session_activity(users)
            
            logger.info(f"✅ Found {len(users)} users")
            return users
            
        except Exception as e:
            logger.error(f"❌ Error getting users: {e}")
            return []
    
    def _process_cognito_user(self, cognito_user: Dict) -> Optional[Dict]:
        """Process a single Cognito user"""
        try:
            username = cognito_user.get('Username', '')
            user_status = cognito_user.get('UserStatus', 'UNKNOWN')
            enabled = cognito_user.get('Enabled', False)
            created_date = cognito_user.get('UserCreateDate')
            last_modified = cognito_user.get('UserLastModifiedDate')
            
            # Extract user attributes
            attributes = {}
            for attr in cognito_user.get('Attributes', []):
                attributes[attr['Name']] = attr['Value']
            
            return {
                'username': username,
                'email': attributes.get('email', f'{username}@redington.local'),
                'status': 'offline',  # Will be updated by session check
                'cognito_status': user_status,
                'enabled': enabled,
                'created_date': created_date.isoformat() if created_date else '',
                'last_modified': last_modified.isoformat() if last_modified else '',
                'login_time': '',  # Will be updated by session check
                'last_activity': '',  # Will be updated by session check
                'session_duration': '0m',
                'chat_sessions': 0,
                'messages_sent': 0,
                'phone_number': attributes.get('phone_number', ''),
                'email_verified': attributes.get('email_verified', 'false') == 'true'
            }
            
        except Exception as e:
            logger.error(f"Error processing user: {e}")
            return None
    
    async def _check_session_activity(self, users: List[Dict]) -> List[Dict]:
        """Check session activity to determine online status"""
        if not self.session_table:
            return users
        
        try:
            from boto3.dynamodb.conditions import Key
            
            for user in users:
                username = user['username']
                
                try:
                    # Query user sessions
                    response = self.session_table.query(
                        KeyConditionExpression=Key("user_id").eq(username)
                    )
                    
                    sessions = response.get('Items', [])
                    
                    if sessions:
                        latest_activity = None
                        earliest_login = None
                        message_count = 0
                        
                        for session in sessions:
                            # Count messages
                            if 'message_data' in session or 'content' in session:
                                message_count += 1
                            
                            # Get timestamps
                            for time_field in ['timestamp', 'last_activity', 'created_at']:
                                if time_field in session:
                                    activity_time = session[time_field]
                                    
                                    # Handle different formats
                                    if isinstance(activity_time, Decimal):
                                        # Unix timestamp in milliseconds
                                        activity_time = datetime.fromtimestamp(float(activity_time) / 1000).isoformat()
                                    elif isinstance(activity_time, (int, float)):
                                        activity_time = datetime.fromtimestamp(activity_time / 1000).isoformat()
                                    elif isinstance(activity_time, str):
                                        # ISO string - use as is
                                        pass
                                    
                                    if not latest_activity or activity_time > latest_activity:
                                        latest_activity = activity_time
                                    
                                    if not earliest_login or activity_time < earliest_login:
                                        earliest_login = activity_time
                                    
                                    break
                        
                        # Update user data
                        user['chat_sessions'] = len(sessions)
                        user['messages_sent'] = message_count
                        
                        if latest_activity:
                            user['last_activity'] = latest_activity
                            user['login_time'] = earliest_login or latest_activity
                            
                            # Check if online (active within last 30 minutes)
                            try:
                                if '+' in latest_activity:
                                    activity_dt = datetime.fromisoformat(latest_activity.replace('Z', '+00:00'))
                                else:
                                    activity_dt = datetime.fromisoformat(latest_activity)
                                
                                current_time = datetime.utcnow()
                                if activity_dt.tzinfo:
                                    activity_dt = activity_dt.replace(tzinfo=None)
                                
                                time_diff = (current_time - activity_dt).total_seconds()
                                minutes_ago = time_diff / 60
                                
                                # Mark as online if active within last 30 minutes
                                if time_diff < 1800:  # 30 minutes
                                    user['status'] = 'online'
                                    logger.info(f"✅ {username} is ONLINE - active {minutes_ago:.1f} minutes ago")
                                else:
                                    user['status'] = 'offline'
                                    logger.info(f"⚪ {username} is OFFLINE - active {minutes_ago:.1f} minutes ago")
                                
                                # Calculate session duration
                                if earliest_login:
                                    if '+' in earliest_login:
                                        login_dt = datetime.fromisoformat(earliest_login.replace('Z', '+00:00'))
                                    else:
                                        login_dt = datetime.fromisoformat(earliest_login)
                                    
                                    if login_dt.tzinfo:
                                        login_dt = login_dt.replace(tzinfo=None)
                                    
                                    duration = activity_dt - login_dt
                                    user['session_duration'] = self._format_duration(duration)
                                
                            except Exception as e:
                                logger.error(f"Error calculating time for {username}: {e}")
                                user['status'] = 'offline'
                    
                except Exception as e:
                    logger.error(f"Error checking sessions for {username}: {e}")
                    continue
            
            return users
            
        except Exception as e:
            logger.error(f"Error checking session activity: {e}")
            return users
    
    def _format_duration(self, duration) -> str:
        """Format duration to readable string"""
        try:
            total_seconds = int(duration.total_seconds())
            if total_seconds < 60:
                return f"{total_seconds}s"
            
            total_minutes = total_seconds // 60
            if total_minutes < 60:
                return f"{total_minutes}m"
            else:
                hours = total_minutes // 60
                minutes = total_minutes % 60
                return f"{hours}h {minutes}m"
        except:
            return "0m"

# Initialize API
simple_admin_api = SimpleAdminAPI()

async def verify_admin(credentials: HTTPAuthorizationCredentials = Depends(security)):
    """Verify admin token"""
    token = credentials.credentials
    payload = simple_admin_api.verify_admin_token(token)
    return payload

@app.get("/")
async def root():
    """Root endpoint"""
    return {
        "message": "Simple Admin API - Correct Online Status",
        "version": "1.0.0",
        "status": "operational",
        "timestamp": datetime.utcnow().isoformat()
    }

@app.post("/api/v1/auth/login", response_model=AdminLoginResponse)
async def admin_login(login_request: AdminLoginRequest):
    """Admin login endpoint"""
    username = login_request.username
    password = login_request.password
    
    if username not in ADMIN_USERS or ADMIN_USERS[username] != password:
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail="Invalid credentials"
        )
    
    access_token = simple_admin_api.create_admin_token(username)
    
    logger.info(f"✅ Admin login: {username}")
    
    return AdminLoginResponse(
        access_token=access_token,
        token_type="Bearer",
        expires_in=28800,
        user_info={
            "username": username,
            "role": "admin",
            "email": f"{username}@redington.local"
        }
    )

@app.get("/api/v1/admin/verify")
async def verify_admin_token(admin_user: Dict = Depends(verify_admin)):
    """Verify admin token"""
    return {
        "valid": True,
        "user": admin_user,
        "timestamp": datetime.utcnow().isoformat()
    }

@app.get("/api/v1/admin/active-users")
async def get_active_users(admin_user: Dict = Depends(verify_admin)):
    """Get users with correct online status"""
    users = await simple_admin_api.get_cognito_users()
    
    logger.info(f"Admin {admin_user['username']} requested users")
    
    return users

if __name__ == "__main__":
    import uvicorn
    uvicorn.run(app, host="0.0.0.0", port=8003)
