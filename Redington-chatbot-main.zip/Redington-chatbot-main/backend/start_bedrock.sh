#!/bin/bash

# Bedrock Integration Backend Startup Script
echo "🚀 Starting Redington AI Bot - Bedrock Integration Backend..."

# Check if virtual environment exists
if [ ! -d "venv" ]; then
    echo "📦 Creating virtual environment..."
    python3 -m venv venv
fi

# Activate virtual environment
echo "🔧 Activating virtual environment..."
source venv/bin/activate

# Install/upgrade dependencies
echo "📚 Installing dependencies..."
pip install -r requirements.txt

# Kill any existing backend process
echo "🔄 Stopping existing backend processes..."
pkill -f "bedrock_main" || true
pkill -f "enhanced_streaming_main" || true
pkill -f "uvicorn.*8000" || true

# Wait a moment for processes to stop
sleep 2

# Start the Bedrock integration backend
echo "✨ Starting Bedrock Integration Backend on port 8000..."
echo "🤖 Features: Real AWS Bedrock Claude Integration"
echo "📊 Capabilities: Deep Proposals, Technical Analysis, Business Recommendations"
echo "🔗 Backend URL: http://localhost:8000"
echo "📖 API Docs: http://localhost:8000/docs"
echo ""

# Check AWS credentials
if aws sts get-caller-identity > /dev/null 2>&1; then
    echo "✅ AWS credentials configured - Bedrock integration enabled"
else
    echo "⚠️  AWS credentials not found - Running in fallback mode with enhanced templates"
    echo "💡 To enable Bedrock: Configure AWS credentials with 'aws configure'"
fi

echo ""

# Run with detailed logging
python -m uvicorn bedrock_main:app \
    --host 0.0.0.0 \
    --port 8000 \
    --reload \
    --log-level info \
    --access-log \
    2>&1 | tee bedrock_backend.log
