#!/usr/bin/env python3
"""
Session Hooks - Integration points for real-time session tracking
"""

import sys
import os
sys.path.append(os.path.dirname(os.path.abspath(__file__)))

from realtime_session_tracker import session_tracker
import logging

logger = logging.getLogger(__name__)

def on_user_login(username: str, session_id: str = None):
    """Called when user logs in"""
    try:
        session_tracker.user_login(username, session_id)
        logger.info(f"🔐 Session tracking: {username} logged in")
    except Exception as e:
        logger.error(f"❌ Error tracking login for {username}: {e}")

def on_user_logout(username: str):
    """Called when user logs out"""
    try:
        session_tracker.user_logout(username)
        logger.info(f"🚪 Session tracking: {username} logged out")
    except Exception as e:
        logger.error(f"❌ Error tracking logout for {username}: {e}")

def on_user_activity(username: str):
    """Called when user sends a message or performs activity"""
    try:
        session_tracker.user_heartbeat(username)
        logger.debug(f"💓 Session tracking: {username} activity heartbeat")
    except Exception as e:
        logger.error(f"❌ Error tracking activity for {username}: {e}")

def get_realtime_active_users():
    """Get list of currently active users"""
    try:
        return session_tracker.get_active_users()
    except Exception as e:
        logger.error(f"❌ Error getting active users: {e}")
        return []
