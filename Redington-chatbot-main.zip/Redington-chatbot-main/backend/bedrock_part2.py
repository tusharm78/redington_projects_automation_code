Assistant: I understand you want to provide detailed, actionable proposals and recommendations.
