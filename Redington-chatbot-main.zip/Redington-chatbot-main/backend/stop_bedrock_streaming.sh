#!/bin/bash

# Stop Bedrock Streaming Backend
echo "🛑 Stopping Redington AI Bot - Bedrock Streaming Backend"
echo "=================================================="

if [ -f "bedrock_streaming.pid" ]; then
    PID=$(cat bedrock_streaming.pid)
    if ps -p $PID > /dev/null 2>&1; then
        echo "🔄 Stopping backend (PID: $PID)..."
        kill $PID
        
        # Wait for graceful shutdown
        for i in {1..10}; do
            if ! ps -p $PID > /dev/null 2>&1; then
                echo "✅ Backend stopped successfully"
                rm -f bedrock_streaming.pid
                exit 0
            fi
            sleep 1
        done
        
        # Force kill if still running
        echo "⚠️  Forcing shutdown..."
        kill -9 $PID 2>/dev/null
        rm -f bedrock_streaming.pid
        echo "✅ Backend force stopped"
    else
        echo "⚠️  Backend not running (stale PID file)"
        rm -f bedrock_streaming.pid
    fi
else
    echo "⚠️  No PID file found - backend may not be running"
    
    # Try to kill any running instances
    pkill -f "bedrock_streaming_main" 2>/dev/null && echo "🧹 Cleaned up any running instances"
fi
