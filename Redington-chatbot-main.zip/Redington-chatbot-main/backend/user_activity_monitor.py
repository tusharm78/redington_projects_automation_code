import boto3
import json
import uuid
import os
from datetime import datetime, timezone, timedelta
from typing import Dict, List, Optional, Any
from dotenv import load_dotenv
import asyncio
import logging

# Load environment variables
load_dotenv()

logger = logging.getLogger(__name__)

class UserActivityMonitor:
    """Monitor and track user login sessions and activity"""
    
    def __init__(self):
        self.dynamodb = boto3.resource("dynamodb", region_name="us-east-1")
        self.table_name = "user_active_sessions"
        
        # Memory fallback for active sessions
        self.active_sessions = {}
        
        try:
            self.table = self.dynamodb.Table(self.table_name)
            # Test table access
            self.table.load()
            logger.info(f"✅ Connected to DynamoDB table: {self.table_name}")
        except Exception as e:
            logger.warning(f"⚠️ DynamoDB table not accessible: {e}")
            logger.info("🔄 Running in memory-only mode")
            self.table = None
    
    def _get_timestamp(self) -> str:
        """Get current timestamp in ISO format"""
        return datetime.now(timezone.utc).isoformat()
    
    async def user_login(self, username: str, user_info: Dict[str, Any], session_token: str) -> str:
        """Record user login and create active session"""
        session_id = str(uuid.uuid4())
        timestamp = self._get_timestamp()
        
        session_data = {
            "session_id": session_id,
            "username": username,
            "email": user_info.get("email", ""),
            "login_time": timestamp,
            "last_activity": timestamp,
            "session_token": session_token,
            "status": "active",
            "ip_address": user_info.get("ip_address", ""),
            "user_agent": user_info.get("user_agent", ""),
            "chat_sessions": 0,
            "messages_sent": 0
        }
        
        if self.table:
            try:
                # Save to DynamoDB with TTL (24 hours)
                ttl = int((datetime.now(timezone.utc) + timedelta(hours=24)).timestamp())
                
                self.table.put_item(
                    Item={
                        "username": username,
                        "session_id": session_id,
                        "session_data": json.dumps(session_data),
                        "login_time": timestamp,
                        "last_activity": timestamp,
                        "status": "active",
                        "ttl": ttl
                    }
                )
                logger.info(f"✅ User login recorded in DynamoDB: {username}")
            except Exception as e:
                logger.error(f"DynamoDB error recording login: {e}")
                self._save_session_memory(username, session_id, session_data)
        else:
            self._save_session_memory(username, session_id, session_data)
        
        return session_id
    
    def _save_session_memory(self, username: str, session_id: str, session_data: Dict[str, Any]):
        """Save session to memory storage"""
        self.active_sessions[username] = session_data
    
    async def track_activity(self, username: str, activity_type: str = "chat_message"):
        """Track user activity - alias for update_user_activity"""
        await self.update_user_activity(username, activity_type)
    
    async def update_user_activity(self, username: str, activity_type: str = "general"):
        """Update user's last activity timestamp"""
        timestamp = self._get_timestamp()
        
        if self.table:
            try:
                # Update last activity in DynamoDB
                response = self.table.update_item(
                    Key={"username": username},
                    UpdateExpression="SET last_activity = :timestamp, #status = :status",
                    ExpressionAttributeNames={"#status": "status"},
                    ExpressionAttributeValues={
                        ":timestamp": timestamp,
                        ":status": "active"
                    },
                    ReturnValues="UPDATED_NEW"
                )
                
                # Update activity counters based on type
                if activity_type == "chat_message":
                    self.table.update_item(
                        Key={"username": username},
                        UpdateExpression="ADD messages_sent :inc",
                        ExpressionAttributeValues={":inc": 1}
                    )
                elif activity_type == "new_chat":
                    self.table.update_item(
                        Key={"username": username},
                        UpdateExpression="ADD chat_sessions :inc",
                        ExpressionAttributeValues={":inc": 1}
                    )
                
            except Exception as e:
                logger.error(f"Error updating user activity: {e}")
                # Update memory fallback
                if username in self.active_sessions:
                    self.active_sessions[username]["last_activity"] = timestamp
        else:
            # Update memory fallback
            if username in self.active_sessions:
                self.active_sessions[username]["last_activity"] = timestamp
                if activity_type == "chat_message":
                    self.active_sessions[username]["messages_sent"] += 1
                elif activity_type == "new_chat":
                    self.active_sessions[username]["chat_sessions"] += 1
    
    async def user_logout(self, username: str):
        """Record user logout"""
        timestamp = self._get_timestamp()
        
        if self.table:
            try:
                self.table.update_item(
                    Key={"username": username},
                    UpdateExpression="SET #status = :status, logout_time = :timestamp",
                    ExpressionAttributeNames={"#status": "status"},
                    ExpressionAttributeValues={
                        ":status": "logged_out",
                        ":timestamp": timestamp
                    }
                )
                logger.info(f"✅ User logout recorded: {username}")
            except Exception as e:
                logger.error(f"Error recording logout: {e}")
        
        # Remove from memory
        if username in self.active_sessions:
            del self.active_sessions[username]
    
    async def get_active_users(self) -> List[Dict[str, Any]]:
        """Get list of currently active users"""
        active_users = []
        cutoff_time = datetime.now(timezone.utc) - timedelta(minutes=30)  # Consider inactive after 30 minutes
        
        if self.table:
            try:
                # Scan for active sessions
                response = self.table.scan(
                    FilterExpression="attribute_exists(#status) AND #status = :status",
                    ExpressionAttributeNames={"#status": "status"},
                    ExpressionAttributeValues={":status": "active"}
                )
                
                for item in response.get('Items', []):
                    try:
                        session_data = json.loads(item.get('session_data', '{}'))
                        last_activity = datetime.fromisoformat(session_data.get('last_activity', ''))
                        
                        # Check if user is still active (within last 30 minutes)
                        if last_activity > cutoff_time:
                            user_info = {
                                "username": session_data.get("username"),
                                "email": session_data.get("email"),
                                "login_time": session_data.get("login_time"),
                                "last_activity": session_data.get("last_activity"),
                                "session_duration": self._calculate_duration(session_data.get("login_time")),
                                "chat_sessions": session_data.get("chat_sessions", 0),
                                "messages_sent": session_data.get("messages_sent", 0),
                                "status": "active"
                            }
                            active_users.append(user_info)
                        else:
                            # Mark as inactive
                            await self._mark_user_inactive(item.get('username'))
                    
                    except Exception as e:
                        logger.error(f"Error processing user session: {e}")
                        continue
                        
            except Exception as e:
                logger.error(f"Error getting active users from DynamoDB: {e}")
                # Fall back to memory
                return self._get_active_users_memory(cutoff_time)
        else:
            return self._get_active_users_memory(cutoff_time)
        
        return sorted(active_users, key=lambda x: x.get("last_activity", ""), reverse=True)
    
    def _get_active_users_memory(self, cutoff_time: datetime) -> List[Dict[str, Any]]:
        """Get active users from memory storage"""
        active_users = []
        
        for username, session_data in self.active_sessions.items():
            try:
                last_activity = datetime.fromisoformat(session_data.get('last_activity', ''))
                
                if last_activity > cutoff_time:
                    user_info = {
                        "username": session_data.get("username"),
                        "email": session_data.get("email"),
                        "login_time": session_data.get("login_time"),
                        "last_activity": session_data.get("last_activity"),
                        "session_duration": self._calculate_duration(session_data.get("login_time")),
                        "chat_sessions": session_data.get("chat_sessions", 0),
                        "messages_sent": session_data.get("messages_sent", 0),
                        "status": "active"
                    }
                    active_users.append(user_info)
            except Exception as e:
                logger.error(f"Error processing memory session: {e}")
                continue
        
        return active_users
    
    async def _mark_user_inactive(self, username: str):
        """Mark user as inactive due to timeout"""
        if self.table:
            try:
                self.table.update_item(
                    Key={"username": username},
                    UpdateExpression="SET #status = :status",
                    ExpressionAttributeNames={"#status": "status"},
                    ExpressionAttributeValues={":status": "inactive"}
                )
            except Exception as e:
                logger.error(f"Error marking user inactive: {e}")
    
    def _calculate_duration(self, login_time: str) -> str:
        """Calculate session duration"""
        try:
            login_dt = datetime.fromisoformat(login_time)
            now = datetime.now(timezone.utc)
            duration = now - login_dt
            
            hours = int(duration.total_seconds() // 3600)
            minutes = int((duration.total_seconds() % 3600) // 60)
            
            if hours > 0:
                return f"{hours}h {minutes}m"
            else:
                return f"{minutes}m"
        except Exception:
            return "Unknown"
    
    async def get_user_session_details(self, username: str) -> Optional[Dict[str, Any]]:
        """Get detailed session information for a specific user"""
        if self.table:
            try:
                response = self.table.get_item(Key={"username": username})
                if 'Item' in response:
                    session_data = json.loads(response['Item'].get('session_data', '{}'))
                    return session_data
            except Exception as e:
                logger.error(f"Error getting user session details: {e}")
        
        # Check memory fallback
        return self.active_sessions.get(username)
    
    async def cleanup_inactive_sessions(self):
        """Clean up sessions that have been inactive for more than 24 hours"""
        cutoff_time = datetime.now(timezone.utc) - timedelta(hours=24)
        
        if self.table:
            try:
                # Scan for old sessions
                response = self.table.scan()
                
                for item in response.get('Items', []):
                    try:
                        session_data = json.loads(item.get('session_data', '{}'))
                        last_activity = datetime.fromisoformat(session_data.get('last_activity', ''))
                        
                        if last_activity < cutoff_time:
                            # Delete old session
                            self.table.delete_item(Key={"username": item.get('username')})
                            logger.info(f"Cleaned up inactive session for: {item.get('username')}")
                    
                    except Exception as e:
                        logger.error(f"Error cleaning up session: {e}")
                        continue
                        
            except Exception as e:
                logger.error(f"Error during cleanup: {e}")
        
        # Clean memory storage
        to_remove = []
        for username, session_data in self.active_sessions.items():
            try:
                last_activity = datetime.fromisoformat(session_data.get('last_activity', ''))
                if last_activity < cutoff_time:
                    to_remove.append(username)
            except Exception:
                to_remove.append(username)
        
        for username in to_remove:
            del self.active_sessions[username]
