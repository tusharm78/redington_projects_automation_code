import asyncio
import time
from fastapi import FastAPI, HTTPException, Depends, status
from fastapi.middleware.cors import CORSMiddleware
from fastapi.security import HTTPBearer, HTTPAuthorizationCredentials
from pydantic import BaseModel
import socketio
import logging
import jwt
from datetime import datetime, timedelta

# Setup logging
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

# Create FastAPI application
app = FastAPI(
    title="Redington AI Bot - Complete Streaming",
    description="Complete streaming implementation with authentication",
    version="1.0.0"
)

# Create Socket.IO server
sio = socketio.AsyncServer(
    async_mode='asgi',
    cors_allowed_origins="*",
    logger=False,
    engineio_logger=False
)

# Combine FastAPI and Socket.IO
socket_app = socketio.ASGIApp(sio, app)

# Add CORS middleware
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# Security
security = HTTPBearer()
SECRET_KEY = "demo-secret-key-for-streaming"

# Pydantic models
class AuthRequest(BaseModel):
    username: str
    password: str

class AuthResponse(BaseModel):
    access_token: str
    token_type: str
    expires_in: int

class UserInfo(BaseModel):
    username: str
    email: str = ""

# In-memory storage
active_sessions = {}
demo_users = {
    "demo": "demo123",
    "admin": "admin123",
    "user": "password"
}

def create_access_token(username: str):
    """Create a JWT token for demo purposes"""
    expire = datetime.utcnow() + timedelta(hours=24)
    payload = {
        "username": username,
        "exp": expire,
        "iat": datetime.utcnow()
    }
    return jwt.encode(payload, SECRET_KEY, algorithm="HS256")

def verify_token(token: str):
    """Verify JWT token"""
    try:
        payload = jwt.decode(token, SECRET_KEY, algorithms=["HS256"])
        return payload
    except jwt.ExpiredSignatureError:
        raise HTTPException(status_code=401, detail="Token expired")
    except jwt.JWTError:
        raise HTTPException(status_code=401, detail="Invalid token")

async def get_current_user(credentials: HTTPAuthorizationCredentials = Depends(security)):
    """Get current user from token"""
    payload = verify_token(credentials.credentials)
    return payload.get("username")

# API Endpoints
@app.get("/")
async def root():
    return {"message": "Redington AI Bot - Complete Streaming", "version": "1.0.0"}

@app.get("/health")
async def health_check():
    return {"status": "healthy", "service": "redington-streaming-complete"}

@app.post("/api/v1/auth/login", response_model=AuthResponse)
async def login(auth_request: AuthRequest):
    """Login endpoint"""
    username = auth_request.username
    password = auth_request.password
    
    # Check demo credentials
    if username in demo_users and demo_users[username] == password:
        token = create_access_token(username)
        return AuthResponse(
            access_token=token,
            token_type="bearer",
            expires_in=86400  # 24 hours
        )
    
    raise HTTPException(
        status_code=status.HTTP_401_UNAUTHORIZED,
        detail="Invalid credentials"
    )

@app.post("/api/v1/auth/logout")
async def logout(current_user: str = Depends(get_current_user)):
    """Logout endpoint"""
    return {"message": "Successfully logged out"}

@app.get("/api/v1/auth/me", response_model=UserInfo)
async def get_user_info(current_user: str = Depends(get_current_user)):
    """Get current user info"""
    return UserInfo(
        username=current_user,
        email=f"{current_user}@redington-demo.com"
    )

@app.get("/api/v1/sessions")
async def get_sessions(current_user: str = Depends(get_current_user)):
    """Get user sessions"""
    return {
        "sessions": [
            {
                "id": "demo-session-1",
                "name": "Streaming Chat Session",
                "created_at": datetime.now().isoformat(),
                "updated_at": datetime.now().isoformat()
            }
        ]
    }

@app.post("/api/v1/sessions")
async def create_session(current_user: str = Depends(get_current_user)):
    """Create new session"""
    session_id = f"session-{int(time.time())}"
    return {
        "id": session_id,
        "name": "New Chat Session",
        "created_at": datetime.now().isoformat(),
        "updated_at": datetime.now().isoformat()
    }

# Socket.IO event handlers
@sio.event
async def connect(sid, environ):
    """Handle client connection"""
    logger.info(f"Client connected: {sid}")
    active_sessions[sid] = {
        'connected_at': time.time(),
        'authenticated': False,
        'user': None
    }

@sio.event
async def disconnect(sid):
    """Handle client disconnection"""
    logger.info(f"Client disconnected: {sid}")
    if sid in active_sessions:
        del active_sessions[sid]

@sio.event
async def authenticate(sid, data):
    """Handle authentication via Socket.IO"""
    try:
        token = data.get('token')
        if not token:
            await sio.emit('auth-error', {'error': 'No token provided'}, room=sid)
            return
        
        # Verify token
        payload = verify_token(token)
        username = payload.get('username')
        
        if sid in active_sessions:
            active_sessions[sid]['authenticated'] = True
            active_sessions[sid]['user'] = username
        
        await sio.emit('auth-success', {'user': username}, room=sid)
        logger.info(f"User {username} authenticated for session {sid}")
        
    except Exception as e:
        logger.error(f"Authentication error: {e}")
        await sio.emit('auth-error', {'error': 'Authentication failed'}, room=sid)

@sio.event
async def send_message(sid, data):
    """Handle chat message with streaming response"""
    try:
        session = active_sessions.get(sid)
        if not session or not session.get('authenticated'):
            await sio.emit('chat-error', {'error': 'Not authenticated'}, room=sid)
            return
        
        message = data.get('message', '')
        if not message.strip():
            await sio.emit('chat-error', {'error': 'Empty message'}, room=sid)
            return
        
        logger.info(f"Processing message from {session['user']}: {message[:100]}...")
        
        # Start streaming response
        await stream_ai_response(sid, message, session['user'])
        
    except Exception as e:
        logger.error(f"Error processing message: {e}")
        await sio.emit('chat-error', {'error': f'Failed to process message: {str(e)}'}, room=sid)

async def stream_ai_response(sid: str, user_message: str, username: str):
    """Stream AI response word by word"""
    try:
        # Generate contextual response
        if "redington" in user_message.lower():
            response = """Redington is a leading technology distributor and solutions provider in the Asia-Pacific region. We specialize in distributing cutting-edge technology products and providing comprehensive IT solutions to businesses across various industries. Our expertise spans cloud computing, cybersecurity, data analytics, digital transformation consulting, and enterprise software solutions. We partner with top technology vendors to deliver innovative solutions that help businesses grow and succeed in the digital age."""
        elif "service" in user_message.lower():
            response = """Our comprehensive services include Cloud Computing Solutions for scalable and flexible infrastructure, Advanced Cybersecurity Services to protect your digital assets, Data Analytics and Business Intelligence for data-driven decision making, Digital Transformation Consulting to modernize your business operations, Enterprise Software Solutions for enhanced productivity, 24/7 Technical Support and Maintenance for seamless operations, and Professional Training and Certification programs for skill development and technology adoption."""
        elif "hello" in user_message.lower() or "hi" in user_message.lower():
            response = f"""Hello {username}! Welcome to Redington AI Assistant. I'm here to help you with information about our technology solutions, services, and capabilities. You can ask me about our cloud services, cybersecurity solutions, digital transformation offerings, or any other technology-related questions. How can I assist you today?"""
        else:
            response = f"""Thank you for your message, {username}. As Redington's AI Assistant, I can provide information about our comprehensive technology solutions including cloud computing, cybersecurity, data analytics, digital transformation services, and enterprise software solutions. We're committed to helping businesses leverage technology for growth and success. What specific area would you like to know more about?"""
        
        # Send response metadata
        response_data = {
            'conversation_id': 'demo-conversation',
            'session_id': 'demo-session', 
            'message_id': f'msg-{int(time.time())}',
            'timestamp': datetime.now().isoformat(),
            'model_used': 'Redington-AI-Streaming'
        }
        
        await sio.emit('chat-start', response_data, room=sid)
        
        # Stream word by word (same as proposal generator)
        words = response.split(' ')
        chunk_size = 3  # 3 words per chunk
        delay = 0.05  # 50ms delay
        
        current_index = 0
        
        while current_index < len(words):
            chunk_words = words[current_index:current_index + chunk_size]
            chunk = ' '.join(chunk_words) + (' ' if current_index + chunk_size < len(words) else '')
            
            await sio.emit('chat-chunk', {
                **response_data,
                'chunk': chunk,
                'is_complete': False
            }, room=sid)
            
            current_index += chunk_size
            await asyncio.sleep(delay)
        
        # Send completion
        await sio.emit('chat-chunk', {
            **response_data,
            'chunk': '',
            'is_complete': True,
            'full_response': response
        }, room=sid)
        
        logger.info(f"Completed streaming response for {username}")
        
    except Exception as e:
        logger.error(f"Error in streaming response: {e}")
        await sio.emit('chat-error', {
            'error': f'Streaming failed: {str(e)}'
        }, room=sid)

if __name__ == "__main__":
    import uvicorn
    uvicorn.run(
        "complete_streaming_main:socket_app",
        host="0.0.0.0",
        port=8000,
        reload=False,
        log_level="info"
    )
