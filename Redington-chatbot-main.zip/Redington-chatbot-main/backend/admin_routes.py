from fastapi import APIRouter, Depends, HTTPException, status
from fastapi.security import HTTPAuthorizationCredentials, HTTPBearer
from pydantic import BaseModel
from typing import List, Dict, Any, Optional
import logging
from datetime import datetime, timezone
import json

from cognito_auth import CognitoAuth
from user_activity_monitor import UserActivityMonitor

logger = logging.getLogger(__name__)

# Initialize components
security = HTTPBearer()
cognito_auth = CognitoAuth()
activity_monitor = UserActivityMonitor()

# Create router
router = APIRouter(prefix="/api/v1/admin", tags=["admin"])

# Pydantic models
class ActiveUserResponse(BaseModel):
    username: str
    email: str
    login_time: str
    last_activity: str
    session_duration: str
    chat_sessions: int
    messages_sent: int
    status: str

class UserActivityStats(BaseModel):
    total_active_users: int
    total_sessions_today: int
    average_session_duration: str
    most_active_user: Optional[str]
    active_users: List[ActiveUserResponse]

class AdminStatsResponse(BaseModel):
    timestamp: str
    stats: UserActivityStats

# Admin user list - Updated with specified users
ADMIN_USERS = [
    "admin",
    "administrator", 
    "redington_admin",
    "tanmay",
    "meenal", 
    "varunesh"
]

async def verify_admin_token(credentials: HTTPAuthorizationCredentials = Depends(security)):
    """Verify JWT token and check if user is admin"""
    try:
        token = credentials.credentials
        payload = cognito_auth.verify_token(token)
        username = payload.get("username")
        
        if not username:
            raise HTTPException(
                status_code=status.HTTP_401_UNAUTHORIZED,
                detail="Invalid token: no username found"
            )
        
        # Check if user is admin
        if username not in ADMIN_USERS:
            raise HTTPException(
                status_code=status.HTTP_403_FORBIDDEN,
                detail="Access denied: Admin privileges required"
            )
        
        return {"username": username, "payload": payload}
    
    except Exception as e:
        logger.error(f"Admin token verification failed: {e}")
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail="Invalid or expired token"
        )

@router.get("/active-users", response_model=List[ActiveUserResponse])
async def get_active_users(admin_user: dict = Depends(verify_admin_token)):
    """Get list of currently active users (Admin only)"""
    try:
        logger.info(f"Admin {admin_user['username']} requested active users list")
        
        active_users = await activity_monitor.get_active_users()
        
        return [
            ActiveUserResponse(
                username=user["username"],
                email=user["email"],
                login_time=user["login_time"],
                last_activity=user["last_activity"],
                session_duration=user["session_duration"],
                chat_sessions=user["chat_sessions"],
                messages_sent=user["messages_sent"],
                status=user["status"]
            )
            for user in active_users
        ]
    
    except Exception as e:
        logger.error(f"Error getting active users: {e}")
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail="Failed to retrieve active users"
        )

@router.get("/user-details/{username}")
async def get_user_session_details(
    username: str, 
    admin_user: dict = Depends(verify_admin_token)
):
    """Get detailed session information for a specific user (Admin only)"""
    try:
        logger.info(f"Admin {admin_user['username']} requested details for user: {username}")
        
        user_details = await activity_monitor.get_user_session_details(username)
        
        if not user_details:
            raise HTTPException(
                status_code=status.HTTP_404_NOT_FOUND,
                detail=f"No active session found for user: {username}"
            )
        
        return user_details
    
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Error getting user details: {e}")
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail="Failed to retrieve user details"
        )

@router.get("/stats", response_model=AdminStatsResponse)
async def get_admin_stats(admin_user: dict = Depends(verify_admin_token)):
    """Get comprehensive admin statistics (Admin only)"""
    try:
        logger.info(f"Admin {admin_user['username']} requested admin statistics")
        
        active_users = await activity_monitor.get_active_users()
        
        # Calculate statistics
        total_active = len(active_users)
        total_sessions = sum(user.get("chat_sessions", 0) for user in active_users)
        total_messages = sum(user.get("messages_sent", 0) for user in active_users)
        
        # Find most active user
        most_active_user = None
        if active_users:
            most_active_user = max(
                active_users, 
                key=lambda x: x.get("messages_sent", 0)
            ).get("username")
        
        # Calculate average session duration (simplified)
        avg_duration = "N/A"
        if active_users:
            durations = []
            for user in active_users:
                try:
                    login_time = datetime.fromisoformat(user.get("login_time", ""))
                    now = datetime.now(timezone.utc)
                    duration_minutes = int((now - login_time).total_seconds() / 60)
                    durations.append(duration_minutes)
                except Exception:
                    continue
            
            if durations:
                avg_minutes = sum(durations) / len(durations)
                hours = int(avg_minutes // 60)
                minutes = int(avg_minutes % 60)
                avg_duration = f"{hours}h {minutes}m" if hours > 0 else f"{minutes}m"
        
        stats = UserActivityStats(
            total_active_users=total_active,
            total_sessions_today=total_sessions,
            average_session_duration=avg_duration,
            most_active_user=most_active_user,
            active_users=[
                ActiveUserResponse(
                    username=user["username"],
                    email=user["email"],
                    login_time=user["login_time"],
                    last_activity=user["last_activity"],
                    session_duration=user["session_duration"],
                    chat_sessions=user["chat_sessions"],
                    messages_sent=user["messages_sent"],
                    status=user["status"]
                )
                for user in active_users
            ]
        )
        
        return AdminStatsResponse(
            timestamp=datetime.now(timezone.utc).isoformat(),
            stats=stats
        )
    
    except Exception as e:
        logger.error(f"Error getting admin stats: {e}")
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail="Failed to retrieve admin statistics"
        )

@router.post("/force-logout/{username}")
async def force_user_logout(
    username: str,
    admin_user: dict = Depends(verify_admin_token)
):
    """Force logout a specific user (Admin only)"""
    try:
        logger.info(f"Admin {admin_user['username']} forcing logout for user: {username}")
        
        # Check if user exists and is active
        user_details = await activity_monitor.get_user_session_details(username)
        if not user_details:
            raise HTTPException(
                status_code=status.HTTP_404_NOT_FOUND,
                detail=f"No active session found for user: {username}"
            )
        
        # Force logout
        await activity_monitor.user_logout(username)
        
        logger.info(f"User {username} was forcefully logged out by admin {admin_user['username']}")
        
        return {
            "message": f"User {username} has been logged out successfully",
            "timestamp": datetime.now(timezone.utc).isoformat()
        }
    
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Error forcing user logout: {e}")
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail="Failed to logout user"
        )

@router.post("/cleanup-sessions")
async def cleanup_inactive_sessions(admin_user: dict = Depends(verify_admin_token)):
    """Clean up inactive sessions (Admin only)"""
    try:
        logger.info(f"Admin {admin_user['username']} requested session cleanup")
        
        await activity_monitor.cleanup_inactive_sessions()
        
        return {
            "message": "Inactive sessions cleaned up successfully",
            "timestamp": datetime.now(timezone.utc).isoformat()
        }
    
    except Exception as e:
        logger.error(f"Error cleaning up sessions: {e}")
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail="Failed to cleanup sessions"
        )

@router.get("/system-health")
async def get_system_health(admin_user: dict = Depends(verify_admin_token)):
    """Get system health information (Admin only)"""
    try:
        logger.info(f"Admin {admin_user['username']} requested system health")
        
        active_users = await activity_monitor.get_active_users()
        
        # Basic health metrics
        health_info = {
            "status": "healthy",
            "timestamp": datetime.now(timezone.utc).isoformat(),
            "active_users_count": len(active_users),
            "database_status": "connected" if activity_monitor.table else "memory_only",
            "services": {
                "cognito_auth": "operational",
                "session_manager": "operational",
                "activity_monitor": "operational"
            },
            "admin_users": ADMIN_USERS
        }
        
        return health_info
    
    except Exception as e:
        logger.error(f"Error getting system health: {e}")
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail="Failed to retrieve system health"
        )
