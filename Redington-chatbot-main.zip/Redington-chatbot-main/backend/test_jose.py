try:
    from jose import jwt
    print("Jose module imported successfully!")
except ImportError as e:
    print(f"Import error: {e}")
