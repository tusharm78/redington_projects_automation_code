#!/usr/bin/env python3
"""
Test script for customer name extraction functionality
"""

import re
from typing import Optional

def _extract_customer_name(user_message: str) -> Optional[str]:
    """Extract customer name from user message using various patterns"""
    # Improved patterns to better capture company names
    patterns = [
        # "for [Company Name]" - captures multi-word company names
        r'for\s+([A-Za-z][A-Za-z0-9\s&.-]{1,30}?)(?:\s+(?:company|corp|corporation|inc|incorporated|ltd|limited|llc|pvt|private|technologies|tech|systems|solutions|services|group|international|global))?(?:\s|$|[.,!?])',
        # "customer name is [Company Name]"
        r'customer\s+(?:name\s+is\s+|is\s+)([A-Za-z][A-Za-z0-9\s&.-]{1,30}?)(?:\s+(?:company|corp|corporation|inc|incorporated|ltd|limited|llc|pvt|private|technologies|tech|systems|solutions|services|group|international|global))?(?:\s|$|[.,!?])',
        # "client is [Company Name]"
        r'client\s+(?:name\s+is\s+|is\s+)([A-Za-z][A-Za-z0-9\s&.-]{1,30}?)(?:\s+(?:company|corp|corporation|inc|incorporated|ltd|limited|llc|pvt|private|technologies|tech|systems|solutions|services|group|international|global))?(?:\s|$|[.,!?])',
        # "proposal for [Company Name]"
        r'proposal\s+for\s+([A-Za-z][A-Za-z0-9\s&.-]{1,30}?)(?:\s+(?:company|corp|corporation|inc|incorporated|ltd|limited|llc|pvt|private|technologies|tech|systems|solutions|services|group|international|global))?(?:\s|$|[.,!?])',
        # "company name is [Company Name]"
        r'(?:company|organization|firm)\s+(?:name\s+is\s+|is\s+|called\s+)([A-Za-z][A-Za-z0-9\s&.-]{1,30}?)(?:\s|$|[.,!?])',
        # More specific patterns for common phrasings
        r'for\s+(?:the\s+)?company\s+([A-Za-z][A-Za-z0-9\s&.-]{1,30}?)(?:\s|$|[.,!?])',
        r'for\s+customer\s+([A-Za-z][A-Za-z0-9\s&.-]{1,30}?)(?:\s+(?:company|corp|corporation|inc|incorporated|ltd|limited|llc|pvt|private))?(?:\s|$|[.,!?])',
    ]
    
    for pattern in patterns:
        match = re.search(pattern, user_message, re.IGNORECASE)
        if match:
            customer_name = match.group(1).strip()
            # Clean up the customer name
            customer_name = re.sub(r'\s+', ' ', customer_name)  # Remove extra spaces
            customer_name = customer_name.title()  # Proper case
            
            # Filter out common words that aren't company names
            excluded_words = {
                'the', 'and', 'or', 'but', 'with', 'from', 'this', 'that', 'they', 'them',
                'customer', 'client', 'company', 'name', 'called', 'any', 'some', 'all',
                'without', 'proposal', 'create', 'generate', 'need', 'want', 'make'
            }
            
            # Validate it's not too short and not an excluded word
            if (len(customer_name) >= 2 and 
                customer_name.lower() not in excluded_words and
                not customer_name.lower().startswith(('a ', 'an ', 'the '))):
                return customer_name
    
    return None

# Test cases
test_messages = [
    "Create a proposal for Microsoft",
    "Generate proposal for company Acme Corp",
    "I need a proposal for TechSolutions Inc",
    "Customer name is Global Systems Ltd",
    "Client is Amazon Web Services",
    "Proposal for Redington Technologies",
    "Company name is IBM Corporation",
    "Create proposal for customer Tesla Motors",
    "Generate a cloud migration proposal for Netflix",
    "I need AWS infrastructure proposal for Spotify",
    "Create a proposal without any customer name",
    "For the company called Meta Platforms",
    "Customer is Apple Inc.",
    "Proposal for ABC Company",
    "For customer XYZ Solutions",
    "Company name is Tech Innovators LLC",
    "Client name is Digital Dynamics",
    "Create proposal for Quantum Computing Corp",
]

print("🧪 Testing Customer Name Extraction (Improved)")
print("=" * 60)

for i, message in enumerate(test_messages, 1):
    extracted_name = _extract_customer_name(message)
    status = "✅" if extracted_name else "❌"
    print(f"{i:2d}. {status} '{message}'")
    if extracted_name:
        print(f"    → Extracted: '{extracted_name}'")
    print()

print("Test completed!")
