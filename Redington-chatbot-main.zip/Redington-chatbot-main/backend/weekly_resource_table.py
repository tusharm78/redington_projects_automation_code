#!/usr/bin/env python3
"""
Weekly Resource Allocation Table for Proposals
Calculation: Sum of all weekly values × 8 hours × 5 days × hourly rate
"""
from typing import Dict, List, Any
from proposal_costing_service import RESOURCE_RATES

class WeeklyResourceTable:
    """Generate weekly resource allocation table for proposals"""
    
    def __init__(self):
        self.resource_rates = RESOURCE_RATES
    
    def generate_weekly_table(self, costing_data: Dict[str, Any]) -> str:
        """Generate weekly resource allocation table in the exact requested format"""
        
        # Calculate project duration (max 26 weeks for readability)
        total_weeks = min(int(costing_data['estimated_weeks']), 26)
        
        # Create weekly allocation matrix
        weekly_allocation = self._create_weekly_allocation(costing_data, total_weeks)
        
        table_content = ""
        
        # Create header
        header = "| Resources |"
        for week in range(1, total_weeks + 1):
            header += f" Week {week} |"
        header += " Man Hours |"
        
        table_content += header + "\n"
        
        # Create separator
        separator = "|-----------|"
        for week in range(1, total_weeks + 1):
            separator += "--------|"
        separator += "----------|"
        table_content += separator + "\n"
        
        # Add resource rows
        total_project_cost = 0
        
        for resource_type in sorted(weekly_allocation.keys()):
            if weekly_allocation[resource_type]['sum'] > 0:
                allocation_data = weekly_allocation[resource_type]
                
                row = f"| {resource_type} |"
                for week in range(1, total_weeks + 1):
                    value = allocation_data['weekly_values'].get(week, 0)
                    if value > 0:
                        row += f" {value} |"
                    else:
                        row += " - |"
                
                cost = allocation_data['cost']
                total_project_cost += cost
                row += f" {cost:,.0f} |"
                table_content += row + "\n"
        
        # Add total row
        table_content += separator + "\n"
        total_row = "| **TOTAL** |"
        for week in range(1, total_weeks + 1):
            week_total = sum(
                allocation['weekly_values'].get(week, 0) 
                for allocation in weekly_allocation.values()
                if allocation['sum'] > 0
            )
            if week_total > 0:
                total_row += f" **{week_total:.1f}** |"
            else:
                total_row += " **-** |"
        
        total_row += f" **{total_project_cost:,.0f}** |"
        table_content += total_row + "\n"
        
        return table_content
    
    def _create_weekly_allocation(self, costing_data: Dict[str, Any], total_weeks: int) -> Dict[str, Dict]:
        """Create weekly allocation matrix from costing data"""
        
        weekly_allocation = {}
        
        # Initialize all resources
        for resource_type in self.resource_rates.keys():
            weekly_allocation[resource_type] = {
                'weekly_values': {},
                'sum': 0,
                'cost': 0
            }
        
        # Process phases and tasks to create weekly allocation
        current_week = 1
        
        for phase in costing_data['phases']:
            phase_start_week = current_week
            
            for task in phase.tasks:
                task_duration_weeks = int(task.duration_weeks)
                
                # Distribute task across weeks
                for week_offset in range(task_duration_weeks):
                    week_num = phase_start_week + week_offset
                    if week_num <= total_weeks:
                        
                        for resource_type, fte_allocation in task.resources.items():
                            if resource_type in weekly_allocation:
                                # Convert FTE to allocation value
                                # FTE 1.0 = full week = value 1.0
                                # FTE 0.2 = 1 day = value 0.2
                                allocation_value = fte_allocation
                                
                                # Add to weekly allocation
                                current_value = weekly_allocation[resource_type]['weekly_values'].get(week_num, 0)
                                weekly_allocation[resource_type]['weekly_values'][week_num] = current_value + allocation_value
                
                # Move to next task (allow some overlap)
                phase_start_week += max(1, int(task_duration_weeks * 0.8))
        
        # Calculate sum and cost for each resource
        for resource_type in weekly_allocation:
            # Sum all weekly values
            sum_value = sum(weekly_allocation[resource_type]['weekly_values'].values())
            weekly_allocation[resource_type]['sum'] = sum_value
            
            # Calculate cost: Sum × 8 hours × 5 days × Rate
            rate = self.resource_rates.get(resource_type, 16)
            cost = sum_value * 8 * 5 * rate
            weekly_allocation[resource_type]['cost'] = cost
        
        # Remove resources with no allocation
        weekly_allocation = {
            resource: data for resource, data in weekly_allocation.items() 
            if data['sum'] > 0
        }
        
        return weekly_allocation

# Global instance
weekly_resource_table = WeeklyResourceTable()
