import asyncio
import sys
from enhanced_bedrock_main import bedrock_integration

async def test_streaming():
    bedrock = bedrock_integration()
    
    print('Testing streaming response...')
    
    async for chunk in bedrock.generate_streaming_response(
        'create a simple test proposal', 
        'demo', 
        'test-streaming-session',
        'us.anthropic.claude-3-7-sonnet-20250219-v1:0'
    ):
        if 'is_complete' in chunk and 'true' in chunk:
            print('✅ Streaming completed')
            break
    
    print('✅ Test completed')

if __name__ == '__main__':
    asyncio.run(test_streaming())
