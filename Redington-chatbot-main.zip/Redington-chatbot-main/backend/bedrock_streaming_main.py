import asyncio
import time
import re
import json
import boto3
from fastapi import FastAPI, HTTPException, Depends, status
from fastapi.middleware.cors import CORSMiddleware
from fastapi.security import HTTPBearer, HTTPAuthorizationCredentials
from fastapi.responses import StreamingResponse
from pydantic import BaseModel
import logging
import jwt
from jwt.exceptions import ExpiredSignatureError, InvalidTokenError
from datetime import datetime, timedelta
from typing import AsyncGenerator, Dict, List, Optional

# Setup logging
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

# Create FastAPI application
app = FastAPI(
    title="Redington AI Bot - Bedrock Streaming",
    description="Real AWS Bedrock Claude integration with enhanced streaming",
    version="3.0.0"
)

# Add CORS middleware
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# Security
security = HTTPBearer()
SECRET_KEY = "demo-secret-key-for-bedrock-streaming"

# Pydantic models
class AuthRequest(BaseModel):
    username: str
    password: str

class AuthResponse(BaseModel):
    access_token: str
    token_type: str
    expires_in: int

class UserInfo(BaseModel):
    username: str
    email: str = ""

class ChatRequest(BaseModel):
    message: str
    conversation_id: str = "default"
    session_id: str = "default"
    model: str = "claude-3-7-sonnet"

class StreamChunk(BaseModel):
    chunk: str
    is_complete: bool = False
    metadata: Optional[Dict] = None

# Demo users
demo_users = {
    "demo": "demo123",
    "admin": "admin123",
    "user": "password"
}

def create_access_token(username: str):
    """Create a JWT token for demo purposes"""
    expire = datetime.utcnow() + timedelta(hours=24)
    payload = {
        "username": username,
        "exp": expire,
        "iat": datetime.utcnow()
    }
    return jwt.encode(payload, SECRET_KEY, algorithm="HS256")

def verify_token(token: str):
    """Verify JWT token"""
    try:
        payload = jwt.decode(token, SECRET_KEY, algorithms=["HS256"])
        return payload
    except ExpiredSignatureError:
        raise HTTPException(status_code=401, detail="Token expired")
    except InvalidTokenError:
        raise HTTPException(status_code=401, detail="Invalid token")

async def get_current_user(credentials: HTTPAuthorizationCredentials = Depends(security)):
    """Get current user from token"""
    payload = verify_token(credentials.credentials)
    return payload.get("username")

class BedrockStreamingIntegration:
    """AWS Bedrock Claude integration with enhanced streaming"""
    
    def __init__(self):
        self.bedrock_client = None
        self.model_id = "us.anthropic.claude-3-7-sonnet-20250219-v1:0"
        self.system_prompt = """You are an expert Presales Proposal Generator for **Redington**. Your objective is to create detailed and compelling proposals for prospective clients and new business use cases. You will follow a well-defined structure, centering on the client's specific requirements and the proposed solution.

---
**Proposal Guidelines:**

**Customer Placeholders:**

* Wherever names such as Customer Name, Services Head, Presales/Technical Head, Enterprise Sales, or Technical Contact are to be included, insert placeholders in angle brackets, such as:
  `<Customer Name>`, `<Services Head>`, etc.
* Do not insert any actual names or contact details. Leave these fields blank for manual input later.
* Proposal content should be presented in **tabular format** wherever applicable.

**PROPOSAL DETAILS SECTION:**
This section should include:

* Proposal Title
* Services Head (Placeholder)
* Presales/Technical Head (Placeholder)
* Enterprise Sales (Placeholder)
* Technical Contact (Placeholder)
* Proposal Creation Date
* Proposal Validity
* Proposal Type
* Commercial Currency (USD)

**TABLE OF CONTENTS:**

* Provide a structured list of all proposal sections.
* Maintain the following formatting:

  * Main Section Headings: **Bold, Uppercase, Numbered (e.g., 1. INTRODUCTION)**
  * Subheadings: **Bold and Capitalized (e.g., 1.1 Overview)**
  * Sub-subheadings: *Italicized with sentence case (e.g., 1.1.1 Key features)*
  * Follow a consistent heading hierarchy throughout.

**EXECUTIVE SUMMARY:**

* Introduction and gratitude
* Key benefits of the proposed solution
* Summary of the client's main requirements
* A call to schedule further discussion

**STATED REQUIREMENT:**

* A detailed paragraph outlining the client's problem and business challenge
* A list of key requirements shared by the customer (in bullet points)

**SUCCESS CRITERIA:**

* List measurable outcomes in bullet format that define success and demonstrate how the solution addresses key pain points

**PROPOSED SOLUTION:**

* Start by summarizing the client's initial issue and the goal they want to achieve
* Break down the solution into multiple subsections with relevant bullet points under each:

  * Account Access
  * Assessment
  * Compute Considerations
  * Security
  * Optimizing Resource Management
  * Enhancing Observability, Logging, and Monitoring
  * Storage
  * Backup

**PROPOSED ARCHITECTURE:**

* Include a high-level design of the architecture (e.g., DNS, CDN, Load Balancer, etc.)
* Add descriptive content that can later be translated into an actual diagram (e.g., in Draw.io)

**SCOPE OF WORK:**

* Provide a detailed list of all tasks, activities, and deliverables for the project
* Cover each phase with specific descriptions, expected outcomes, and assigned responsibilities
* Include granular technical details, such as:

  * Account creation
  * VPC setup
  * IAM configuration
  * Service configuration based on the use case
  * Parameter or setting-level configurations
* Clarify which configurations can be done directly and which require custom implementation (e.g., AWS Lambda@Edge), with examples if possible

**TESTING:**

* Indicate responsibilities (most of which are client-driven)

**RACI MATRIX:**

* Define roles and responsibilities between Redington and the client

**OUT OF SCOPE:**

* Clearly specify exclusions from the engagement

**GENERAL ASSUMPTIONS & DEPENDENCIES:**

* Outline assumptions and dependencies on the client side

**PROJECT TIMELINE:**

* Provide a phase-wise breakdown of the timeline

# **PROPOSED COMMERCIALS:** (COMMENTED OUT)

* Include either a placeholder for pricing or reference a separate commercial document

* Offer a high-level estimation and list of assumptions

**ESCALATION MATRIX:**

* Add a placeholder for escalation contacts

**CLIENT SATISFACTION:**

* Describe how client satisfaction will be ensured or measured


**Constraints & Guidelines:**

* **Company Branding**: You are representing **Redington**, so refer to it as the solution provider where needed
* Always focus on the value delivered to the client
* Use placeholders where details are unknown or client-specific
* Maintain a clear, professional tone
* Never include personal or confidential information.
* Everything will be without any html tag

---

Always generate comprehensive proposals following this exact structure and format."""
        
        self._initialize_bedrock()
    
    def _initialize_bedrock(self):
        """Initialize AWS Bedrock client"""
        try:
            self.bedrock_client = boto3.client(
                'bedrock-runtime',
                region_name='us-east-1'
            )
            logger.info("✅ AWS Bedrock client initialized successfully")
        except Exception as e:
            logger.warning(f"⚠️ AWS Bedrock not available: {e}")
            logger.info("🔄 Running in fallback mode")
            self.bedrock_client = None

    async def generate_streaming_response(
        self, 
        user_message: str, 
        username: str, 
        model: str = "claude-3-7-sonnet"
    ) -> AsyncGenerator[str, None]:
        """Generate streaming response using AWS Bedrock Claude with enhanced formatting"""
        
        try:
            if self.bedrock_client:
                # Use real Bedrock Claude
                async for chunk in self._stream_bedrock_response(user_message, username):
                    yield chunk
            else:
                # Fallback to enhanced static response
                async for chunk in self._stream_fallback_response(user_message, username):
                    yield chunk
                    
        except Exception as e:
            logger.error(f"Error in streaming response: {e}")
            error_chunk = {
                "chunk": f"\n\n❌ **Error**: Failed to generate response - {str(e)}\n",
                "is_complete": True,
                "metadata": {"error": True}
            }
            yield f"data: {json.dumps(error_chunk)}\n\n"

    async def _stream_bedrock_response(self, user_message: str, username: str) -> AsyncGenerator[str, None]:
        """Stream response from Bedrock Claude"""
        try:
            # Prepare the request body
            body = json.dumps({
                "anthropic_version": "bedrock-2023-05-31",
                "max_tokens": 4000,
                "system": self.system_prompt,
                "messages": [
                    {
                        "role": "user",
                        "content": f"User: {username}\nQuery: {user_message}\n\nPlease provide a comprehensive response with detailed information and actionable insights."
                    }
                ],
                "temperature": 0.7,
                "top_p": 0.9
            })
            
            # Make streaming request to Bedrock
            response = self.bedrock_client.invoke_model_with_response_stream(
                body=body,
                modelId=self.model_id,
                accept="application/json",
                contentType="application/json"
            )
            
            # Process streaming response
            accumulated_text = ""
            chunk_buffer = ""
            chunk_count = 0
            
            for event in response['body']:
                if 'chunk' in event:
                    chunk_data = json.loads(event['chunk']['bytes'].decode())
                    
                    if chunk_data['type'] == 'content_block_delta':
                        if 'delta' in chunk_data and 'text' in chunk_data['delta']:
                            new_text = chunk_data['delta']['text']
                            accumulated_text += new_text
                            chunk_buffer += new_text
                            
                            # Send chunks when we have enough content or hit natural breaks
                            if (len(chunk_buffer) >= 50 or 
                                any(marker in chunk_buffer for marker in ['\n\n', '. ', '? ', '! ', ':\n', '```\n'])):
                                
                                chunk_to_send = {
                                    "chunk": chunk_buffer,
                                    "is_complete": False,
                                    "metadata": {
                                        "chunk_index": chunk_count,
                                        "timestamp": datetime.now().isoformat(),
                                        "source": "bedrock_claude"
                                    }
                                }
                                
                                yield f"data: {json.dumps(chunk_to_send)}\n\n"
                                
                                # Add natural delay based on content type
                                if chunk_buffer.startswith('#'):  # Headers
                                    delay = 0.1
                                elif '```' in chunk_buffer:  # Code blocks
                                    delay = 0.15
                                elif chunk_buffer.startswith('-') or chunk_buffer.startswith('*'):  # Lists
                                    delay = 0.08
                                else:  # Regular text
                                    delay = 0.05 + (len(chunk_buffer) / 1000)
                                
                                await asyncio.sleep(delay)
                                
                                chunk_buffer = ""
                                chunk_count += 1
            
            # Send any remaining content
            if chunk_buffer:
                final_chunk = {
                    "chunk": chunk_buffer,
                    "is_complete": True,
                    "metadata": {
                        "chunk_index": chunk_count,
                        "total_chunks": chunk_count + 1,
                        "timestamp": datetime.now().isoformat(),
                        "source": "bedrock_claude",
                        "total_length": len(accumulated_text)
                    }
                }
                yield f"data: {json.dumps(final_chunk)}\n\n"
            else:
                # Send completion marker
                completion_chunk = {
                    "chunk": "",
                    "is_complete": True,
                    "metadata": {
                        "chunk_index": chunk_count,
                        "total_chunks": chunk_count,
                        "timestamp": datetime.now().isoformat(),
                        "source": "bedrock_claude",
                        "total_length": len(accumulated_text)
                    }
                }
                yield f"data: {json.dumps(completion_chunk)}\n\n"
                
        except Exception as e:
            logger.error(f"Bedrock streaming error: {e}")
            error_chunk = {
                "chunk": f"\n\n❌ **Bedrock Error**: {str(e)}\n\nFalling back to enhanced mode...\n\n",
                "is_complete": False,
                "metadata": {"error": True, "fallback": True}
            }
            yield f"data: {json.dumps(error_chunk)}\n\n"
            
            # Fallback to static response
            async for chunk in self._stream_fallback_response(user_message, username):
                yield chunk

    async def _stream_fallback_response(self, user_message: str, username: str) -> AsyncGenerator[str, None]:
        """Fallback streaming response with enhanced formatting"""
        
        fallback_response = f"""# Redington Technology Solutions - Comprehensive Proposal

## Executive Summary

Thank you **{username}** for your inquiry: *"{user_message}"*

Redington is committed to providing comprehensive technology solutions that drive business transformation and competitive advantage across the Asia-Pacific region.

## Detailed Requirements Analysis

### 🎯 **Understanding Your Business Needs**

Based on your query, we've identified the following key areas where Redington can provide significant value:

1. **Technology Assessment** - Comprehensive evaluation of current infrastructure and capabilities
2. **Solution Architecture** - Custom design tailored to your specific business requirements  
3. **Implementation Strategy** - Phased approach ensuring minimal business disruption
4. **Ongoing Support** - 24/7 monitoring, maintenance, and optimization services

### 💡 **Recommended Technology Solutions**

#### Cloud Computing & Infrastructure
- **Infrastructure as a Service (IaaS)**
  - Scalable virtual machines with auto-scaling capabilities
  - High-performance storage solutions with 99.99% uptime SLA
  - Advanced networking with global connectivity options
  - Comprehensive disaster recovery and backup solutions

- **Platform as a Service (PaaS)**
  - Application development and deployment platforms
  - Managed database services with automated backups
  - API management and integration services
  - DevOps automation and CI/CD pipelines

#### Advanced Cybersecurity Framework
```yaml
Security Architecture:
  Threat Detection:
    - Real-time monitoring and analysis
    - AI-powered threat intelligence
    - Behavioral analytics and anomaly detection
    - 24/7 Security Operations Center (SOC)
  
  Identity & Access Management:
    - Zero-trust security model
    - Multi-factor authentication (MFA)
    - Single sign-on (SSO) integration
    - Privileged access management (PAM)
```

### 📊 **Business Value Proposition**

| Solution Area | Expected Benefits | ROI Timeline | Cost Savings |
|---------------|-------------------|--------------|--------------|
| Cloud Migration | 25-40% infrastructure cost reduction | 12-18 months | $500K-2M annually |
| Cybersecurity | 95% reduction in security incidents | 6-12 months | $1M-5M risk mitigation |
| Data Analytics | 30-50% improvement in decision speed | 9-15 months | $2M-10M revenue impact |

### 🚀 **Implementation Roadmap**

#### Phase 1: Discovery & Assessment (Weeks 1-6)
- Current state analysis and infrastructure audit
- Requirements gathering and stakeholder alignment
- Solution design and architecture blueprint

#### Phase 2: Pilot Implementation (Weeks 7-14)
- Proof of concept development
- User training and change management
- Performance testing and optimization

#### Phase 3: Production Deployment (Weeks 15-26)
- Full-scale implementation
- Data migration and system integration
- Go-live support and monitoring

### 💰 **Investment Analysis**

**Initial Investment**: $200K - $1.2M
**Ongoing Operational Costs**: $50K - $300K monthly
**Expected ROI**: 250-400% over 3 years

> **Next Steps**: Contact our solutions team for a detailed consultation tailored to your specific requirements.

---

**Ready to transform your business?** Let's discuss how Redington can help you achieve your technology goals."""

        # Split response into chunks for streaming
        chunks = self._create_streaming_chunks(fallback_response)
        
        for i, chunk in enumerate(chunks):
            # Vary delay based on chunk type and length
            if chunk.startswith('#'):  # Headers
                delay = 0.1
            elif chunk.startswith('```'):  # Code blocks
                delay = 0.15
            elif chunk.startswith('-') or chunk.startswith('*'):  # Lists
                delay = 0.08
            else:  # Regular text
                delay = 0.05 + (len(chunk) / 1000)
            
            chunk_data = {
                "chunk": chunk,
                "is_complete": i == len(chunks) - 1,
                "metadata": {
                    "chunk_index": i,
                    "total_chunks": len(chunks),
                    "timestamp": datetime.now().isoformat(),
                    "source": "fallback_enhanced"
                }
            }
            
            yield f"data: {json.dumps(chunk_data)}\n\n"
            await asyncio.sleep(delay)

    def _create_streaming_chunks(self, text: str) -> List[str]:
        """Create properly formatted streaming chunks"""
        chunks = []
        
        # Split by double newlines first (paragraphs)
        paragraphs = text.split('\n\n')
        
        for paragraph in paragraphs:
            if len(paragraph) > 200:
                # Split long paragraphs by sentences
                sentences = re.split(r'(?<=[.!?])\s+', paragraph)
                current_chunk = ""
                
                for sentence in sentences:
                    if len(current_chunk + sentence) > 150:
                        if current_chunk:
                            chunks.append(current_chunk.strip() + "\n\n")
                        current_chunk = sentence + " "
                    else:
                        current_chunk += sentence + " "
                
                if current_chunk:
                    chunks.append(current_chunk.strip() + "\n\n")
            else:
                chunks.append(paragraph + "\n\n")
        
        return [chunk for chunk in chunks if chunk.strip()]

# Initialize Bedrock integration
bedrock_integration = BedrockStreamingIntegration()

# API Endpoints
@app.get("/")
async def root():
    return {"message": "Redington AI Bot - Bedrock Streaming", "version": "3.0.0"}

@app.get("/health")
async def health_check():
    bedrock_status = "connected" if bedrock_integration.bedrock_client else "fallback_mode"
    return {
        "status": "healthy", 
        "service": "redington-bedrock-streaming",
        "bedrock_status": bedrock_status,
        "model": bedrock_integration.model_id
    }

@app.post("/api/v1/auth/login", response_model=AuthResponse)
async def login(auth_request: AuthRequest):
    """Login endpoint"""
    username = auth_request.username
    password = auth_request.password
    
    if username in demo_users and demo_users[username] == password:
        token = create_access_token(username)
        return AuthResponse(
            access_token=token,
            token_type="bearer",
            expires_in=86400
        )
    
    raise HTTPException(
        status_code=status.HTTP_401_UNAUTHORIZED,
        detail="Invalid credentials"
    )

@app.post("/api/v1/auth/logout")
async def logout(current_user: str = Depends(get_current_user)):
    """Logout endpoint"""
    return {"message": "Successfully logged out"}

@app.get("/api/v1/auth/me", response_model=UserInfo)
async def get_user_info(current_user: str = Depends(get_current_user)):
    """Get current user info"""
    return UserInfo(
        username=current_user,
        email=f"{current_user}@redington-demo.com"
    )

@app.post("/api/v1/chat/stream")
async def stream_chat(
    request: ChatRequest,
    current_user: str = Depends(get_current_user)
):
    """Stream chat response with Bedrock Claude integration"""
    
    logger.info(f"Bedrock streaming request from {current_user}: {request.message[:100]}...")
    
    return StreamingResponse(
        bedrock_integration.generate_streaming_response(
            request.message, 
            current_user, 
            request.model
        ),
        media_type="text/plain",
        headers={
            "Cache-Control": "no-cache",
            "Connection": "keep-alive",
            "Access-Control-Allow-Origin": "*",
        }
    )

@app.get("/api/v1/chat/models")
async def get_available_models(current_user: str = Depends(get_current_user)):
    """Get available AI models"""
    return {
        "models": {
            "Claude 3.7 Sonnet": {
                "model_id": "us.anthropic.claude-3-7-sonnet-20250219-v1:0",
                "input_format": "multimodal",
                "thinking": 0,
                "temperature": 0.7,
                "top_p": 0.9,
                "top_k": 500,
                "max_tokens": 4000,
                "memory_window": 10,
                "max_top_k": 500,
                "status": "connected" if bedrock_integration.bedrock_client else "fallback"
            }
        },
        "default_model": "Claude 3.7 Sonnet",
        "bedrock_status": "connected" if bedrock_integration.bedrock_client else "fallback_mode"
    }

@app.get("/api/v1/sessions")
async def get_sessions(current_user: str = Depends(get_current_user)):
    """Get user sessions"""
    return {
        "sessions": [
            {
                "id": "bedrock-session-1",
                "name": "Bedrock Claude Chat",
                "created_at": datetime.now().isoformat(),
                "updated_at": datetime.now().isoformat()
            }
        ]
    }

@app.get("/api/v1/conversations")
async def get_conversations(current_user: str = Depends(get_current_user)):
    """Get user conversations"""
    return {
        "conversations": [
            {
                "conversation_id": "bedrock-conversation-1",
                "title": "Bedrock AI Consultation",
                "created_at": datetime.now().isoformat(),
                "updated_at": datetime.now().isoformat(),
                "message_count": 0
            }
        ]
    }

@app.get("/api/v1/chat/history/{conversation_id}")
async def get_conversation_history(
    conversation_id: str,
    current_user: str = Depends(get_current_user)
):
    """Get conversation history"""
    return {
        "messages": [],
        "conversation_id": conversation_id
    }

@app.post("/api/v1/sessions")
async def create_session(current_user: str = Depends(get_current_user)):
    """Create new session"""
    session_id = f"bedrock-session-{int(time.time())}"
    return {
        "id": session_id,
        "name": "New Bedrock Chat Session",
        "created_at": datetime.now().isoformat(),
        "updated_at": datetime.now().isoformat()
    }

if __name__ == "__main__":
    import uvicorn
    uvicorn.run(
        "bedrock_streaming_main:app",
        host="0.0.0.0",
        port=8000,
        reload=False,
        log_level="info"
    )
