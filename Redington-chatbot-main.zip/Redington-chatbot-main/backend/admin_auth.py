#!/usr/bin/env python3
"""
Admin Authentication System - Separate from Cognito
Built-in admin credentials only, no Cognito integration
"""

import hashlib
import jwt
import os
from datetime import datetime, timedelta
from typing import Dict, Optional
import logging

logger = logging.getLogger(__name__)

class AdminAuthSystem:
    def __init__(self):
        # Built-in admin credentials (separate from Cognito)
        self.admin_users = {
            "admin": {
                "password_hash": self._hash_password("admin@123%"),
                "email": "admin@redington.local",
                "role": "super_admin",
                "created": "2025-01-01T00:00:00Z"
            }
        }
        
        # JWT secret for admin tokens (different from main app)
        self.jwt_secret = os.getenv("ADMIN_JWT_SECRET", "admin-secret-key-change-in-production-2025")
        
        logger.info("✅ Admin authentication system initialized")
        logger.info(f"📊 {len(self.admin_users)} admin users configured")
    
    def _hash_password(self, password: str) -> str:
        """Hash password with salt"""
        salt = "redington_admin_salt_2025"
        return hashlib.sha256((password + salt).encode()).hexdigest()
    
    def authenticate_admin(self, username: str, password: str) -> Optional[Dict]:
        """Authenticate admin user with built-in credentials"""
        try:
            # Check if username exists
            if username not in self.admin_users:
                logger.warning(f"❌ Admin login attempt with invalid username: {username}")
                return None
            
            # Verify password
            password_hash = self._hash_password(password)
            stored_hash = self.admin_users[username]["password_hash"]
            
            if password_hash != stored_hash:
                logger.warning(f"❌ Admin login attempt with invalid password for: {username}")
                return None
            
            # Authentication successful
            admin_data = self.admin_users[username].copy()
            admin_data["username"] = username
            del admin_data["password_hash"]  # Don't return password hash
            
            logger.info(f"✅ Admin authentication successful: {username}")
            return admin_data
            
        except Exception as e:
            logger.error(f"❌ Error during admin authentication: {e}")
            return None
    
    def create_admin_token(self, admin_data: Dict) -> str:
        """Create JWT token for authenticated admin"""
        try:
            payload = {
                "username": admin_data["username"],
                "email": admin_data["email"],
                "role": admin_data["role"],
                "type": "admin_token",  # Distinguish from user tokens
                "iat": datetime.utcnow(),
                "exp": datetime.utcnow() + timedelta(hours=8)  # 8 hour expiry
            }
            
            token = jwt.encode(payload, self.jwt_secret, algorithm="HS256")
            logger.info(f"✅ Admin token created for: {admin_data['username']}")
            return token
            
        except Exception as e:
            logger.error(f"❌ Error creating admin token: {e}")
            raise
    
    def verify_admin_token(self, token: str) -> Optional[Dict]:
        """Verify admin JWT token"""
        try:
            payload = jwt.decode(token, self.jwt_secret, algorithms=["HS256"])
            
            # Verify token type
            if payload.get("type") != "admin_token":
                logger.warning("❌ Invalid token type for admin access")
                return None
            
            # Verify user still exists
            username = payload.get("username")
            if username not in self.admin_users:
                logger.warning(f"❌ Admin token for non-existent user: {username}")
                return None
            
            logger.debug(f"✅ Admin token verified for: {username}")
            return payload
            
        except jwt.ExpiredSignatureError:
            logger.warning("❌ Admin token expired")
            return None
        except jwt.InvalidTokenError as e:
            logger.warning(f"❌ Invalid admin token: {e}")
            return None
        except Exception as e:
            logger.error(f"❌ Error verifying admin token: {e}")
            return None
    
    def add_admin_user(self, username: str, password: str, email: str, role: str = "admin") -> bool:
        """Add new admin user (for future expansion)"""
        try:
            if username in self.admin_users:
                logger.warning(f"❌ Admin user already exists: {username}")
                return False
            
            self.admin_users[username] = {
                "password_hash": self._hash_password(password),
                "email": email,
                "role": role,
                "created": datetime.utcnow().isoformat()
            }
            
            logger.info(f"✅ Admin user added: {username}")
            return True
            
        except Exception as e:
            logger.error(f"❌ Error adding admin user: {e}")
            return False
    
    def change_admin_password(self, username: str, old_password: str, new_password: str) -> bool:
        """Change admin password"""
        try:
            # Verify current password
            if not self.authenticate_admin(username, old_password):
                logger.warning(f"❌ Password change failed - invalid current password for: {username}")
                return False
            
            # Update password
            self.admin_users[username]["password_hash"] = self._hash_password(new_password)
            logger.info(f"✅ Password changed for admin: {username}")
            return True
            
        except Exception as e:
            logger.error(f"❌ Error changing admin password: {e}")
            return False
    
    def get_admin_info(self, username: str) -> Optional[Dict]:
        """Get admin user information"""
        try:
            if username not in self.admin_users:
                return None
            
            admin_data = self.admin_users[username].copy()
            admin_data["username"] = username
            del admin_data["password_hash"]  # Don't return password hash
            
            return admin_data
            
        except Exception as e:
            logger.error(f"❌ Error getting admin info: {e}")
            return None

# Global admin auth instance
admin_auth = AdminAuthSystem()

if __name__ == "__main__":
    # Test the admin auth system
    print("🧪 Testing Admin Authentication System")
    print("=" * 50)
    
    # Test authentication
    result = admin_auth.authenticate_admin("admin", "admin@123%")
    if result:
        print("✅ Admin authentication successful")
        print(f"   Username: {result['username']}")
        print(f"   Email: {result['email']}")
        print(f"   Role: {result['role']}")
        
        # Test token creation
        token = admin_auth.create_admin_token(result)
        print(f"✅ Admin token created: {token[:50]}...")
        
        # Test token verification
        verified = admin_auth.verify_admin_token(token)
        if verified:
            print("✅ Admin token verification successful")
        else:
            print("❌ Admin token verification failed")
    else:
        print("❌ Admin authentication failed")
    
    # Test wrong password
    result = admin_auth.authenticate_admin("admin", "wrong_password")
    if result:
        print("❌ Wrong password test failed - should not authenticate")
    else:
        print("✅ Wrong password correctly rejected")
