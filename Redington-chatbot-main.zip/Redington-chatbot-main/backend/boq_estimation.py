#!/usr/bin/env python3
"""
BOQ (Bill of Quantities) Cost Estimation for AWS Services
Generates 3 options based on project requirements
"""
from typing import Dict, List, Any
import re

class BOQEstimation:
    """Generate BOQ cost estimation with 3 options for AWS services"""
    
    def __init__(self):
        # AWS Service pricing (monthly costs in USD)
        self.aws_pricing = {
            'ec2': {
                'basic': {'t3.micro': 8.5, 't3.small': 17, 't3.medium': 34},
                'standard': {'t3.large': 67, 't3.xlarge': 134, 'm5.large': 88},
                'premium': {'m5.xlarge': 176, 'm5.2xlarge': 352, 'c5.2xlarge': 310}
            },
            'rds': {
                'basic': {'db.t3.micro': 15, 'db.t3.small': 30},
                'standard': {'db.t3.medium': 61, 'db.t3.large': 122},
                'premium': {'db.m5.large': 180, 'db.m5.xlarge': 360}
            },
            's3': {
                'basic': 23,  # 1TB storage
                'standard': 115,  # 5TB storage
                'premium': 230   # 10TB storage
            },
            'vpc': {
                'basic': 45,  # Basic networking
                'standard': 90,  # Standard with NAT Gateway
                'premium': 180   # Premium with multiple AZs
            },
            'load_balancer': {
                'basic': 22,  # Application Load Balancer
                'standard': 44,  # ALB + Network Load Balancer
                'premium': 88   # Multiple load balancers
            },
            'cloudwatch': {
                'basic': 15,  # Basic monitoring
                'standard': 45,  # Enhanced monitoring
                'premium': 90   # Advanced monitoring + alerts
            },
            'backup': {
                'basic': 25,  # Basic backup
                'standard': 75,  # Standard backup + snapshots
                'premium': 150  # Premium backup + cross-region
            },
            'security': {
                'basic': 30,  # Basic security services
                'standard': 90,  # WAF + Shield
                'premium': 180  # Advanced security suite
            }
        }
    
    def analyze_project_requirements(self, proposal_text: str) -> Dict[str, int]:
        """Analyze project requirements to determine AWS service needs"""
        
        text_lower = proposal_text.lower()
        requirements = {
            'applications': 1,
            'databases': 1,
            'users': 100,
            'storage_gb': 1000,
            'environments': 2  # dev, prod
        }
        
        # Extract number of applications
        app_matches = re.findall(r'(\d+)\s*(?:applications?|apps?|systems?)', text_lower)
        if app_matches:
            requirements['applications'] = max(int(match) for match in app_matches)
        
        # Extract number of databases
        db_matches = re.findall(r'(\d+)\s*(?:databases?|dbs?)', text_lower)
        if db_matches:
            requirements['databases'] = max(int(match) for match in db_matches)
        
        # Extract number of users
        user_matches = re.findall(r'(\d+)\s*(?:users?|employees?|people)', text_lower)
        if user_matches:
            requirements['users'] = max(int(match) for match in user_matches)
        
        # Determine storage needs based on applications
        requirements['storage_gb'] = requirements['applications'] * 500  # 500GB per app
        
        # Determine environments
        if any(env in text_lower for env in ['production', 'staging', 'development', 'test']):
            requirements['environments'] = 3  # dev, staging, prod
        
        return requirements
    
    def generate_boq_options(self, proposal_text: str) -> str:
        """Generate BOQ cost estimation with 3 options"""
        
        requirements = self.analyze_project_requirements(proposal_text)
        
        boq_content = f"""
### **14.2 BOQ Cost Estimation**

**Project Requirements Analysis:**
- Applications to migrate: {requirements['applications']}
- Database instances: {requirements['databases']}
- Expected users: {requirements['users']}
- Storage requirements: {requirements['storage_gb']} GB
- Environments: {requirements['environments']} (Dev/Staging/Prod)

"""
        
        # Generate 3 options
        options = ['Basic', 'Standard', 'Premium']
        option_configs = ['basic', 'standard', 'premium']
        
        for i, (option_name, config) in enumerate(zip(options, option_configs)):
            monthly_cost = self._calculate_option_cost(requirements, config)
            yearly_cost = monthly_cost * 12
            
            boq_content += f"""
#### **Option {i+1}: {option_name} Configuration**

| AWS Service | Configuration | Monthly Cost (USD) |
|-------------|---------------|-------------------|"""
            
            # EC2 Instances
            ec2_instances = self._get_ec2_config(requirements, config)
            for instance, cost in ec2_instances.items():
                boq_content += f"\n| EC2 Compute | {instance} | ${cost:,.0f} |"
            
            # RDS Database
            rds_config = self._get_rds_config(requirements, config)
            for db, cost in rds_config.items():
                boq_content += f"\n| RDS Database | {db} | ${cost:,.0f} |"
            
            # Other services
            other_services = self._get_other_services_cost(requirements, config)
            for service, cost in other_services.items():
                service_name = service.replace('_', ' ').title()
                boq_content += f"\n| {service_name} | {config.title()} tier | ${cost:,.0f} |"
            
            boq_content += f"""
|-------------|---------------|-------------------|
| **TOTAL MONTHLY** | | **${monthly_cost:,.0f}** |
| **TOTAL YEARLY** | | **${yearly_cost:,.0f}** |

**{option_name} Configuration Includes:**
{self._get_configuration_details(config)}

"""
        
        # Add comparison table
        boq_content += self._generate_comparison_table(requirements)
        
        return boq_content
    
    def _calculate_option_cost(self, requirements: Dict[str, int], config: str) -> float:
        """Calculate total monthly cost for an option"""
        
        total_cost = 0
        
        # EC2 costs
        ec2_config = self._get_ec2_config(requirements, config)
        total_cost += sum(ec2_config.values())
        
        # RDS costs
        rds_config = self._get_rds_config(requirements, config)
        total_cost += sum(rds_config.values())
        
        # Other services
        other_services = self._get_other_services_cost(requirements, config)
        total_cost += sum(other_services.values())
        
        return total_cost
    
    def _get_ec2_config(self, requirements: Dict[str, int], config: str) -> Dict[str, float]:
        """Get EC2 configuration and costs"""
        
        instances = {}
        app_count = requirements['applications']
        env_count = requirements['environments']
        
        if config == 'basic':
            # Basic: t3.small for apps, t3.micro for utilities
            instances['t3.small (App Servers)'] = self.aws_pricing['ec2']['basic']['t3.small'] * app_count
            instances['t3.micro (Utilities)'] = self.aws_pricing['ec2']['basic']['t3.micro'] * env_count
        elif config == 'standard':
            # Standard: t3.large for apps, t3.medium for utilities
            instances['t3.large (App Servers)'] = self.aws_pricing['ec2']['standard']['t3.large'] * app_count
            instances['t3.medium (Utilities)'] = self.aws_pricing['ec2']['basic']['t3.medium'] * env_count
        else:  # premium
            # Premium: m5.xlarge for apps, m5.large for utilities
            instances['m5.xlarge (App Servers)'] = self.aws_pricing['ec2']['premium']['m5.xlarge'] * app_count
            instances['m5.large (Utilities)'] = self.aws_pricing['ec2']['standard']['m5.large'] * env_count
        
        return instances
    
    def _get_rds_config(self, requirements: Dict[str, int], config: str) -> Dict[str, float]:
        """Get RDS configuration and costs"""
        
        databases = {}
        db_count = requirements['databases']
        
        if config == 'basic':
            databases['db.t3.small (Primary)'] = self.aws_pricing['rds']['basic']['db.t3.small'] * db_count
        elif config == 'standard':
            databases['db.t3.medium (Primary)'] = self.aws_pricing['rds']['standard']['db.t3.medium'] * db_count
            databases['db.t3.small (Read Replica)'] = self.aws_pricing['rds']['basic']['db.t3.small']
        else:  # premium
            databases['db.m5.large (Primary)'] = self.aws_pricing['rds']['premium']['db.m5.large'] * db_count
            databases['db.m5.large (Read Replica)'] = self.aws_pricing['rds']['premium']['db.m5.large']
            databases['db.t3.medium (Dev/Test)'] = self.aws_pricing['rds']['standard']['db.t3.medium']
        
        return databases
    
    def _get_other_services_cost(self, requirements: Dict[str, int], config: str) -> Dict[str, float]:
        """Get other AWS services costs"""
        
        services = {}
        
        for service in ['s3', 'vpc', 'load_balancer', 'cloudwatch', 'backup', 'security']:
            services[service] = self.aws_pricing[service][config]
        
        return services
    
    def _get_configuration_details(self, config: str) -> str:
        """Get configuration details for each option"""
        
        if config == 'basic':
            return """- Basic EC2 instances (t3.small/micro)
- Single RDS database
- Standard S3 storage (1TB)
- Basic VPC setup
- Application Load Balancer
- Basic monitoring and backup
- Standard security configuration"""
        
        elif config == 'standard':
            return """- Standard EC2 instances (t3.large/medium)
- Primary + Read Replica databases
- Enhanced S3 storage (5TB)
- VPC with NAT Gateway
- Application + Network Load Balancers
- Enhanced monitoring and alerting
- WAF + AWS Shield protection"""
        
        else:  # premium
            return """- Premium EC2 instances (m5.xlarge/large)
- Multi-AZ databases with read replicas
- Premium S3 storage (10TB) with lifecycle
- Multi-AZ VPC with redundancy
- Multiple load balancers with SSL
- Advanced monitoring and automation
- Complete security suite with compliance"""
    
    def _generate_comparison_table(self, requirements: Dict[str, int]) -> str:
        """Generate comparison table for all options"""
        
        basic_cost = self._calculate_option_cost(requirements, 'basic')
        standard_cost = self._calculate_option_cost(requirements, 'standard')
        premium_cost = self._calculate_option_cost(requirements, 'premium')
        
        return f"""
#### **BOQ Options Comparison**

| Feature | Basic | Standard | Premium |
|---------|-------|----------|---------|
| **Monthly Cost** | **${basic_cost:,.0f}** | **${standard_cost:,.0f}** | **${premium_cost:,.0f}** |
| **Yearly Cost** | **${basic_cost*12:,.0f}** | **${standard_cost*12:,.0f}** | **${premium_cost*12:,.0f}** |
| EC2 Performance | Basic (t3.small) | Standard (t3.large) | Premium (m5.xlarge) |
| Database Setup | Single instance | Primary + Replica | Multi-AZ + Replicas |
| Storage | 1TB | 5TB | 10TB |
| High Availability | Basic | Standard | Premium |
| Security | Standard | Enhanced | Advanced |
| Monitoring | Basic | Enhanced | Advanced |

#### **Recommended Option**
- **For Small Projects (1-5 apps)**: Basic Configuration
- **For Medium Projects (5-20 apps)**: Standard Configuration  
- **For Large Projects (20+ apps)**: Premium Configuration

**Note**: All costs are estimated monthly charges in USD. Actual costs may vary based on usage patterns, data transfer, and additional services required.
"""

# Global instance
boq_estimation = BOQEstimation()
