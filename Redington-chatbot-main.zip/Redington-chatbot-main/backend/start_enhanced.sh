#!/bin/bash

# Enhanced Streaming Backend Startup Script
echo "🚀 Starting Redington AI Bot - Enhanced Streaming Backend..."

# Check if virtual environment exists
if [ ! -d "venv" ]; then
    echo "📦 Creating virtual environment..."
    python3 -m venv venv
fi

# Activate virtual environment
echo "🔧 Activating virtual environment..."
source venv/bin/activate

# Install/upgrade dependencies
echo "📚 Installing dependencies..."
pip install -r requirements.txt

# Kill any existing backend process
echo "🔄 Stopping existing backend processes..."
pkill -f "enhanced_streaming_main" || true
pkill -f "uvicorn.*8000" || true

# Wait a moment for processes to stop
sleep 2

# Start the enhanced streaming backend
echo "✨ Starting Enhanced Streaming Backend on port 8000..."
echo "📊 Features: Structured Markdown Streaming, Real-time Formatting"
echo "🔗 Backend URL: http://localhost:8000"
echo "📖 API Docs: http://localhost:8000/docs"
echo ""

# Run with detailed logging
python -m uvicorn enhanced_streaming_main:app \
    --host 0.0.0.0 \
    --port 8000 \
    --reload \
    --log-level info \
    --access-log \
    2>&1 | tee enhanced_backend.log
