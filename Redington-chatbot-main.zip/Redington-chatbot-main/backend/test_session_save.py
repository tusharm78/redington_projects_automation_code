#!/usr/bin/env python3
import asyncio
import sys
import os
from session_manager import SessionManager

async def test_message_saving():
    session_manager = SessionManager()
    username = 'test_user'
    session_id = 'test_session_123'
    
    print('🧪 Testing message saving...')
    
    try:
        print('1. Saving user message...')
        await session_manager.save_message(username, session_id, 'user', 'Test user message')
        print('✅ User message saved')
        
        print('2. Saving assistant message...')
        await session_manager.save_message(username, session_id, 'assistant', 'Test assistant response', 'claude-3-7-sonnet')
        print('✅ Assistant message saved')
        
        print('3. Retrieving messages...')
        messages = await session_manager.get_session_messages(session_id)
        print(f'📋 Retrieved {len(messages)} messages:')
        
        for i, msg in enumerate(messages):
            print(f'   {i+1}. Role: {msg["role"]} | Content: {msg["content"][:50]}...')
            
    except Exception as e:
        print(f'❌ Error during testing: {e}')
        import traceback
        traceback.print_exc()

if __name__ == '__main__':
    asyncio.run(test_message_saving())
