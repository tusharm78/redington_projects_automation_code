#!/usr/bin/env python3
"""
Real-time Admin API - Shows actual online/offline status with session tracking
"""

import asyncio
import json
import boto3
import os
from datetime import datetime, timedelta
from typing import Dict, List, Optional
from fastapi import FastAPI, HTTPException, Depends, status
from fastapi.middleware.cors import CORSMiddleware
from fastapi.security import HTTPBearer, HTTPAuthorizationCredentials
from pydantic import BaseModel
import jwt
from dotenv import load_dotenv
import logging

# Import our session tracking
from realtime_session_tracker import session_tracker
from session_hooks import get_realtime_active_users

# Load environment variables
load_dotenv()

# Setup logging
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

# Create FastAPI app
app = FastAPI(
    title="Real-time Admin API",
    description="Real-time user monitoring with session tracking",
    version="2.0.0"
)

# Add CORS middleware
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# Security
security = HTTPBearer()

# Pydantic models
class AdminLoginRequest(BaseModel):
    username: str
    password: str

class AdminLoginResponse(BaseModel):
    access_token: str
    token_type: str
    expires_in: int
    user_info: Dict

# Admin users
ADMIN_USERS = {
    "admin": "admin123",
    "tanmay": "tanmay123", 
    "meenal": "meenal123",
    "varunesh": "varunesh123"
}

# JWT Secret
SECRET_KEY = os.getenv("SECRET_KEY", "your-secret-key-change-in-production")

# Cognito Configuration
COGNITO_USER_POOL_ID = os.getenv("POOL_ID")
COGNITO_REGION = os.getenv("AWS_DEFAULT_REGION", "us-east-1")

class RealTimeAdminAPI:
    def __init__(self):
        self.cognito_client = None
        self.init_aws_clients()
    
    def init_aws_clients(self):
        """Initialize AWS clients"""
        try:
            self.cognito_client = boto3.client('cognito-idp', region_name=COGNITO_REGION)
            logger.info("✅ Connected to AWS Cognito")
        except Exception as e:
            logger.error(f"❌ Failed to connect to Cognito: {e}")
    
    def create_admin_token(self, username: str) -> str:
        """Create JWT token for admin"""
        payload = {
            "username": username,
            "role": "admin",
            "exp": datetime.utcnow() + timedelta(hours=8)
        }
        return jwt.encode(payload, SECRET_KEY, algorithm="HS256")
    
    def verify_admin_token(self, token: str) -> Dict:
        """Verify admin JWT token"""
        try:
            payload = jwt.decode(token, SECRET_KEY, algorithms=["HS256"])
            username = payload.get("username")
            
            if username not in ADMIN_USERS:
                raise HTTPException(
                    status_code=status.HTTP_403_FORBIDDEN,
                    detail="Access denied"
                )
            
            return payload
        except jwt.ExpiredSignatureError:
            raise HTTPException(
                status_code=status.HTTP_401_UNAUTHORIZED,
                detail="Token expired"
            )
        except jwt.InvalidTokenError:
            raise HTTPException(
                status_code=status.HTTP_401_UNAUTHORIZED,
                detail="Invalid token"
            )
    
    async def get_all_users_with_realtime_status(self) -> List[Dict]:
        """Get all Cognito users with real-time online status"""
        if not self.cognito_client or not COGNITO_USER_POOL_ID:
            return []
        
        try:
            # Get all Cognito users
            all_users = []
            paginator = self.cognito_client.get_paginator('list_users')
            
            for page in paginator.paginate(UserPoolId=COGNITO_USER_POOL_ID):
                for user in page.get('Users', []):
                    user_data = self._process_cognito_user(user)
                    if user_data:
                        all_users.append(user_data)
            
            # Get real-time active users
            active_users = get_realtime_active_users()
            active_usernames = {user['username'] for user in active_users}
            
            # Create lookup for active user data
            active_user_data = {user['username']: user for user in active_users}
            
            # Update status for all users
            for user in all_users:
                username = user['username']
                
                if username in active_usernames:
                    # User is currently online
                    active_data = active_user_data[username]
                    user['status'] = 'online'
                    user['login_time'] = active_data['login_time']
                    user['last_activity'] = active_data['last_activity']
                    user['session_duration'] = active_data['session_duration']
                    logger.debug(f"✅ {username} is ONLINE (real-time)")
                else:
                    # User is offline
                    user['status'] = 'offline'
                    logger.debug(f"⚪ {username} is OFFLINE (real-time)")
            
            # Sort by status (online first) then by username
            all_users.sort(key=lambda x: (x['status'] != 'online', x['username']))
            
            online_count = len([u for u in all_users if u['status'] == 'online'])
            logger.info(f"📊 Real-time status: {online_count} online, {len(all_users) - online_count} offline")
            
            return all_users
            
        except Exception as e:
            logger.error(f"❌ Error getting users with real-time status: {e}")
            return []
    
    def _process_cognito_user(self, cognito_user: Dict) -> Optional[Dict]:
        """Process a single Cognito user"""
        try:
            username = cognito_user.get('Username', '')
            user_status = cognito_user.get('UserStatus', 'UNKNOWN')
            enabled = cognito_user.get('Enabled', False)
            created_date = cognito_user.get('UserCreateDate')
            last_modified = cognito_user.get('UserLastModifiedDate')
            
            # Extract user attributes
            attributes = {}
            for attr in cognito_user.get('Attributes', []):
                attributes[attr['Name']] = attr['Value']
            
            return {
                'username': username,
                'email': attributes.get('email', f'{username}@redington.local'),
                'status': 'offline',  # Will be updated by real-time check
                'cognito_status': user_status,
                'enabled': enabled,
                'created_date': created_date.isoformat() if created_date else '',
                'last_modified': last_modified.isoformat() if last_modified else '',
                'login_time': '',  # Will be updated by real-time check
                'last_activity': '',  # Will be updated by real-time check
                'session_duration': '0m',
                'chat_sessions': 0,
                'messages_sent': 0,
                'phone_number': attributes.get('phone_number', ''),
                'email_verified': attributes.get('email_verified', 'false') == 'true'
            }
            
        except Exception as e:
            logger.error(f"Error processing user: {e}")
            return None

# Initialize API
realtime_admin_api = RealTimeAdminAPI()

async def verify_admin(credentials: HTTPAuthorizationCredentials = Depends(security)):
    """Verify admin token"""
    token = credentials.credentials
    payload = realtime_admin_api.verify_admin_token(token)
    return payload

@app.get("/")
async def root():
    """Root endpoint"""
    return {
        "message": "Real-time Admin API - True Session Tracking",
        "version": "2.0.0",
        "status": "operational",
        "features": ["real-time-sessions", "heartbeat-tracking", "instant-logout-detection"],
        "timestamp": datetime.utcnow().isoformat()
    }

@app.post("/api/v1/auth/login", response_model=AdminLoginResponse)
async def admin_login(login_request: AdminLoginRequest):
    """Admin login endpoint"""
    username = login_request.username
    password = login_request.password
    
    if username not in ADMIN_USERS or ADMIN_USERS[username] != password:
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail="Invalid credentials"
        )
    
    access_token = realtime_admin_api.create_admin_token(username)
    
    logger.info(f"✅ Admin login: {username}")
    
    return AdminLoginResponse(
        access_token=access_token,
        token_type="Bearer",
        expires_in=28800,
        user_info={
            "username": username,
            "role": "admin",
            "email": f"{username}@redington.local"
        }
    )

@app.get("/api/v1/admin/verify")
async def verify_admin_token(admin_user: Dict = Depends(verify_admin)):
    """Verify admin token"""
    return {
        "valid": True,
        "user": admin_user,
        "timestamp": datetime.utcnow().isoformat()
    }

@app.get("/api/v1/admin/active-users")
async def get_active_users(admin_user: Dict = Depends(verify_admin)):
    """Get all users with real-time online/offline status"""
    users = await realtime_admin_api.get_all_users_with_realtime_status()
    
    logger.info(f"Admin {admin_user['username']} requested real-time user status")
    
    return users

@app.post("/api/v1/admin/simulate-login/{username}")
async def simulate_user_login(username: str, admin_user: Dict = Depends(verify_admin)):
    """Simulate user login for testing"""
    try:
        session_tracker.user_login(username, f"admin-test-{username}")
        logger.info(f"Admin {admin_user['username']} simulated login for {username}")
        
        return {
            "success": True,
            "message": f"User {username} marked as online",
            "timestamp": datetime.utcnow().isoformat()
        }
    except Exception as e:
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail=f"Failed to simulate login: {str(e)}"
        )

@app.post("/api/v1/admin/simulate-logout/{username}")
async def simulate_user_logout(username: str, admin_user: Dict = Depends(verify_admin)):
    """Simulate user logout for testing"""
    try:
        session_tracker.user_logout(username)
        logger.info(f"Admin {admin_user['username']} simulated logout for {username}")
        
        return {
            "success": True,
            "message": f"User {username} marked as offline",
            "timestamp": datetime.utcnow().isoformat()
        }
    except Exception as e:
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail=f"Failed to simulate logout: {str(e)}"
        )

@app.get("/api/v1/admin/realtime-stats")
async def get_realtime_stats(admin_user: Dict = Depends(verify_admin)):
    """Get real-time statistics"""
    try:
        active_users = get_realtime_active_users()
        all_users = await realtime_admin_api.get_all_users_with_realtime_status()
        
        stats = {
            "total_users": len(all_users),
            "online_users": len(active_users),
            "offline_users": len(all_users) - len(active_users),
            "active_sessions": len(active_users),
            "last_updated": datetime.utcnow().isoformat()
        }
        
        return {"stats": stats}
        
    except Exception as e:
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail=f"Failed to get stats: {str(e)}"
        )

if __name__ == "__main__":
    import uvicorn
    uvicorn.run(app, host="0.0.0.0", port=8004)
