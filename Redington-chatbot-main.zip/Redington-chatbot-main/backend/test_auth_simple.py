#!/usr/bin/env python3
"""
Simple authentication test to isolate the issue
"""
import os
import sys
import asyncio
import boto3
from dotenv import load_dotenv

# Load environment variables
load_dotenv()

# Add current directory to path
sys.path.append(os.path.dirname(__file__))

async def test_simple_auth():
    """Test authentication with minimal setup"""
    
    username = "varunesh"
    password = "TempPass123!"
    
    print("=== Simple Authentication Test ===")
    print(f"Username: {username}")
    print(f"Password: {password}")
    print(f"Pool ID: {os.getenv('POOL_ID')}")
    print(f"Region: {os.getenv('AWS_DEFAULT_REGION')}")
    print()
    
    try:
        # Direct Cognito client test
        cognito_client = boto3.client('cognito-idp', region_name=os.getenv('AWS_DEFAULT_REGION'))
        
        # Calculate secret hash
        import hmac
        import hashlib
        import base64
        
        def calculate_secret_hash(username, client_id, client_secret):
            message = username + client_id
            dig = hmac.new(
                client_secret.encode('utf-8'),
                message.encode('utf-8'),
                hashlib.sha256
            ).digest()
            return base64.b64encode(dig).decode()
        
        client_id = os.getenv('APP_CLIENT_ID')
        client_secret = os.getenv('APP_CLIENT_SECRET')
        secret_hash = calculate_secret_hash(username, client_id, client_secret)
        
        print("🔐 Calling initiate_auth...")
        response = cognito_client.initiate_auth(
            ClientId=client_id,
            AuthFlow='USER_PASSWORD_AUTH',
            AuthParameters={
                'USERNAME': username,
                'PASSWORD': password,
                'SECRET_HASH': secret_hash
            }
        )
        
        print(f"✅ Response received!")
        print(f"Response keys: {list(response.keys())}")
        
        if 'ChallengeName' in response:
            challenge_name = response['ChallengeName']
            print(f"🔄 Challenge: {challenge_name}")
            
            if challenge_name == 'NEW_PASSWORD_REQUIRED':
                session = response.get('Session', '')
                print(f"✅ Password change required!")
                print(f"Session: {session[:50]}...")
                
                # This is the expected response for a new user
                return {
                    'status': 'password_change_required',
                    'challenge': challenge_name,
                    'session': session,
                    'username': username
                }
        
        elif 'AuthenticationResult' in response:
            print(f"✅ Authentication successful!")
            auth_result = response['AuthenticationResult']
            return {
                'status': 'success',
                'access_token': auth_result['AccessToken'][:50] + '...',
                'username': username
            }
        
        else:
            print(f"⚠️ Unexpected response format")
            print(f"Response: {response}")
            return {'status': 'unexpected', 'response': response}
            
    except Exception as e:
        print(f"❌ Error: {type(e).__name__}: {str(e)}")
        import traceback
        traceback.print_exc()
        return {'status': 'error', 'error': str(e)}

if __name__ == "__main__":
    result = asyncio.run(test_simple_auth())
    
    print("\n" + "=" * 50)
    print("RESULT:")
    print(f"Status: {result.get('status')}")
    
    if result.get('status') == 'password_change_required':
        print("✅ SUCCESS: Password change challenge detected correctly!")
        print("This is the expected behavior for new users.")
        print(f"Challenge: {result.get('challenge')}")
        print(f"Session available: {'Yes' if result.get('session') else 'No'}")
    elif result.get('status') == 'success':
        print("✅ SUCCESS: User authenticated successfully!")
        print("This user already has a permanent password.")
    else:
        print("❌ ISSUE: Unexpected result")
        print(f"Details: {result}")
