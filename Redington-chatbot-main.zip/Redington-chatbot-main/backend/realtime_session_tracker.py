#!/usr/bin/env python3
"""
Real-time Session Tracker - Tracks active user sessions with heartbeat mechanism
"""

import boto3
import json
import time
from datetime import datetime, timedelta
from typing import Dict, List, Set
import threading
import logging

logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

class RealTimeSessionTracker:
    def __init__(self):
        self.dynamodb = boto3.resource('dynamodb', region_name='us-east-1')
        self.active_sessions_table = None
        self.init_active_sessions_table()
        
        # In-memory tracking for immediate updates
        self.active_sessions: Dict[str, Dict] = {}
        self.session_lock = threading.Lock()
        
        # Start cleanup thread
        self.cleanup_thread = threading.Thread(target=self._cleanup_expired_sessions, daemon=True)
        self.cleanup_thread.start()
        
    def init_active_sessions_table(self):
        """Initialize or create active sessions table"""
        table_name = 'active_user_sessions'
        
        try:
            # Try to get existing table
            self.active_sessions_table = self.dynamodb.Table(table_name)
            self.active_sessions_table.load()
            logger.info(f"✅ Connected to existing table: {table_name}")
        except:
            # Create new table if it doesn't exist
            try:
                self.active_sessions_table = self.dynamodb.create_table(
                    TableName=table_name,
                    KeySchema=[
                        {
                            'AttributeName': 'username',
                            'KeyType': 'HASH'
                        }
                    ],
                    AttributeDefinitions=[
                        {
                            'AttributeName': 'username',
                            'AttributeType': 'S'
                        }
                    ],
                    BillingMode='PAY_PER_REQUEST'
                )
                
                # Wait for table to be created
                self.active_sessions_table.wait_until_exists()
                logger.info(f"✅ Created new table: {table_name}")
                
            except Exception as e:
                logger.error(f"❌ Failed to create table: {e}")
                self.active_sessions_table = None
    
    def user_login(self, username: str, session_id: str = None) -> bool:
        """Track user login - mark as active"""
        try:
            current_time = datetime.utcnow().isoformat()
            session_data = {
                'username': username,
                'session_id': session_id or f"session_{int(time.time())}",
                'login_time': current_time,
                'last_heartbeat': current_time,
                'status': 'online'
            }
            
            # Update in-memory tracking
            with self.session_lock:
                self.active_sessions[username] = session_data
            
            # Update DynamoDB
            if self.active_sessions_table:
                self.active_sessions_table.put_item(
                    Item={
                        'username': username,
                        'session_id': session_data['session_id'],
                        'login_time': current_time,
                        'last_heartbeat': current_time,
                        'status': 'online',
                        'ttl': int((datetime.utcnow() + timedelta(hours=2)).timestamp())
                    }
                )
            
            logger.info(f"✅ User {username} marked as ONLINE")
            return True
            
        except Exception as e:
            logger.error(f"❌ Error tracking login for {username}: {e}")
            return False
    
    def user_logout(self, username: str) -> bool:
        """Track user logout - mark as offline"""
        try:
            current_time = datetime.utcnow().isoformat()
            
            # Remove from in-memory tracking
            with self.session_lock:
                if username in self.active_sessions:
                    self.active_sessions[username]['status'] = 'offline'
                    self.active_sessions[username]['logout_time'] = current_time
                    # Remove from active sessions after marking offline
                    del self.active_sessions[username]
            
            # Update DynamoDB to mark as offline, then delete
            if self.active_sessions_table:
                try:
                    # First update status to offline
                    self.active_sessions_table.update_item(
                        Key={'username': username},
                        UpdateExpression='SET #status = :status, logout_time = :logout_time',
                        ExpressionAttributeNames={'#status': 'status'},
                        ExpressionAttributeValues={
                            ':status': 'offline',
                            ':logout_time': current_time
                        }
                    )
                    
                    # Then delete the record after a short delay
                    time.sleep(1)
                    self.active_sessions_table.delete_item(
                        Key={'username': username}
                    )
                except:
                    pass  # Item might not exist
            
            logger.info(f"✅ User {username} marked as OFFLINE")
            return True
            
        except Exception as e:
            logger.error(f"❌ Error tracking logout for {username}: {e}")
            return False
    
    def user_heartbeat(self, username: str) -> bool:
        """Update user heartbeat - keep session alive"""
        try:
            current_time = datetime.utcnow().isoformat()
            
            # Update in-memory tracking
            with self.session_lock:
                if username in self.active_sessions:
                    self.active_sessions[username]['last_heartbeat'] = current_time
                else:
                    # User not in memory, might be a new session
                    return self.user_login(username)
            
            # Update DynamoDB
            if self.active_sessions_table:
                self.active_sessions_table.update_item(
                    Key={'username': username},
                    UpdateExpression='SET last_heartbeat = :heartbeat, #status = :status',
                    ExpressionAttributeNames={'#status': 'status'},
                    ExpressionAttributeValues={
                        ':heartbeat': current_time,
                        ':status': 'online'
                    }
                )
            
            logger.debug(f"💓 Heartbeat updated for {username}")
            return True
            
        except Exception as e:
            logger.error(f"❌ Error updating heartbeat for {username}: {e}")
            return False
    
    def get_active_users(self) -> List[Dict]:
        """Get list of currently active users"""
        try:
            active_users = []
            current_time = datetime.utcnow()
            
            # Check in-memory sessions first (fastest)
            with self.session_lock:
                for username, session_data in self.active_sessions.items():
                    try:
                        last_heartbeat = datetime.fromisoformat(session_data['last_heartbeat'])
                        time_diff = (current_time - last_heartbeat).total_seconds()
                        
                        # Consider active if heartbeat within last 2 minutes
                        if time_diff < 120:  # 2 minutes
                            active_users.append({
                                'username': username,
                                'status': 'online',
                                'login_time': session_data['login_time'],
                                'last_activity': session_data['last_heartbeat'],
                                'session_duration': self._calculate_duration(
                                    session_data['login_time'], 
                                    session_data['last_heartbeat']
                                )
                            })
                    except Exception as e:
                        logger.error(f"Error processing session for {username}: {e}")
                        continue
            
            # Also check DynamoDB for any missed sessions
            if self.active_sessions_table:
                try:
                    response = self.active_sessions_table.scan()
                    for item in response.get('Items', []):
                        username = item['username']
                        
                        # Skip if already in memory results
                        if any(u['username'] == username for u in active_users):
                            continue
                        
                        try:
                            last_heartbeat = datetime.fromisoformat(item['last_heartbeat'])
                            time_diff = (current_time - last_heartbeat).total_seconds()
                            
                            if time_diff < 120:  # 2 minutes
                                active_users.append({
                                    'username': username,
                                    'status': 'online',
                                    'login_time': item['login_time'],
                                    'last_activity': item['last_heartbeat'],
                                    'session_duration': self._calculate_duration(
                                        item['login_time'], 
                                        item['last_heartbeat']
                                    )
                                })
                        except Exception as e:
                            logger.error(f"Error processing DDB item for {username}: {e}")
                            continue
                            
                except Exception as e:
                    logger.error(f"Error scanning DynamoDB: {e}")
            
            logger.info(f"📊 Found {len(active_users)} active users")
            return active_users
            
        except Exception as e:
            logger.error(f"❌ Error getting active users: {e}")
            return []
    
    def _calculate_duration(self, start_time: str, end_time: str) -> str:
        """Calculate session duration"""
        try:
            start_dt = datetime.fromisoformat(start_time)
            end_dt = datetime.fromisoformat(end_time)
            duration = end_dt - start_dt
            
            total_seconds = int(duration.total_seconds())
            if total_seconds < 60:
                return f"{total_seconds}s"
            
            total_minutes = total_seconds // 60
            if total_minutes < 60:
                return f"{total_minutes}m"
            else:
                hours = total_minutes // 60
                minutes = total_minutes % 60
                return f"{hours}h {minutes}m"
        except:
            return "0m"
    
    def _cleanup_expired_sessions(self):
        """Background thread to cleanup expired sessions"""
        while True:
            try:
                current_time = datetime.utcnow()
                expired_users = []
                
                # Check in-memory sessions
                with self.session_lock:
                    for username, session_data in list(self.active_sessions.items()):
                        try:
                            last_heartbeat = datetime.fromisoformat(session_data['last_heartbeat'])
                            time_diff = (current_time - last_heartbeat).total_seconds()
                            
                            # Mark as expired if no heartbeat for 5 minutes
                            if time_diff > 300:  # 5 minutes
                                expired_users.append(username)
                                del self.active_sessions[username]
                        except:
                            expired_users.append(username)
                            if username in self.active_sessions:
                                del self.active_sessions[username]
                
                # Cleanup expired users from DynamoDB
                if self.active_sessions_table and expired_users:
                    for username in expired_users:
                        try:
                            self.active_sessions_table.delete_item(
                                Key={'username': username}
                            )
                            logger.info(f"🧹 Cleaned up expired session for {username}")
                        except:
                            pass
                
                # Sleep for 30 seconds before next cleanup
                time.sleep(30)
                
            except Exception as e:
                logger.error(f"❌ Error in cleanup thread: {e}")
                time.sleep(60)  # Wait longer on error

# Global instance
session_tracker = RealTimeSessionTracker()

if __name__ == "__main__":
    # Test the session tracker
    print("🧪 Testing Real-time Session Tracker")
    
    # Simulate user login
    session_tracker.user_login("test_user")
    
    # Check active users
    active = session_tracker.get_active_users()
    print(f"Active users: {len(active)}")
    
    # Simulate logout
    time.sleep(2)
    session_tracker.user_logout("test_user")
    
    # Check again
    active = session_tracker.get_active_users()
    print(f"Active users after logout: {len(active)}")
