import boto3
from boto3.dynamodb.conditions import Key
from botocore.exceptions import ClientError
from typing import Dict, List, Any, Optional
import uuid
from datetime import datetime
import json

class DynamoDBService:
    def __init__(self):
        self.dynamodb = boto3.resource('dynamodb', region_name='us-east-1')
        self.user_chat_sessions_table = self.dynamodb.Table('user_chat_sessions')
        self.chat_messages_table = self.dynamodb.Table('chat_messages')

    def get_user_chat_sessions(self, user_id: str) -> Dict[str, str]:
        """
        Loads all chat sessions metadata for a user from DynamoDB
        Returns dict of {chat_id: chat_title}
        Only returns SESSION entries, not MESSAGE entries
        """
        if not user_id:
            return {}
        
        try:
            response = self.user_chat_sessions_table.query(
                KeyConditionExpression=Key('user_id').eq(user_id),
                ScanIndexForward=True  # Order by chat_id
            )
            
            # Filter only SESSION entries and clean up the chat_id
            sessions = {}
            for item in response.get('Items', []):
                chat_id = item['chat_id']
                
                # Only include SESSION entries, not MESSAGE entries
                if chat_id.startswith('SESSION#'):
                    # Remove the SESSION# prefix to get the actual chat_id
                    clean_chat_id = chat_id.replace('SESSION#', '')
                    chat_title = item.get('chat_title', f"Chat {clean_chat_id[:8]}")
                    
                    # Clean up the title if it's generic
                    if chat_title.startswith('Chat SESSION#'):
                        chat_title = f"Chat {clean_chat_id[:8]}"
                    
                    sessions[clean_chat_id] = chat_title
            
            return sessions
            
        except ClientError as e:
            raise Exception(f"Error loading chat sessions: {e.response['Error']['Message']}")

    # Keep all other methods the same...
    def create_new_chat_session(self, user_id: str, chat_title: str = None) -> str:
        """
        Creates a new chat session for a user in DynamoDB
        Returns the chat_id of the new session
        """
        if not user_id:
            raise ValueError("User ID is required")
        
        # Check if user has reached max chats (increased limit for testing)
        MAX_CHATS_PER_USER = 20
        user_sessions = self.get_user_chat_sessions(user_id)
        
        if len(user_sessions) >= MAX_CHATS_PER_USER:
            raise Exception(f"Maximum of {MAX_CHATS_PER_USER} chats allowed per user")
        
        # Generate unique chat_id
        chat_id = str(uuid.uuid4())
        
        # Default title if none provided
        if not chat_title:
            chat_title = f"New Chat {datetime.now().strftime('%m/%d %H:%M')}"
        
        try:
            # Store session metadata with SESSION# prefix
            self.user_chat_sessions_table.put_item(
                Item={
                    'user_id': user_id,
                    'chat_id': f'SESSION#{chat_id}',  # Add SESSION# prefix
                    'chat_title': chat_title,
                    'created_at': int(datetime.now().timestamp()),
                    'updated_at': int(datetime.now().timestamp())
                }
            )
            
            return chat_id
            
        except ClientError as e:
            raise Exception(f"Error creating chat session: {e.response['Error']['Message']}")

    def delete_chat_session(self, user_id: str, chat_id: str) -> bool:
        """
        Deletes a chat session and all its messages from DynamoDB
        Enhanced to ensure complete deletion and prevent reappearing sessions
        """
        if not user_id or not chat_id:
            raise ValueError("User ID and Chat ID are required")
        
        try:
            # First, delete all messages for this chat
            self._delete_chat_messages(user_id, chat_id)
            
            # Delete the main chat session metadata (with SESSION# prefix)
            self.user_chat_sessions_table.delete_item(
                Key={
                    'user_id': user_id,
                    'chat_id': f'SESSION#{chat_id}'
                }
            )
            
            return True
            
        except ClientError as e:
            print(f"Error deleting chat session: {e}")
            return False

    def update_chat_title(self, user_id: str, chat_id: str, new_title: str) -> bool:
        """
        Updates the title of a chat session
        """
        if not user_id or not chat_id or not new_title:
            raise ValueError("User ID, Chat ID, and new title are required")
        
        try:
            # Update the session title (with SESSION# prefix)
            self.user_chat_sessions_table.update_item(
                Key={
                    'user_id': user_id,
                    'chat_id': f'SESSION#{chat_id}'
                },
                UpdateExpression='SET chat_title = :title, updated_at = :updated_at',
                ExpressionAttributeValues={
                    ':title': new_title,
                    ':updated_at': int(datetime.now().timestamp())
                }
            )
            
            return True
            
        except ClientError as e:
            print(f"Error updating chat title: {e}")
            return False

    def _delete_chat_messages(self, user_id: str, chat_id: str):
        """
        Helper method to delete all messages for a chat session
        """
        try:
            # Query all messages for this chat
            response = self.chat_messages_table.query(
                KeyConditionExpression=Key('conversation_id').eq(chat_id)
            )
            
            # Delete each message
            for item in response.get('Items', []):
                self.chat_messages_table.delete_item(
                    Key={
                        'conversation_id': item['conversation_id'],
                        'timestamp': item['timestamp']
                    }
                )
                
        except ClientError as e:
            print(f"Error deleting chat messages: {e}")

    def save_message(self, user_id: str, chat_id: str, role: str, content: str, model: str = None) -> str:
        """
        Saves a message to DynamoDB
        Returns the message_id
        """
        message_id = str(uuid.uuid4())
        timestamp = datetime.now().isoformat()
        
        try:
            self.chat_messages_table.put_item(
                Item={
                    'conversation_id': chat_id,
                    'timestamp': timestamp,
                    'id': message_id,
                    'role': role,
                    'content': content,
                    'model': model or 'unknown'
                }
            )
            
            return message_id
            
        except ClientError as e:
            raise Exception(f"Error saving message: {e.response['Error']['Message']}")

    def load_chat_history(self, user_id: str, chat_id: str) -> List[Dict[str, Any]]:
        """
        Loads chat history for a specific conversation
        """
        try:
            response = self.chat_messages_table.query(
                KeyConditionExpression=Key('conversation_id').eq(chat_id),
                ScanIndexForward=True  # Order by timestamp
            )
            
            return response.get('Items', [])
            
        except ClientError as e:
            raise Exception(f"Error loading chat history: {e.response['Error']['Message']}")

# Create a singleton instance
dynamodb_service = DynamoDBService()
