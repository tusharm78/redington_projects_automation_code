"""
Simple OTI Costing Service - Standalone Implementation
Shows only final total values without complex calculations.
Completely independent of main application functionality.
"""

from typing import Dict, Any, Optional
from fastapi import APIRouter, HTTPException
from pydantic import BaseModel
import logging

logger = logging.getLogger(__name__)

# Data models for simple OTI service
class OTISimpleRequest(BaseModel):
    project_name: str
    duration_months: int = 12
    team_size: int = 5
    complexity: str = "medium"  # low, medium, high

class OTISimpleResponse(BaseModel):
    project_name: str
    total_cost: float
    monthly_cost: float
    breakdown: Dict[str, float]
    currency: str = "USD"

class OTISimpleService:
    """Simple OTI Costing Service - Final Totals Only"""
    
    def __init__(self):
        self.base_rates = {
            "low": 15000,      # Base monthly cost for low complexity
            "medium": 25000,   # Base monthly cost for medium complexity  
            "high": 40000      # Base monthly cost for high complexity
        }
        
        self.team_multiplier = {
            1: 0.5, 2: 0.7, 3: 0.8, 4: 0.9, 5: 1.0,
            6: 1.2, 7: 1.4, 8: 1.6, 9: 1.8, 10: 2.0
        }
    
    def calculate_simple_oti_cost(self, request: OTISimpleRequest) -> OTISimpleResponse:
        """Calculate simple OTI cost - final totals only"""
        try:
            # Get base cost for complexity
            base_monthly = self.base_rates.get(request.complexity.lower(), self.base_rates["medium"])
            
            # Apply team size multiplier
            team_mult = self.team_multiplier.get(request.team_size, 1.0)
            if request.team_size > 10:
                team_mult = 2.0 + (request.team_size - 10) * 0.1
            
            # Calculate final costs
            monthly_cost = base_monthly * team_mult
            total_cost = monthly_cost * request.duration_months
            
            # Simple breakdown
            breakdown = {
                "Base Cost": base_monthly,
                "Team Adjustment": monthly_cost - base_monthly,
                "Monthly Total": monthly_cost,
                "Project Duration (months)": request.duration_months,
                "Final Total": total_cost
            }
            
            return OTISimpleResponse(
                project_name=request.project_name,
                total_cost=round(total_cost, 2),
                monthly_cost=round(monthly_cost, 2),
                breakdown=breakdown,
                currency="USD"
            )
            
        except Exception as e:
            logger.error(f"Error calculating OTI cost: {e}")
            raise HTTPException(status_code=500, detail="Error calculating OTI cost")

# Create router for the service
def create_oti_simple_router() -> APIRouter:
    """Create router for simple OTI service"""
    router = APIRouter(prefix="/oti-simple", tags=["OTI Simple Costing"])
    service = OTISimpleService()
    
    @router.post("/calculate", response_model=OTISimpleResponse)
    async def calculate_oti_simple(request: OTISimpleRequest):
        """Calculate simple OTI cost - final totals only"""
        return service.calculate_simple_oti_cost(request)
    
    @router.get("/health")
    async def oti_simple_health():
        """Health check for OTI simple service"""
        return {
            "service": "oti-simple-costing",
            "status": "healthy",
            "version": "1.0.0",
            "description": "Simple OTI costing with final totals only"
        }
    
    @router.get("/rates")
    async def get_oti_rates():
        """Get current OTI base rates"""
        return {
            "base_rates": service.base_rates,
            "team_multipliers": service.team_multiplier,
            "currency": "USD"
        }
    
    return router

# Export the service and router
__all__ = ["OTISimpleService", "create_oti_simple_router", "OTISimpleRequest", "OTISimpleResponse"]
