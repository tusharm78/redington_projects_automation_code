import boto3
import os
import uuid
import hashlib
from datetime import datetime
from typing import List, Dict, Any, Optional
from botocore.exceptions import ClientError
from boto3.dynamodb.conditions import Key

class DynamoDBService:
    def __init__(self):
        """Initialize DynamoDB service with the same tables as Streamlit app"""
        self.region = os.environ.get("AWS_REGION", "us-east-1")
        self.dynamodb = boto3.resource('dynamodb', region_name=self.region)
        
        # Same table names as Streamlit app
        self.chat_history_table = self.dynamodb.Table('chat_history')
        self.user_chat_sessions_table = self.dynamodb.Table('user_chat_sessions')
        
        # Verify tables exist
        try:
            self.chat_history_table.load()
            self.user_chat_sessions_table.load()
        except ClientError as e:
            raise Exception(f"Failed to connect to DynamoDB tables: {e.response['Error']['Message']}")

    def create_new_chat_session(self, user_id: str, chat_title: str = None) -> str:
        """
        Creates a new chat session in DynamoDB and returns the chat_id
        """
        if not user_id:
            raise ValueError("User ID is required")
        
        # Check if user has reached max chats (increased limit for testing)
        MAX_CHATS_PER_USER = 20
        user_sessions = self.get_user_chat_sessions(user_id)
        
        if len(user_sessions) >= MAX_CHATS_PER_USER:
            raise Exception(f"Maximum of {MAX_CHATS_PER_USER} active chats reached. Please delete an existing chat.")
        
        # Generate new chat ID
        chat_id = str(uuid.uuid4())
        
        # Default title if not provided
        if not chat_title:
            chat_title = f"Chat {chat_id[:8]}"
        
        try:
            # Create chat session metadata
            item = {
                'user_id': user_id,
                'chat_id': chat_id,
                'chat_title': chat_title,
                'created_at': int(datetime.now().timestamp() * 1000),
                'updated_at': int(datetime.now().timestamp() * 1000)
            }
            
            self.user_chat_sessions_table.put_item(Item=item)
            return chat_id
            
        except ClientError as e:
            raise Exception(f"Error creating chat session: {e.response['Error']['Message']}")

    def get_user_chat_sessions(self, user_id: str) -> Dict[str, str]:
        """
        Loads all chat sessions metadata for a user from DynamoDB
        Returns dict of {chat_id: chat_title}
        Only returns SESSION entries, not MESSAGE entries
        """
        if not user_id:
            return {}
        
        try:
            response = self.user_chat_sessions_table.query(
                KeyConditionExpression=Key('user_id').eq(user_id),
                ScanIndexForward=True  # Order by chat_id
            )
            
            # Filter only SESSION entries and clean up the chat_id
            sessions = {}
            for item in response.get('Items', []):
                chat_id = item['chat_id']
                
                # Only include SESSION entries, not MESSAGE entries
                if chat_id.startswith('SESSION#'):
                    # Remove the SESSION# prefix to get the actual chat_id
                    clean_chat_id = chat_id.replace('SESSION#', '')
                    chat_title = item.get('chat_title', f"Chat {clean_chat_id[:8]}")
                    
                    # Clean up the title if it's generic
                    if chat_title.startswith('Chat SESSION#'):
                        chat_title = f"Chat {clean_chat_id[:8]}"
                    
                    sessions[clean_chat_id] = chat_title
            
            return sessions
            
        except ClientError as e:
            raise Exception(f"Error loading chat sessions: {e.response['Error']['Message']}")

    def delete_chat_session(self, user_id: str, chat_id: str) -> bool:
        """
        Deletes a chat session and all its messages from DynamoDB
        Enhanced to ensure complete deletion and prevent reappearing sessions
        """
        if not user_id or not chat_id:
            raise ValueError("User ID and Chat ID are required")
        
        try:
            # First, delete all messages for this chat
            self._delete_chat_messages(user_id, chat_id)
            
            # Delete the main chat session metadata (with SESSION# prefix)
            self.user_chat_sessions_table.delete_item(
                Key={
                    'user_id': user_id,
                    'chat_id': f'SESSION#{chat_id}'
                }
            )
            
            # Also try to delete without prefix (for backward compatibility)
            try:
                self.user_chat_sessions_table.delete_item(
                    Key={
                        'user_id': user_id,
                        'chat_id': chat_id
                    }
                )
            except:
                pass  # Ignore if it doesn't exist
            
            return True
            
        except ClientError as e:
            print(f"Error deleting chat session: {e}")
            return False

    def _delete_chat_messages(self, user_id: str, chat_id: str):
        """
        Helper function to delete all messages for a specific chat
        Enhanced to handle different message formats
        """
        try:
            # Query all messages for this chat (format: chat_id#timestamp)
            response = self.chat_history_table.query(
                KeyConditionExpression=Key('user_id').eq(user_id) & Key('chat_message_id').begins_with(f"{chat_id}#")
            )
            
            # Delete each message
            with self.chat_history_table.batch_writer() as batch:
                for item in response.get('Items', []):
                    batch.delete_item(
                        Key={
                            'user_id': item['user_id'],
                            'chat_message_id': item['chat_message_id']
                        }
                    )
            
            # Also check for MESSAGE# format entries (from session_manager)
            try:
                response = self.user_chat_sessions_table.query(
                    KeyConditionExpression=Key('user_id').eq(user_id)
                )
                
                with self.user_chat_sessions_table.batch_writer() as batch:
                    for item in response.get("Items", []):
                        item_chat_id = item.get("chat_id", "")
                        if item_chat_id.startswith(f"MESSAGE#{chat_id}"):
                            batch.delete_item(
                                Key={
                                    "user_id": user_id,
                                    "chat_id": item_chat_id
                                }
                            )
                            print(f"🗑️ Deleted message entry: {item_chat_id}")
                            
            except Exception as e:
                print(f"Warning: Could not clean up MESSAGE entries: {e}")
                
        except ClientError as e:
            raise Exception(f"Error deleting chat messages: {e.response['Error']['Message']}")

    def update_chat_title(self, user_id: str, chat_id: str, new_title: str) -> bool:
        """
        Updates the title of a specific chat session
        """
        if not user_id or not chat_id or not new_title:
            raise ValueError("User ID, Chat ID, and new title are required")
        
        try:
            # Update with SESSION# prefix
            self.user_chat_sessions_table.update_item(
                Key={
                    'user_id': user_id,
                    'chat_id': f'SESSION#{chat_id}'
                },
                UpdateExpression='SET chat_title = :title, updated_at = :updated_at',
                ExpressionAttributeValues={
                    ':title': new_title,
                    ':updated_at': int(datetime.now().timestamp() * 1000)
                }
            )
            
            return True
            
        except ClientError as e:
            raise Exception(f"Error updating chat title: {e.response['Error']['Message']}")

    def store_message(self, user_id: str, chat_id: str, role: str, content: str, 
                     user_prompt: str = "", has_context: bool = False, 
                     images: List[str] = None) -> str:
        """
        Store a message in DynamoDB with the same structure as Streamlit app
        Returns the message_id
        """
        if not user_id or not chat_id:
            raise ValueError("User ID and Chat ID are required")
        
        # Generate timestamp and composite sort key (same as Streamlit)
        message_timestamp = int(datetime.now().timestamp() * 1000)
        chat_message_id = f"{chat_id}#{message_timestamp}"
        message_id = str(uuid.uuid4())
        
        # Create hash for deduplication (same as Streamlit)
        message_hash_data = f"{chat_message_id}-{role}-{content}"
        message_hash = hashlib.md5(message_hash_data.encode()).hexdigest()
        
        try:
            item = {
                'user_id': user_id,
                'chat_message_id': chat_message_id,
                'chat_id': chat_id,
                'message_timestamp': message_timestamp,
                'message_id': message_id,
                'role': role,
                'content': content,
                'has_context': has_context,
                'message_hash': message_hash
            }
            
            # Add optional fields if provided
            if user_prompt:
                item['user_prompt'] = user_prompt
            if images:
                item['images'] = images
            
            # Remove None values
            item = {k: v for k, v in item.items() if v is not None}
            
            self.chat_history_table.put_item(Item=item)
            
            # Update chat session timestamp
            self.user_chat_sessions_table.update_item(
                Key={
                    'user_id': user_id,
                    'chat_id': chat_id
                },
                UpdateExpression='SET updated_at = :updated_at',
                ExpressionAttributeValues={
                    ':updated_at': message_timestamp
                }
            )
            
            return message_id
            
        except ClientError as e:
            raise Exception(f"Error storing message: {e.response['Error']['Message']}")

    def load_chat_history(self, user_id: str, chat_id: str) -> List[Dict[str, Any]]:
        """
        Loads chat history for a given chat ID from DynamoDB
        Returns list of messages in chronological order
        """
        if not user_id or not chat_id:
            return []
        
        try:
            response = self.chat_history_table.query(
                KeyConditionExpression=Key('user_id').eq(user_id) & Key('chat_message_id').begins_with(f"{chat_id}#"),
                ScanIndexForward=True  # Ascending order by timestamp
            )
            
            messages = []
            for item in response.get('Items', []):
                message = {
                    'message_id': item.get('message_id'),
                    'role': item.get('role'),
                    'content': item.get('content'),
                    'timestamp': item.get('message_timestamp'),
                    'has_context': item.get('has_context', False)
                }
                
                # Add optional fields if present
                if item.get('user_prompt'):
                    message['user_prompt'] = item['user_prompt']
                if item.get('images'):
                    message['images'] = item['images']
                
                messages.append(message)
            
            return messages
            
        except ClientError as e:
            raise Exception(f"Error loading chat history: {e.response['Error']['Message']}")

    def get_chat_session_info(self, user_id: str, chat_id: str) -> Optional[Dict[str, Any]]:
        """
        Get information about a specific chat session
        """
        if not user_id or not chat_id:
            return None
        
        try:
            response = self.user_chat_sessions_table.get_item(
                Key={
                    'user_id': user_id,
                    'chat_id': chat_id
                }
            )
            
            return response.get('Item')
            
        except ClientError as e:
            raise Exception(f"Error getting chat session info: {e.response['Error']['Message']}")

# Global instance
dynamodb_service = DynamoDBService()
