"""
Optional Integration Helper for OTI Simple Service
This allows safe integration without affecting main functionality
"""

def try_import_oti_simple():
    """Safely try to import OTI simple service"""
    try:
        from services.oti_simple_service import create_oti_simple_router
        return create_oti_simple_router(), True
    except ImportError as e:
        print(f"OTI Simple service not available: {e}")
        return None, False
    except Exception as e:
        print(f"Error loading OTI Simple service: {e}")
        return None, False

def get_oti_simple_status():
    """Get OTI simple service availability status"""
    try:
        from services.oti_simple_service import OTISimpleService
        return True
    except ImportError:
        return False
