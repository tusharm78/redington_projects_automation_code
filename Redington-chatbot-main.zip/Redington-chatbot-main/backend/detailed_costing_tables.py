#!/usr/bin/env python3
"""
Detailed Costing Tables Generator
Creates comprehensive tabular format showing resource allocation, hours, and costs for each task
"""
from typing import Dict, List, Any
from proposal_costing_service import proposal_costing_service, RESOURCE_RATES, HOURS_PER_WEEK
import pandas as pd
from datetime import datetime

class DetailedCostingTables:
    """Generate detailed tabular costing breakdowns"""
    
    def __init__(self):
        self.costing_service = proposal_costing_service
        self.resource_rates = RESOURCE_RATES
        self.hours_per_week = HOURS_PER_WEEK
    
    def generate_detailed_task_table(self, costing_data: Dict[str, Any]) -> str:
        """Generate detailed task-level resource allocation table"""
        
        table_content = """
## 📊 **DETAILED RESOURCE ALLOCATION BY TASK**

### 🔍 **Task-Level Breakdown**

| Phase | Task | Resource Type | FTE | Weeks | Hours | Rate/Hr | Cost | % of Task |
|-------|------|---------------|-----|-------|-------|---------|------|-----------|"""
        
        for phase in costing_data['phases']:
            phase_name = phase.phase_name
            
            for task in phase.tasks:
                task_name = task.task_name
                task_total = task.total_cost
                
                # Sort resources by cost (highest first)
                sorted_resources = sorted(
                    task.resources.items(), 
                    key=lambda x: x[1] * task.duration_weeks * HOURS_PER_WEEK * RESOURCE_RATES.get(x[0], 0),
                    reverse=True
                )
                
                for i, (resource_type, fte_allocation) in enumerate(sorted_resources):
                    if resource_type in RESOURCE_RATES:
                        hours = fte_allocation * task.duration_weeks * HOURS_PER_WEEK
                        rate = RESOURCE_RATES[resource_type]
                        cost = hours * rate
                        percentage = (cost / task_total * 100) if task_total > 0 else 0
                        
                        # Show phase and task name only for first resource
                        phase_display = phase_name if i == 0 else ""
                        task_display = task_name if i == 0 else ""
                        
                        table_content += f"\n| {phase_display} | {task_display} | {resource_type} | {fte_allocation} | {task.duration_weeks} | {hours:.0f} | ${rate} | ${cost:,.0f} | {percentage:.1f}% |"
                
                # Add task total row
                table_content += f"\n| | **{task_name} TOTAL** | | | | **{task.total_hours:.0f}** | | **${task.total_cost:,.0f}** | **100.0%** |"
                table_content += f"\n|-------|------|---------------|-----|-------|-------|---------|------|-----------|"
        
        return table_content
    
    def generate_resource_utilization_table(self, costing_data: Dict[str, Any]) -> str:
        """Generate resource utilization summary table"""
        
        table_content = """
## 👥 **RESOURCE UTILIZATION SUMMARY**

### 📈 **Total Hours and Cost by Resource Type**

| Resource Type | Total Hours | Hourly Rate | Total Cost | % of Project | Avg FTE | Peak FTE |
|---------------|-------------|-------------|------------|--------------|---------|----------|"""
        
        # Calculate detailed resource metrics
        resource_details = {}
        total_project_cost = costing_data['total_cost']
        
        for phase in costing_data['phases']:
            for task in phase.tasks:
                for resource_type, fte_allocation in task.resources.items():
                    if resource_type not in resource_details:
                        resource_details[resource_type] = {
                            'total_hours': 0,
                            'total_cost': 0,
                            'fte_allocations': [],
                            'rate': RESOURCE_RATES.get(resource_type, 0)
                        }
                    
                    hours = fte_allocation * task.duration_weeks * HOURS_PER_WEEK
                    cost = hours * RESOURCE_RATES.get(resource_type, 0)
                    
                    resource_details[resource_type]['total_hours'] += hours
                    resource_details[resource_type]['total_cost'] += cost
                    resource_details[resource_type]['fte_allocations'].append(fte_allocation)
        
        # Sort by total cost (highest first)
        sorted_resources = sorted(
            resource_details.items(),
            key=lambda x: x[1]['total_cost'],
            reverse=True
        )
        
        for resource_type, details in sorted_resources:
            percentage = (details['total_cost'] / total_project_cost * 100) if total_project_cost > 0 else 0
            avg_fte = sum(details['fte_allocations']) / len(details['fte_allocations']) if details['fte_allocations'] else 0
            peak_fte = max(details['fte_allocations']) if details['fte_allocations'] else 0
            
            table_content += f"\n| {resource_type} | {details['total_hours']:.0f} | ${details['rate']} | ${details['total_cost']:,.0f} | {percentage:.1f}% | {avg_fte:.1f} | {peak_fte:.1f} |"
        
        # Add totals row
        total_hours = sum(details['total_hours'] for _, details in resource_details.items())
        avg_rate = total_project_cost / total_hours if total_hours > 0 else 0
        
        table_content += f"\n|---------------|-------------|-------------|------------|--------------|---------|----------|"
        table_content += f"\n| **TOTAL** | **{total_hours:.0f}** | **${avg_rate:.0f}** | **${total_project_cost:,.0f}** | **100.0%** | | |"
        
        return table_content
    
    def generate_phase_summary_table(self, costing_data: Dict[str, Any]) -> str:
        """Generate phase-level summary table"""
        
        table_content = """
## 📋 **PHASE-LEVEL SUMMARY**

### 🗓️ **Duration, Resources, and Costs by Phase**

| Phase | Duration (Weeks) | Tasks | Total Hours | Total Cost | % of Project | Key Resources |
|-------|------------------|-------|-------------|------------|--------------|---------------|"""
        
        total_project_cost = costing_data['total_cost']
        
        for phase in costing_data['phases']:
            duration = sum(task.duration_weeks for task in phase.tasks)
            task_count = len(phase.tasks)
            percentage = (phase.total_cost / total_project_cost * 100) if total_project_cost > 0 else 0
            
            # Find key resources (top 3 by cost in this phase)
            phase_resources = {}
            for task in phase.tasks:
                for resource_type, fte_allocation in task.resources.items():
                    if resource_type not in phase_resources:
                        phase_resources[resource_type] = 0
                    hours = fte_allocation * task.duration_weeks * HOURS_PER_WEEK
                    cost = hours * RESOURCE_RATES.get(resource_type, 0)
                    phase_resources[resource_type] += cost
            
            # Get top 3 resources
            top_resources = sorted(phase_resources.items(), key=lambda x: x[1], reverse=True)[:3]
            key_resources = ", ".join([resource for resource, _ in top_resources])
            
            table_content += f"\n| {phase.phase_name} | {duration:.1f} | {task_count} | {phase.total_hours:.0f} | ${phase.total_cost:,.0f} | {percentage:.1f}% | {key_resources} |"
        
        return table_content
    
    def generate_weekly_resource_timeline(self, costing_data: Dict[str, Any]) -> str:
        """Generate weekly resource allocation timeline"""
        
        table_content = """
## 📅 **WEEKLY RESOURCE ALLOCATION TIMELINE**

### ⏰ **Resource Loading by Week**

*Note: This shows the theoretical weekly allocation assuming sequential execution*

| Week | Phase | Active Tasks | Cloud Arch | DevOp Arch | DevOp Eng | Cloud Eng | Network Eng | Security Eng | Security Lead | Cloud Lead | PM |
|------|-------|--------------|------------|------------|-----------|-----------|-------------|--------------|---------------|------------|-----|"""
        
        week_counter = 1
        
        for phase in costing_data['phases']:
            for task in phase.tasks:
                task_weeks = int(task.duration_weeks)
                
                for week in range(task_weeks):
                    # Show phase name only for first week of first task in phase
                    phase_display = phase.phase_name if week == 0 and task == phase.tasks[0] else ""
                    
                    # Resource allocations for this week
                    allocations = {
                        'Cloud Architect': task.resources.get('Cloud Architect', 0),
                        'DevOp Architect': task.resources.get('DevOp Architect', 0),
                        'DevOp Engineer': task.resources.get('DevOp Engineer', 0),
                        'Cloud Engineer': task.resources.get('Cloud Engineer', 0),
                        'Network Engg': task.resources.get('Network Engg', 0),
                        'Security Engg': task.resources.get('Security Engg', 0),
                        'Security Lead': task.resources.get('Security Lead', 0),
                        'Cloud Lead': task.resources.get('Cloud Lead', 0),
                        'Project Management': task.resources.get('Project Management', 0)
                    }
                    
                    # Format allocations (show only non-zero)
                    formatted_allocations = []
                    for resource, allocation in allocations.items():
                        if allocation > 0:
                            formatted_allocations.append(f"{allocation:.1f}")
                        else:
                            formatted_allocations.append("-")
                    
                    table_content += f"\n| {week_counter} | {phase_display} | {task.task_name} | {' | '.join(formatted_allocations)} |"
                    week_counter += 1
        
        return table_content
    
    def generate_cost_comparison_table(self, costing_data: Dict[str, Any]) -> str:
        """Generate cost comparison and scenarios table"""
        
        table_content = """
## 💰 **COST SCENARIOS AND COMPARISONS**

### 💡 **Pricing Options**

| Scenario | Base Cost | Buffer % | Total Cost | Use Case |
|----------|-----------|----------|------------|----------|"""
        
        for scenario_name, cost in costing_data['cost_scenarios'].items():
            base_cost = costing_data['total_cost']
            buffer_pct = ((cost - base_cost) / base_cost * 100) if base_cost > 0 else 0
            
            use_cases = {
                'Base Cost': 'Internal planning, minimum viable cost',
                'Conservative (15% buffer)': '**RECOMMENDED** - Standard client quote',
                'Conservative (20% buffer)': 'Risk mitigation, complex projects',
                'Premium (30% buffer)': 'High-risk projects, extensive customization'
            }
            
            use_case = use_cases.get(scenario_name, 'Custom scenario')
            emphasis = "**" if "15%" in scenario_name else ""
            
            table_content += f"\n| {emphasis}{scenario_name}{emphasis} | ${base_cost:,.0f} | {buffer_pct:+.0f}% | {emphasis}${cost:,.0f}{emphasis} | {use_case} |"
        
        # Add cost breakdown by category
        table_content += """

### 📊 **Cost Breakdown by Resource Category**

| Category | Resources | Total Hours | Total Cost | % of Project |
|----------|-----------|-------------|------------|--------------|"""
        
        categories = {
            'Architecture & Design': ['Cloud Architect', 'DevOp Architect', 'Cloud Lead'],
            'Implementation': ['DevOp Engineer', 'Cloud Engineer'],
            'Security': ['Security Lead', 'Security Engg'],
            'Infrastructure': ['Network Engg'],
            'Management': ['Project Management']
        }
        
        total_cost = costing_data['total_cost']
        
        for category, resources in categories.items():
            category_hours = 0
            category_cost = 0
            
            for resource_type, data in costing_data['resource_utilization'].items():
                if resource_type in resources:
                    category_hours += data['total_hours']
                    category_cost += data['total_cost']
            
            if category_cost > 0:
                percentage = (category_cost / total_cost * 100)
                resource_list = ", ".join([r for r in resources if r in [res['resource'] for res in costing_data['resource_utilization']]])
                table_content += f"\n| {category} | {resource_list} | {category_hours:.0f} | ${category_cost:,.0f} | {percentage:.1f}% |"
        
        return table_content
    
    def generate_complete_detailed_report(self, user_message: str, proposal_content: str = "") -> str:
        """Generate complete detailed costing report with all tables"""
        
        # Generate costing data
        customer_name = self.costing_service.analyze_proposal_content(user_message).get('customer_name', 'Customer')
        if 'customer' in user_message.lower() or 'client' in user_message.lower():
            import re
            match = re.search(r'(?:customer|client)[:\s]+([A-Za-z\s&]+?)(?:\s|$|,|\.|they|who)', user_message, re.IGNORECASE)
            if match:
                customer_name = match.group(1).strip()
        
        costing_data = self.costing_service.generate_costing_for_proposal(
            proposal_text=proposal_content or user_message,
            customer_name=customer_name
        )
        
        # Generate all detailed tables
        report = f"""
# 📊 **DETAILED OTI COSTING REPORT**

## 📋 **Project Overview**
- **Customer**: {costing_data['customer_name']}
- **Project Type**: {costing_data['project_type'].replace('_', ' ').title()}
- **Complexity Level**: {costing_data['complexity_level']}
- **Generated On**: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}

## 🎯 **Executive Summary**
- **Total Project Hours**: {costing_data['total_hours']:,.0f} hours
- **Total Project Cost**: ${costing_data['total_cost']:,.2f} USD
- **Estimated Duration**: {costing_data['estimated_weeks']:.1f} weeks
- **Average Hourly Rate**: ${costing_data['total_cost']/costing_data['total_hours']:.2f} USD/hour
- **Recommended Quote**: ${costing_data['cost_scenarios']['Conservative (15% buffer)']:,.2f} USD

{self.generate_detailed_task_table(costing_data)}

{self.generate_resource_utilization_table(costing_data)}

{self.generate_phase_summary_table(costing_data)}

{self.generate_weekly_resource_timeline(costing_data)}

{self.generate_cost_comparison_table(costing_data)}

## 📝 **Key Assumptions**
- **Working Hours**: 8 hours/day, 5 days/week (40 hours/week)
- **FTE Allocation**: Full-Time Equivalent based on task requirements
- **Resource Rates**: Current market rates in USD
- **Timeline**: Sequential execution with some parallel activities
- **Complexity**: Assessed based on project scope and requirements

## 🎯 **Recommendations**
1. **Recommended Quote**: ${costing_data['cost_scenarios']['Conservative (15% buffer)']:,.2f} USD (15% buffer)
2. **Timeline**: {costing_data['estimated_weeks']:.0f}-{costing_data['estimated_weeks']*1.2:.0f} weeks depending on parallel execution
3. **Team Size**: 2-4 resources working in parallel for optimal efficiency
4. **Risk Mitigation**: 15-20% buffer recommended for scope changes

---
*This detailed report provides comprehensive resource allocation, hour calculations, and cost breakdowns for accurate project planning and client presentations.*
"""
        
        return report

# Global instance
detailed_costing_tables = DetailedCostingTables()
