import asyncio
import time
from fastapi import FastAPI, HTTPException, Depends, status
from fastapi.middleware.cors import CORSMiddleware
from fastapi.middleware.trustedhost import TrustedHostMiddleware
from fastapi.security import HTTPBearer, HTTPAuthorizationCredentials
import socketio
from typing import Dict, List, Any
import logging
import json
import os
from dotenv import load_dotenv

# Import existing services
from app.services.chat_service import ChatService
from app.services.auth_service import AuthService
from app.models.schemas import ChatRequest, ChatResponse, ChatMessage
from app.api import auth
from app.api.sessions import router as sessions_router
from app.api.local_rag import router as local_rag_router
from app.core.config import settings

# Load environment variables
load_dotenv()

# Setup logging
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

# Create FastAPI application
app = FastAPI(
    title="Redington AI Bot API with Streaming",
    description="Backend API for Redington AI Chatbot with Real-time Streaming",
    version="2.0.0"
)

# Create Socket.IO server
sio = socketio.AsyncServer(
    async_mode='asgi',
    cors_allowed_origins=[
        "http://localhost:3000",
        "http://localhost:4000", 
        "http://127.0.0.1:3000",
        "http://127.0.0.1:4000",
        "http://localhost:3001",
        "http://127.0.0.1:3001"
    ]
)

# Combine FastAPI and Socket.IO
socket_app = socketio.ASGIApp(sio, app)

# Add CORS middleware
app.add_middleware(
    CORSMiddleware,
    allow_origins=[
        "http://localhost:3000",
        "http://localhost:4000",
        "http://127.0.0.1:3000", 
        "http://127.0.0.1:4000",
        "http://localhost:3001",
        "http://127.0.0.1:3001"
    ],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# Add trusted host middleware
app.add_middleware(
    TrustedHostMiddleware,
    allowed_hosts=["localhost", "127.0.0.1", "*.localhost", "43.204.187.174", "43.204.187.174:8000", "43.204.187.174:3001"]
)

# Include existing routers
app.include_router(auth.router, prefix="/api/v1")
app.include_router(sessions_router, prefix="/api/v1")
app.include_router(local_rag_router, prefix="/api/v1/rag", tags=["Local RAG"])

# Initialize services
chat_service = ChatService()
auth_service = AuthService()
security = HTTPBearer()

# In-memory storage for active sessions
active_sessions: Dict[str, Dict] = {}

async def get_current_user_from_token(token: str):
    """Get current user from token"""
    try:
        payload = auth_service.verify_token(token)
        return payload.get("username", "anonymous")
    except Exception:
        return None

@app.get("/")
async def root():
    """Root endpoint"""
    return {"message": "Redington AI Bot API with Real-time Streaming", "version": "2.0.0"}

@app.get("/health")
async def health_check():
    """Health check endpoint"""
    return {"status": "healthy", "service": "redington-ai-bot-streaming-api"}

# Socket.IO event handlers
@sio.event
async def connect(sid, environ):
    """Handle client connection"""
    logger.info(f"Client connected: {sid}")
    active_sessions[sid] = {
        'connected_at': time.time(),
        'user': None,
        'conversation_id': None
    }

@sio.event
async def disconnect(sid):
    """Handle client disconnection"""
    logger.info(f"Client disconnected: {sid}")
    if sid in active_sessions:
        del active_sessions[sid]

@sio.event
async def authenticate(sid, data):
    """Handle authentication"""
    try:
        token = data.get('token')
        if not token:
            await sio.emit('auth-error', {'error': 'No token provided'}, room=sid)
            return
        
        user = await get_current_user_from_token(token)
        if not user:
            await sio.emit('auth-error', {'error': 'Invalid token'}, room=sid)
            return
        
        active_sessions[sid]['user'] = user
        await sio.emit('auth-success', {'user': user}, room=sid)
        logger.info(f"User {user} authenticated for session {sid}")
        
    except Exception as e:
        logger.error(f"Authentication error: {e}")
        await sio.emit('auth-error', {'error': 'Authentication failed'}, room=sid)

@sio.event
async def send_message(sid, data):
    """Handle chat message with streaming response"""
    try:
        # Check authentication
        session = active_sessions.get(sid)
        if not session or not session.get('user'):
            await sio.emit('chat-error', {'error': 'Not authenticated'}, room=sid)
            return
        
        # Extract message data
        message = data.get('message', '')
        conversation_id = data.get('conversation_id')
        session_id = data.get('session_id')
        
        if not message.strip():
            await sio.emit('chat-error', {'error': 'Empty message'}, room=sid)
            return
        
        logger.info(f"Processing message from {session['user']}: {message[:100]}...")
        
        # Create chat request
        chat_request = ChatRequest(
            message=message,
            conversation_id=conversation_id,
            session_id=session_id,
            model_config=data.get('model_config', {})
        )
        
        # Start streaming response
        await stream_chat_response(sid, chat_request, session['user'])
        
    except Exception as e:
        logger.error(f"Error processing message: {e}")
        await sio.emit('chat-error', {'error': f'Failed to process message: {str(e)}'}, room=sid)

async def stream_chat_response(sid: str, request: ChatRequest, user: str):
    """Stream chat response word by word"""
    try:
        # Get the full response from chat service
        response = await chat_service.process_chat_message(request, user)
        
        if not response or not response.response:
            await sio.emit('chat-error', {'error': 'No response generated'}, room=sid)
            return
        
        # Prepare response data
        response_data = {
            'conversation_id': response.conversation_id,
            'session_id': response.session_id,
            'message_id': response.message_id,
            'timestamp': response.timestamp,
            'model_used': response.model_used
        }
        
        # Send initial response metadata
        await sio.emit('chat-start', response_data, room=sid)
        
        # Stream the response word by word
        words = response.response.split(' ')
        chunk_size = 3  # Number of words per chunk
        delay = 0.05  # Delay between chunks (50ms)
        
        current_index = 0
        
        while current_index < len(words):
            # Get next chunk of words
            chunk_words = words[current_index:current_index + chunk_size]
            chunk = ' '.join(chunk_words) + (' ' if current_index + chunk_size < len(words) else '')
            
            # Send chunk
            await sio.emit('chat-chunk', {
                **response_data,
                'chunk': chunk,
                'is_complete': False
            }, room=sid)
            
            current_index += chunk_size
            
            # Add delay for streaming effect
            await asyncio.sleep(delay)
        
        # Send completion signal
        await sio.emit('chat-chunk', {
            **response_data,
            'chunk': '',
            'is_complete': True,
            'full_response': response.response
        }, room=sid)
        
        logger.info(f"Completed streaming response for session {sid}")
        
    except Exception as e:
        logger.error(f"Error in streaming response: {e}")
        await sio.emit('chat-error', {
            'error': f'Streaming failed: {str(e)}',
            'conversation_id': request.conversation_id
        }, room=sid)

# Keep existing HTTP endpoints for backward compatibility
@app.post("/api/v1/chat/message", response_model=ChatResponse)
async def send_message_http(
    request: ChatRequest,
    credentials: HTTPAuthorizationCredentials = Depends(security)
):
    """HTTP endpoint for chat (backward compatibility)"""
    try:
        token = credentials.credentials
        user = await get_current_user_from_token(token)
        if not user:
            raise HTTPException(
                status_code=status.HTTP_401_UNAUTHORIZED,
                detail="Invalid authentication credentials"
            )
        
        response = await chat_service.process_chat_message(request, user)
        return response
    except Exception as e:
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail=f"Error processing message: {str(e)}"
        )

if __name__ == "__main__":
    import uvicorn
    uvicorn.run(
        "streaming_main:socket_app",
        host="0.0.0.0",
        port=8000,
        reload=True,
        log_level="info"
    )
