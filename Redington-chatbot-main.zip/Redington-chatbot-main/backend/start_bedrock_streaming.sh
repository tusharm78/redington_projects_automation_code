#!/bin/bash

# Start Bedrock Streaming Backend
echo "🚀 Starting Redington AI Bot - Bedrock Streaming Backend"
echo "=================================================="

# Check if already running
if [ -f "bedrock_streaming.pid" ]; then
    PID=$(cat bedrock_streaming.pid)
    if ps -p $PID > /dev/null 2>&1; then
        echo "⚠️  Backend already running (PID: $PID)"
        echo "   Use ./stop_bedrock_streaming.sh to stop first"
        exit 1
    else
        echo "🧹 Cleaning up stale PID file"
        rm -f bedrock_streaming.pid
    fi
fi

# Start the backend
echo "🔧 Starting Bedrock streaming backend..."
nohup python3 bedrock_streaming_main.py > bedrock_streaming.log 2>&1 & 
PID=$!
echo $PID > bedrock_streaming.pid

# Wait for startup
echo "⏳ Waiting for backend to initialize..."
sleep 3

# Check if it's running
if ps -p $PID > /dev/null 2>&1; then
    # Test health endpoint
    if curl -s http://localhost:8000/health > /dev/null 2>&1; then
        echo "✅ Backend started successfully (PID: $PID)"
        echo "🔗 Health check: http://localhost:8000/health"
        echo "📖 API Docs: http://localhost:8000/docs"
        echo "📋 Logs: tail -f bedrock_streaming.log"
        
        # Show Bedrock status
        BEDROCK_STATUS=$(curl -s http://localhost:8000/health | jq -r '.bedrock_status' 2>/dev/null || echo "unknown")
        if [ "$BEDROCK_STATUS" = "connected" ]; then
            echo "🤖 Bedrock Claude: ✅ Connected"
        else
            echo "🤖 Bedrock Claude: ⚠️  Fallback mode"
        fi
    else
        echo "❌ Backend started but health check failed"
        echo "📋 Check logs: tail -f bedrock_streaming.log"
    fi
else
    echo "❌ Failed to start backend"
    echo "📋 Check logs: tail -f bedrock_streaming.log"
    rm -f bedrock_streaming.pid
    exit 1
fi
