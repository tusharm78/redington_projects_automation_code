import re

# Read the file
with open("enhanced_bedrock_main.py", "r") as f:
    content = f.read()

# Fix the role normalization in the conversation context building
old_pattern = r"""            for msg in recent_messages\[:-1\]:  # Exclude the just-saved user message
                conversation_context\.append\(\{
                    "role": msg\["role"\],
                    "content": msg\["content"\]
                \}\)"""

new_pattern = """            for msg in recent_messages[:-1]:  # Exclude the just-saved user message
                # Normalize role for Bedrock compatibility
                bedrock_role = "assistant" if msg["role"].startswith("assistant") else "user"
                conversation_context.append({
                    "role": bedrock_role,
                    "content": msg["content"]
                })"""

content = re.sub(old_pattern, new_pattern, content, flags=re.MULTILINE)

# Fix assistant_enhanced to assistant
content = content.replace(assistant_enhanced, assistant)

# Write back
with open("enhanced_bedrock_main.py", "w") as f:
    f.write(content)

print("Fixed role normalization and assistant_enhanced issues")
