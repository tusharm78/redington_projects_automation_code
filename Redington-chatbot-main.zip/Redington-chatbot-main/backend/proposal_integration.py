#!/usr/bin/env python3
"""
Proposal Integration Service
Seamlessly integrates OTI costing with proposal generation
"""
import re
import logging
from typing import Optional, Dict, Any
from proposal_costing_service import proposal_costing_service

logger = logging.getLogger(__name__)

class ProposalIntegrationService:
    """Service to integrate OTI costing with proposal generation"""
    
    def __init__(self):
        self.costing_service = proposal_costing_service
        
        # Keywords that trigger costing calculation
        self.costing_triggers = [
            "cost", "pricing", "budget", "estimate", "quote", 
            "proposal", "investment", "timeline", "duration",
            "resource", "team", "effort", "hours"
        ]
    
    def should_include_costing(self, user_message: str, generated_content: str = "") -> bool:
        """Determine if costing should be included based on user request and content"""
        
        # Check user message for costing-related keywords
        message_lower = user_message.lower()
        content_lower = generated_content.lower()
        
        # Direct costing request
        if any(trigger in message_lower for trigger in self.costing_triggers):
            return True
        
        # Proposal generation request
        if "proposal" in message_lower or "quote" in message_lower:
            return True
        
        # Check if generated content is a proposal (contains typical proposal sections)
        proposal_indicators = [
            "executive summary", "solution overview", "implementation",
            "deliverables", "timeline", "next steps", "benefits"
        ]
        
        if any(indicator in content_lower for indicator in proposal_indicators):
            return True
        
        return False
    
    def extract_customer_name(self, user_message: str, generated_content: str = "") -> str:
        """Extract customer name from user message or generated content"""
        
        # Common patterns for customer names
        patterns = [
            r"customer[:\s]+([A-Za-z\s&]+?)(?:\s|$|,|\.|they|who)",
            r"client[:\s]+([A-Za-z\s&]+?)(?:\s|$|,|\.|they|who)",
            r"for\s+([A-Za-z\s&]+?)(?:\s+they|\s+who|\s+has|\s+needs|\s+wants)",
            r"company[:\s]+([A-Za-z\s&]+?)(?:\s|$|,|\.|they|who)",
            r"organization[:\s]+([A-Za-z\s&]+?)(?:\s|$|,|\.|they|who)"
        ]
        
        # Search in user message first
        text_to_search = user_message + " " + generated_content
        
        for pattern in patterns:
            match = re.search(pattern, text_to_search, re.IGNORECASE)
            if match:
                customer_name = match.group(1).strip()
                # Clean up the name
                customer_name = re.sub(r'\s+', ' ', customer_name)
                if len(customer_name) > 2 and len(customer_name) < 50:
                    return customer_name
        
        return "Valued Customer"
    
    def generate_enhanced_proposal(self, user_message: str, base_proposal: str) -> str:
        """Generate enhanced proposal with integrated costing"""
        
        try:
            # Check if costing should be included
            if not self.should_include_costing(user_message, base_proposal):
                return base_proposal
            
            # Extract customer name
            customer_name = self.extract_customer_name(user_message, base_proposal)
            
            # Generate costing data
            costing_data = self.costing_service.generate_costing_for_proposal(
                proposal_text=base_proposal,
                customer_name=customer_name
            )
            
            # Format costing table with weekly breakdown
            costing_table = self._format_enhanced_costing_table(costing_data)
            
            # Integrate costing into proposal
            enhanced_proposal = self._integrate_costing_into_proposal(base_proposal, costing_table)
            
            logger.info(f"Enhanced proposal generated with costing for {customer_name}")
            # Add OTI costing as the last section
            enhanced_proposal = self._add_oti_costing_to_proposal(enhanced_proposal)
            
            return enhanced_proposal
            
        except Exception as e:
            logger.error(f"Error generating enhanced proposal: {str(e)}")
            # Return original proposal if costing fails
            return base_proposal
    
    def _integrate_costing_into_proposal(self, base_proposal: str, costing_table: str) -> str:
        """Integrate costing table into the proposal at the appropriate location"""
        
        # Find the best location to insert costing
        insertion_patterns = [
            (r"(## \*\*Implementation Timeline\*\*.*?)(\n## |\n\*\*|$)", "after_timeline"),
            (r"(## \*\*Deliverables\*\*.*?)(\n## |\n\*\*|$)", "after_deliverables"),
            (r"(## \*\*Solution Overview\*\*.*?)(\n## |\n\*\*|$)", "after_solution"),
            (r"(## \*\*Next Steps\*\*)", "before_next_steps"),
            (r"(\*\*Thank you.*?$)", "before_thank_you")
        ]
        
        for pattern, location in insertion_patterns:
            match = re.search(pattern, base_proposal, re.DOTALL | re.IGNORECASE)
            if match:
                if location.startswith("after_"):
                    # Insert after the matched section
                    insertion_point = match.end(1)
                    enhanced_proposal = (
                        base_proposal[:insertion_point] + 
                        "\n\n" + costing_table + "\n" +
                        base_proposal[insertion_point:]
                    )
                else:
                    # Insert before the matched section
                    insertion_point = match.start(1)
                    enhanced_proposal = (
                        base_proposal[:insertion_point] + 
                        costing_table + "\n\n" +
                        base_proposal[insertion_point:]
                    )
                
                # Add OTI costing as the last section
            enhanced_proposal = self._add_oti_costing_to_proposal(enhanced_proposal)
            
            return enhanced_proposal
        
        # If no specific location found, append at the end
        return base_proposal + "\n\n" + costing_table
    
    def _format_enhanced_costing_table(self, costing_data: Dict[str, any]) -> str:
        """Format OTI costing under PROPOSED COMMERCIALS - DISABLED"""
        
        # Return empty string to disable commercial section generation
        # All other functionality remains intact
        return ""


    def get_costing_summary(self, user_message: str, proposal_content: str = "") -> Optional[Dict[str, Any]]:
        """Get just the costing summary without modifying the proposal"""
        
        try:
            customer_name = self.extract_customer_name(user_message, proposal_content)
            costing_data = self.costing_service.generate_costing_for_proposal(
                proposal_text=proposal_content or user_message,
                customer_name=customer_name
            )
            return costing_data
        except Exception as e:
            logger.error(f"Error generating costing summary: {str(e)}")
            return None

# Global integration service instance

    def _generate_oti_costing_table(self, proposal_content: str) -> str:
        """Generate simple OTI costing table based on weeks estimation"""
        
        import re
        
        # Extract number of weeks from proposal content
        weeks_patterns = [
            r'(\d+)\s*weeks?',
            r'Duration[:\s]*(\d+)\s*weeks?',
            r'Timeline[:\s]*(\d+)\s*weeks?',
            r'Project Duration[:\s]*(\d+)\s*weeks?'
        ]
        
        estimated_weeks = 6  # Default fallback
        
        for pattern in weeks_patterns:
            matches = re.findall(pattern, proposal_content, re.IGNORECASE)
            if matches:
                try:
                    estimated_weeks = int(matches[-1])  # Take the last match
                    break
                except ValueError:
                    continue
        
        # Calculate total cost: weeks × 8 hours × 5 days × $25 base rate
        total_cost = estimated_weeks * 8 * 5 * 25
        
        # Generate OTI costing table
        oti_table = f'''
## **OTI COSTING**

| Costing | No of Weeks | Total Cost |
|---------|-------------|------------|
| One time implementation charges | {estimated_weeks} | ${total_cost:,} |

*Based on standard resource allocation: weeks × 8 hours × 5 days × $25 base rate*
'''
        
        return oti_table

    def _add_oti_costing_to_proposal(self, proposal_content: str) -> str:
        """Add OTI costing table as the last section of the proposal"""
        
        try:
            # Generate OTI costing table
            oti_table = self._generate_oti_costing_table(proposal_content)
            
            # Add OTI table at the end of the proposal
            enhanced_proposal = proposal_content + '\n' + oti_table
            
            # Add OTI costing as the last section
            enhanced_proposal = self._add_oti_costing_to_proposal(enhanced_proposal)
            
            return enhanced_proposal
            
        except Exception as e:
            logger.error(f'Error adding OTI costing: {str(e)}')
            # Return original proposal if OTI costing fails
            return proposal_content
proposal_integration = ProposalIntegrationService()
