#!/usr/bin/env python3
"""
Proposal Costing Service for Redington Chatbot
Automatically calculates OTI costing during proposal generation
"""
import re
import json
from typing import Dict, List, Optional, Tuple
from datetime import datetime, timedelta
from dataclasses import dataclass
import logging

logger = logging.getLogger(__name__)

# Resource rates per hour (in USD)
RESOURCE_RATES = {
    'Cloud Architect': 35,
    'DevOp Architect': 40,
    'DevOp Engineer': 25,
    'Cloud Engineer': 16,
    'Network Engg': 16,
    'Security Engg': 20,
    'Security Lead': 28,
    'Cloud Lead': 28,
    'Project Management': 30
}

# Working parameters
HOURS_PER_DAY = 8
DAYS_PER_WEEK = 5
HOURS_PER_WEEK = HOURS_PER_DAY * DAYS_PER_WEEK

@dataclass
class TaskCosting:
    task_name: str
    duration_weeks: float
    resources: Dict[str, float]  # resource_type: fte_allocation
    total_hours: float = 0
    total_cost: float = 0
    
    def __post_init__(self):
        self.calculate_cost()
    
    def calculate_cost(self):
        """Calculate total hours and cost for this task"""
        self.total_hours = 0
        self.total_cost = 0
        
        for resource_type, fte_allocation in self.resources.items():
            if resource_type in RESOURCE_RATES:
                hours = fte_allocation * self.duration_weeks * HOURS_PER_WEEK
                cost = hours * RESOURCE_RATES[resource_type]
                self.total_hours += hours
                self.total_cost += cost

@dataclass
class PhaseCosting:
    phase_name: str
    tasks: List[TaskCosting]
    total_hours: float = 0
    total_cost: float = 0
    
    def __post_init__(self):
        self.calculate_totals()
    
    def calculate_totals(self):
        """Calculate phase totals"""
        self.total_hours = sum(task.total_hours for task in self.tasks)
        self.total_cost = sum(task.total_cost for task in self.tasks)

class ProposalCostingService:
    """Service to automatically calculate OTI costing for proposals"""
    
    def __init__(self):
        self.resource_rates = RESOURCE_RATES
        self.hours_per_week = HOURS_PER_WEEK
        
        # Predefined task templates based on common activities
        self.task_templates = {
            # Assessment & Planning
            "assessment": TaskCosting(
                task_name="Infrastructure Assessment",
                duration_weeks=2,
                resources={"Cloud Architect": 1.0, "Cloud Engineer": 0.5, "Security Engg": 0.3}
            ),
            "requirements": TaskCosting(
                task_name="Requirements Gathering",
                duration_weeks=1,
                resources={"Cloud Architect": 0.8, "DevOp Architect": 0.5, "Project Management": 0.5}
            ),
            "design": TaskCosting(
                task_name="Solution Design",
                duration_weeks=2,
                resources={"Cloud Architect": 1.0, "DevOp Architect": 0.8, "Security Lead": 0.5, "Project Management": 0.3}
            ),
            
            # Infrastructure Setup
            "infrastructure": TaskCosting(
                task_name="Cloud Infrastructure Setup",
                duration_weeks=3,
                resources={"Cloud Architect": 0.8, "DevOp Architect": 1.0, "Cloud Engineer": 1.0, "DevOp Engineer": 0.8}
            ),
            "network": TaskCosting(
                task_name="Network Configuration",
                duration_weeks=2,
                resources={"Network Engg": 1.0, "Cloud Engineer": 0.5, "DevOp Engineer": 0.5}
            ),
            "security": TaskCosting(
                task_name="Security Implementation",
                duration_weeks=2,
                resources={"Security Lead": 1.0, "Security Engg": 1.0, "Cloud Architect": 0.3}
            ),
            
            # Migration & Implementation
            "migration": TaskCosting(
                task_name="Application Migration",
                duration_weeks=4,
                resources={"DevOp Architect": 0.8, "DevOp Engineer": 1.0, "Cloud Engineer": 1.0, "Cloud Architect": 0.5}
            ),
            "testing": TaskCosting(
                task_name="Testing & Validation",
                duration_weeks=2,
                resources={"DevOp Engineer": 1.0, "Cloud Engineer": 0.8, "Security Engg": 0.5, "Project Management": 0.5}
            ),
            "optimization": TaskCosting(
                task_name="Performance Optimization",
                duration_weeks=2,
                resources={"Cloud Architect": 0.8, "DevOp Architect": 0.8, "DevOp Engineer": 0.5}
            ),
            
            # Support & Handover
            "documentation": TaskCosting(
                task_name="Documentation & Training",
                duration_weeks=1,
                resources={"Cloud Lead": 1.0, "DevOp Architect": 0.5, "Project Management": 1.0}
            ),
            "support": TaskCosting(
                task_name="Go-Live Support",
                duration_weeks=2,
                resources={"Cloud Architect": 0.5, "DevOp Engineer": 0.8, "Cloud Engineer": 0.5, "Project Management": 0.8}
            )
        }
    
    def analyze_proposal_content(self, proposal_text: str) -> Dict[str, any]:
        """Analyze proposal content to identify required activities and estimate costs"""
        
        # Keywords to identify different types of activities
        activity_keywords = {
            "assessment": ["assess", "evaluation", "analysis", "current state", "discovery"],
            "requirements": ["requirement", "gathering", "specification", "scope"],
            "design": ["design", "architecture", "blueprint", "solution"],
            "infrastructure": ["infrastructure", "provisioning", "setup", "deployment"],
            "network": ["network", "connectivity", "vpn", "routing"],
            "security": ["security", "compliance", "encryption", "access control"],
            "migration": ["migration", "migrate", "move", "transfer"],
            "testing": ["testing", "validation", "verification", "qa"],
            "optimization": ["optimization", "performance", "tuning", "scaling"],
            "documentation": ["documentation", "training", "knowledge transfer"],
            "support": ["support", "maintenance", "monitoring", "go-live"]
        }
        
        # Identify required activities based on content
        identified_activities = []
        proposal_lower = proposal_text.lower()
        
        for activity, keywords in activity_keywords.items():
            if any(keyword in proposal_lower for keyword in keywords):
                identified_activities.append(activity)
        
        # If no specific activities identified, use default cloud migration set
        if not identified_activities:
            identified_activities = ["assessment", "requirements", "design", "infrastructure", "migration", "testing", "support"]
        
        # Scale based on project complexity indicators
        complexity_multiplier = self._assess_complexity(proposal_text)
        
        return {
            "identified_activities": identified_activities,
            "complexity_multiplier": complexity_multiplier,
            "project_type": self._identify_project_type(proposal_text)
        }
    
    def _assess_complexity(self, proposal_text: str) -> float:
        """Assess project complexity based on content"""
        complexity_indicators = {
            "high": ["enterprise", "large scale", "complex", "multiple", "integration", "legacy"],
            "medium": ["medium", "standard", "typical", "moderate"],
            "low": ["simple", "basic", "small", "straightforward"]
        }
        
        proposal_lower = proposal_text.lower()
        
        high_count = sum(1 for indicator in complexity_indicators["high"] if indicator in proposal_lower)
        medium_count = sum(1 for indicator in complexity_indicators["medium"] if indicator in proposal_lower)
        low_count = sum(1 for indicator in complexity_indicators["low"] if indicator in proposal_lower)
        
        if high_count > medium_count and high_count > low_count:
            return 1.3  # 30% increase for high complexity
        elif low_count > medium_count and low_count > high_count:
            return 0.8  # 20% decrease for low complexity
        else:
            return 1.0  # Standard complexity
    
    def _identify_project_type(self, proposal_text: str) -> str:
        """Identify the type of project"""
        project_types = {
            "cloud_migration": ["migration", "migrate", "move to cloud", "cloud adoption"],
            "devops_implementation": ["devops", "ci/cd", "automation", "pipeline"],
            "security_audit": ["security", "audit", "compliance", "assessment"],
            "infrastructure_setup": ["infrastructure", "setup", "deployment", "provisioning"]
        }
        
        proposal_lower = proposal_text.lower()
        
        for project_type, keywords in project_types.items():
            if any(keyword in proposal_lower for keyword in keywords):
                return project_type
        
        return "cloud_migration"  # Default
    
    def generate_costing_for_proposal(self, proposal_text: str, customer_name: str = "Customer") -> Dict[str, any]:
        """Generate comprehensive costing breakdown for a proposal"""
        
        # Analyze proposal content
        analysis = self.analyze_proposal_content(proposal_text)
        
        # Get required tasks based on identified activities
        required_tasks = []
        for activity in analysis["identified_activities"]:
            if activity in self.task_templates:
                task = self.task_templates[activity]
                # Apply complexity multiplier to duration
                adjusted_task = TaskCosting(
                    task_name=task.task_name,
                    duration_weeks=task.duration_weeks * analysis["complexity_multiplier"],
                    resources=task.resources.copy()
                )
                required_tasks.append(adjusted_task)
        
        # Group tasks into phases
        phases = self._group_tasks_into_phases(required_tasks)
        
        # Calculate totals
        total_hours = sum(phase.total_hours for phase in phases)
        total_cost = sum(phase.total_cost for phase in phases)
        
        # Generate resource utilization summary
        resource_summary = self._calculate_resource_utilization(phases)
        
        # Calculate timeline
        max_parallel_resources = 3  # Assume 3 resources can work in parallel
        estimated_weeks = total_hours / (HOURS_PER_WEEK * max_parallel_resources)
        
        # Cost scenarios
        cost_scenarios = {
            "Base Cost": total_cost,
            "Conservative (15% buffer)": total_cost * 1.15,
            "Conservative (20% buffer)": total_cost * 1.20,
            "Premium (30% buffer)": total_cost * 1.30
        }
        
        return {
            "customer_name": customer_name,
            "project_type": analysis["project_type"],
            "complexity_level": "High" if analysis["complexity_multiplier"] > 1.2 else "Medium" if analysis["complexity_multiplier"] > 0.9 else "Low",
            "total_hours": total_hours,
            "total_cost": total_cost,
            "estimated_weeks": estimated_weeks,
            "phases": phases,
            "resource_utilization": resource_summary,
            "cost_scenarios": cost_scenarios,
            "proposal_text": proposal_text,  # Add proposal text for BOQ analysis
            "generated_on": datetime.now().isoformat()
        }
    
    def _group_tasks_into_phases(self, tasks: List[TaskCosting]) -> List[PhaseCosting]:
        """Group tasks into logical phases"""
        
        phase_mapping = {
            "Phase 1: Assessment & Planning": ["Infrastructure Assessment", "Requirements Gathering", "Solution Design"],
            "Phase 2: Infrastructure Setup": ["Cloud Infrastructure Setup", "Network Configuration", "Security Implementation"],
            "Phase 3: Implementation & Migration": ["Application Migration", "Testing & Validation", "Performance Optimization"],
            "Phase 4: Handover & Support": ["Documentation & Training", "Go-Live Support"]
        }
        
        phases = []
        
        for phase_name, task_names in phase_mapping.items():
            phase_tasks = [task for task in tasks if task.task_name in task_names]
            if phase_tasks:
                phases.append(PhaseCosting(phase_name=phase_name, tasks=phase_tasks))
        
        return phases
    
    def _calculate_resource_utilization(self, phases: List[PhaseCosting]) -> Dict[str, Dict[str, float]]:
        """Calculate resource utilization across all phases"""
        resource_summary = {}
        
        for phase in phases:
            for task in phase.tasks:
                for resource_type, fte_allocation in task.resources.items():
                    if resource_type not in resource_summary:
                        resource_summary[resource_type] = {
                            "total_hours": 0,
                            "total_cost": 0,
                            "rate": RESOURCE_RATES.get(resource_type, 0)
                        }
                    
                    hours = fte_allocation * task.duration_weeks * HOURS_PER_WEEK
                    cost = hours * RESOURCE_RATES.get(resource_type, 0)
                    
                    resource_summary[resource_type]["total_hours"] += hours
                    resource_summary[resource_type]["total_cost"] += cost
        
        return resource_summary
    
    def format_costing_table(self, costing_data: Dict[str, any]) -> str:
        """Format costing data into a table for proposal inclusion"""
        
        table_content = f"""
## 💰 **PROJECT COSTING BREAKDOWN**

### 📊 **Project Overview**
- **Customer**: {costing_data['customer_name']}
- **Project Type**: {costing_data['project_type'].replace('_', ' ').title()}
- **Complexity Level**: {costing_data['complexity_level']}
- **Estimated Duration**: {costing_data['estimated_weeks']:.1f} weeks
- **Total Hours**: {costing_data['total_hours']:,.0f} hours

### 📋 **Phase-wise Breakdown**

| Phase | Duration | Hours | Cost (USD) | Percentage |
|-------|----------|-------|------------|------------|"""
        
        total_cost = costing_data['total_cost']
        
        for phase in costing_data['phases']:
            percentage = (phase.total_cost / total_cost * 100) if total_cost > 0 else 0
            table_content += f"\n| {phase.phase_name} | {sum(task.duration_weeks for task in phase.tasks):.1f}w | {phase.total_hours:,.0f} | ${phase.total_cost:,.0f} | {percentage:.1f}% |"
        
        table_content += f"\n| **TOTAL** | **{costing_data['estimated_weeks']:.1f}w** | **{costing_data['total_hours']:,.0f}** | **${total_cost:,.0f}** | **100.0%** |"
        
        table_content += f"""

### 👥 **Resource Utilization**

| Resource Type | Hours | Cost (USD) | Rate/Hour | Utilization % |
|---------------|-------|------------|-----------|---------------|"""
        
        for resource, data in costing_data['resource_utilization'].items():
            utilization = (data['total_cost'] / total_cost * 100) if total_cost > 0 else 0
            table_content += f"\n| {resource} | {data['total_hours']:,.0f} | ${data['total_cost']:,.0f} | ${data['rate']}/hr | {utilization:.1f}% |"
        
        table_content += f"""

### 💡 **Cost Scenarios**

| Scenario | Cost (USD) | Description |
|----------|------------|-------------|
| Base Cost | ${costing_data['cost_scenarios']['Base Cost']:,.0f} | Direct resource cost |
| **Recommended** | **${costing_data['cost_scenarios']['Conservative (15% buffer)']:,.0f}** | **15% buffer for contingency** |
| Conservative | ${costing_data['cost_scenarios']['Conservative (20% buffer)']:,.0f} | 20% buffer for risk mitigation |
| Premium | ${costing_data['cost_scenarios']['Premium (30% buffer)']:,.0f} | 30% buffer for complex scenarios |

### 📅 **Timeline Assumptions**
- **Working Hours**: {HOURS_PER_DAY} hours/day, {DAYS_PER_WEEK} days/week
- **Parallel Resources**: Up to 3 resources working simultaneously
- **Buffer Time**: Included in cost scenarios above

---
*Generated on: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')} UTC*
"""
        
        return table_content

# Global service instance
proposal_costing_service = ProposalCostingService()
