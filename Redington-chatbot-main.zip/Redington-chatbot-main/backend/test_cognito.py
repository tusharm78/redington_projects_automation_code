#!/usr/bin/env python3

import os
import boto3
from dotenv import load_dotenv

# Load environment variables
load_dotenv()

def test_cognito_config():
    print("=== Cognito Configuration Test ===")
    
    region = os.getenv('AWS_DEFAULT_REGION', 'us-east-1')
    pool_id = os.getenv('POOL_ID')
    client_id = os.getenv('APP_CLIENT_ID')
    client_secret = os.getenv('APP_CLIENT_SECRET')
    
    print(f"Region: {region}")
    print(f"Pool ID: {pool_id}")
    print(f"Client ID: {client_id}")
    print(f"Client Secret: {client_secret[:10]}..." if client_secret else "None")
    
    # Test Cognito client creation
    try:
        cognito_client = boto3.client('cognito-idp', region_name=region)
        print(f"✅ Cognito client created for region: {region}")
        
        # Test if client exists
        response = cognito_client.describe_user_pool_client(
            UserPoolId=pool_id,
            ClientId=client_id
        )
        print("✅ Cognito client exists and is accessible")
        print(f"Client Name: {response['UserPoolClient']['ClientName']}")
        
    except Exception as e:
        print(f"❌ Cognito client error: {e}")
        
        # Try with ap-south-1 explicitly
        try:
            print("\n🔄 Trying with ap-south-1 region...")
            cognito_client = boto3.client('cognito-idp', region_name='ap-south-1')
            response = cognito_client.describe_user_pool_client(
                UserPoolId=pool_id,
                ClientId=client_id
            )
            print("✅ Cognito client works with ap-south-1!")
            print(f"Client Name: {response['UserPoolClient']['ClientName']}")
        except Exception as e2:
            print(f"❌ Still failed with ap-south-1: {e2}")

if __name__ == "__main__":
    test_cognito_config()
