import asyncio
import time
from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware
import socketio
import logging

# Setup logging
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

# Create FastAPI application
app = FastAPI(
    title="Redington AI Bot - Simple Streaming Demo",
    description="Simplified streaming demo without authentication",
    version="1.0.0"
)

# Create Socket.IO server with relaxed CORS
sio = socketio.AsyncServer(
    async_mode='asgi',
    cors_allowed_origins="*",  # Allow all origins for demo
    logger=True,
    engineio_logger=True
)

# Combine FastAPI and Socket.IO
socket_app = socketio.ASGIApp(sio, app)

# Add CORS middleware
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],  # Allow all origins for demo
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# In-memory storage for active sessions
active_sessions = {}

@app.get("/")
async def root():
    return {"message": "Redington AI Bot - Simple Streaming Demo", "version": "1.0.0"}

@app.get("/health")
async def health_check():
    return {"status": "healthy", "service": "redington-streaming-demo"}

# Socket.IO event handlers
@sio.event
async def connect(sid, environ):
    """Handle client connection"""
    logger.info(f"Client connected: {sid}")
    active_sessions[sid] = {
        'connected_at': time.time(),
        'authenticated': True  # Auto-authenticate for demo
    }
    # Send immediate auth success
    await sio.emit('auth-success', {'user': 'demo-user'}, room=sid)

@sio.event
async def disconnect(sid):
    """Handle client disconnection"""
    logger.info(f"Client disconnected: {sid}")
    if sid in active_sessions:
        del active_sessions[sid]

@sio.event
async def send_message(sid, data):
    """Handle chat message with streaming response"""
    try:
        session = active_sessions.get(sid)
        if not session:
            await sio.emit('chat-error', {'error': 'Session not found'}, room=sid)
            return
        
        message = data.get('message', '')
        if not message.strip():
            await sio.emit('chat-error', {'error': 'Empty message'}, room=sid)
            return
        
        logger.info(f"Processing message: {message[:100]}...")
        
        # Start streaming response
        await stream_demo_response(sid, message)
        
    except Exception as e:
        logger.error(f"Error processing message: {e}")
        await sio.emit('chat-error', {'error': f'Failed to process message: {str(e)}'}, room=sid)

async def stream_demo_response(sid: str, user_message: str):
    """Stream a demo response word by word"""
    try:
        # Generate a demo response based on the user message
        if "redington" in user_message.lower():
            demo_response = """Redington is a leading technology distributor and solutions provider in the Asia-Pacific region. We specialize in distributing cutting-edge technology products and providing comprehensive IT solutions to businesses across various industries. Our services include cloud solutions, cybersecurity, data analytics, digital transformation consulting, and enterprise software solutions. We work with top technology vendors to deliver innovative solutions that help businesses grow and succeed in the digital age."""
        elif "service" in user_message.lower():
            demo_response = """Our comprehensive services include: Cloud Computing Solutions for scalable infrastructure, Cybersecurity Services to protect your digital assets, Data Analytics and Business Intelligence for informed decision-making, Digital Transformation Consulting to modernize your operations, Enterprise Software Solutions for productivity enhancement, Technical Support and Maintenance for seamless operations, and Training and Certification programs for skill development."""
        elif "hello" in user_message.lower() or "hi" in user_message.lower():
            demo_response = """Hello! Welcome to Redington AI Assistant. I'm here to help you with information about our technology solutions, services, and capabilities. Feel free to ask me about our cloud services, cybersecurity solutions, digital transformation offerings, or any other technology-related questions you might have."""
        else:
            demo_response = f"""Thank you for your message: "{user_message}". As Redington's AI Assistant, I can help you with information about our technology distribution services, cloud solutions, cybersecurity offerings, digital transformation consulting, and enterprise software solutions. We're committed to providing innovative technology solutions that drive business growth and success."""
        
        # Send initial response metadata
        response_data = {
            'conversation_id': 'demo-conversation',
            'session_id': 'demo-session',
            'message_id': f'msg-{int(time.time())}',
            'timestamp': time.strftime('%Y-%m-%d %H:%M:%S'),
            'model_used': 'Redington-AI-Demo'
        }
        
        await sio.emit('chat-start', response_data, room=sid)
        
        # Stream the response word by word
        words = demo_response.split(' ')
        chunk_size = 3  # 3 words per chunk
        delay = 0.1  # 100ms delay for visible streaming effect
        
        current_index = 0
        
        while current_index < len(words):
            # Get next chunk of words
            chunk_words = words[current_index:current_index + chunk_size]
            chunk = ' '.join(chunk_words) + (' ' if current_index + chunk_size < len(words) else '')
            
            # Send chunk
            await sio.emit('chat-chunk', {
                **response_data,
                'chunk': chunk,
                'is_complete': False
            }, room=sid)
            
            current_index += chunk_size
            
            # Add delay for streaming effect
            await asyncio.sleep(delay)
        
        # Send completion signal
        await sio.emit('chat-chunk', {
            **response_data,
            'chunk': '',
            'is_complete': True,
            'full_response': demo_response
        }, room=sid)
        
        logger.info(f"Completed streaming response for session {sid}")
        
    except Exception as e:
        logger.error(f"Error in streaming response: {e}")
        await sio.emit('chat-error', {
            'error': f'Streaming failed: {str(e)}'
        }, room=sid)

if __name__ == "__main__":
    import uvicorn
    uvicorn.run(
        "simple_streaming_main:socket_app",
        host="0.0.0.0",
        port=8000,
        reload=False,
        log_level="info"
    )
