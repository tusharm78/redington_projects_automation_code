#!/usr/bin/env python3
"""
Advanced Real-time Session Tracker - Monitors actual chatbot usage
Integrates with main backend to track real user sessions
"""

import boto3
import json
import time
from datetime import datetime, timedelta
from typing import Dict, List, Optional
import threading
import logging
from decimal import Decimal

logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

class AdvancedSessionTracker:
    def __init__(self):
        self.dynamodb = boto3.resource('dynamodb', region_name='us-east-1')
        self.session_table = None
        self.active_sessions_table = None
        self.init_tables()
        
        # In-memory cache for fast access
        self.active_users_cache: Dict[str, Dict] = {}
        self.cache_lock = threading.Lock()
        
        # Start monitoring threads
        self.start_monitoring_threads()
        
    def init_tables(self):
        """Initialize DynamoDB tables"""
        try:
            # Main session table (existing)
            self.session_table = self.dynamodb.Table('user_chat_sessions')
            self.session_table.load()
            logger.info("✅ Connected to user_chat_sessions table")
            
            # Active sessions tracking table
            self.active_sessions_table = self._get_or_create_active_sessions_table()
            
        except Exception as e:
            logger.error(f"❌ Error initializing tables: {e}")
    
    def _get_or_create_active_sessions_table(self):
        """Get or create active sessions table"""
        table_name = 'realtime_active_sessions'
        
        try:
            table = self.dynamodb.Table(table_name)
            table.load()
            logger.info(f"✅ Connected to {table_name}")
            return table
        except:
            try:
                table = self.dynamodb.create_table(
                    TableName=table_name,
                    KeySchema=[
                        {'AttributeName': 'username', 'KeyType': 'HASH'}
                    ],
                    AttributeDefinitions=[
                        {'AttributeName': 'username', 'AttributeType': 'S'}
                    ],
                    BillingMode='PAY_PER_REQUEST'
                )
                table.wait_until_exists()
                logger.info(f"✅ Created {table_name}")
                return table
            except Exception as e:
                logger.error(f"❌ Failed to create {table_name}: {e}")
                return None
    
    def start_monitoring_threads(self):
        """Start background monitoring threads"""
        # Thread to monitor main session table
        monitor_thread = threading.Thread(target=self._monitor_session_activity, daemon=True)
        monitor_thread.start()
        
        # Thread to cleanup expired sessions
        cleanup_thread = threading.Thread(target=self._cleanup_expired_sessions, daemon=True)
        cleanup_thread.start()
        
        logger.info("✅ Started monitoring threads")
    
    def _monitor_session_activity(self):
        """Monitor the main session table for real activity"""
        last_scan_time = datetime.utcnow()
        
        while True:
            try:
                current_time = datetime.utcnow()
                
                # Scan for recent activity (last 2 minutes)
                cutoff_time = current_time - timedelta(minutes=2)
                
                if self.session_table:
                    # Get all recent sessions
                    response = self.session_table.scan()
                    
                    active_users = {}
                    
                    for item in response.get('Items', []):
                        try:
                            username = item.get('user_id')
                            if not username:
                                continue
                            
                            # Get the most recent timestamp
                            latest_timestamp = None
                            
                            # Check various timestamp fields
                            for field in ['timestamp', 'last_activity', 'created_at']:
                                if field in item:
                                    timestamp_value = item[field]
                                    
                                    # Handle different timestamp formats
                                    if isinstance(timestamp_value, str):
                                        timestamp_str = timestamp_value
                                    elif isinstance(timestamp_value, (int, float, Decimal)):
                                        # Unix timestamp in milliseconds
                                        timestamp_str = datetime.fromtimestamp(float(timestamp_value) / 1000).isoformat()
                                    else:
                                        continue
                                    
                                    if not latest_timestamp or timestamp_str > latest_timestamp:
                                        latest_timestamp = timestamp_str
                            
                            if latest_timestamp:
                                # Parse timestamp
                                try:
                                    if '+' in latest_timestamp:
                                        activity_dt = datetime.fromisoformat(latest_timestamp.replace('Z', '+00:00'))
                                    else:
                                        activity_dt = datetime.fromisoformat(latest_timestamp)
                                    
                                    if activity_dt.tzinfo:
                                        activity_dt = activity_dt.replace(tzinfo=None)
                                    
                                    # Check if activity is recent (within last 5 minutes)
                                    time_diff = (current_time - activity_dt).total_seconds()
                                    
                                    if time_diff < 300:  # 5 minutes
                                        # User is active
                                        if username not in active_users or latest_timestamp > active_users[username]['last_activity']:
                                            active_users[username] = {
                                                'username': username,
                                                'status': 'online',
                                                'last_activity': latest_timestamp,
                                                'session_duration': self._calculate_session_duration(item),
                                                'message_count': self._count_user_messages(username),
                                                'last_seen': current_time.isoformat()
                                            }
                                
                                except Exception as e:
                                    logger.debug(f"Error parsing timestamp for {username}: {e}")
                                    continue
                        
                        except Exception as e:
                            logger.debug(f"Error processing item: {e}")
                            continue
                    
                    # Update cache and active sessions table
                    with self.cache_lock:
                        self.active_users_cache = active_users
                    
                    # Update active sessions table
                    self._update_active_sessions_table(active_users)
                    
                    logger.info(f"📊 Monitoring: {len(active_users)} active users detected")
                
                # Sleep for 30 seconds before next scan
                time.sleep(30)
                
            except Exception as e:
                logger.error(f"❌ Error in monitoring thread: {e}")
                time.sleep(60)  # Wait longer on error
    
    def _count_user_messages(self, username: str) -> int:
        """Count messages for a user"""
        try:
            if not self.session_table:
                return 0
            
            from boto3.dynamodb.conditions import Key
            
            response = self.session_table.query(
                KeyConditionExpression=Key("user_id").eq(username)
            )
            
            message_count = 0
            for item in response.get('Items', []):
                if 'message_data' in item or 'content' in item:
                    message_count += 1
            
            return message_count
            
        except Exception as e:
            logger.debug(f"Error counting messages for {username}: {e}")
            return 0
    
    def _calculate_session_duration(self, session_item: Dict) -> str:
        """Calculate session duration from session item"""
        try:
            created_time = None
            latest_time = None
            
            # Find earliest and latest timestamps
            for field in ['created_at', 'timestamp', 'last_activity']:
                if field in session_item:
                    timestamp_value = session_item[field]
                    
                    if isinstance(timestamp_value, str):
                        timestamp_str = timestamp_value
                    elif isinstance(timestamp_value, (int, float, Decimal)):
                        timestamp_str = datetime.fromtimestamp(float(timestamp_value) / 1000).isoformat()
                    else:
                        continue
                    
                    if not created_time or timestamp_str < created_time:
                        created_time = timestamp_str
                    if not latest_time or timestamp_str > latest_time:
                        latest_time = timestamp_str
            
            if created_time and latest_time:
                created_dt = datetime.fromisoformat(created_time.replace('Z', '+00:00').replace('+00:00', ''))
                latest_dt = datetime.fromisoformat(latest_time.replace('Z', '+00:00').replace('+00:00', ''))
                
                duration = latest_dt - created_dt
                total_seconds = int(duration.total_seconds())
                
                if total_seconds < 60:
                    return f"{total_seconds}s"
                elif total_seconds < 3600:
                    return f"{total_seconds // 60}m"
                else:
                    hours = total_seconds // 3600
                    minutes = (total_seconds % 3600) // 60
                    return f"{hours}h {minutes}m"
            
            return "0m"
            
        except Exception as e:
            logger.debug(f"Error calculating duration: {e}")
            return "0m"
    
    def _update_active_sessions_table(self, active_users: Dict):
        """Update the active sessions table"""
        if not self.active_sessions_table:
            return
        
        try:
            current_time = datetime.utcnow().isoformat()
            
            # Update active users
            for username, user_data in active_users.items():
                self.active_sessions_table.put_item(
                    Item={
                        'username': username,
                        'status': 'online',
                        'last_activity': user_data['last_activity'],
                        'session_duration': user_data['session_duration'],
                        'message_count': user_data['message_count'],
                        'updated_at': current_time,
                        'ttl': int((datetime.utcnow() + timedelta(minutes=10)).timestamp())
                    }
                )
            
        except Exception as e:
            logger.error(f"❌ Error updating active sessions table: {e}")
    
    def _cleanup_expired_sessions(self):
        """Cleanup expired sessions"""
        while True:
            try:
                current_time = datetime.utcnow()
                
                # Clean up cache
                with self.cache_lock:
                    expired_users = []
                    for username, user_data in list(self.active_users_cache.items()):
                        try:
                            last_seen = datetime.fromisoformat(user_data['last_seen'])
                            if (current_time - last_seen).total_seconds() > 600:  # 10 minutes
                                expired_users.append(username)
                        except:
                            expired_users.append(username)
                    
                    for username in expired_users:
                        del self.active_users_cache[username]
                        logger.info(f"🧹 Cleaned up expired session for {username}")
                
                # Sleep for 2 minutes before next cleanup
                time.sleep(120)
                
            except Exception as e:
                logger.error(f"❌ Error in cleanup thread: {e}")
                time.sleep(300)  # Wait longer on error
    
    def get_realtime_active_users(self) -> List[Dict]:
        """Get current active users from cache"""
        with self.cache_lock:
            return list(self.active_users_cache.values())
    
    def get_user_activity_details(self, username: str) -> Optional[Dict]:
        """Get detailed activity for a specific user"""
        try:
            if not self.session_table:
                return None
            
            from boto3.dynamodb.conditions import Key
            
            response = self.session_table.query(
                KeyConditionExpression=Key("user_id").eq(username)
            )
            
            sessions = response.get('Items', [])
            if not sessions:
                return None
            
            # Analyze user activity
            total_messages = 0
            total_sessions = len(sessions)
            latest_activity = None
            earliest_activity = None
            
            for session in sessions:
                if 'message_data' in session or 'content' in session:
                    total_messages += 1
                
                # Get timestamps
                for field in ['timestamp', 'last_activity', 'created_at']:
                    if field in session:
                        timestamp_value = session[field]
                        
                        if isinstance(timestamp_value, str):
                            timestamp_str = timestamp_value
                        elif isinstance(timestamp_value, (int, float, Decimal)):
                            timestamp_str = datetime.fromtimestamp(float(timestamp_value) / 1000).isoformat()
                        else:
                            continue
                        
                        if not latest_activity or timestamp_str > latest_activity:
                            latest_activity = timestamp_str
                        if not earliest_activity or timestamp_str < earliest_activity:
                            earliest_activity = timestamp_str
            
            return {
                'username': username,
                'total_messages': total_messages,
                'total_sessions': total_sessions,
                'latest_activity': latest_activity,
                'earliest_activity': earliest_activity,
                'is_currently_active': username in self.active_users_cache
            }
            
        except Exception as e:
            logger.error(f"❌ Error getting user activity details: {e}")
            return None

# Global instance
advanced_tracker = AdvancedSessionTracker()

if __name__ == "__main__":
    print("🚀 Advanced Session Tracker Started")
    print("Monitoring real chatbot usage...")
    
    # Keep running
    try:
        while True:
            active_users = advanced_tracker.get_realtime_active_users()
            print(f"📊 Currently active users: {len(active_users)}")
            for user in active_users:
                print(f"   - {user['username']}: {user['message_count']} messages, {user['session_duration']} duration")
            time.sleep(60)
    except KeyboardInterrupt:
        print("Stopping tracker...")
