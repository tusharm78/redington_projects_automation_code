import boto3
import json
import uuid
import os
from dotenv import load_dotenv
from datetime import datetime, timezone
from typing import List, Dict, Any, Optional
from boto3.dynamodb.conditions import Key

# Load environment variables
load_dotenv()

class SessionManager:
    """DynamoDB-based session and chat history manager"""
    
    def __init__(self):
        self.dynamodb = boto3.resource("dynamodb", region_name="us-east-1")
        self.table_name = "user_chat_sessions"
        
        # Always initialize memory storage for fallback
        self.memory_sessions = {}
        self.memory_messages = {}
        
        try:
            self.table = self.dynamodb.Table(self.table_name)
            # Test table access
            self.table.load()
            print(f"✅ Connected to DynamoDB table: {self.table_name}")
        except Exception as e:
            print(f"⚠️ DynamoDB table not accessible: {e}")
            print("🔄 Running in memory-only mode")
            self.table = None
    
    def _get_timestamp(self) -> str:
        """Get current timestamp in ISO format"""
        return datetime.now(timezone.utc).isoformat()
    
    async def create_session(self, username: str, title: str = None) -> str:
        """Create a new chat session"""
        session_id = str(uuid.uuid4())
        timestamp = self._get_timestamp()
        
        session_data = {
            "session_id": session_id,
            "username": username,
            "title": title or f"Chat Session {datetime.now().strftime('%Y-%m-%d %H:%M')}",
            "created_at": timestamp,
            "updated_at": timestamp,
            "message_count": 0,
            "last_message": ""
        }
        
        if self.table:
            try:
                # Save session metadata using correct keys
                self.table.put_item(
                    Item={
                        "user_id": username,
                        "chat_id": f"SESSION#{session_id}",
                        "session_data": json.dumps(session_data),
                        "created_at": timestamp,
                        "updated_at": timestamp,
                        "session_id": session_id,
                        "title": session_data["title"]
                    }
                )
                print(f"✅ Session created in DynamoDB: {session_id}")
            except Exception as e:
                print(f"DynamoDB error creating session: {e}")
                self._save_session_memory(username, session_id, session_data)
        else:
            self._save_session_memory(username, session_id, session_data)
        
        return session_id
    
    def _save_session_memory(self, username: str, session_id: str, session_data: Dict[str, Any]):
        """Save session to memory storage"""
        if username not in self.memory_sessions:
            self.memory_sessions[username] = {}
        
        self.memory_sessions[username][session_id] = session_data
    
    async def save_message(self, username: str, session_id: str, role: str, content: str, model: str = None) -> str:
        """Save a chat message"""
        message_id = str(uuid.uuid4())
        timestamp = self._get_timestamp()
        
        message_data = {
            "message_id": message_id,
            "session_id": session_id,
            "username": username,
            "role": role,
            "content": content,
            "model": model,
            "timestamp": timestamp
        }
        
        if self.table:
            try:
                # Save message using correct keys
                self.table.put_item(
                    Item={
                        "user_id": username,
                        "chat_id": f"MESSAGE#{session_id}#{message_id}",
                        "message_data": json.dumps(message_data),
                        "role": role,
                        "content": content,
                        "timestamp": timestamp,
                        "session_id": session_id,
                        "message_id": message_id
                    }
                )
                
                # Update session with last message info
                try:
                    self.table.update_item(
                        Key={
                            "user_id": username,
                            "chat_id": f"SESSION#{session_id}"
                        },
                        UpdateExpression="SET updated_at = :timestamp, last_message = :last_msg, message_count = if_not_exists(message_count, :zero) + :inc",
                        ExpressionAttributeValues={
                            ":timestamp": timestamp,
                            ":last_msg": content[:100] + "..." if len(content) > 100 else content,
                            ":zero": 0,
                            ":inc": 1
                        }
                    )
                except Exception as update_error:
                    print(f"Warning: Could not update session metadata: {update_error}")
                
                print(f"✅ Message saved to DynamoDB: {message_id}")
            except Exception as e:
                print(f"DynamoDB error saving message: {e}")
                self._save_message_memory(username, session_id, message_data)
        else:
            self._save_message_memory(username, session_id, message_data)
        
        return message_id
    
    def _save_message_memory(self, username: str, session_id: str, message_data: Dict[str, Any]):
        """Save message to memory storage"""
        if session_id not in self.memory_messages:
            self.memory_messages[session_id] = []
        
        self.memory_messages[session_id].append(message_data)
        
        # Update session metadata in memory
        if username in self.memory_sessions and session_id in self.memory_sessions[username]:
            session = self.memory_sessions[username][session_id]
            session["updated_at"] = message_data["timestamp"]
            session["message_count"] = session.get("message_count", 0) + 1
            session["last_message"] = message_data["content"][:100] + "..." if len(message_data["content"]) > 100 else message_data["content"]
    
    async def get_session_messages(self, session_id: str) -> List[Dict[str, Any]]:
        """Get all messages for a session"""
        if self.table:
            try:
                # Scan for messages with this session_id
                response = self.table.scan(
                    FilterExpression="attribute_exists(session_id) AND session_id = :sid",
                    ExpressionAttributeValues={":sid": session_id}
                )
                
                messages = []
                for item in response.get("Items", []):
                    if "message_data" in item:
                        message_data = json.loads(item["message_data"])
                        messages.append({
                            "id": message_data["message_id"],
                            "role": message_data["role"],
                            "content": message_data["content"],
                            "timestamp": message_data["timestamp"],
                            "model": message_data.get("model", "")
                        })
                    elif "role" in item and "content" in item:
                        messages.append({
                            "id": item.get("message_id", str(uuid.uuid4())),
                            "role": item["role"],
                            "content": item["content"],
                            "timestamp": item.get("timestamp", ""),
                            "model": item.get("model", "")
                        })
                
                messages.sort(key=lambda x: x["timestamp"])
                print(f"✅ Retrieved {len(messages)} messages for session {session_id}")
                return messages
                
            except Exception as e:
                print(f"DynamoDB error getting messages: {e}")
        
        # Memory fallback
        memory_messages = [
            {
                "id": msg["message_id"],
                "role": msg["role"],
                "content": msg["content"],
                "timestamp": msg["timestamp"],
                "model": msg.get("model", "")
            }
            for msg in self.memory_messages.get(session_id, [])
        ]
        print(f"📝 Retrieved {len(memory_messages)} messages from memory for session {session_id}")
        return memory_messages
    
    async def get_user_sessions(self, username: str) -> List[Dict[str, Any]]:
        """Get all sessions for a user - FILTERED to only show sessions with messages"""
        if self.table:
            try:
                # Query by user_id only, then filter in Python
                response = self.table.query(
                    KeyConditionExpression=Key("user_id").eq(username)
                )
                
                sessions = []
                for item in response.get("Items", []):
                    chat_id = item.get("chat_id", "")
                    if chat_id.startswith("SESSION#"):
                        # ✅ MINIMAL FIX: Only include sessions with messages
                        message_count = item.get("message_count", 0)
                        if message_count > 0:  # Filter out empty sessions
                            if "session_data" in item:
                                session_data = json.loads(item["session_data"])
                                sessions.append({
                                    "id": session_data["session_id"],
                                    "name": session_data["title"],
                                    "created_at": session_data["created_at"],
                                    "updated_at": session_data["updated_at"],
                                    "message_count": session_data.get("message_count", 0),
                                    "last_message": session_data.get("last_message", "")
                                })
                            elif "session_id" in item and "title" in item:
                                sessions.append({
                                    "id": item["session_id"],
                                    "name": item["title"],
                                    "created_at": item.get("created_at", ""),
                                    "updated_at": item.get("updated_at", ""),
                                    "message_count": item.get("message_count", 0),
                                    "last_message": item.get("last_message", "")
                                })
                
                sessions.sort(key=lambda x: x["updated_at"], reverse=True)
                print(f"✅ Retrieved {len(sessions)} sessions with messages for user {username}")
                return sessions
                
            except Exception as e:
                print(f"DynamoDB error getting sessions: {e}")
        
        # Memory fallback - also filter empty sessions
        user_sessions = self.memory_sessions.get(username, {})
        memory_sessions = [
            {
                "id": session_id,
                "name": session_data.get("title", "Untitled Session"),
                "created_at": session_data.get("created_at", ""),
                "updated_at": session_data.get("updated_at", ""),
                "message_count": session_data.get("message_count", 0),
                "last_message": session_data.get("last_message", "")
            }
            for session_id, session_data in user_sessions.items()
            if session_data.get("message_count", 0) > 0  # Filter out empty sessions
        ]
        memory_sessions.sort(key=lambda x: x["updated_at"], reverse=True)
        print(f"📝 Retrieved {len(memory_sessions)} sessions with messages from memory for user {username}")
        return memory_sessions
    
    async def update_session_title(self, username: str, session_id: str, title: str):
        """Update session title"""
        if self.table:
            try:
                self.table.update_item(
                    Key={
                        "user_id": username,
                        "chat_id": f"SESSION#{session_id}"
                    },
                    UpdateExpression="SET title = :title, updated_at = :timestamp",
                    ExpressionAttributeValues={
                        ":title": title,
                        ":timestamp": self._get_timestamp()
                    }
                )
                print(f"✅ Session title updated: {session_id}")
            except Exception as e:
                print(f"DynamoDB error updating session: {e}")
                if username in self.memory_sessions and session_id in self.memory_sessions[username]:
                    self.memory_sessions[username][session_id]["title"] = title
                    self.memory_sessions[username][session_id]["updated_at"] = self._get_timestamp()
        else:
            if username in self.memory_sessions and session_id in self.memory_sessions[username]:
                self.memory_sessions[username][session_id]["title"] = title
                self.memory_sessions[username][session_id]["updated_at"] = self._get_timestamp()
    
    async def delete_session(self, username: str, session_id: str):
        """Delete a session and all its messages"""
        if self.table:
            try:
                response = self.table.query(
                    KeyConditionExpression=Key("user_id").eq(username)
                )
                
                with self.table.batch_writer() as batch:
                    for item in response.get("Items", []):
                        chat_id = item.get("chat_id", "")
                        if chat_id.startswith(f"SESSION#{session_id}") or chat_id.startswith(f"MESSAGE#{session_id}"):
                            batch.delete_item(
                                Key={
                                    "user_id": username,
                                    "chat_id": chat_id
                                }
                            )
                
                print(f"✅ Session deleted: {session_id}")
            except Exception as e:
                print(f"DynamoDB error deleting session: {e}")
                if username in self.memory_sessions and session_id in self.memory_sessions[username]:
                    del self.memory_sessions[username][session_id]
                if session_id in self.memory_messages:
                    del self.memory_messages[session_id]
        else:
            if username in self.memory_sessions and session_id in self.memory_sessions[username]:
                del self.memory_sessions[username][session_id]
            if session_id in self.memory_messages:
                del self.memory_messages[session_id]
