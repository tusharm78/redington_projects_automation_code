#!/bin/bash

# Stop Enhanced Bedrock Backend with Cognito
echo "🛑 Stopping Redington AI Bot - Enhanced Bedrock with Cognito"
echo "============================================================"

if [ -f "enhanced_cognito.pid" ]; then
    PID=$(cat enhanced_cognito.pid)
    if ps -p $PID > /dev/null 2>&1; then
        echo "🔄 Stopping backend (PID: $PID)..."
        kill $PID
        
        # Wait for graceful shutdown
        for i in {1..10}; do
            if ! ps -p $PID > /dev/null 2>&1; then
                echo "✅ Backend stopped successfully"
                rm -f enhanced_cognito.pid
                exit 0
            fi
            sleep 1
        done
        
        # Force kill if still running
        echo "⚠️  Forcing shutdown..."
        kill -9 $PID 2>/dev/null
        rm -f enhanced_cognito.pid
        echo "✅ Backend force stopped"
    else
        echo "⚠️  Backend not running (stale PID file)"
        rm -f enhanced_cognito.pid
    fi
else
    echo "⚠️  No PID file found - backend may not be running"
    
    # Try to kill any running instances
    pkill -f "enhanced_bedrock_main" 2>/dev/null && echo "🧹 Cleaned up any running instances"
fi
