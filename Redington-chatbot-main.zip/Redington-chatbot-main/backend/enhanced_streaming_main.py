import asyncio
import time
import re
from fastapi import FastAPI, HTTPException, Depends, status
from fastapi.middleware.cors import CORSMiddleware
from fastapi.security import HTTPBearer, HTTPAuthorizationCredentials
from fastapi.responses import StreamingResponse
from pydantic import BaseModel
import logging
import jwt
from jwt.exceptions import ExpiredSignatureError, InvalidTokenError
from datetime import datetime, timedelta
from typing import AsyncGenerator, Dict, List, Optional
import json

# Setup logging
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

# Create FastAPI application
app = FastAPI(
    title="Redington AI Bot - Enhanced Streaming",
    description="Enhanced streaming with structured markdown formatting",
    version="2.0.0"
)

# Add CORS middleware
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# Security
security = HTTPBearer()
SECRET_KEY = "demo-secret-key-for-enhanced-streaming"

# Pydantic models
class AuthRequest(BaseModel):
    username: str
    password: str

class AuthResponse(BaseModel):
    access_token: str
    token_type: str
    expires_in: int

class UserInfo(BaseModel):
    username: str
    email: str = ""

class ChatRequest(BaseModel):
    message: str
    conversation_id: str = "default"
    session_id: str = "default"
    model: str = "enhanced-ai"

class StreamChunk(BaseModel):
    chunk: str
    is_complete: bool = False
    metadata: Optional[Dict] = None

# Demo users
demo_users = {
    "demo": "demo123",
    "admin": "admin123",
    "user": "password"
}

def create_access_token(username: str):
    """Create a JWT token for demo purposes"""
    expire = datetime.utcnow() + timedelta(hours=24)
    payload = {
        "username": username,
        "exp": expire,
        "iat": datetime.utcnow()
    }
    return jwt.encode(payload, SECRET_KEY, algorithm="HS256")

def verify_token(token: str):
    """Verify JWT token"""
    try:
        payload = jwt.decode(token, SECRET_KEY, algorithms=["HS256"])
        return payload
    except ExpiredSignatureError:
        raise HTTPException(status_code=401, detail="Token expired")
    except InvalidTokenError:
        raise HTTPException(status_code=401, detail="Invalid token")

async def get_current_user(credentials: HTTPAuthorizationCredentials = Depends(security)):
    """Get current user from token"""
    payload = verify_token(credentials.credentials)
    return payload.get("username")

class MarkdownStreamFormatter:
    """Enhanced formatter for streaming markdown responses"""
    
    def __init__(self):
        self.response_templates = {
            "redington_overview": {
                "summary": "## Redington Technology Solutions Overview\n\n",
                "content": [
                    "**Redington** is a leading technology distributor and solutions provider in the Asia-Pacific region.\n\n",
                    "### Our Core Services\n\n",
                    "- **Cloud Computing Solutions** - Scalable and flexible infrastructure\n",
                    "- **Advanced Cybersecurity Services** - Comprehensive protection for digital assets\n",
                    "- **Data Analytics & Business Intelligence** - Data-driven decision making tools\n",
                    "- **Digital Transformation Consulting** - Modernizing business operations\n",
                    "- **Enterprise Software Solutions** - Enhanced productivity platforms\n",
                    "- **24/7 Technical Support** - Seamless operations and maintenance\n\n",
                    "### Key Benefits\n\n",
                    "1. **Expertise** - Deep technical knowledge across multiple domains\n",
                    "2. **Partnership** - Strong relationships with leading technology vendors\n",
                    "3. **Innovation** - Cutting-edge solutions for modern business challenges\n",
                    "4. **Support** - Comprehensive training and certification programs\n\n",
                    "### Industry Focus\n\n",
                    "We serve businesses across various industries including:\n\n",
                    "```\n",
                    "• Financial Services    • Healthcare\n",
                    "• Manufacturing        • Education\n",
                    "• Retail & E-commerce  • Government\n",
                    "• Telecommunications   • Media & Entertainment\n",
                    "```\n\n",
                    "**Ready to transform your business?** Contact us to learn how Redington can help you leverage technology for growth and success."
                ]
            },
            "services_detailed": {
                "summary": "## Comprehensive Technology Services\n\n",
                "content": [
                    "### 🌩️ Cloud Computing Solutions\n\n",
                    "**Infrastructure as a Service (IaaS)**\n",
                    "- Scalable virtual machines and storage\n",
                    "- High-availability architectures\n",
                    "- Disaster recovery solutions\n\n",
                    "**Platform as a Service (PaaS)**\n",
                    "- Application development platforms\n",
                    "- Database management services\n",
                    "- Integration and API management\n\n",
                    "**Software as a Service (SaaS)**\n",
                    "- Business productivity suites\n",
                    "- Customer relationship management\n",
                    "- Enterprise resource planning\n\n",
                    "### 🔒 Advanced Cybersecurity Services\n\n",
                    "**Threat Detection & Response**\n",
                    "```yaml\n",
                    "Security Operations Center (SOC):\n",
                    "  - 24/7 monitoring\n",
                    "  - Incident response\n",
                    "  - Threat intelligence\n",
                    "  - Forensic analysis\n",
                    "```\n\n",
                    "**Identity & Access Management**\n",
                    "- Multi-factor authentication\n",
                    "- Single sign-on solutions\n",
                    "- Privileged access management\n",
                    "- Zero-trust architecture\n\n",
                    "### 📊 Data Analytics & Business Intelligence\n\n",
                    "**Data Processing Pipeline**\n",
                    "1. **Data Collection** - Multi-source data ingestion\n",
                    "2. **Data Processing** - ETL/ELT operations\n",
                    "3. **Data Storage** - Data lakes and warehouses\n",
                    "4. **Data Analysis** - Advanced analytics and ML\n",
                    "5. **Data Visualization** - Interactive dashboards\n\n",
                    "**Key Technologies**\n",
                    "- Apache Spark & Hadoop\n",
                    "- Microsoft Power BI\n",
                    "- Tableau & Qlik\n",
                    "- AWS Analytics Suite\n",
                    "- Google Cloud AI/ML\n\n",
                    "> **Success Story**: Helped a major retailer increase sales by 25% through predictive analytics and customer behavior insights."
                ]
            },
            "greeting": {
                "summary": "# Welcome to Redington AI Assistant! 👋\n\n",
                "content": [
                    "Hello **{username}**! I'm your dedicated AI assistant for all things Redington.\n\n",
                    "## How I Can Help You\n\n",
                    "### 🔍 Information & Guidance\n",
                    "- Technology solutions overview\n",
                    "- Service capabilities and features\n",
                    "- Industry best practices\n",
                    "- Implementation strategies\n\n",
                    "### 💡 Quick Start Options\n\n",
                    "**Popular Topics:**\n",
                    "- `Tell me about Redington services`\n",
                    "- `Cloud computing solutions`\n",
                    "- `Cybersecurity offerings`\n",
                    "- `Digital transformation consulting`\n",
                    "- `Data analytics capabilities`\n\n",
                    "### 📋 Response Format\n\n",
                    "All my responses are structured with:\n",
                    "- **Clear headings** for easy navigation\n",
                    "- **Bullet points** for key information\n",
                    "- **Code blocks** for technical details\n",
                    "- **Tables** for comparisons\n",
                    "- **Quotes** for important insights\n\n",
                    "---\n\n",
                    "**What would you like to know about Redington's technology solutions?**"
                ]
            },
            "default": {
                "summary": "## Redington AI Response\n\n",
                "content": [
                    "Thank you for your question, **{username}**.\n\n",
                    "### Understanding Your Query\n\n",
                    "I've analyzed your message: *\"{user_message}\"*\n\n",
                    "### Redington's Approach\n\n",
                    "As your technology partner, Redington offers:\n\n",
                    "1. **Comprehensive Solutions** - End-to-end technology services\n",
                    "2. **Expert Consultation** - Deep industry knowledge and experience\n",
                    "3. **Proven Results** - Track record of successful implementations\n",
                    "4. **Ongoing Support** - Continuous partnership beyond deployment\n\n",
                    "### Next Steps\n\n",
                    "```markdown\n",
                    "💡 Recommendation:\n",
                    "   Contact our solutions team for a detailed consultation\n",
                    "   tailored to your specific requirements.\n",
                    "```\n\n",
                    "**Would you like more specific information about any of our services?**"
                ]
            }
        }
    
    def get_response_template(self, user_message: str, username: str) -> Dict:
        """Select appropriate response template based on user message"""
        message_lower = user_message.lower()
        
        if any(word in message_lower for word in ["hello", "hi", "hey", "greetings"]):
            template = self.response_templates["greeting"]
        elif any(word in message_lower for word in ["redington", "company", "about", "overview"]):
            template = self.response_templates["redington_overview"]
        elif any(word in message_lower for word in ["service", "services", "offering", "solution"]):
            template = self.response_templates["services_detailed"]
        else:
            template = self.response_templates["default"]
        
        # Format template with user data
        formatted_content = []
        for content_part in template["content"]:
            formatted_part = content_part.format(
                username=username,
                user_message=user_message
            )
            formatted_content.append(formatted_part)
        
        return {
            "summary": template["summary"].format(username=username),
            "content": formatted_content
        }
    
    def create_streaming_chunks(self, template: Dict) -> List[str]:
        """Create properly formatted streaming chunks"""
        chunks = []
        
        # Start with summary
        chunks.append(template["summary"])
        
        # Add content in meaningful chunks
        for content_part in template["content"]:
            # Split long content into smaller, meaningful chunks
            if len(content_part) > 200:
                # Split by sentences or logical breaks
                sentences = re.split(r'(?<=[.!?])\s+', content_part)
                current_chunk = ""
                
                for sentence in sentences:
                    if len(current_chunk + sentence) > 150:
                        if current_chunk:
                            chunks.append(current_chunk.strip() + "\n")
                        current_chunk = sentence + " "
                    else:
                        current_chunk += sentence + " "
                
                if current_chunk:
                    chunks.append(current_chunk.strip() + "\n")
            else:
                chunks.append(content_part)
        
        return chunks

# Initialize formatter
formatter = MarkdownStreamFormatter()

async def generate_streaming_response(
    user_message: str, 
    username: str
) -> AsyncGenerator[str, None]:
    """Generate streaming response with proper markdown formatting"""
    
    try:
        # Get response template
        template = formatter.get_response_template(user_message, username)
        
        # Create streaming chunks
        chunks = formatter.create_streaming_chunks(template)
        
        # Stream chunks with appropriate delays
        for i, chunk in enumerate(chunks):
            # Vary delay based on chunk type and length
            if chunk.startswith('#'):  # Headers
                delay = 0.1
            elif chunk.startswith('```'):  # Code blocks
                delay = 0.15
            elif chunk.startswith('-') or chunk.startswith('*'):  # Lists
                delay = 0.08
            else:  # Regular text
                delay = 0.05 + (len(chunk) / 1000)  # Longer chunks = longer delay
            
            # Send chunk
            chunk_data = {
                "chunk": chunk,
                "is_complete": i == len(chunks) - 1,
                "metadata": {
                    "chunk_index": i,
                    "total_chunks": len(chunks),
                    "timestamp": datetime.now().isoformat()
                }
            }
            
            yield f"data: {json.dumps(chunk_data)}\n\n"
            
            # Add delay between chunks
            await asyncio.sleep(delay)
            
    except Exception as e:
        logger.error(f"Error in streaming response: {e}")
        error_chunk = {
            "chunk": f"\n\n❌ **Error**: Failed to generate response - {str(e)}\n",
            "is_complete": True,
            "metadata": {"error": True}
        }
        yield f"data: {json.dumps(error_chunk)}\n\n"

# API Endpoints
@app.get("/")
async def root():
    return {"message": "Redington AI Bot - Enhanced Streaming", "version": "2.0.0"}

@app.get("/health")
async def health_check():
    return {"status": "healthy", "service": "redington-enhanced-streaming"}

@app.post("/api/v1/auth/login", response_model=AuthResponse)
async def login(auth_request: AuthRequest):
    """Login endpoint"""
    username = auth_request.username
    password = auth_request.password
    
    if username in demo_users and demo_users[username] == password:
        token = create_access_token(username)
        return AuthResponse(
            access_token=token,
            token_type="bearer",
            expires_in=86400
        )
    
    raise HTTPException(
        status_code=status.HTTP_401_UNAUTHORIZED,
        detail="Invalid credentials"
    )

@app.post("/api/v1/auth/logout")
async def logout(current_user: str = Depends(get_current_user)):
    """Logout endpoint"""
    return {"message": "Successfully logged out"}

@app.get("/api/v1/auth/me", response_model=UserInfo)
async def get_user_info(current_user: str = Depends(get_current_user)):
    """Get current user info"""
    return UserInfo(
        username=current_user,
        email=f"{current_user}@redington-demo.com"
    )

@app.post("/api/v1/chat/stream")
async def stream_chat(
    request: ChatRequest,
    current_user: str = Depends(get_current_user)
):
    """Stream chat response with enhanced markdown formatting"""
    
    logger.info(f"Streaming request from {current_user}: {request.message[:100]}...")
    
    return StreamingResponse(
        generate_streaming_response(request.message, current_user),
        media_type="text/plain",
        headers={
            "Cache-Control": "no-cache",
            "Connection": "keep-alive",
            "Access-Control-Allow-Origin": "*",
        }
    )

@app.get("/api/v1/chat/models")
async def get_available_models(current_user: str = Depends(get_current_user)):
    """Get available AI models"""
    return {
        "models": {
            "Claude 3.7 Sonnet": {
                "model_id": "us.anthropic.claude-3-7-sonnet-20250219-v1:0",
                "input_format": "multimodal",
                "thinking": 0,
                "temperature": 1.0,
                "top_p": 1.0,
                "top_k": 500,
                "max_tokens": 64000,
                "memory_window": 10,
                "max_top_k": 500
            },
            "Enhanced AI": {
                "model_id": "enhanced-redington-ai",
                "input_format": "text",
                "thinking": 0,
                "temperature": 0.7,
                "top_p": 0.9,
                "top_k": 250,
                "max_tokens": 4000,
                "memory_window": 10,
                "max_top_k": 500
            }
        },
        "default_model": "Enhanced AI"
    }

@app.get("/api/v1/sessions")
async def get_sessions(current_user: str = Depends(get_current_user)):
    """Get user sessions"""
    return {
        "sessions": [
            {
                "id": "enhanced-session-1",
                "name": "Enhanced Streaming Chat",
                "created_at": datetime.now().isoformat(),
                "updated_at": datetime.now().isoformat()
            }
        ]
    }

@app.get("/api/v1/conversations")
async def get_conversations(current_user: str = Depends(get_current_user)):
    """Get user conversations"""
    return {
        "conversations": [
            {
                "conversation_id": "demo-conversation-1",
                "title": "Enhanced Streaming Demo",
                "created_at": datetime.now().isoformat(),
                "updated_at": datetime.now().isoformat(),
                "message_count": 0
            }
        ]
    }

@app.get("/api/v1/chat/history/{conversation_id}")
async def get_conversation_history(
    conversation_id: str,
    current_user: str = Depends(get_current_user)
):
    """Get conversation history"""
    return {
        "messages": [],
        "conversation_id": conversation_id
    }

@app.post("/api/v1/sessions")
async def create_session(current_user: str = Depends(get_current_user)):
    """Create new session"""
    session_id = f"session-{int(time.time())}"
    return {
        "id": session_id,
        "name": "New Enhanced Chat Session",
        "created_at": datetime.now().isoformat(),
        "updated_at": datetime.now().isoformat()
    }

if __name__ == "__main__":
    import uvicorn
    uvicorn.run(
        "enhanced_streaming_main:app",
        host="0.0.0.0",
        port=8000,
        reload=False,
        log_level="info"
    )
