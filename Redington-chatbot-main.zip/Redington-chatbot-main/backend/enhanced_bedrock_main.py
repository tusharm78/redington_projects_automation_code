import asyncio
import time
import re
import json
import boto3
import os
from dotenv import load_dotenv
from fastapi import FastAPI, HTTPException, Depends, status
from fastapi.middleware.cors import CORSMiddleware
from fastapi.security import HTTPBearer, HTTPAuthorizationCredentials
from fastapi.responses import StreamingResponse
from pydantic import BaseModel
import logging
import jwt
from jwt.exceptions import ExpiredSignatureError, InvalidTokenError
from datetime import datetime, timedelta
from typing import AsyncGenerator, Dict, List, Optional

# Load environment variables
load_dotenv()

# Setup logging first
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

# Import our custom modules
from cognito_auth import CognitoAuth
from session_manager import SessionManager

# Import OTI costing module
try:
    from oti_routes import router as oti_router
    OTI_AVAILABLE = True
    logger.info("✅ OTI costing module loaded successfully")
except ImportError as e:
    OTI_AVAILABLE = False
    logger.warning(f"⚠️ OTI costing module not available: {e}")

# Import proposal integration service
try:
    from proposal_integration import proposal_integration
    PROPOSAL_COSTING_AVAILABLE = True
    logger.info("✅ Proposal costing integration loaded successfully")
except ImportError as e:
    PROPOSAL_COSTING_AVAILABLE = False
    logger.warning(f"⚠️ Proposal costing integration not available: {e}")

# Create FastAPI application
app = FastAPI(
    title="Redington AI Bot - Enhanced Bedrock with Cognito & OTI Costing",
    description="Real AWS Bedrock Claude integration with Cognito auth, session management, and OTI costing",
    version="4.1.0"
)

# Add CORS middleware
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# Security
security = HTTPBearer()

# Pydantic models
class AuthRequest(BaseModel):
    username: str
    password: str

class AuthResponse(BaseModel):
    access_token: str
    token_type: str
    expires_in: int
    user_info: Optional[Dict] = None

class UserInfo(BaseModel):
    username: str
    email: str = ""
    sub: str = ""

class ChatRequest(BaseModel):
    message: str
    conversation_id: str = "default"
    session_id: str = "default"
    model: str = "claude-3-7-sonnet"

class StreamChunk(BaseModel):
    chunk: str
    is_complete: bool = False
    metadata: Optional[Dict] = None

class SessionCreate(BaseModel):
    title: str = None

class SessionUpdate(BaseModel):
    title: str

# Initialize services
cognito_auth = CognitoAuth()
session_manager = SessionManager()

async def get_current_user(credentials: HTTPAuthorizationCredentials = Depends(security)):
    """Get current user from Cognito token or fallback"""
    token = credentials.credentials
    
    try:
        # Try Cognito first
        user_info = await cognito_auth.verify_token(token)
        return user_info['username']
    except:
        try:
            # Fallback to demo JWT
            user_info = cognito_auth.verify_fallback_token(token)
            return user_info['username']
        except:
            raise HTTPException(
                status_code=status.HTTP_401_UNAUTHORIZED,
                detail="Invalid or expired token"
            )

class BedrockStreamingIntegration:
    """AWS Bedrock Claude integration with enhanced streaming and session management"""
    
    def __init__(self):
        self.bedrock_client = None
        self.model_id = "us.anthropic.claude-3-7-sonnet-20250219-v1:0"
        self.base_system_prompt = """You are a helpful AI assistant for Redington technology solutions for **Redington**. You help users with technology questions and can create proposals when specifically requested for prospective clients and new business use cases. You will follow a well-defined structure, centering on the client's specific requirements and the proposed solution.

---
**Proposal Guidelines:**

**Customer Placeholders:**

* Wherever names such as Customer Name, Services Head, Presales/Technical Head, Enterprise Sales, or Technical Contact are to be included, insert placeholders in angle brackets, such as:
  `<Customer Name>`, `<Services Head>`, etc.
* Do not insert any actual names or contact details. Leave these fields blank for manual input later.
* Proposal content should be presented in **tabular format** wherever applicable.

**PROPOSAL DETAILS SECTION:**
This section should include:

* Proposal Title
* Services Head (Placeholder)
* Presales/Technical Head (Placeholder)
* Enterprise Sales (Placeholder)
* Technical Contact (Placeholder)
* Proposal Creation Date
* Proposal Validity
* Proposal Type
* Commercial Currency

**TABLE OF CONTENTS:**

* Provide a structured list of all proposal sections.
* Maintain the following formatting:

  * Main Section Headings: **Bold, Uppercase, Numbered (e.g., 1. INTRODUCTION)**
  * Subheadings: **Bold and Capitalized (e.g., 1.1 Overview)**
  * Sub-subheadings: *Italicized with sentence case (e.g., 1.1.1 Key features)*
  * Follow a consistent heading hierarchy throughout.

**EXECUTIVE SUMMARY:**

* Introduction and gratitude
* Key benefits of the proposed solution
* Summary of the client's main requirements
* A call to schedule further discussion

**STATED REQUIREMENT:**

* A detailed paragraph outlining the client's problem and business challenge
* A list of key requirements shared by the customer (in bullet points)

**SUCCESS CRITERIA:**

* List measurable outcomes in bullet format that define success and demonstrate how the solution addresses key pain points

**PROPOSED SOLUTION:**

* Start by summarizing the client's initial issue and the goal they want to achieve
* Break down the solution into multiple subsections with relevant bullet points under each:

  * Account Access
  * Assessment
  * Compute Considerations
  * Security
  * Optimizing Resource Management
  * Enhancing Observability, Logging, and Monitoring
  * Storage
  * Backup

**PROPOSED ARCHITECTURE:**

* Include a high-level design of the architecture (e.g., DNS, CDN, Load Balancer, etc.)
* Add descriptive content that can later be translated into an actual diagram (e.g., in Draw.io)

**SCOPE OF WORK:**

* Provide a detailed list of all tasks, activities, and deliverables for the project
* Cover each phase with specific descriptions, expected outcomes, and assigned responsibilities
* Include granular technical details, such as:

  * Account creation
  * VPC setup
  * IAM configuration
  * Service configuration based on the use case
  * Parameter or setting-level configurations
* Clarify which configurations can be done directly and which require custom implementation (e.g., AWS Lambda@Edge), with examples if possible

**TESTING:**

* Indicate responsibilities (most of which are client-driven)

**RACI MATRIX:**

* Define roles and responsibilities between Redington and the client

**OUT OF SCOPE:**

* Clearly specify exclusions from the engagement

**GENERAL ASSUMPTIONS & DEPENDENCIES:**

* Outline assumptions and dependencies on the client side

**PROJECT TIMELINE:**

* Estimate total project duration in weeks (typically 8-16 weeks for most projects)
* This timeline will be used for commercial cost calculation
* Provide a phase-wise breakdown of the timeline

**ESCALATION MATRIX:**

* Add a placeholder for escalation contacts

**CLIENT SATISFACTION:**

* Describe how client satisfaction will be ensured or measured

**PROPOSED COMMERCIAL:**

* Include a table with implementation cost based on project timeline
* Use format: One Time Implementation Cost | X weeks | Calculate as: Duration(weeks) × 8 × 5 × 25 (in USD)
* IMPORTANT: Calculate the exact cost using the formula: Total Weeks × 8 × 5 × 25 (amount in USD)
* Example: For 12 weeks = 12 × 8 × 5 × 25 = $12,000
* Always show the calculated USD amount, not placeholders
* Do not add any explanatory note below the commercial table


**Constraints & Guidelines:**

* **Company Branding**: You are representing **Redington**, so refer to it as the solution provider where needed
* Always focus on the value delivered to the client
* Use placeholders where details are unknown or client-specific
* Maintain a clear, professional tone
* Never include personal or confidential information.
* Everything will be without any html tag

---

Always generate comprehensive proposals following this exact structure and format."""
        
        self._initialize_bedrock()
    
    def _extract_customer_name(self, user_message: str) -> Optional[str]:
        """Extract customer name from user message using various patterns"""
        # Convert to lowercase for pattern matching
        message_lower = user_message.lower()
        
        # Improved patterns to better capture company names
        patterns = [
            # "for [Company Name]" - captures multi-word company names
            r'for\s+([A-Za-z][A-Za-z0-9\s&.-]{1,30}?)(?:\s+(?:company|corp|corporation|inc|incorporated|ltd|limited|llc|pvt|private|technologies|tech|systems|solutions|services|group|international|global))?(?:\s|$|[.,!?])',
            # "customer name is [Company Name]"
            r'customer\s+(?:name\s+is\s+|is\s+)([A-Za-z][A-Za-z0-9\s&.-]{1,30}?)(?:\s+(?:company|corp|corporation|inc|incorporated|ltd|limited|llc|pvt|private|technologies|tech|systems|solutions|services|group|international|global))?(?:\s|$|[.,!?])',
            # "client is [Company Name]"
            r'client\s+(?:name\s+is\s+|is\s+)([A-Za-z][A-Za-z0-9\s&.-]{1,30}?)(?:\s+(?:company|corp|corporation|inc|incorporated|ltd|limited|llc|pvt|private|technologies|tech|systems|solutions|services|group|international|global))?(?:\s|$|[.,!?])',
            # "proposal for [Company Name]"
            r'proposal\s+for\s+([A-Za-z][A-Za-z0-9\s&.-]{1,30}?)(?:\s+(?:company|corp|corporation|inc|incorporated|ltd|limited|llc|pvt|private|technologies|tech|systems|solutions|services|group|international|global))?(?:\s|$|[.,!?])',
            # "company name is [Company Name]"
            r'(?:company|organization|firm)\s+(?:name\s+is\s+|is\s+|called\s+)([A-Za-z][A-Za-z0-9\s&.-]{1,30}?)(?:\s|$|[.,!?])',
            # More specific patterns for common phrasings
            r'for\s+(?:the\s+)?company\s+([A-Za-z][A-Za-z0-9\s&.-]{1,30}?)(?:\s|$|[.,!?])',
            r'for\s+customer\s+([A-Za-z][A-Za-z0-9\s&.-]{1,30}?)(?:\s+(?:company|corp|corporation|inc|incorporated|ltd|limited|llc|pvt|private))?(?:\s|$|[.,!?])',
        ]
        
        for pattern in patterns:
            match = re.search(pattern, user_message, re.IGNORECASE)
            if match:
                customer_name = match.group(1).strip()
                # Clean up the customer name
                customer_name = re.sub(r'\s+', ' ', customer_name)  # Remove extra spaces
                customer_name = customer_name.title()  # Proper case
                
                # Filter out common words that aren't company names
                excluded_words = {
                    'the', 'and', 'or', 'but', 'with', 'from', 'this', 'that', 'they', 'them',
                    'customer', 'client', 'company', 'name', 'called', 'any', 'some', 'all',
                    'without', 'proposal', 'create', 'generate', 'need', 'want', 'make'
                }
                
                # Validate it's not too short and not an excluded word
                if (len(customer_name) >= 2 and 
                    customer_name.lower() not in excluded_words and
                    not customer_name.lower().startswith(('a ', 'an ', 'the '))):
                    return customer_name
        
        return None
    
    def _get_dynamic_system_prompt(self, user_message: str) -> str:
        """Get system prompt with customer name replacement if detected"""
        customer_name = self._extract_customer_name(user_message)
        
        if customer_name:
            # Replace <Customer Name> placeholder with actual customer name
            modified_prompt = self.base_system_prompt.replace('<Customer Name>', customer_name)
            
            # Also add a note about the customer name being provided
            customer_instruction = f"\n\n**IMPORTANT**: The customer name '{customer_name}' has been provided. Use this name instead of '<Customer Name>' placeholder throughout the proposal. All other placeholders like <Services Head>, <Technical Contact>, etc. should remain as placeholders."
            
            return modified_prompt + customer_instruction
        else:
            return self.base_system_prompt
    
    def _initialize_bedrock(self):
        """Initialize AWS Bedrock client"""
        try:
            self.bedrock_client = boto3.client(
                'bedrock-runtime',
                region_name='us-east-1'
            )
            logger.info("✅ AWS Bedrock client initialized successfully")
        except Exception as e:
            logger.warning(f"⚠️ AWS Bedrock not available: {e}")
            logger.info("🔄 Running in fallback mode")
            self.bedrock_client = None

    def _calculate_project_estimation(self, response_text: str) -> dict:
        """Calculate project estimation based on timeline weeks using formula: Total Weeks × 5 × 8 × 35"""
        try:
            # Extract total weeks from the response
            # Look for patterns like "Total Project Duration: X weeks"
            week_patterns = [
                r'Total Project Duration:\s*(\d+)\s*weeks?',
                r'Total Duration:\s*(\d+)\s*weeks?',
                r'Project Duration:\s*(\d+)\s*weeks?'
            ]
            
            total_weeks = 0
            for pattern in week_patterns:
                match = re.search(pattern, response_text, re.IGNORECASE)
                if match:
                    total_weeks = int(match.group(1))
                    break
            
            # If no total found, try to sum individual phase weeks from timeline table
            if total_weeks == 0:
                # Look for individual phase durations in the timeline table
                phase_matches = re.findall(r'\|\s*\w+\s*\|\s*(\d+)\s*weeks?\s*\|', response_text, re.IGNORECASE)
                if phase_matches:
                    # Sum all week numbers found in the timeline table
                    total_weeks = sum(int(w) for w in phase_matches)
            
            # Default to 16 weeks if nothing found
            if total_weeks == 0:
                total_weeks = 16
            
            # Calculate using formula: Total Weeks × 5 × 8 × 35
            base_cost = 35  # Fixed base cost
            multiplier_1 = 5  # Fixed multiplier
            multiplier_2 = 8  # Fixed multiplier
            
            total_cost = total_weeks * multiplier_1 * multiplier_2 * base_cost
            cost_per_week = total_cost // total_weeks if total_weeks > 0 else 0
            
            return {
                'total_weeks': total_weeks,
                'base_cost': base_cost,
                'multiplier_1': multiplier_1,
                'multiplier_2': multiplier_2,
                'total_cost': total_cost,
                'cost_per_week': cost_per_week,
                'formatted_cost': f"${total_cost:,}"
            }
            
        except Exception as e:
            logger.warning(f"Error calculating estimation: {e}")
            # Return default calculation for 16 weeks
            default_cost = 16 * 5 * 8 * 35  # 22,400
            return {
                'total_weeks': 16,
                'base_cost': 35,
                'multiplier_1': 5,
                'multiplier_2': 8,
                'total_cost': default_cost,
                'cost_per_week': default_cost // 16,
                'formatted_cost': f"${default_cost:,}"
            }


    def _calculate_commercial_cost(self, response_text):
        """Calculate commercial cost based on timeline weeks using formula: Total Weeks × 8 × 5 × 25 (amount in USD)"""
        try:
            # Extract weeks from the response text
            weeks_match = re.search(r'(\d+)\s*weeks?', response_text.lower())
            if weeks_match:
                total_weeks = int(weeks_match.group(1))
            else:
                # Fallback: estimate based on response length
                response_length = len(response_text)
                if response_length > 5000:
                    total_weeks = 16
                elif response_length > 3000:
                    total_weeks = 12
                else:
                    total_weeks = 8
            
            # Commercial calculation: Total Weeks × 8 × 5 × 25 (amount in USD)
            total_cost = total_weeks * 8 * 5 * 25
            
            return {
                'total_weeks': total_weeks,
                'total_cost': total_cost,
                'formatted_cost': f'${total_cost:,}',
                'cost_per_week': total_cost // total_weeks if total_weeks > 0 else 0
            }
            
        except Exception as e:
            logger.error(f'Error calculating commercial cost: {e}')
            # Return default values
            return {
                'total_weeks': 12,
                'total_cost': 12000,
                'formatted_cost': '2,000',
                'cost_per_week': 1000
            }
    async def generate_streaming_response(
        self, 
        user_message: str, 
        username: str, 
        session_id: str,
        model: str = "claude-3-7-sonnet"
    ) -> AsyncGenerator[str, None]:
        """Generate streaming response using AWS Bedrock Claude with session management"""
        
        try:
            if self.bedrock_client:
                # Use real Bedrock Claude
                async for chunk in self._stream_bedrock_response(user_message, username, session_id):
                    yield chunk
            else:
                # Fallback to enhanced static response
                async for chunk in self._stream_fallback_response(user_message, username, session_id):
                    yield chunk
                    
        except Exception as e:
            logger.error(f"Error in streaming response: {e}")
            error_chunk = {
                "chunk": f"\n\n❌ **Error**: Failed to generate response - {str(e)}\n",
                "is_complete": True,
                "metadata": {"error": True}
            }
            yield f"data: {json.dumps(error_chunk)}\n\n"

    async def _stream_bedrock_response(self, user_message: str, username: str, session_id: str) -> AsyncGenerator[str, None]:
        """Stream response from Bedrock Claude with session saving"""
        logger.info(f"🚀 Starting Bedrock streaming for session {session_id}, user: {username}")
        try:
            # Save user message first
            await session_manager.save_message(username, session_id, "user", user_message)
            
            # Get conversation history for context
            messages = await session_manager.get_session_messages(session_id)
            
            # Build conversation context (last 10 messages for context)
            conversation_context = []
            recent_messages = messages[-10:] if len(messages) > 10 else messages
            
            for msg in recent_messages[:-1]:  # Exclude the just-saved user message
                conversation_context.append({
                    "role": "assistant" if msg["role"].startswith("assistant") else "user",
                    "content": msg["content"]
                })
            
            # Add current user message
            conversation_context.append({
                "role": "user",
                "content": user_message
            })
            
            # Prepare the request body with dynamic system prompt
            dynamic_system_prompt = self._get_dynamic_system_prompt(user_message)
            body = json.dumps({
                "anthropic_version": "bedrock-2023-05-31",
                "max_tokens": 8000,  # Increased from 4000 to allow complete proposals
                "system": dynamic_system_prompt,
                "messages": conversation_context,
                "temperature": 0.7,
                "top_p": 0.9
            })
            
            # Make streaming request to Bedrock
            response = self.bedrock_client.invoke_model_with_response_stream(
                body=body,
                modelId=self.model_id,
                accept="application/json",
                contentType="application/json"
            )
            
            # Process streaming response
            accumulated_text = ""
            chunk_buffer = ""
            chunk_count = 0
            
            for event in response['body']:
                if 'chunk' in event:
                    chunk_data = json.loads(event['chunk']['bytes'].decode())
                    
                    if chunk_data['type'] == 'content_block_delta':
                        if 'delta' in chunk_data and 'text' in chunk_data['delta']:
                            new_text = chunk_data['delta']['text']
                            accumulated_text += new_text
                            chunk_buffer += new_text
                            
                            # Send chunks when we have enough content or hit natural breaks
                            if (len(chunk_buffer) >= 50 or 
                                any(marker in chunk_buffer for marker in ['\n\n', '. ', '? ', '! ', ':\n', '```\n'])):
                                
                                chunk_to_send = {
                                    "chunk": chunk_buffer,
                                    "is_complete": False,
                                    "metadata": {
                                        "chunk_index": chunk_count,
                                        "timestamp": datetime.now().isoformat(),
                                        "source": "bedrock_claude",
                                        "session_id": session_id
                                    }
                                }
                                
                                yield f"data: {json.dumps(chunk_to_send)}\n\n"
                                
                                # Add natural delay based on content type
                                if chunk_buffer.startswith('#'):  # Headers
                                    delay = 0.1
                                elif '```' in chunk_buffer:  # Code blocks
                                    delay = 0.15
                                elif chunk_buffer.startswith('-') or chunk_buffer.startswith('*'):  # Lists
                                    delay = 0.08
                                else:  # Regular text
                                    delay = 0.05 + (len(chunk_buffer) / 1000)
                                
                                await asyncio.sleep(delay)
                                
                                chunk_buffer = ""
                                chunk_count += 1
            
            # Send any remaining content (but don't mark as complete yet)
            if chunk_buffer:
                final_chunk = {
                    "chunk": chunk_buffer,
                    "is_complete": False,  # Don't complete yet - costing might be added
                    "metadata": {
                        "chunk_index": chunk_count,
                        "timestamp": datetime.now().isoformat(),
                        "source": "bedrock_claude",
                        "session_id": session_id,
                        "total_length": len(accumulated_text)
                    }
                }
                yield f"data: {json.dumps(final_chunk)}\n\n"
            
            # Save assistant response
            # Add OTI costing to all proposals
            if "##" in accumulated_text and ("proposal" in user_message.lower() or "EXECUTIVE SUMMARY" in accumulated_text or "SOLUTION OVERVIEW" in accumulated_text):
                try:
                    logger.info("💰 Adding OTI costing to proposal")
                    accumulated_text = proposal_integration._add_oti_costing_to_proposal(accumulated_text)
                    logger.info("✅ OTI costing added successfully")
                except Exception as e:
                    logger.error(f"❌ Error adding OTI costing: {str(e)}")
            
            logger.info(f"💾 About to save assistant message for session {session_id}, length: {len(accumulated_text)}")
            logger.info(f"🔍 Session ID: {session_id}, Username: {username}, Text length: {len(accumulated_text)}")
            try:
                await session_manager.save_message(username, session_id, "assistant", accumulated_text, self.model_id)
                logger.info(f"✅ Assistant message saved successfully for session {session_id}")
            except Exception as save_error:
                logger.error(f"❌ Failed to save assistant message: {save_error}")
            # Check if we should add costing information
            costing_added = False
            costing_chunks = []
            if PROPOSAL_COSTING_AVAILABLE and proposal_integration.should_include_costing(user_message, accumulated_text):
                logger.info(f"🎯 Costing logic triggered for session {session_id}")
                try:
                    logger.info("🧮 Generating detailed costing information for proposal")
                    
                    # Generate detailed costing table
                    customer_name = proposal_integration.extract_customer_name(user_message, accumulated_text)
                    logger.info(f"📝 Customer name extracted: {customer_name}")
                    
                    costing_data = proposal_integration.costing_service.generate_costing_for_proposal(
                        proposal_text=accumulated_text,
                        customer_name=customer_name
                    )
                    logger.info(f"💰 Costing data generated: ${costing_data['total_cost']:,.2f}")
                    
                    # Use detailed format instead of basic format
                    detailed_costing_table = proposal_integration._format_enhanced_costing_table(costing_data)
                    logger.info(f"📊 Costing table generated: {len(detailed_costing_table)} characters")
                    
                    # Stream the costing information as additional chunks
                    costing_chunks = self._split_text_into_chunks(detailed_costing_table)
                    logger.info(f"📦 Split into {len(costing_chunks)} chunks")
                    
                    for i, chunk_text in enumerate(costing_chunks):
                        costing_chunk = {
                            "chunk": chunk_text,
                            "is_complete": False,  # Still not complete
                            "metadata": {
                                "chunk_index": chunk_count + i + 1,
                                "timestamp": datetime.now().isoformat(),
                                "source": "oti_costing_detailed",
                                "session_id": session_id,
                                "costing_data": True
                            }
                        }
                        yield f"data: {json.dumps(costing_chunk)}\n\n"
                        await asyncio.sleep(0.1)  # Small delay for smooth streaming
                    
                    logger.info("✅ Costing chunks streamed successfully")
                    
                    # Save the enhanced response with costing
                    enhanced_response = accumulated_text + "\n\n" + detailed_costing_table
                    # Save the enhanced response with costing (this will update the existing message)
                    try:
                        await session_manager.save_message(username, session_id, "assistant", enhanced_response, "oti_costing_detailed")
                        logger.info(f"✅ Enhanced response with costing saved for session {session_id}")
                    except Exception as enhanced_save_error:
                        logger.error(f"❌ Failed to save enhanced response: {enhanced_save_error}")
                    
                    costing_added = True
                    
                except Exception as costing_error:
                    logger.error(f"Error adding detailed costing information: {costing_error}")
                    # Continue without costing if there's an error
            
            # NOW send the final completion marker
            completion_chunk = {
                "chunk": "",
                "is_complete": True,
                "metadata": {
                    "chunk_index": chunk_count + (len(costing_chunks) if costing_added else 0),
                    "total_chunks": chunk_count + (len(costing_chunks) if costing_added else 0),
                    "timestamp": datetime.now().isoformat(),
                    "source": "bedrock_complete",
                    "session_id": session_id,
                    "total_length": len(accumulated_text),
                    "costing_included": costing_added
                }
            }
            logger.info(f"🏁 About to send completion chunk for session {session_id}")
            yield f"data: {json.dumps(completion_chunk)}\n\n"
            
            # FINAL SAVE: Ensure assistant message is always saved
            try:
                logger.info(f"🔒 Final save attempt for session {session_id}")
                await session_manager.save_message(username, session_id, "assistant", accumulated_text, f"{self.model_id}_final")
                logger.info(f"✅ Final assistant message saved for session {session_id}")
            except Exception as final_save_error:
                logger.error(f"❌ Final save failed: {final_save_error}")
                
        except Exception as e:
            logger.error(f"Bedrock streaming error: {e}")
            error_chunk = {
                "chunk": f"\n\n❌ **Bedrock Error**: {str(e)}\n\nFalling back to enhanced mode...\n\n",
                "is_complete": False,
                "metadata": {"error": True, "fallback": True}
            }
            yield f"data: {json.dumps(error_chunk)}\n\n"
            
            # Fallback to static response
            async for chunk in self._stream_fallback_response(user_message, username, session_id):
                yield chunk

    async def _stream_fallback_response(self, user_message: str, username: str, session_id: str) -> AsyncGenerator[str, None]:
        """Fallback streaming response with enhanced formatting and session saving"""
        
        # Save user message
        await session_manager.save_message(username, session_id, "user", user_message)
        
        # Extract customer name for dynamic replacement
        customer_name = self._extract_customer_name(user_message)
        customer_display = customer_name if customer_name else "<Customer Name>"
        
        fallback_response = f"""# REDINGTON TECHNOLOGY SOLUTIONS - COMPREHENSIVE PROPOSAL

## PROPOSAL DETAILS

| Field | Value |
|-------|-------|
| Proposal Title | Technology Solutions for {customer_display} |
| Services Head | <Services Head> |
| Presales/Technical Head | <Presales/Technical Head> |
| Enterprise Sales | <Enterprise Sales> |
| Technical Contact | <Technical Contact> |
| Proposal Creation Date | {datetime.now().strftime('%B %d, %Y')} |
| Proposal Validity | 90 days from proposal date |
| Proposal Type | Professional Services |
| Commercial Currency | USD |

## TABLE OF CONTENTS

1. **EXECUTIVE SUMMARY**
2. **STATED REQUIREMENT**
3. **SUCCESS CRITERIA**
4. **PROPOSED SOLUTION**
5. **PROPOSED ARCHITECTURE**
6. **SCOPE OF WORK**
7. **TESTING**
8. **RACI MATRIX**
9. **OUT OF SCOPE**
10. **GENERAL ASSUMPTIONS & DEPENDENCIES**
11. **PROJECT TIMELINE**
12. **ESCALATION MATRIX**
13. **CLIENT SATISFACTION**
# 14. **PROPOSED COMMERCIALS** (COMMENTED OUT)

## 1. EXECUTIVE SUMMARY

Thank you **{username}** for your inquiry: *"{user_message}"*

Redington is pleased to present this comprehensive proposal addressing {customer_display}'s technology requirements. Our solution leverages industry best practices and cutting-edge technologies to deliver measurable business value.

### Key Benefits:
- **Scalable Infrastructure** - Future-ready technology foundation
- **Enhanced Security** - Comprehensive protection framework
- **Operational Excellence** - Streamlined processes and automation
- **Cost Optimization** - Efficient resource utilization

We look forward to discussing this proposal and scheduling a detailed consultation.

## 2. STATED REQUIREMENT

Based on your inquiry, we understand your organization requires a comprehensive technology solution that addresses:

**Business Challenge:**
Your organization seeks to modernize its technology infrastructure while maintaining operational continuity and ensuring scalable growth capabilities.

**Key Requirements:**
- Scalable and reliable infrastructure
- Enhanced security and compliance
- Improved operational efficiency
- Cost-effective solution delivery
- Minimal business disruption during implementation

## 3. SUCCESS CRITERIA

- **Performance**: 99.9% system uptime and <2s response times
- **Security**: Zero critical security incidents
- **Scalability**: Support for 300% growth without performance degradation
- **Cost Savings**: 25-40% reduction in operational costs
- **User Adoption**: >90% user satisfaction scores
- **ROI**: Positive return on investment within 18 months

## 4. PROPOSED SOLUTION

### 4.1 **Account Access and Management**
- Centralized identity and access management
- Multi-factor authentication implementation
- Role-based access controls

### 4.2 **Assessment and Discovery**
- Current state infrastructure analysis
- Gap analysis and recommendations
- Risk assessment and mitigation planning

### 4.3 **Security Implementation**
- Zero-trust security architecture
- Advanced threat protection
- Compliance framework implementation

### 4.4 **Resource Management Optimization**
- Automated resource provisioning
- Performance monitoring and optimization
- Cost management and reporting

## 5. PROPOSED ARCHITECTURE

**High-Level Architecture Components:**
- **Load Balancer**: Distributes traffic across multiple instances
- **Application Tier**: Scalable compute resources
- **Database Tier**: High-availability data storage
- **Security Layer**: Comprehensive protection framework
- **Monitoring**: Real-time observability and alerting

*Detailed architecture diagrams will be provided in the technical design phase.*

## 6. SCOPE OF WORK

The scope of work encompasses a comprehensive approach to deliver a complete cloud transformation solution. This section outlines the detailed activities, deliverables, and responsibilities across all project phases to ensure successful implementation and seamless transition to the cloud environment.

### **Phase 1: Discovery and Assessment (Weeks 1-4)**

**Objective:** Conduct thorough analysis of current state and define future state architecture

**Detailed Activities:**

**Infrastructure Discovery and Documentation**
- Perform comprehensive inventory of all physical and virtual servers, including specifications, configurations, and current utilization metrics
- Document existing network topology, including switches, routers, firewalls, load balancers, and network segmentation
- Catalog all databases, including versions, sizes, performance characteristics, and interdependencies
- Identify and document all storage systems, backup solutions, and data retention policies
- Map all security controls, including access management systems, monitoring tools, and compliance frameworks
- Document disaster recovery and business continuity procedures currently in place
- Assess current monitoring and alerting systems and their effectiveness

**Application Portfolio Analysis**
- Conduct detailed analysis of all applications including business criticality, technical architecture, and performance requirements
- Identify application interdependencies and data flow patterns between systems
- Assess application compatibility with cloud platforms and identify potential migration challenges
- Evaluate current application performance baselines and service level agreements
- Document integration points with third-party systems and external services
- Analyze application licensing requirements and cloud compatibility
- Identify applications suitable for retirement, replacement, or modernization

**Business Requirements Gathering**
- Conduct stakeholder interviews to understand business objectives and success criteria
- Document current pain points, challenges, and areas for improvement
- Define performance requirements, availability expectations, and scalability needs
- Understand compliance and regulatory requirements specific to the industry
- Identify budget constraints and timeline expectations
- Document change management requirements and organizational readiness
- Assess current IT skills and training needs for cloud operations

**Risk Assessment and Mitigation Planning**
- Identify technical risks associated with migration including compatibility issues and performance concerns
- Assess business risks including potential downtime, data loss, and operational disruption
- Evaluate security risks and develop appropriate mitigation strategies
- Document regulatory and compliance risks and required controls
- Develop comprehensive risk register with mitigation plans and contingency procedures
- Identify critical success factors and potential failure points
- Create detailed rollback procedures for each migration wave

**Deliverables:**
- Comprehensive current state documentation including infrastructure inventory, application catalog, and network diagrams
- Detailed gap analysis report highlighting areas requiring attention or improvement
- Business requirements document with clearly defined success criteria and acceptance criteria
- Risk assessment report with detailed mitigation strategies and contingency plans
- Migration readiness assessment with recommendations for proceeding to next phase

### **Phase 2: Solution Design and Planning (Weeks 5-8)**

**Objective:** Design comprehensive cloud solution architecture and develop detailed implementation plan

**Detailed Activities:**

**Cloud Architecture Design**
- Design scalable and resilient cloud infrastructure architecture aligned with business requirements
- Define network architecture including virtual private clouds, subnets, routing, and connectivity options
- Design security architecture with defense-in-depth approach including identity management, access controls, and data protection
- Plan compute resources including virtual machines, containers, and serverless components based on workload requirements
- Design storage architecture with appropriate tiers, backup strategies, and disaster recovery capabilities
- Define database architecture including migration strategies, performance optimization, and high availability configurations
- Design monitoring and logging architecture for comprehensive visibility and alerting
- Plan disaster recovery and business continuity solutions with defined recovery time and recovery point objectives

**Migration Strategy Development**
- Develop detailed migration approach using appropriate strategies including rehost, replatform, refactor, or replace
- Create migration wave planning with logical grouping of applications based on dependencies and business criticality
- Define migration sequences to minimize business disruption and ensure smooth transition
- Develop data migration strategies including data validation, synchronization, and cutover procedures
- Plan testing strategies for each migration wave including functional, performance, and security testing
- Define rollback procedures and criteria for each migration wave
- Create detailed project timeline with dependencies, critical path, and resource allocation

**Security and Compliance Framework**
- Design comprehensive security controls aligned with industry best practices and regulatory requirements
- Define identity and access management strategy including single sign-on, multi-factor authentication, and privileged access management
- Plan data encryption strategies for data at rest, in transit, and in use
- Design network security controls including firewalls, intrusion detection, and network segmentation
- Develop security monitoring and incident response procedures
- Plan compliance controls and audit procedures for relevant regulations
- Define security testing and validation procedures throughout the migration process

**Operational Framework Design**
- Design cloud operations model including roles, responsibilities, and procedures
- Plan monitoring and alerting framework with appropriate metrics, thresholds, and escalation procedures
- Define backup and recovery procedures with testing and validation schedules
- Plan capacity management and auto-scaling strategies
- Design cost management and optimization framework
- Develop change management procedures for ongoing operations
- Plan knowledge transfer and training programs for operational staff

**Deliverables:**
- Detailed cloud architecture design documents including infrastructure, security, and operational components
- Comprehensive migration plan with detailed timelines, resource requirements, and risk mitigation strategies
- Security and compliance framework documentation with detailed controls and procedures
- Operational procedures and runbooks for ongoing cloud management
- Detailed project plan with work breakdown structure, resource allocation, and critical path analysis

### **Phase 3: Environment Preparation and Foundation Setup (Weeks 9-12)**

**Objective:** Establish secure and scalable cloud foundation ready for application migration

**Detailed Activities:**

**Cloud Foundation Implementation**
- Establish cloud accounts with appropriate organizational structure and governance controls
- Implement identity and access management framework with role-based access controls and security policies
- Configure network infrastructure including virtual private clouds, subnets, routing tables, and security groups
- Establish connectivity between on-premises and cloud environments using appropriate methods such as VPN or dedicated connections
- Implement core security services including logging, monitoring, and threat detection
- Configure backup and disaster recovery infrastructure with appropriate retention policies
- Establish cost management and billing controls with budgets and alerts
- Implement compliance and governance controls with appropriate policies and procedures

**Security Implementation**
- Deploy and configure security monitoring tools including intrusion detection, vulnerability scanning, and log analysis
- Implement data encryption services and key management systems
- Configure network security controls including firewalls, web application firewalls, and DDoS protection
- Establish security incident response procedures and tools
- Implement privileged access management and just-in-time access controls
- Configure security compliance monitoring and reporting tools
- Conduct security testing and validation of implemented controls
- Establish security operations procedures and escalation processes

**Monitoring and Operations Setup**
- Deploy comprehensive monitoring solution covering infrastructure, applications, and security
- Configure alerting and notification systems with appropriate thresholds and escalation procedures
- Implement log aggregation and analysis systems for operational and security insights
- Establish performance monitoring and capacity planning tools
- Configure automated backup and recovery systems with regular testing procedures
- Implement configuration management and change tracking systems
- Establish operational dashboards and reporting systems
- Configure cost monitoring and optimization tools with regular review procedures

**Testing and Validation**
- Conduct comprehensive testing of cloud foundation including connectivity, security, and performance
- Validate disaster recovery procedures and recovery time objectives
- Test backup and restore procedures across all systems and data types
- Conduct security testing including penetration testing and vulnerability assessments
- Validate monitoring and alerting systems with simulated scenarios
- Test operational procedures and runbooks with actual scenarios
- Conduct performance testing to establish baselines and validate capacity
- Document all test results and remediate any identified issues

**Deliverables:**
- Fully configured and tested cloud foundation environment ready for application migration
- Comprehensive security implementation with validated controls and monitoring
- Operational monitoring and management systems with established procedures
- Detailed test results and validation reports for all implemented systems
- Updated operational procedures and runbooks based on actual implementation

### **Phase 4: Application Migration and Integration (Weeks 13-20)**

**Objective:** Migrate applications to cloud environment with minimal business disruption

**Detailed Activities:**

**Migration Wave 1: Non-Critical Applications**
- Execute migration of development and test environments to validate procedures and identify potential issues
- Migrate non-critical applications with minimal business impact to build confidence and refine processes
- Conduct thorough testing of migrated applications including functionality, performance, and integration
- Validate data integrity and consistency after migration
- Update DNS and routing configurations to direct traffic to cloud environments
- Monitor application performance and user experience during initial operation
- Document lessons learned and refine migration procedures for subsequent waves
- Provide initial training to operations staff on managing cloud-based applications

**Migration Wave 2: Production Support Systems**
- Migrate production support systems including monitoring, logging, and management tools
- Update integration points and dependencies to work with cloud-based systems
- Conduct comprehensive testing to ensure all support systems function correctly
- Validate backup and recovery procedures for production support systems
- Update operational procedures to reflect new cloud-based support systems
- Train operations staff on new procedures and tools
- Monitor system performance and stability during initial operation period
- Establish ongoing maintenance and update procedures for support systems

**Migration Wave 3: Business-Critical Applications**
- Execute carefully planned migration of business-critical applications during approved maintenance windows
- Implement comprehensive monitoring and alerting during migration process
- Conduct thorough testing including functional, performance, and integration testing
- Validate all business processes and user workflows after migration
- Update disaster recovery and business continuity procedures for cloud-based applications
- Provide comprehensive user training and support during transition period
- Monitor application performance, availability, and user satisfaction closely
- Establish ongoing optimization and improvement procedures

**Data Migration and Synchronization**
- Execute data migration using appropriate tools and techniques to ensure data integrity and minimize downtime
- Implement data synchronization procedures to keep systems consistent during migration period
- Conduct comprehensive data validation and reconciliation after migration
- Update data backup and recovery procedures for cloud-based systems
- Implement data archiving and retention policies aligned with business requirements
- Establish data governance and quality management procedures
- Conduct data security and privacy validation to ensure compliance
- Document data lineage and transformation procedures for ongoing management

**Integration and Testing**
- Validate all application integrations and data flows after migration
- Conduct end-to-end testing of business processes across all migrated systems
- Perform load testing and performance validation under realistic conditions
- Test disaster recovery and business continuity procedures with migrated applications
- Validate security controls and access management for all migrated systems
- Conduct user acceptance testing with business stakeholders
- Test operational procedures including monitoring, backup, and maintenance
- Document all test results and remediate any identified issues

**Deliverables:**
- Successfully migrated applications running in cloud environment with validated functionality
- Comprehensive testing results demonstrating system performance and reliability
- Updated integration and data flow documentation reflecting cloud architecture
- Validated disaster recovery and business continuity procedures for cloud systems
- User training materials and documentation for ongoing operations

### **Phase 5: Optimization and Stabilization (Weeks 21-24)**

**Objective:** Optimize cloud environment for performance, cost, and operational efficiency

**Detailed Activities:**

**Performance Optimization**
- Conduct comprehensive performance analysis of all migrated applications and infrastructure
- Identify opportunities for performance improvement including resource optimization and configuration tuning
- Implement auto-scaling policies and load balancing configurations to handle variable workloads
- Optimize database performance including indexing, query optimization, and caching strategies
- Fine-tune network configurations to minimize latency and maximize throughput
- Implement content delivery networks and caching solutions where appropriate
- Conduct stress testing and capacity planning to ensure systems can handle peak loads
- Establish ongoing performance monitoring and optimization procedures

**Cost Optimization**
- Analyze cloud resource utilization and identify opportunities for cost reduction
- Implement resource scheduling and automation to optimize costs during off-peak periods
- Review and optimize storage tiers and data lifecycle policies
- Implement cost monitoring and alerting to prevent budget overruns
- Negotiate reserved capacity and committed use discounts where appropriate
- Establish cost allocation and chargeback procedures for different business units
- Implement cost optimization recommendations and track savings achieved
- Establish ongoing cost review and optimization procedures

**Security Hardening and Compliance**
- Conduct comprehensive security review and hardening of all cloud systems
- Implement additional security controls based on operational experience and threat landscape
- Conduct compliance validation and audit preparation for relevant regulations
- Update security policies and procedures based on cloud operational experience
- Implement advanced threat detection and response capabilities
- Conduct security training for operations and development staff
- Establish ongoing security monitoring and improvement procedures
- Document security controls and compliance status for audit purposes

**Operational Excellence**
- Refine operational procedures based on actual operational experience
- Implement automation for routine operational tasks including provisioning, monitoring, and maintenance
- Establish service level agreements and operational metrics for cloud services
- Implement change management procedures for ongoing system modifications
- Establish incident management and problem resolution procedures
- Implement capacity planning and resource forecasting procedures
- Conduct operational training and knowledge transfer for all relevant staff
- Establish continuous improvement procedures for ongoing optimization

**Knowledge Transfer and Documentation**
- Conduct comprehensive knowledge transfer sessions covering all aspects of cloud operations
- Create detailed operational documentation including procedures, runbooks, and troubleshooting guides
- Provide specialized training on cloud-specific tools and technologies
- Establish ongoing support and mentoring arrangements for operations staff
- Create disaster recovery and business continuity documentation and procedures
- Document lessons learned and best practices for future reference
- Establish ongoing training and skill development programs
- Create comprehensive system documentation for ongoing maintenance and support

**Deliverables:**
- Optimized cloud environment with improved performance, cost efficiency, and security
- Comprehensive operational documentation and procedures for ongoing management
- Trained operations staff with validated skills and knowledge for cloud management
- Established ongoing optimization and improvement procedures
- Detailed project closure report with lessons learned and recommendations

### **Phase 6: Transition to Operations and Project Closure (Weeks 25-26)**

**Objective:** Complete transition to operational support and formally close project

**Detailed Activities:**

**Operational Transition**
- Complete handover of all systems and procedures to operational support teams
- Validate that all operational procedures and runbooks are current and accurate
- Ensure all monitoring and alerting systems are properly configured and functional
- Confirm that all backup and disaster recovery procedures are tested and validated
- Establish ongoing support contracts and service level agreements
- Complete final security and compliance validation
- Conduct final performance and capacity validation
- Establish ongoing optimization and improvement procedures

**Project Closure Activities**
- Conduct comprehensive project review with all stakeholders
- Document lessons learned and recommendations for future projects
- Complete final project deliverables and obtain stakeholder sign-off
- Conduct final budget reconciliation and cost analysis
- Archive project documentation and deliverables for future reference
- Conduct project team retrospective and knowledge capture
- Prepare final project report with achievements, challenges, and recommendations
- Formally close project and release project resources

**Deliverables:**
- Fully operational cloud environment with established support procedures
- Complete project documentation and knowledge transfer
- Final project report with comprehensive analysis and recommendations
- Formal project closure with stakeholder sign-off and approval

**Key Success Factors:**
- Clear communication and stakeholder engagement throughout all phases
- Comprehensive testing and validation at each stage
- Proactive risk management and issue resolution
- Continuous monitoring and optimization
- Thorough documentation and knowledge transfer
- Strong project governance and change management

## 7. TESTING

**Testing Responsibilities:**
- **Redington**: Infrastructure testing, security validation, performance testing
- **Client**: User acceptance testing, business process validation, data verification

## 8. RACI MATRIX

| Activity | Redington | Client |
|----------|-----------|--------|
| Infrastructure Setup | R,A | C,I |
| Security Configuration | R,A | C,I |
| User Training | R,A | C,I |
| Business Testing | C,I | R,A |
| Go-Live Decision | C,I | R,A |

## 9. OUT OF SCOPE

- Legacy system decommissioning
- Third-party software licensing
- End-user device procurement
- Network infrastructure upgrades

## 10. GENERAL ASSUMPTIONS & DEPENDENCIES

**Assumptions:**
- Client provides necessary access and resources
- Existing infrastructure meets minimum requirements
- Key stakeholders are available for decision-making

**Dependencies:**
- Client approval and sign-off at each phase
- Timely provision of required information
- Access to production environments for testing

## 11. PROJECT TIMELINE

| Phase | Duration | Key Milestones |
|-------|----------|----------------|
| Discovery | 4 weeks | Assessment complete, design approved |
| Implementation | 8 weeks | Infrastructure ready, applications deployed |
| Go-Live | 4 weeks | Production deployment, user training complete |

**Total Project Duration: 16 weeks**

## 12. PROPOSED ESTIMATION

**Project Cost Calculation:**

| Component | Value | Description |
|-----------|-------|-------------|
| Total Project Duration | {total_weeks} weeks | Based on project timeline |
| Resource Multiplier | 5 | Fixed resource factor |
| Time Multiplier | 8 | Fixed time factor |
| Base Cost per Unit | $35 | Fixed base cost |

**Calculation Formula:**
```
Total Cost = Total Weeks × 5 × 8 × 35
Total Cost = {total_weeks} × 5 × 8 × 35 = {formatted_cost}
```

**Investment Summary:**
- **Total Project Cost**: {formatted_cost}
- **Cost per Week**: ${cost_per_week:,}
- **Resource Allocation**: Optimized for {total_weeks}-week delivery

*Note: This estimation is based on standard resource allocation and may be adjusted based on specific requirements and scope changes.*

n## 12. PROPOSED ESTIMATION

**Project Cost Calculation:**

| Component | Value | Description |
|-----------|-------|-------------|
| Total Project Duration | {total_weeks} weeks | Based on project timeline |
| Resource Multiplier | 5 | Fixed resource factor |
| Time Multiplier | 8 | Fixed time factor |
| Base Cost per Unit | 5 | Fixed base cost |

**Calculation Formula:**


**Investment Summary:**
- **Total Project Cost**: {formatted_cost}
- **Cost per Week**: 
- **Resource Allocation**: Optimized for {total_weeks}-week delivery

*Note: This estimation is based on standard resource allocation and may be adjusted based on specific requirements and scope changes.*


# - Setup and Configuration: 200-300 hours (COMMENTED OUT)
- Testing and Validation: 100-150 hours
- Training and Documentation: 50-75 hours
- Project Management: 75-100 hours

## 13. PROPOSED COMMERCIAL

**ONE-TIME IMPLEMENTATION & MANAGED SERVICES COST:**

| Service | Duration | Value |
|---------|----------|-------|
| One Time Implementation Cost | COMMERCIAL_WEEKS_PLACEHOLDER weeks | COMMERCIAL_COST_PLACEHOLDER |


## 14. ESCALATION MATRIX

| Level | Contact | Role |
|-------|---------|------|
| L1 | <Technical Contact> | Technical Support |
| L2 | <Project Manager> | Project Management |
| L3 | <Services Head> | Service Delivery |

## 15. CLIENT SATISFACTION

**Satisfaction Measures:**
- Regular project status reviews
- Milestone-based feedback sessions
- Post-implementation satisfaction survey
- Ongoing support quality metrics

---

**Next Steps:**
1. Review and approve this proposal
2. Schedule detailed technical discussion
3. Finalize commercial terms
4. Initiate project kickoff

**Contact Information:**
- **Services Head**: <Services Head>
- **Technical Lead**: <Presales/Technical Head>
- **Sales Contact**: <Enterprise Sales>

Thank you for considering Redington as your technology partner."""

        
        # Calculate project estimation and inject values
        estimation = self._calculate_project_estimation(fallback_response)
        
        # Calculate commercial cost and inject values
        commercial = self._calculate_commercial_cost(fallback_response)

        # Replace commercial placeholders with actual values
        fallback_response = fallback_response.replace(
            "COMMERCIAL_WEEKS_PLACEHOLDER", str(commercial["total_weeks"])
        ).replace(
            "COMMERCIAL_COST_PLACEHOLDER", commercial["formatted_cost"]
        )

        # Replace placeholders in the estimation section
        fallback_response = fallback_response.format(
            total_weeks=estimation['total_weeks'],
            formatted_cost=estimation['formatted_cost'],
            cost_per_week=estimation['cost_per_week']
        )
        # Split response into chunks for streaming
        chunks = self._create_streaming_chunks(fallback_response)
        
        accumulated_text = ""
        for i, chunk in enumerate(chunks):
            accumulated_text += chunk
            
            # Vary delay based on chunk type and length
            if chunk.startswith('#'):  # Headers
                delay = 0.1
            elif chunk.startswith('```'):  # Code blocks
                delay = 0.15
            elif chunk.startswith('-') or chunk.startswith('*'):  # Lists
                delay = 0.08
            else:  # Regular text
                delay = 0.05 + (len(chunk) / 1000)
            
            chunk_data = {
                "chunk": chunk,
                "is_complete": i == len(chunks) - 1,
                "metadata": {
                    "chunk_index": i,
                    "total_chunks": len(chunks),
                    "timestamp": datetime.now().isoformat(),
                    "source": "fallback_enhanced",
                    "session_id": session_id
                }
            }
            
            yield f"data: {json.dumps(chunk_data)}\n\n"
            await asyncio.sleep(delay)
        
        # Save assistant response
        await session_manager.save_message(username, session_id, "assistant", accumulated_text, "fallback-enhanced")

    def _create_streaming_chunks(self, text: str) -> List[str]:
        """Create properly formatted streaming chunks"""
        chunks = []
        
        # Split by double newlines first (paragraphs)
        paragraphs = text.split('\n\n')
        
        for paragraph in paragraphs:
            if len(paragraph) > 200:
                # Split long paragraphs by sentences
                sentences = re.split(r'(?<=[.!?])\s+', paragraph)
                current_chunk = ""
                
                for sentence in sentences:
                    if len(current_chunk + sentence) > 150:
                        if current_chunk:
                            chunks.append(current_chunk.strip() + "\n\n")
                        current_chunk = sentence + " "
                    else:
                        current_chunk += sentence + " "
                
                if current_chunk:
                    chunks.append(current_chunk.strip() + "\n\n")
            else:
                chunks.append(paragraph + "\n\n")
        
        return [chunk for chunk in chunks if chunk.strip()]
    
    def _split_text_into_chunks(self, text: str) -> List[str]:
        """Split text into chunks for streaming costing information"""
        chunks = []
        
        # Split by lines first
        lines = text.split('\n')
        current_chunk = ""
        
        for line in lines:
            # If adding this line would make chunk too long, start new chunk
            if len(current_chunk + line + '\n') > 200:
                if current_chunk:
                    chunks.append(current_chunk)
                current_chunk = line + '\n'
            else:
                current_chunk += line + '\n'
        
        # Add remaining chunk
        if current_chunk:
            chunks.append(current_chunk)
        
        return [chunk for chunk in chunks if chunk.strip()]

# Initialize Bedrock integration
bedrock_integration = BedrockStreamingIntegration()

# Include OTI costing routes if available
if OTI_AVAILABLE:
    app.include_router(oti_router, prefix="/api/v1")
    logger.info("✅ OTI costing routes included")
else:
    logger.warning("⚠️ OTI costing routes not available")

# API Endpoints
@app.get("/")
async def root():
    return {"message": "Redington AI Bot - Enhanced Bedrock with Cognito & OTI Costing", "version": "4.1.0"}

@app.get("/health")
async def health_check():
    bedrock_status = "connected" if bedrock_integration.bedrock_client else "fallback_mode"
    return {
        "status": "healthy", 
        "service": "redington-enhanced-bedrock-cognito-oti",
        "bedrock_status": bedrock_status,
        "model": bedrock_integration.model_id,
        "cognito_configured": bool(cognito_auth.pool_id),
        "dynamodb_configured": bool(session_manager.table),
        "oti_costing_available": OTI_AVAILABLE,
        "proposal_costing_available": PROPOSAL_COSTING_AVAILABLE
    }

@app.post("/api/v1/auth/login", response_model=AuthResponse)
async def login(auth_request: AuthRequest):
    """Login endpoint with Cognito authentication only"""
    username = auth_request.username
    password = auth_request.password
    
    try:
        # Use Cognito authentication only
        auth_result = await cognito_auth.authenticate_user(username, password)
        
        logger.info(f"✅ User {username} logged in successfully via Cognito")
        
        return AuthResponse(
            access_token=auth_result['access_token'],
            token_type="bearer",
            expires_in=auth_result['expires_in'],
            user_info=auth_result['user_info']
        )
    except HTTPException as e:
        logger.warning(f"❌ Login failed for {username}: {e.detail}")
        raise e

@app.post("/api/v1/auth/logout")
async def logout(current_user: str = Depends(get_current_user)):
    """Logout endpoint"""
    logger.info(f"✅ User {current_user} logged out successfully")
    return {"message": "Successfully logged out"}

@app.get("/api/v1/auth/me", response_model=UserInfo)
async def get_user_info(current_user: str = Depends(get_current_user)):
    """Get current user info"""
    return UserInfo(
        username=current_user,
        email=f"{current_user}@redington-demo.com"
    )

@app.post("/api/v1/chat/stream")
async def stream_chat(
    request: ChatRequest,
    current_user: str = Depends(get_current_user)
):
    """Stream chat response with Bedrock Claude integration and session management"""
    
    logger.info(f"Enhanced Bedrock streaming request from {current_user}: {request.message[:100]}...")
    
    # Create session if it doesn't exist or use provided session_id
    session_id = request.session_id
    if session_id == "default":
        session_id = await session_manager.create_session(current_user, "New Chat Session")
    
    return StreamingResponse(
        streaming_response_with_save(
            request.message, 
            current_user,
            session_id,
            request.model
        ),
        media_type="text/event-stream",
        headers={
            "Cache-Control": "no-cache",
            "Connection": "keep-alive",
            "Access-Control-Allow-Origin": "*",
            "X-Session-ID": session_id,
        }
    )

@app.get("/api/v1/chat/models")
async def get_available_models(current_user: str = Depends(get_current_user)):
    """Get available AI models"""
    return {
        "models": {
            "Claude 3.7 Sonnet": {
                "model_id": "us.anthropic.claude-3-7-sonnet-20250219-v1:0",
                "input_format": "multimodal",
                "thinking": 0,
                "temperature": 0.7,
                "top_p": 0.9,
                "top_k": 500,
                "max_tokens": 4000,
                "memory_window": 10,
                "max_top_k": 500,
                "status": "connected" if bedrock_integration.bedrock_client else "fallback"
            }
        },
        "default_model": "Claude 3.7 Sonnet",
        "bedrock_status": "connected" if bedrock_integration.bedrock_client else "fallback_mode"
    }

@app.get("/api/v1/sessions")
async def get_sessions(current_user: str = Depends(get_current_user)):
    """Get user sessions"""
    sessions = await session_manager.get_user_sessions(current_user)
    return {"sessions": sessions}

@app.get("/sessions")
async def get_sessions_legacy(current_user: str = Depends(get_current_user)):
    """Get user sessions - legacy endpoint for frontend compatibility"""
    sessions = await session_manager.get_user_sessions(current_user)
    return {"sessions": sessions}

@app.post("/api/v1/sessions")
async def create_session(
    session_data: SessionCreate,
    current_user: str = Depends(get_current_user)
):
    """Create new session"""
    session_id = await session_manager.create_session(current_user, session_data.title)
    return {
        "id": session_id,
        "name": session_data.title or "New Chat Session",
        "created_at": datetime.now().isoformat(),
        "updated_at": datetime.now().isoformat()
    }

@app.get("/api/v1/conversations")
async def get_conversations(current_user: str = Depends(get_current_user)):
    """Get user conversations (alias for sessions)"""
    sessions = await session_manager.get_user_sessions(current_user)
    conversations = [
        {
            "conversation_id": session["id"],
            "title": session["name"],
            "created_at": session["created_at"],
            "updated_at": session["updated_at"],
            "message_count": session.get("message_count", 0)
        }
        for session in sessions
    ]
    return {"conversations": conversations}

@app.get("/api/v1/chat/history/{session_id}")
async def get_conversation_history(
    session_id: str,
    current_user: str = Depends(get_current_user)
):
    """Get conversation history"""
    messages = await session_manager.get_session_messages(session_id, current_user)
    return {
        "messages": messages,
        "conversation_id": session_id
    }

@app.put("/api/v1/sessions/{session_id}")
async def update_session(
    session_id: str,
    session_data: SessionUpdate,
    current_user: str = Depends(get_current_user)
):
    """Update session title"""
    await session_manager.update_session_title(current_user, session_id, session_data.title)
    return {"message": "Session updated successfully"}

@app.delete("/api/v1/sessions/{session_id}")
async def delete_session(
    session_id: str,
    current_user: str = Depends(get_current_user)
):
    """Delete session"""
    await session_manager.delete_session(current_user, session_id)
    return {"message": "Session deleted successfully"}

if __name__ == "__main__":
    import uvicorn
    uvicorn.run(
        "enhanced_bedrock_main:app",
        host="0.0.0.0",
        port=8000,
        reload=False,
        log_level="info"
    )

@app.get("/api/v1/debug/session/{session_id}")
async def debug_session_messages(session_id: str):
    """Debug endpoint to check session messages"""
    try:
        messages = await session_manager.get_session_messages(session_id)
        return {
            "session_id": session_id,
            "message_count": len(messages),
            "messages": messages
        }
    except Exception as e:
        return {"error": str(e)}

@app.post("/api/v1/debug/save-message")
async def debug_save_message(request: dict):
    """Debug endpoint to test message saving"""
    try:
        await session_manager.save_message(
            request["username"],
            request["session_id"],
            request["role"],
            request["content"],
            request.get("model", "debug")
        )
        return {"status": "Message saved successfully"}
    except Exception as e:
        return {"error": str(e)}

@app.post("/api/v1/debug/force-save")
async def force_save_message():
    """Force save a test assistant message"""
    try:
        session_id = "force-save-test"
        username = "demo"
        content = "This is a test assistant message saved directly"
        
        await session_manager.save_message(username, session_id, "assistant", content, "debug-test")
        
        # Verify it was saved
        messages = await session_manager.get_session_messages(session_id)
        
        return {
            "status": "success",
            "message": "Assistant message saved",
            "session_id": session_id,
            "saved_messages": len(messages),
            "messages": messages
        }
    except Exception as e:
        return {"error": str(e)}

async def streaming_response_with_save(message: str, username: str, session_id: str, model: str):
    """Wrapper that ensures assistant message is saved after streaming"""
    accumulated_response = ""
    
    async for chunk_data in bedrock_integration.generate_streaming_response(message, username, session_id, model):
        # Extract the actual content from the chunk
        if "data: " in chunk_data:
            try:
                import json
                chunk_json = json.loads(chunk_data.replace("data: ", "").strip())
                if "chunk" in chunk_json:
                    accumulated_response += chunk_json["chunk"]
                
                # If this is the completion chunk, save the message
                if chunk_json.get("is_complete", False):
                    try:
                        await session_manager.save_message(username, session_id, "assistant", accumulated_response, "streaming_wrapper")
                        print(f"✅ Assistant message saved via wrapper for session {session_id}")
                    except Exception as save_error:
                        print(f"❌ Wrapper save failed: {save_error}")
            except:
                pass  # Skip malformed chunks
        
        yield chunk_data
