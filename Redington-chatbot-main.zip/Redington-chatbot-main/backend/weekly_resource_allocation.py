#!/usr/bin/env python3
"""
Weekly Resource Allocation Table Generator
Creates detailed week-by-week resource allocation with man hours calculation
"""
from typing import Dict, List, Any, Tuple
from proposal_costing_service import RESOURCE_RATES
import pandas as pd
from datetime import datetime

class WeeklyResourceAllocation:
    """Generate detailed weekly resource allocation tables"""
    
    def __init__(self):
        self.resource_rates = RESOURCE_RATES
        self.hours_per_day = 8
        self.days_per_week = 5
        self.hours_per_week = self.hours_per_day * self.days_per_week  # 40 hours
    
    def generate_weekly_allocation_table(self, costing_data: Dict[str, Any]) -> str:
        """Generate detailed weekly resource allocation table"""
        
        # Calculate project duration in weeks
        total_weeks = int(costing_data['estimated_weeks'])
        if total_weeks > 26:  # Cap at 26 weeks for table readability
            total_weeks = 26
        
        # Create weekly allocation matrix
        weekly_allocation = self._create_weekly_allocation_matrix(costing_data, total_weeks)
        
        # Generate the table
        table_content = f"""
## 📅 **WEEKLY RESOURCE ALLOCATION BREAKDOWN**

### 🗓️ **Project Duration: {total_weeks} Weeks**
### 👥 **Resource Allocation by Week (Days per Week)**

"""
        
        # Create header row
        header = "| Resources |"
        for week in range(1, total_weeks + 1):
            header += f" Week {week} |"
        header += " Man Hours |"
        
        table_content += header + "\n"
        
        # Create separator row
        separator = "|-----------|"
        for week in range(1, total_weeks + 1):
            separator += "--------|"
        separator += "----------|"
        
        table_content += separator + "\n"
        
        # Add resource rows
        total_project_hours = 0
        
        for resource_type in sorted(weekly_allocation.keys()):
            allocation_data = weekly_allocation[resource_type]
            weekly_days = allocation_data['weekly_days']
            total_hours = allocation_data['total_hours']
            
            row = f"| {resource_type} |"
            for week in range(1, total_weeks + 1):
                days = weekly_days.get(week, 0)
                if days > 0:
                    row += f" {days} |"
                else:
                    row += " - |"
            
            row += f" {total_hours:,.0f} |"
            table_content += row + "\n"
            total_project_hours += total_hours
        
        # Add total row
        total_row = "| **TOTAL PROJECT** |"
        for week in range(1, total_weeks + 1):
            week_total_days = sum(
                allocation['weekly_days'].get(week, 0) 
                for allocation in weekly_allocation.values()
            )
            if week_total_days > 0:
                total_row += f" **{week_total_days}** |"
            else:
                total_row += " **-** |"
        total_row += f" **{total_project_hours:,.0f}** |"
        
        table_content += "|-----------|" + "--------|" * total_weeks + "----------|\n"
        table_content += total_row + "\n"
        
        return table_content
    
    def _create_weekly_allocation_matrix(self, costing_data: Dict[str, Any], total_weeks: int) -> Dict[str, Dict]:
        """Create weekly allocation matrix based on project phases and tasks"""
        
        weekly_allocation = {}
        
        # Initialize all resources
        for resource_type in self.resource_rates.keys():
            weekly_allocation[resource_type] = {
                'weekly_days': {},
                'total_hours': 0
            }
        
        # Process each phase and task
        current_week = 1
        
        for phase in costing_data['phases']:
            phase_start_week = current_week
            
            for task in phase.tasks:
                task_duration_weeks = int(task.duration_weeks)
                
                # Allocate resources for this task across its duration
                for week_offset in range(task_duration_weeks):
                    week_num = phase_start_week + week_offset
                    if week_num <= total_weeks:
                        
                        for resource_type, fte_allocation in task.resources.items():
                            if resource_type in weekly_allocation:
                                # Convert FTE to days per week (FTE * 5 days)
                                days_per_week = fte_allocation * 5
                                
                                # Add to existing allocation for this week
                                current_days = weekly_allocation[resource_type]['weekly_days'].get(week_num, 0)
                                weekly_allocation[resource_type]['weekly_days'][week_num] = current_days + days_per_week
                
                # Move to next task start week (tasks can overlap, so we don't always increment)
                phase_start_week += max(1, int(task.duration_weeks * 0.7))  # Allow some overlap
        
        # Calculate total hours for each resource
        for resource_type in weekly_allocation:
            total_hours = 0
            for week, days in weekly_allocation[resource_type]['weekly_days'].items():
                hours = days * self.hours_per_day
                total_hours += hours
            weekly_allocation[resource_type]['total_hours'] = total_hours
        
        # Clean up - remove resources with no allocation
        weekly_allocation = {
            resource: data for resource, data in weekly_allocation.items() 
            if data['total_hours'] > 0
        }
        
        return weekly_allocation
    
    def generate_detailed_weekly_breakdown(self, costing_data: Dict[str, Any]) -> str:
        """Generate detailed weekly breakdown with cost calculations"""
        
        total_weeks = min(int(costing_data['estimated_weeks']), 26)
        weekly_allocation = self._create_weekly_allocation_matrix(costing_data, total_weeks)
        
        table_content = f"""
## 📊 **DETAILED WEEKLY RESOURCE & COST BREAKDOWN**

### 🗓️ **Week-by-Week Resource Allocation**

"""
        
        # Create detailed breakdown for each resource
        for resource_type in sorted(weekly_allocation.keys()):
            if weekly_allocation[resource_type]['total_hours'] > 0:
                allocation_data = weekly_allocation[resource_type]
                rate = self.resource_rates.get(resource_type, 0)
                total_cost = allocation_data['total_hours'] * rate
                
                table_content += f"""
### 👤 **{resource_type}** (${rate}/hour)

| Week | Days | Hours | Cost | Activity |
|------|------|-------|------|----------|"""
                
                total_resource_hours = 0
                total_resource_cost = 0
                
                for week in range(1, total_weeks + 1):
                    days = allocation_data['weekly_days'].get(week, 0)
                    if days > 0:
                        hours = days * self.hours_per_day
                        cost = hours * rate
                        total_resource_hours += hours
                        total_resource_cost += cost
                        
                        # Determine activity based on week
                        activity = self._get_activity_for_week(week, total_weeks)
                        
                        table_content += f"\n| Week {week} | {days:.1f} | {hours:.0f} | ${cost:,.0f} | {activity} |"
                
                table_content += f"\n| **TOTAL** | **-** | **{total_resource_hours:.0f}** | **${total_resource_cost:,.0f}** | **All Activities** |\n"
        
        return table_content
    
    def _get_activity_for_week(self, week: int, total_weeks: int) -> str:
        """Determine primary activity for a given week"""
        
        # Define activity phases based on week ranges
        if week <= 4:
            activities = ["Assessment", "Discovery", "Requirements", "Planning"]
            return activities[(week - 1) % len(activities)]
        elif week <= 8:
            activities = ["Design", "Architecture", "Security Planning", "Migration Planning"]
            return activities[(week - 5) % len(activities)]
        elif week <= 12:
            activities = ["Environment Setup", "Foundation", "Security Implementation", "Testing"]
            return activities[(week - 9) % len(activities)]
        elif week <= 16:
            activities = ["Migration Wave 1", "Migration Wave 2", "Integration", "Validation"]
            return activities[(week - 13) % len(activities)]
        elif week <= 20:
            activities = ["Migration Wave 3", "Optimization", "Performance Tuning", "Documentation"]
            return activities[(week - 17) % len(activities)]
        else:
            activities = ["Go-Live Support", "Knowledge Transfer", "Handover", "Project Closure"]
            return activities[(week - 21) % len(activities)]
    
    def generate_weekly_cost_summary(self, costing_data: Dict[str, Any]) -> str:
        """Generate weekly cost summary table"""
        
        total_weeks = min(int(costing_data['estimated_weeks']), 26)
        weekly_allocation = self._create_weekly_allocation_matrix(costing_data, total_weeks)
        
        table_content = f"""
## 💰 **WEEKLY COST SUMMARY**

### 📈 **Cost Distribution by Week**

| Week | Total Days | Total Hours | Weekly Cost | Cumulative Cost | Primary Phase |
|------|------------|-------------|-------------|-----------------|---------------|"""
        
        cumulative_cost = 0
        
        for week in range(1, total_weeks + 1):
            week_total_days = 0
            week_total_hours = 0
            week_total_cost = 0
            
            for resource_type, allocation_data in weekly_allocation.items():
                days = allocation_data['weekly_days'].get(week, 0)
                if days > 0:
                    hours = days * self.hours_per_day
                    rate = self.resource_rates.get(resource_type, 0)
                    cost = hours * rate
                    
                    week_total_days += days
                    week_total_hours += hours
                    week_total_cost += cost
            
            cumulative_cost += week_total_cost
            primary_phase = self._get_primary_phase_for_week(week, total_weeks)
            
            if week_total_cost > 0:
                table_content += f"\n| Week {week} | {week_total_days:.1f} | {week_total_hours:.0f} | ${week_total_cost:,.0f} | ${cumulative_cost:,.0f} | {primary_phase} |"
        
        table_content += f"\n| **TOTAL** | **-** | **{sum(data['total_hours'] for data in weekly_allocation.values()):.0f}** | **${cumulative_cost:,.0f}** | **-** | **Complete Project** |"
        
        return table_content
    
    def _get_primary_phase_for_week(self, week: int, total_weeks: int) -> str:
        """Determine primary phase for a given week"""
        
        phase_duration = total_weeks / 6  # Assuming 6 phases
        
        if week <= phase_duration:
            return "Discovery & Assessment"
        elif week <= phase_duration * 2:
            return "Design & Planning"
        elif week <= phase_duration * 3:
            return "Foundation Setup"
        elif week <= phase_duration * 4:
            return "Migration & Integration"
        elif week <= phase_duration * 5:
            return "Optimization"
        else:
            return "Transition & Closure"

# Global instance
weekly_resource_allocation = WeeklyResourceAllocation()
