import boto3
import hmac
import hashlib
import base64
import json
import os
from dotenv import load_dotenv
from typing import Optional, Dict, Any
from datetime import datetime, timedelta
import jwt
from jwt.exceptions import ExpiredSignatureError, InvalidTokenError
from fastapi import HTTPException, status

# Load environment variables
load_dotenv()

class CognitoAuth:
    """AWS Cognito Authentication Handler with improved error handling"""
    
    def __init__(self):
        self.pool_id = os.getenv('POOL_ID')
        self.client_id = os.getenv('APP_CLIENT_ID')
        self.client_secret = os.getenv('APP_CLIENT_SECRET')
        
        # Extract region from pool_id (format: region_poolname)
        if self.pool_id and '_' in self.pool_id:
            self.region = self.pool_id.split('_')[0]
        else:
            self.region = os.getenv('AWS_DEFAULT_REGION', 'us-east-1')
        
        if not all([self.pool_id, self.client_id, self.client_secret]):
            raise ValueError("Missing Cognito configuration. Check POOL_ID, APP_CLIENT_ID, APP_CLIENT_SECRET")
        
        self.cognito_client = boto3.client('cognito-idp', region_name=self.region)
        self.secret_key = os.getenv('SECRET_KEY', 'fallback-secret-key')
        
    def _calculate_secret_hash(self, username: str) -> str:
        """Calculate the secret hash for Cognito authentication"""
        message = username + self.client_id
        dig = hmac.new(
            self.client_secret.encode('utf-8'),
            message.encode('utf-8'),
            hashlib.sha256
        ).digest()
        return base64.b64encode(dig).decode()
    
    async def authenticate_user(self, username: str, password: str) -> Dict[str, Any]:
        """Authenticate user with AWS Cognito with improved error handling"""
        print(f"🚀 AUTHENTICATE_USER CALLED FOR: {username}")
        try:
            secret_hash = self._calculate_secret_hash(username)
            
            print(f"🔐 Attempting authentication for user: {username}")
            
            response = self.cognito_client.initiate_auth(
                ClientId=self.client_id,
                AuthFlow='USER_PASSWORD_AUTH',
                AuthParameters={
                    'USERNAME': username,
                    'PASSWORD': password,
                    'SECRET_HASH': secret_hash
                }
            )
            
            print(f"🔐 RAW RESPONSE KEYS: {list(response.keys())}")
            print(f"🔐 CHALLENGE CHECK: {'ChallengeName' in response}")
            
            print(f"🔐 Cognito response keys: {list(response.keys())}")
            
            # Handle challenge responses (like FORCE_CHANGE_PASSWORD)
            if 'ChallengeName' in response:
                challenge_name = response['ChallengeName']
                print(f"🔐 Challenge detected: {challenge_name}")
                if challenge_name == 'NEW_PASSWORD_REQUIRED':
                    raise HTTPException(
                        status_code=status.HTTP_400_BAD_REQUEST,
                        detail={
                            "error": "password_change_required",
                            "message": "User must change password before first login",
                            "challenge_name": challenge_name,
                            "session": response.get('Session', '')
                        }
                    )
                else:
                    raise HTTPException(
                        status_code=status.HTTP_400_BAD_REQUEST,
                        detail={
                            "error": "challenge_required",
                            "message": f"Authentication challenge required: {challenge_name}",
                            "challenge_name": challenge_name
                        }
                    )
            
            # Only access AuthenticationResult if there's no challenge
            if 'AuthenticationResult' not in response:
                print(f"🔐 No AuthenticationResult in response: {response}")
                raise HTTPException(
                    status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
                    detail="Unexpected authentication response format"
                )
            
            # Extract tokens
            auth_result = response['AuthenticationResult']
            access_token = auth_result['AccessToken']
            id_token = auth_result['IdToken']
            refresh_token = auth_result['RefreshToken']
            
            # Get user info from ID token
            user_info = self._decode_token(id_token)
            
            return {
                'access_token': access_token,
                'id_token': id_token,
                'refresh_token': refresh_token,
                'user_info': user_info,
                'expires_in': auth_result.get('ExpiresIn', 3600)
            }
            
        except self.cognito_client.exceptions.NotAuthorizedException as e:
            error_message = str(e)
            if "Incorrect username or password" in error_message:
                # Check if user exists and their status
                try:
                    user_info = self.cognito_client.admin_get_user(
                        UserPoolId=self.pool_id,
                        Username=username
                    )
                    user_status = user_info.get('UserStatus', '')
                    
                    if user_status == 'FORCE_CHANGE_PASSWORD':
                        raise HTTPException(
                            status_code=status.HTTP_400_BAD_REQUEST,
                            detail={
                                "error": "password_change_required",
                                "message": "User account requires password change. Please contact administrator.",
                                "user_status": user_status
                            }
                        )
                    elif user_status == 'UNCONFIRMED':
                        raise HTTPException(
                            status_code=status.HTTP_400_BAD_REQUEST,
                            detail={
                                "error": "account_not_confirmed",
                                "message": "User account not confirmed. Please check your email for confirmation link.",
                                "user_status": user_status
                            }
                        )
                    else:
                        raise HTTPException(
                            status_code=status.HTTP_401_UNAUTHORIZED,
                            detail="Invalid username or password"
                        )
                except self.cognito_client.exceptions.UserNotFoundException:
                    raise HTTPException(
                        status_code=status.HTTP_401_UNAUTHORIZED,
                        detail="Invalid username or password"
                    )
                except HTTPException:
                    raise
                except Exception:
                    # If we can't check user status, return generic error
                    raise HTTPException(
                        status_code=status.HTTP_401_UNAUTHORIZED,
                        detail="Invalid username or password"
                    )
            else:
                raise HTTPException(
                    status_code=status.HTTP_401_UNAUTHORIZED,
                    detail="Authentication failed"
                )
        except self.cognito_client.exceptions.UserNotConfirmedException:
            raise HTTPException(
                status_code=status.HTTP_400_BAD_REQUEST,
                detail={
                    "error": "account_not_confirmed",
                    "message": "User account not confirmed. Please check your email for confirmation link."
                }
            )
        except self.cognito_client.exceptions.PasswordResetRequiredException:
            raise HTTPException(
                status_code=status.HTTP_400_BAD_REQUEST,
                detail={
                    "error": "password_reset_required",
                    "message": "Password reset required. Please contact administrator."
                }
            )
        except HTTPException:
            raise
        except Exception as e:
            print(f"🔥 DETAILED ERROR: {type(e).__name__}: {str(e)}")
            print(f"🔥 ERROR LOCATION: authenticate_user method")
            import traceback
            traceback.print_exc()
            raise HTTPException(
                status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
                detail="Authentication service error"
            )
    
    async def handle_new_password_challenge(self, username: str, new_password: str, session: str) -> Dict[str, Any]:
        """Handle NEW_PASSWORD_REQUIRED challenge"""
        try:
            secret_hash = self._calculate_secret_hash(username)
            
            response = self.cognito_client.respond_to_auth_challenge(
                ClientId=self.client_id,
                ChallengeName='NEW_PASSWORD_REQUIRED',
                Session=session,
                ChallengeResponses={
                    'USERNAME': username,
                    'NEW_PASSWORD': new_password,
                    'SECRET_HASH': secret_hash
                }
            )
            
            # Check if we have a successful authentication result
            if 'AuthenticationResult' not in response:
                raise HTTPException(
                    status_code=status.HTTP_400_BAD_REQUEST,
                    detail="Password change failed - unexpected response format"
                )
            
            # Extract tokens
            auth_result = response['AuthenticationResult']
            access_token = auth_result['AccessToken']
            id_token = auth_result['IdToken']
            refresh_token = auth_result['RefreshToken']
            
            # Get user info from ID token
            user_info = self._decode_token(id_token)
            
            return {
                'access_token': access_token,
                'id_token': id_token,
                'refresh_token': refresh_token,
                'user_info': user_info,
                'expires_in': auth_result.get('ExpiresIn', 3600)
            }
            
        except Exception as e:
            print(f"Password challenge error: {e}")
            raise HTTPException(
                status_code=status.HTTP_400_BAD_REQUEST,
                detail="Failed to set new password"
            )
    
    def _decode_token(self, token: str) -> Dict[str, Any]:
        """Decode JWT token without verification (for user info extraction)"""
        try:
            # Decode without verification to get user info
            decoded = jwt.decode(token, options={"verify_signature": False})
            return {
                'username': decoded.get('cognito:username', ''),
                'email': decoded.get('email', ''),
                'sub': decoded.get('sub', ''),
                'exp': decoded.get('exp', 0)
            }
        except Exception as e:
            print(f"Token decode error: {e}")
            return {}
    
    async def verify_token(self, token: str) -> Dict[str, Any]:
        """Verify Cognito access token"""
        try:
            # For production, you should verify the token signature with Cognito's public keys
            # For now, we'll do basic validation
            response = self.cognito_client.get_user(AccessToken=token)
            
            # Extract user attributes
            user_attributes = {}
            for attr in response.get('UserAttributes', []):
                user_attributes[attr['Name']] = attr['Value']
            
            return {
                'username': response.get('Username', ''),
                'email': user_attributes.get('email', ''),
                'sub': user_attributes.get('sub', ''),
                'attributes': user_attributes
            }
            
        except self.cognito_client.exceptions.NotAuthorizedException:
            raise HTTPException(
                status_code=status.HTTP_401_UNAUTHORIZED,
                detail="Invalid or expired token"
            )
        except Exception as e:
            print(f"Token verification error: {e}")
            raise HTTPException(
                status_code=status.HTTP_401_UNAUTHORIZED,
                detail="Token verification failed"
            )
    
    async def refresh_access_token(self, refresh_token: str, username: str) -> Dict[str, Any]:
        """Refresh access token using refresh token"""
        try:
            secret_hash = self._calculate_secret_hash(username)
            
            response = self.cognito_client.initiate_auth(
                ClientId=self.client_id,
                AuthFlow='REFRESH_TOKEN_AUTH',
                AuthParameters={
                    'REFRESH_TOKEN': refresh_token,
                    'SECRET_HASH': secret_hash
                }
            )
            
            auth_result = response['AuthenticationResult']
            return {
                'access_token': auth_result['AccessToken'],
                'id_token': auth_result['IdToken'],
                'expires_in': auth_result.get('ExpiresIn', 3600)
            }
            
        except Exception as e:
            print(f"Token refresh error: {e}")
            raise HTTPException(
                status_code=status.HTTP_401_UNAUTHORIZED,
                detail="Token refresh failed"
            )
    
    def create_fallback_token(self, username: str) -> str:
        """Create fallback JWT token for demo purposes"""
        expire = datetime.utcnow() + timedelta(hours=24)
        payload = {
            "username": username,
            "exp": expire,
            "iat": datetime.utcnow(),
            "iss": "redington-demo"
        }
        return jwt.encode(payload, self.secret_key, algorithm="HS256")
    
    def verify_fallback_token(self, token: str) -> Dict[str, Any]:
        """Verify fallback JWT token"""
        try:
            payload = jwt.decode(token, self.secret_key, algorithms=["HS256"])
            return {
                'username': payload.get('username', ''),
                'exp': payload.get('exp', 0)
            }
        except ExpiredSignatureError:
            raise HTTPException(
                status_code=status.HTTP_401_UNAUTHORIZED,
                detail="Token expired"
            )
        except InvalidTokenError:
            raise HTTPException(
                status_code=status.HTTP_401_UNAUTHORIZED,
                detail="Invalid token"
            )
