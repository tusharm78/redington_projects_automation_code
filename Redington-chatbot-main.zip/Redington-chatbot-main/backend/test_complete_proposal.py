#!/usr/bin/env python3
"""
Test script to check if complete proposals are generated
"""

import requests
import json
import time

def test_complete_proposal():
    """Test if the complete proposal is generated without truncation"""
    
    print("🧪 Testing Complete Proposal Generation")
    print("=" * 50)
    
    # Login
    print("🔐 Logging in...")
    login_response = requests.post("http://localhost:8000/api/v1/auth/login", json={
        "username": "tanmay",
        "password": "Admin@123$"
    })
    
    if login_response.status_code != 200:
        print(f"❌ Login failed: {login_response.status_code}")
        return
    
    token = login_response.json()["access_token"]
    headers = {"Authorization": f"Bearer {token}"}
    print("✅ Login successful\n")
    
    # Test with a customer name
    test_message = "Create a comprehensive cloud migration proposal for Microsoft Corporation"
    print(f"📝 Testing: '{test_message}'")
    print("🔄 Generating complete response...\n")
    
    # Send request
    response = requests.post("http://localhost:8000/api/v1/chat/stream",
        json={
            "message": test_message,
            "session_id": "complete_test_session",
            "model": "claude-3-7-sonnet"
        },
        headers=headers,
        stream=True
    )
    
    if response.status_code != 200:
        print(f"❌ Request failed: {response.status_code}")
        return
    
    # Collect all chunks
    full_response = ""
    chunk_count = 0
    sections_found = []
    
    print("📄 Streaming response chunks:")
    print("-" * 50)
    
    for line in response.iter_lines():
        if line:
            line_str = line.decode('utf-8')
            if line_str.startswith('data: '):
                try:
                    data = json.loads(line_str[6:])
                    if 'chunk' in data:
                        chunk = data['chunk']
                        full_response += chunk
                        chunk_count += 1
                        
                        # Print chunk info
                        print(f"Chunk {chunk_count}: {len(chunk)} chars")
                        
                        # Look for section headers
                        if chunk.strip().startswith('##') and any(word in chunk.upper() for word in ['EXECUTIVE', 'REQUIREMENT', 'SUCCESS', 'SOLUTION', 'ARCHITECTURE', 'SCOPE', 'TESTING', 'RACI', 'ASSUMPTIONS', 'TIMELINE', 'COMMERCIAL', 'BOQ', 'ESCALATION', 'SATISFACTION']):
                            section = chunk.strip().split('\n')[0]
                            sections_found.append(section)
                            print(f"  → Found section: {section}")
                    
                    if data.get('is_complete', False):
                        print(f"\n✅ Response completed after {chunk_count} chunks")
                        break
                        
                except json.JSONDecodeError:
                    continue
    
    print("-" * 50)
    
    # Analysis
    print(f"\n📊 Analysis:")
    print(f"   • Total response length: {len(full_response)} characters")
    print(f"   • Total chunks received: {chunk_count}")
    print(f"   • Sections found: {len(sections_found)}")
    
    print(f"\n📋 Sections detected:")
    for i, section in enumerate(sections_found, 1):
        print(f"   {i:2d}. {section}")
    
    # Check for key sections that should be present
    expected_sections = [
        'EXECUTIVE SUMMARY',
        'STATED REQUIREMENT', 
        'SUCCESS CRITERIA',
        'PROPOSED SOLUTION',
        'PROPOSED ARCHITECTURE',
        'SCOPE OF WORK',
        'TESTING',
        'RACI MATRIX',
        'OUT OF SCOPE',
        'GENERAL ASSUMPTIONS',
        'PROJECT TIMELINE',
        'PROPOSED COMMERCIALS',
        'BOQ ESTIMATION',
        'ESCALATION MATRIX',
        'CLIENT SATISFACTION'
    ]
    
    print(f"\n🎯 Section Completeness Check:")
    missing_sections = []
    for expected in expected_sections:
        found = any(expected.lower() in section.lower() for section in sections_found)
        status = "✅" if found else "❌"
        print(f"   {status} {expected}")
        if not found:
            missing_sections.append(expected)
    
    if missing_sections:
        print(f"\n⚠️  Missing sections ({len(missing_sections)}):")
        for section in missing_sections:
            print(f"   • {section}")
        print(f"\n💡 This suggests the response was truncated at section {len(sections_found)}")
    else:
        print(f"\n🎉 All expected sections found! Complete proposal generated.")
    
    # Check for customer name replacement
    if "Microsoft" in full_response:
        print(f"\n✅ Customer name 'Microsoft' successfully replaced in proposal")
    else:
        print(f"\n⚠️  Customer name 'Microsoft' not found in response")
    
    # Save full response for inspection
    with open('/home/meenal/redington-chatbot/backend/test_complete_response.txt', 'w') as f:
        f.write(full_response)
    print(f"\n💾 Full response saved to: test_complete_response.txt")

if __name__ == "__main__":
    test_complete_proposal()
