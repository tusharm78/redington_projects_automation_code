from fastapi import FastAPI

app = FastAPI()

@app.get("/")
async def root():
    return {"message": "Test app working"}

@app.get("/health")
async def health():
    return {"status": "healthy"}

if __name__ == "__main__":
    import uvicorn
    uvicorn.run("test_app:app", host="0.0.0.0", port=8003, reload=False)
