#!/bin/bash

# Start Enhanced Bedrock Backend with Cognito
echo "🚀 Starting Redington AI Bot - Enhanced Bedrock with Cognito"
echo "============================================================"

# Check if already running
if [ -f "enhanced_cognito.pid" ]; then
    PID=$(cat enhanced_cognito.pid)
    if ps -p $PID > /dev/null 2>&1; then
        echo "⚠️  Backend already running (PID: $PID)"
        echo "   Use ./stop_enhanced_cognito.sh to stop first"
        exit 1
    else
        echo "🧹 Cleaning up stale PID file"
        rm -f enhanced_cognito.pid
    fi
fi

# Check dependencies
echo "🔍 Checking dependencies..."
python3 -c "import boto3, jwt, fastapi" 2>/dev/null || {
    echo "❌ Missing dependencies. Installing..."
    pip install boto3 PyJWT fastapi uvicorn python-multipart
}

# Start the backend
echo "🔧 Starting Enhanced Bedrock backend with Cognito..."
nohup python3 enhanced_bedrock_main.py > enhanced_cognito.log 2>&1 & 
PID=$!
echo $PID > enhanced_cognito.pid

# Wait for startup
echo "⏳ Waiting for backend to initialize..."
sleep 5

# Check if it's running
if ps -p $PID > /dev/null 2>&1; then
    # Test health endpoint
    if curl -s http://localhost:8000/health > /dev/null 2>&1; then
        echo "✅ Backend started successfully (PID: $PID)"
        echo "🔗 Health check: http://localhost:8000/health"
        echo "📖 API Docs: http://localhost:8000/docs"
        echo "📋 Logs: tail -f enhanced_cognito.log"
        
        # Show service status
        echo ""
        echo "🔧 Service Status:"
        curl -s http://localhost:8000/health | jq . 2>/dev/null || curl -s http://localhost:8000/health
        
    else
        echo "❌ Backend started but health check failed"
        echo "📋 Check logs: tail -f enhanced_cognito.log"
    fi
else
    echo "❌ Failed to start backend"
    echo "📋 Check logs: tail -f enhanced_cognito.log"
    rm -f enhanced_cognito.pid
    exit 1
fi
