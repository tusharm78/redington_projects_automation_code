#!/usr/bin/env python3
"""
Secure Admin API - Separate authentication from Cognito users
Only built-in admin credentials can access this API
"""

import asyncio
import json
import boto3
import os
from datetime import datetime, timedelta
from typing import Dict, List, Optional
from fastapi import FastAPI, HTTPException, Depends, status
from fastapi.middleware.cors import CORSMiddleware
from fastapi.security import HTTPBearer, HTTPAuthorizationCredentials
from pydantic import BaseModel
import logging

# Import our separate admin auth system
from admin_auth import admin_auth
from realtime_session_tracker import session_tracker
from session_hooks import get_realtime_active_users

# Load environment variables
from dotenv import load_dotenv
load_dotenv()

# Setup logging
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

# Create FastAPI app
app = FastAPI(
    title="Secure Admin API",
    description="Admin API with separate authentication (not Cognito)",
    version="3.0.0"
)

# Add CORS middleware
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# Security
security = HTTPBearer()

# Pydantic models
class AdminLoginRequest(BaseModel):
    username: str
    password: str

class AdminLoginResponse(BaseModel):
    access_token: str
    token_type: str
    expires_in: int
    user_info: Dict

# Cognito Configuration (for reading user data only)
COGNITO_USER_POOL_ID = os.getenv("POOL_ID")
COGNITO_REGION = os.getenv("AWS_DEFAULT_REGION", "us-east-1")

class SecureAdminAPI:
    def __init__(self):
        self.cognito_client = None
        self.init_aws_clients()
    
    def init_aws_clients(self):
        """Initialize AWS clients for reading Cognito data"""
        try:
            self.cognito_client = boto3.client('cognito-idp', region_name=COGNITO_REGION)
            logger.info("✅ Connected to AWS Cognito (read-only for user data)")
        except Exception as e:
            logger.error(f"❌ Failed to connect to Cognito: {e}")
    
    async def get_all_users_with_realtime_status(self) -> List[Dict]:
        """Get all Cognito users with real-time online status"""
        if not self.cognito_client or not COGNITO_USER_POOL_ID:
            return []
        
        try:
            # Get all Cognito users (chatbot users)
            all_users = []
            paginator = self.cognito_client.get_paginator('list_users')
            
            for page in paginator.paginate(UserPoolId=COGNITO_USER_POOL_ID):
                for user in page.get('Users', []):
                    user_data = self._process_cognito_user(user)
                    if user_data:
                        all_users.append(user_data)
            
            # Get real-time active users from session tracker
            active_users = get_realtime_active_users()
            active_usernames = {user['username'] for user in active_users}
            
            # Create lookup for active user data
            active_user_data = {user['username']: user for user in active_users}
            
            # Update status for all users
            for user in all_users:
                username = user['username']
                
                if username in active_usernames:
                    # User is currently online in chatbot
                    active_data = active_user_data[username]
                    user['status'] = 'online'
                    user['login_time'] = active_data['login_time']
                    user['last_activity'] = active_data['last_activity']
                    user['session_duration'] = active_data['session_duration']
                    logger.debug(f"✅ {username} is ONLINE (chatbot session active)")
                else:
                    # User is offline
                    user['status'] = 'offline'
                    logger.debug(f"⚪ {username} is OFFLINE (no active chatbot session)")
            
            # Sort by status (online first) then by username
            all_users.sort(key=lambda x: (x['status'] != 'online', x['username']))
            
            online_count = len([u for u in all_users if u['status'] == 'online'])
            logger.info(f"📊 Chatbot users: {online_count} online, {len(all_users) - online_count} offline")
            
            return all_users
            
        except Exception as e:
            logger.error(f"❌ Error getting users with real-time status: {e}")
            return []
    
    def _process_cognito_user(self, cognito_user: Dict) -> Optional[Dict]:
        """Process a single Cognito user (chatbot user)"""
        try:
            username = cognito_user.get('Username', '')
            user_status = cognito_user.get('UserStatus', 'UNKNOWN')
            enabled = cognito_user.get('Enabled', False)
            created_date = cognito_user.get('UserCreateDate')
            last_modified = cognito_user.get('UserLastModifiedDate')
            
            # Extract user attributes
            attributes = {}
            for attr in cognito_user.get('Attributes', []):
                attributes[attr['Name']] = attr['Value']
            
            return {
                'username': username,
                'email': attributes.get('email', f'{username}@redington.local'),
                'status': 'offline',  # Will be updated by real-time check
                'cognito_status': user_status,
                'enabled': enabled,
                'created_date': created_date.isoformat() if created_date else '',
                'last_modified': last_modified.isoformat() if last_modified else '',
                'login_time': '',  # Will be updated by real-time check
                'last_activity': '',  # Will be updated by real-time check
                'session_duration': '0m',
                'chat_sessions': 0,
                'messages_sent': 0,
                'phone_number': attributes.get('phone_number', ''),
                'email_verified': attributes.get('email_verified', 'false') == 'true'
            }
            
        except Exception as e:
            logger.error(f"Error processing user: {e}")
            return None

# Initialize API
secure_admin_api = SecureAdminAPI()

async def verify_admin(credentials: HTTPAuthorizationCredentials = Depends(security)):
    """Verify admin token using separate admin auth system"""
    try:
        token = credentials.credentials
        payload = admin_auth.verify_admin_token(token)
        
        if not payload:
            raise HTTPException(
                status_code=status.HTTP_401_UNAUTHORIZED,
                detail="Invalid or expired admin token"
            )
        
        return payload
        
    except Exception as e:
        logger.error(f"❌ Admin token verification error: {e}")
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail="Authentication failed"
        )

@app.get("/")
async def root():
    """Root endpoint"""
    return {
        "message": "Secure Admin API - Separate Authentication",
        "version": "3.0.0",
        "status": "operational",
        "authentication": "built-in-admin-only",
        "features": ["real-time-sessions", "heartbeat-tracking", "instant-logout-detection"],
        "security": "isolated-from-cognito",
        "timestamp": datetime.utcnow().isoformat()
    }

@app.post("/api/v1/auth/login", response_model=AdminLoginResponse)
async def admin_login(login_request: AdminLoginRequest):
    """Admin login with built-in credentials only"""
    username = login_request.username
    password = login_request.password
    
    # Authenticate using separate admin auth system
    admin_data = admin_auth.authenticate_admin(username, password)
    
    if not admin_data:
        logger.warning(f"❌ Failed admin login attempt: {username}")
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail="Invalid admin credentials"
        )
    
    # Create admin token
    access_token = admin_auth.create_admin_token(admin_data)
    
    logger.info(f"✅ Admin login successful: {username}")
    
    return AdminLoginResponse(
        access_token=access_token,
        token_type="Bearer",
        expires_in=28800,  # 8 hours
        user_info={
            "username": admin_data["username"],
            "email": admin_data["email"],
            "role": admin_data["role"],
            "type": "admin"
        }
    )

@app.get("/api/v1/admin/verify")
async def verify_admin_token(admin_user: Dict = Depends(verify_admin)):
    """Verify admin token"""
    return {
        "valid": True,
        "user": admin_user,
        "timestamp": datetime.utcnow().isoformat()
    }

@app.get("/api/v1/admin/active-users")
async def get_active_users(admin_user: Dict = Depends(verify_admin)):
    """Get all chatbot users with real-time online/offline status"""
    users = await secure_admin_api.get_all_users_with_realtime_status()
    
    logger.info(f"Admin {admin_user['username']} requested chatbot user status")
    
    return users

@app.post("/api/v1/admin/simulate-login/{username}")
async def simulate_user_login(username: str, admin_user: Dict = Depends(verify_admin)):
    """Simulate chatbot user login for testing"""
    try:
        session_tracker.user_login(username, f"admin-test-{username}")
        logger.info(f"Admin {admin_user['username']} simulated chatbot login for {username}")
        
        return {
            "success": True,
            "message": f"Chatbot user {username} marked as online",
            "timestamp": datetime.utcnow().isoformat()
        }
    except Exception as e:
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail=f"Failed to simulate login: {str(e)}"
        )

@app.post("/api/v1/admin/simulate-logout/{username}")
async def simulate_user_logout(username: str, admin_user: Dict = Depends(verify_admin)):
    """Simulate chatbot user logout for testing"""
    try:
        session_tracker.user_logout(username)
        logger.info(f"Admin {admin_user['username']} simulated chatbot logout for {username}")
        
        return {
            "success": True,
            "message": f"Chatbot user {username} marked as offline",
            "timestamp": datetime.utcnow().isoformat()
        }
    except Exception as e:
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail=f"Failed to simulate logout: {str(e)}"
        )

@app.get("/api/v1/admin/realtime-stats")
async def get_realtime_stats(admin_user: Dict = Depends(verify_admin)):
    """Get real-time statistics"""
    try:
        active_users = get_realtime_active_users()
        all_users = await secure_admin_api.get_all_users_with_realtime_status()
        
        stats = {
            "total_chatbot_users": len(all_users),
            "online_chatbot_users": len(active_users),
            "offline_chatbot_users": len(all_users) - len(active_users),
            "active_sessions": len(active_users),
            "last_updated": datetime.utcnow().isoformat()
        }
        
        return {"stats": stats}
        
    except Exception as e:
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail=f"Failed to get stats: {str(e)}"
        )

@app.get("/api/v1/admin/profile")
async def get_admin_profile(admin_user: Dict = Depends(verify_admin)):
    """Get admin profile information"""
    try:
        profile = admin_auth.get_admin_info(admin_user["username"])
        
        if not profile:
            raise HTTPException(
                status_code=status.HTTP_404_NOT_FOUND,
                detail="Admin profile not found"
            )
        
        return {
            "profile": profile,
            "timestamp": datetime.utcnow().isoformat()
        }
        
    except HTTPException:
        raise
    except Exception as e:
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail=f"Failed to get profile: {str(e)}"
        )

if __name__ == "__main__":
    import uvicorn
    uvicorn.run(app, host="0.0.0.0", port=8005)
