from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware
from fastapi.middleware.trustedhost import TrustedHostMiddleware
from app.api import auth, chat
from app.api.sessions import router as sessions_router
from app.api.local_rag import router as local_rag_router
from app.core.config import settings

# Create FastAPI application
app = FastAPI(
    title="Redington AI Bot API",
    description="Backend API for Redington AI Chatbot with Local RAG",
    version="1.0.0"
)

# Add CORS middleware
app.add_middleware(
    CORSMiddleware,
    allow_origins=settings.allowed_origins,
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# Add trusted host middleware
app.add_middleware(
    TrustedHostMiddleware,
    allowed_hosts=["localhost", "127.0.0.1", "*.localhost", "43.204.187.174", "43.204.187.174:8000", "43.204.187.174:3001"]
)

# Include routers
app.include_router(auth.router, prefix="/api/v1")
app.include_router(chat.router, prefix="/api/v1")
app.include_router(sessions_router, prefix="/api/v1")
app.include_router(local_rag_router, prefix="/api/v1/rag", tags=["Local RAG"])

@app.get("/")
async def root():
    """Root endpoint"""
    return {"message": "Redington AI Bot API with Local RAG", "version": "1.0.0"}

@app.get("/health")
async def health_check():
    """Health check endpoint"""
    return {"status": "healthy", "service": "redington-ai-bot-api"}

if __name__ == "__main__":
    import uvicorn
    uvicorn.run(
        "main:app",
        host="0.0.0.0",
        port=8000,
        reload=True,
        log_level="info"
    )
