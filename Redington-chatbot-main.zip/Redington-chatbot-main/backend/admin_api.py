#!/usr/bin/env python3
"""
Admin API Backend - Provides real user data from AWS Cognito
This runs independently and queries Cognito for real user information
"""

import asyncio
import json
import boto3
import os
from datetime import datetime, timedelta
from typing import Dict, List, Optional
from fastapi import FastAPI, HTTPException, Depends, status
from fastapi.middleware.cors import CORSMiddleware
from fastapi.security import HTTPBearer, HTTPAuthorizationCredentials
from pydantic import BaseModel
import jwt
from dotenv import load_dotenv
import logging

# Load environment variables
load_dotenv()

# Setup logging
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

# Create FastAPI app
app = FastAPI(
    title="Redington AI Bot - Admin API",
    description="Admin API for monitoring real Cognito users",
    version="1.0.0"
)

# Add CORS middleware
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# Security
security = HTTPBearer()

# Pydantic models
class AdminLoginRequest(BaseModel):
    username: str
    password: str

class AdminLoginResponse(BaseModel):
    access_token: str
    token_type: str
    expires_in: int
    user_info: Dict

# Admin users (same as before)
ADMIN_USERS = {
    "admin": "admin123",
    "tanmay": "tanmay123", 
    "meenal": "meenal123",
    "varunesh": "varunesh123"
}

# JWT Secret
SECRET_KEY = os.getenv("SECRET_KEY", "your-secret-key-change-in-production")

# Cognito Configuration
COGNITO_USER_POOL_ID = os.getenv("POOL_ID")
COGNITO_REGION = os.getenv("AWS_DEFAULT_REGION", "us-east-1")

class AdminAPI:
    def __init__(self):
        self.cognito_client = None
        self.dynamodb = None
        self.session_table = None
        self.init_aws_clients()
    
    def init_aws_clients(self):
        """Initialize AWS clients with same config as main backend"""
        try:
            # Use same region and credentials as main backend
            session = boto3.Session()
            
            # Initialize Cognito client
            self.cognito_client = session.client('cognito-idp', region_name=COGNITO_REGION)
            logger.info("✅ Connected to AWS Cognito")
            
            # Initialize DynamoDB with same session
            self.dynamodb = session.resource('dynamodb', region_name=COGNITO_REGION)
            self.session_table = self.dynamodb.Table('user_chat_sessions')
            
            # Test table access
            try:
                self.session_table.load()
                logger.info("✅ Connected to DynamoDB table: user_chat_sessions")
                logger.info(f"✅ Table status: {self.session_table.table_status}")
            except Exception as e:
                logger.error(f"❌ Failed to access DynamoDB table: {e}")
                self.session_table = None
                
        except Exception as e:
            logger.error(f"❌ Failed to connect to AWS services: {e}")
            self.cognito_client = None
            self.dynamodb = None
            self.session_table = None
    
    def create_admin_token(self, username: str) -> str:
        """Create JWT token for admin"""
        payload = {
            "username": username,
            "role": "admin",
            "exp": datetime.utcnow() + timedelta(hours=8)  # 8 hour expiry
        }
        return jwt.encode(payload, SECRET_KEY, algorithm="HS256")
    
    def verify_admin_token(self, token: str) -> Dict:
        """Verify admin JWT token"""
        try:
            payload = jwt.decode(token, SECRET_KEY, algorithms=["HS256"])
            username = payload.get("username")
            
            if username not in ADMIN_USERS:
                raise HTTPException(
                    status_code=status.HTTP_403_FORBIDDEN,
                    detail="Access denied: Admin privileges required"
                )
            
            return payload
        except jwt.ExpiredSignatureError:
            raise HTTPException(
                status_code=status.HTTP_401_UNAUTHORIZED,
                detail="Token expired"
            )
        except jwt.InvalidTokenError:
            raise HTTPException(
                status_code=status.HTTP_401_UNAUTHORIZED,
                detail="Invalid token"
            )
    
    async def get_cognito_users(self) -> List[Dict]:
        """Get real users from AWS Cognito"""
        if not self.cognito_client or not COGNITO_USER_POOL_ID:
            logger.error("❌ Cognito client or pool ID not configured")
            return []
        
        try:
            users = []
            paginator = self.cognito_client.get_paginator('list_users')
            
            # Get all users from Cognito
            for page in paginator.paginate(UserPoolId=COGNITO_USER_POOL_ID):
                for user in page.get('Users', []):
                    user_data = self._process_cognito_user(user)
                    if user_data:
                        users.append(user_data)
            
            # Enhance with session data if available
            users = await self._enhance_with_session_data(users)
            
            logger.info(f"✅ Found {len(users)} Cognito users")
            return users
            
        except Exception as e:
            logger.error(f"❌ Error getting Cognito users: {e}")
            return []
    
    def _process_cognito_user(self, cognito_user: Dict) -> Optional[Dict]:
        """Process a single Cognito user"""
        try:
            username = cognito_user.get('Username', '')
            user_status = cognito_user.get('UserStatus', 'UNKNOWN')
            enabled = cognito_user.get('Enabled', False)
            created_date = cognito_user.get('UserCreateDate')
            last_modified = cognito_user.get('UserLastModifiedDate')
            
            # Extract user attributes
            attributes = {}
            for attr in cognito_user.get('Attributes', []):
                attributes[attr['Name']] = attr['Value']
            
            # Determine if user is "online" (active recently)
            # For Cognito users, we'll consider them online if they were modified recently
            is_online = False
            if last_modified:
                time_diff = (datetime.now(last_modified.tzinfo) - last_modified).total_seconds()
                is_online = time_diff < 3600  # Active within last hour
            
            return {
                'username': username,
                'email': attributes.get('email', f'{username}@redington.local'),
                'status': 'online' if (is_online and enabled and user_status == 'CONFIRMED') else 'offline',
                'cognito_status': user_status,
                'enabled': enabled,
                'created_date': created_date.isoformat() if created_date else '',
                'last_modified': last_modified.isoformat() if last_modified else '',
                'login_time': last_modified.isoformat() if last_modified else '',
                'last_activity': last_modified.isoformat() if last_modified else '',
                'session_duration': self._calculate_duration_from_cognito(created_date, last_modified),
                'chat_sessions': 0,  # Will be enhanced from session data
                'messages_sent': 0,  # Will be enhanced from session data
                'phone_number': attributes.get('phone_number', ''),
                'email_verified': attributes.get('email_verified', 'false') == 'true'
            }
            
        except Exception as e:
            logger.error(f"Error processing Cognito user: {e}")
            return None
    
    async def _enhance_with_session_data(self, users: List[Dict]) -> List[Dict]:
        """Enhance Cognito user data with session information from DynamoDB"""
        if not self.session_table:
            return users
        
        try:
            # Get recent activity cutoff (last 10 minutes for online status)
            online_cutoff = datetime.utcnow() - timedelta(minutes=10)
            online_cutoff_str = online_cutoff.isoformat()
            
            # Get session data for each user
            for user in users:
                username = user['username']
                
                # Query DynamoDB for user sessions using correct key structure
                try:
                    from boto3.dynamodb.conditions import Key
                    
                    response = self.session_table.query(
                        KeyConditionExpression=Key("user_id").eq(username)
                    )
                    
                    sessions = response.get('Items', [])
                    if sessions:
                        # Count messages and sessions
                        message_count = 0
                        session_count = len(sessions)
                        latest_activity = None
                        login_time = None
                        
                        for session in sessions:
                            if 'message_data' in session:
                                message_count += 1
                            
                            # Get the most recent activity
                            activity_time = session.get('last_activity', session.get('created_at'))
                            if activity_time:
                                if not latest_activity or activity_time > latest_activity:
                                    latest_activity = activity_time
                            
                            # Get earliest login time
                            created_time = session.get('created_at')
                            if created_time:
                                if not login_time or created_time < login_time:
                                    login_time = created_time
                        
                        # Update user data with session info
                        user['chat_sessions'] = session_count
                        user['messages_sent'] = message_count
                        
                        if latest_activity:
                            user['last_activity'] = latest_activity
                            user['login_time'] = login_time or latest_activity
                            
                            # Update online status based on recent chatbot activity
                            try:
                                activity_dt = datetime.fromisoformat(latest_activity.replace('Z', '+00:00'))
                                time_diff = (datetime.utcnow() - activity_dt.replace(tzinfo=None)).total_seconds()
                                
                                # Mark as online if active in chatbot within last 10 minutes
                                if time_diff < 600:  # 10 minutes
                                    user['status'] = 'online'
                                    logger.info(f"User {username} marked online - last activity {time_diff/60:.1f} minutes ago")
                                else:
                                    user['status'] = 'offline'
                                    logger.info(f"User {username} marked offline - last activity {time_diff/60:.1f} minutes ago")
                                    
                                # Update session duration from login to last activity
                                if login_time:
                                    login_dt = datetime.fromisoformat(login_time.replace('Z', '+00:00'))
                                    duration = activity_dt - login_dt
                                    user['session_duration'] = self._format_duration(duration)
                                    
                            except Exception as e:
                                logger.error(f"Error calculating activity for {username}: {e}")
                        else:
                            # No chatbot activity, keep Cognito-based status
                            user['status'] = 'offline'
                            logger.info(f"User {username} has no chatbot activity")
                    else:
                        # No sessions found, user hasn't used chatbot
                        user['status'] = 'offline'
                        user['chat_sessions'] = 0
                        user['messages_sent'] = 0
                        logger.info(f"User {username} has no chatbot sessions")
                
                except Exception as e:
                    logger.error(f"Error getting session data for {username}: {e}")
                    continue
            
            return users
            
        except Exception as e:
            logger.error(f"Error enhancing with session data: {e}")
            return users
    
    def _format_duration(self, duration) -> str:
        """Format duration object to readable string"""
        try:
            total_seconds = int(duration.total_seconds())
            if total_seconds < 60:
                return f"{total_seconds}s"
            
            total_minutes = total_seconds // 60
            if total_minutes < 60:
                return f"{total_minutes}m"
            else:
                hours = total_minutes // 60
                minutes = total_minutes % 60
                return f"{hours}h {minutes}m"
        except:
            return "0m"
    
    def _calculate_duration_from_cognito(self, created_date, last_modified) -> str:
        """Calculate duration from Cognito timestamps"""
        try:
            if not created_date or not last_modified:
                return "0m"
            
            duration = last_modified - created_date
            total_minutes = int(duration.total_seconds() / 60)
            
            if total_minutes < 60:
                return f"{total_minutes}m"
            else:
                hours = total_minutes // 60
                minutes = total_minutes % 60
                return f"{hours}h {minutes}m"
        except:
            return "0m"

# Initialize admin API
admin_api = AdminAPI()

async def verify_admin(credentials: HTTPAuthorizationCredentials = Depends(security)):
    """Verify admin token"""
    token = credentials.credentials
    payload = admin_api.verify_admin_token(token)
    return payload

@app.get("/")
async def root():
    """Root endpoint"""
    return {
        "message": "Redington AI Bot - Admin API (Cognito Integration)",
        "version": "1.0.0",
        "status": "operational",
        "cognito_configured": bool(COGNITO_USER_POOL_ID),
        "timestamp": datetime.utcnow().isoformat()
    }

@app.post("/api/v1/auth/login", response_model=AdminLoginResponse)
async def admin_login(login_request: AdminLoginRequest):
    """Admin login endpoint"""
    username = login_request.username
    password = login_request.password
    
    if username not in ADMIN_USERS or ADMIN_USERS[username] != password:
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail="Invalid credentials"
        )
    
    # Create token
    access_token = admin_api.create_admin_token(username)
    
    logger.info(f"✅ Admin login successful: {username}")
    
    return AdminLoginResponse(
        access_token=access_token,
        token_type="Bearer",
        expires_in=28800,  # 8 hours
        user_info={
            "username": username,
            "role": "admin",
            "email": f"{username}@redington.local"
        }
    )

@app.get("/api/v1/admin/verify")
async def verify_admin_token(admin_user: Dict = Depends(verify_admin)):
    """Verify admin token (for session persistence)"""
    return {
        "valid": True,
        "user": admin_user,
        "timestamp": datetime.utcnow().isoformat()
    }

@app.get("/api/v1/admin/active-users")
async def get_active_users(admin_user: Dict = Depends(verify_admin)):
    """Get active users from AWS Cognito"""
    users = await admin_api.get_cognito_users()
    
    logger.info(f"Admin {admin_user['username']} requested Cognito users")
    
    return users

@app.get("/api/v1/admin/stats")
async def get_admin_stats(admin_user: Dict = Depends(verify_admin)):
    """Get admin statistics from Cognito users"""
    users = await admin_api.get_cognito_users()
    
    active_users = [u for u in users if u['status'] == 'online']
    confirmed_users = [u for u in users if u['cognito_status'] == 'CONFIRMED']
    total_sessions = sum(u['chat_sessions'] for u in users)
    total_messages = sum(u['messages_sent'] for u in users)
    
    most_active = max(users, key=lambda u: u['messages_sent']) if users else None
    
    # Calculate average duration
    durations = []
    for user in users:
        duration_str = user['session_duration']
        minutes = 0
        if 'h' in duration_str:
            hours = int(duration_str.split('h')[0])
            minutes += hours * 60
        if 'm' in duration_str:
            mins = int(duration_str.split('m')[0].split(' ')[-1])
            minutes += mins
        durations.append(minutes)
    
    avg_duration_mins = sum(durations) // len(durations) if durations else 0
    avg_duration = f"{avg_duration_mins // 60}h {avg_duration_mins % 60}m" if avg_duration_mins >= 60 else f"{avg_duration_mins}m"
    
    stats = {
        "total_active_users": len(active_users),
        "total_users": len(users),
        "confirmed_users": len(confirmed_users),
        "total_sessions": total_sessions,
        "total_messages": total_messages,
        "avg_duration": avg_duration,
        "most_active_user": most_active['username'] if most_active else None
    }
    
    logger.info(f"Admin {admin_user['username']} requested Cognito stats")
    
    return {"stats": stats}

@app.get("/api/v1/admin/user/{username}")
async def get_user_details(username: str, admin_user: Dict = Depends(verify_admin)):
    """Get detailed information for a specific user"""
    users = await admin_api.get_cognito_users()
    user = next((u for u in users if u['username'] == username), None)
    
    if not user:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="User not found"
        )
    
    logger.info(f"Admin {admin_user['username']} requested details for user {username}")
    
    return user

@app.post("/api/v1/admin/simulate-activity/{username}")
async def simulate_user_activity(username: str, admin_user: Dict = Depends(verify_admin)):
    """Simulate user activity for testing (creates a session entry)"""
    if not admin_api.session_table:
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail="DynamoDB not configured"
        )
    
    try:
        # Create a test session entry to simulate activity
        current_time = datetime.utcnow().isoformat()
        chat_id = f"admin-test-{username}-{int(datetime.utcnow().timestamp())}"
        
        admin_api.session_table.put_item(
            Item={
                'user_id': username,  # Use user_id as primary key
                'chat_id': chat_id,   # Use chat_id as sort key
                'session_id': chat_id,
                'created_at': current_time,
                'last_activity': current_time,
                'message_data': json.dumps({
                    'message_id': f'test-{int(datetime.utcnow().timestamp())}',
                    'role': 'user',
                    'content': 'Test message for admin monitoring',
                    'timestamp': current_time
                })
            }
        )
        
        logger.info(f"Admin {admin_user['username']} simulated activity for user {username}")
        
        return {
            "success": True,
            "message": f"Activity simulated for user {username}",
            "chat_id": chat_id,
            "timestamp": current_time
        }
        
    except Exception as e:
        logger.error(f"Error simulating activity for {username}: {e}")
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail=f"Failed to simulate activity: {str(e)}"
        )

if __name__ == "__main__":
    import uvicorn
    uvicorn.run(app, host="0.0.0.0", port=8002)
