#!/usr/bin/env python3
"""
Test script to demonstrate customer name replacement functionality
"""

import requests
import json
import time

# Test configuration
BASE_URL = "http://localhost:8000"
USERNAME = "tanmay"
PASSWORD = "Admin@123$"

def test_customer_name_replacement():
    """Test the customer name replacement functionality"""
    
    print("🧪 Testing Customer Name Replacement Functionality")
    print("=" * 60)
    
    # Step 1: Login
    print("1. 🔐 Logging in...")
    login_response = requests.post(f"{BASE_URL}/api/v1/auth/login", json={
        "username": USERNAME,
        "password": PASSWORD
    })
    
    if login_response.status_code != 200:
        print(f"❌ Login failed: {login_response.status_code}")
        return
    
    token = login_response.json()["access_token"]
    headers = {"Authorization": f"Bearer {token}"}
    print("✅ Login successful")
    
    # Step 2: Test messages with customer names
    test_cases = [
        {
            "message": "Create a proposal for Microsoft Corporation",
            "expected_customer": "Microsoft"
        },
        {
            "message": "Generate a cloud migration proposal for Amazon Web Services",
            "expected_customer": "Amazon"
        },
        {
            "message": "Customer name is Tesla Motors and I need an infrastructure proposal",
            "expected_customer": "Tesla"
        },
        {
            "message": "Create a proposal without mentioning any specific customer",
            "expected_customer": None
        }
    ]
    
    for i, test_case in enumerate(test_cases, 1):
        print(f"\n{i}. 📝 Testing: '{test_case['message']}'")
        print(f"   Expected customer: {test_case['expected_customer'] or 'None'}")
        
        # Send chat request
        chat_response = requests.post(f"{BASE_URL}/api/v1/chat/stream", 
            json={
                "message": test_case["message"],
                "session_id": f"test_session_{i}",
                "model": "claude-3-7-sonnet"
            },
            headers=headers,
            stream=True
        )
        
        if chat_response.status_code != 200:
            print(f"   ❌ Chat request failed: {chat_response.status_code}")
            continue
        
        # Collect response chunks
        full_response = ""
        for line in chat_response.iter_lines():
            if line:
                line_str = line.decode('utf-8')
                if line_str.startswith('data: '):
                    try:
                        data = json.loads(line_str[6:])
                        if 'chunk' in data:
                            full_response += data['chunk']
                        if data.get('is_complete', False):
                            break
                    except json.JSONDecodeError:
                        continue
        
        # Check if customer name was replaced correctly
        if test_case['expected_customer']:
            if test_case['expected_customer'] in full_response:
                print(f"   ✅ Customer name '{test_case['expected_customer']}' found in response")
            else:
                print(f"   ❌ Customer name '{test_case['expected_customer']}' NOT found in response")
            
            # Check if placeholder was replaced
            if "<Customer Name>" in full_response:
                print(f"   ⚠️  Placeholder '<Customer Name>' still present (should be replaced)")
            else:
                print(f"   ✅ Placeholder '<Customer Name>' was replaced")
        else:
            # For cases without customer name, placeholder should remain
            if "<Customer Name>" in full_response:
                print(f"   ✅ Placeholder '<Customer Name>' correctly preserved")
            else:
                print(f"   ⚠️  Placeholder '<Customer Name>' was unexpectedly replaced")
        
        # Show a snippet of the response
        snippet = full_response[:200] + "..." if len(full_response) > 200 else full_response
        print(f"   📄 Response snippet: {snippet}")
        
        time.sleep(1)  # Brief pause between tests
    
    print(f"\n🎉 Customer name replacement testing completed!")

if __name__ == "__main__":
    test_customer_name_replacement()
