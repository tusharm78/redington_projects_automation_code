#!/usr/bin/env python3
"""
Test script for Enhanced Streaming API
"""

import requests
import json
import time

def test_enhanced_streaming():
    """Test the enhanced streaming API"""
    
    print("🧪 Testing Enhanced Streaming API")
    print("=" * 40)
    
    # Test authentication
    print("\n1. Testing Authentication...")
    auth_data = {
        "username": "demo",
        "password": "demo123"
    }
    
    try:
        auth_response = requests.post(
            "http://localhost:8000/api/v1/auth/login",
            json=auth_data,
            timeout=10
        )
        
        if auth_response.status_code == 200:
            token = auth_response.json()["access_token"]
            print("✅ Authentication successful")
        else:
            print(f"❌ Authentication failed: {auth_response.status_code}")
            return
            
    except Exception as e:
        print(f"❌ Authentication error: {e}")
        return
    
    # Test streaming
    print("\n2. Testing Enhanced Streaming...")
    
    headers = {
        "Authorization": f"Bearer {token}",
        "Content-Type": "application/json"
    }
    
    stream_data = {
        "message": "Tell me about Redington services",
        "conversation_id": "test-conversation",
        "session_id": "test-session"
    }
    
    try:
        print("📡 Starting stream request...")
        response = requests.post(
            "http://localhost:8000/api/v1/chat/stream",
            json=stream_data,
            headers=headers,
            stream=True,
            timeout=30
        )
        
        if response.status_code == 200:
            print("✅ Stream started successfully")
            print("\n📝 Streaming Response:")
            print("-" * 50)
            
            chunk_count = 0
            total_content = ""
            
            for line in response.iter_lines():
                if line:
                    line_str = line.decode('utf-8')
                    if line_str.startswith('data: '):
                        try:
                            chunk_data = json.loads(line_str[6:])  # Remove 'data: '
                            chunk = chunk_data.get('chunk', '')
                            is_complete = chunk_data.get('is_complete', False)
                            metadata = chunk_data.get('metadata', {})
                            
                            if chunk:
                                print(chunk, end='', flush=True)
                                total_content += chunk
                                chunk_count += 1
                            
                            if is_complete:
                                print(f"\n\n✅ Stream completed!")
                                print(f"📊 Total chunks: {chunk_count}")
                                print(f"📏 Total length: {len(total_content)} characters")
                                break
                                
                        except json.JSONDecodeError as e:
                            print(f"\n⚠️  JSON decode error: {e}")
                            continue
            
            print("-" * 50)
            
        else:
            print(f"❌ Stream failed: {response.status_code}")
            print(f"Response: {response.text}")
            
    except Exception as e:
        print(f"❌ Streaming error: {e}")
        return
    
    # Test health endpoint
    print("\n3. Testing Health Endpoint...")
    try:
        health_response = requests.get("http://localhost:8000/health", timeout=5)
        if health_response.status_code == 200:
            health_data = health_response.json()
            print(f"✅ Health check: {health_data}")
        else:
            print(f"❌ Health check failed: {health_response.status_code}")
    except Exception as e:
        print(f"❌ Health check error: {e}")
    
    print("\n🎉 Enhanced Streaming Test Complete!")

if __name__ == "__main__":
    test_enhanced_streaming()
