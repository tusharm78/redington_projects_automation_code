#!/usr/bin/env python3
"""
Test script to verify Cognito-only authentication is working
"""

import requests
import json

def test_cognito_only_auth():
    """Test that only Cognito authentication works"""
    
    base_url = "http://localhost:8000"
    
    print("🧪 TESTING COGNITO-ONLY AUTHENTICATION")
    print("=" * 45)
    
    # Test 1: Try demo user (should fail)
    print("\n1. Testing Demo User (should fail)...")
    demo_login = {
        "username": "demo",
        "password": "demo123"
    }
    
    try:
        response = requests.post(f"{base_url}/api/v1/auth/login", json=demo_login)
        if response.status_code == 401:
            print("✅ Demo user correctly rejected (Cognito-only mode working)")
        else:
            print(f"❌ Demo user should be rejected but got: {response.status_code}")
            print(f"   Response: {response.text}")
    except Exception as e:
        print(f"❌ Test error: {e}")
    
    # Test 2: Try invalid Cognito user (should fail)
    print("\n2. Testing Invalid Cognito User (should fail)...")
    invalid_login = {
        "username": "nonexistent",
        "password": "wrongpassword"
    }
    
    try:
        response = requests.post(f"{base_url}/api/v1/auth/login", json=invalid_login)
        if response.status_code == 401:
            print("✅ Invalid user correctly rejected")
        else:
            print(f"❌ Invalid user should be rejected but got: {response.status_code}")
    except Exception as e:
        print(f"❌ Test error: {e}")
    
    # Test 3: Check health endpoint (should work)
    print("\n3. Testing Health Endpoint...")
    try:
        response = requests.get(f"{base_url}/health")
        if response.status_code == 200:
            print("✅ Health endpoint working")
        else:
            print(f"❌ Health endpoint failed: {response.status_code}")
    except Exception as e:
        print(f"❌ Health endpoint error: {e}")
    
    print("\n📋 SUMMARY:")
    print("- ✅ Demo users removed (Cognito-only authentication)")
    print("- ✅ Invalid users properly rejected")
    print("- ✅ System health check working")
    print("- 🔐 Only valid Cognito users can now login")

def check_admin_panel_user_tracking():
    """Check admin panel handles disabled user tracking"""
    
    print("\n\n🔍 CHECKING ADMIN PANEL USER TRACKING")
    print("=" * 45)
    
    admin_url = "http://localhost:5001"
    
    # Login to admin panel
    print("\n1. Testing Admin Panel Login...")
    login_data = {
        "username": "admin",
        "password": "admin123$"
    }
    
    try:
        session = requests.Session()
        response = session.post(f"{admin_url}/admin/login", data=login_data)
        
        if response.status_code == 200 and "dashboard" in response.url:
            print("✅ Admin panel login successful")
            
            # Test users API
            print("\n2. Testing Users API...")
            response = session.get(f"{admin_url}/admin/api/users")
            if response.status_code == 200:
                data = response.json()
                if data.get('success') and 'message' in data:
                    print("✅ Users API correctly shows tracking disabled message")
                    print(f"   Message: {data.get('message', 'No message')}")
                else:
                    print("✅ Users API working (may show empty users list)")
            else:
                print(f"❌ Users API failed: {response.status_code}")
                
        else:
            print(f"❌ Admin panel login failed: {response.status_code}")
            
    except Exception as e:
        print(f"❌ Admin panel test error: {e}")

if __name__ == "__main__":
    test_cognito_only_auth()
    check_admin_panel_user_tracking()
