# Redington AI Bot - System Architecture Documentation

## 📋 Table of Contents
1. [System Overview](#system-overview)
2. [Technology Stack](#technology-stack)
3. [Architecture Flow](#architecture-flow)
4. [Component Details](#component-details)
5. [Data Flow](#data-flow)
6. [API Endpoints](#api-endpoints)
7. [File Structure](#file-structure)
8. [Deployment Guide](#deployment-guide)

---

## 🏗️ System Overview

The Redington AI Bot is a **full-stack web application** that provides an intelligent chatbot interface with enhanced streaming capabilities. The system is built with a **React frontend** and **FastAPI backend**, featuring real-time markdown streaming, authentication, and conversation management.

### Key Features
- ✅ **Enhanced Streaming Responses** with real-time markdown formatting
- ✅ **JWT Authentication** with demo user system
- ✅ **Conversation Management** with history and sessions
- ✅ **File Upload Support** (PDF, DOCX, XLSX, CSV, TXT, Images)
- ✅ **Multiple AI Models** support
- ✅ **Responsive UI** with Material-UI components
- ✅ **Real-time Communication** via streaming APIs

---

## 🛠️ Technology Stack

### Frontend Technologies
| Technology | Version | Purpose |
|------------|---------|---------|
| **React** | 18.x | Core UI framework |
| **TypeScript** | 4.x | Type safety and development experience |
| **Material-UI (MUI)** | 5.x | UI component library |
| **React Router** | 6.x | Client-side routing |
| **Axios** | 1.x | HTTP client for API calls |
| **ReactMarkdown** | 8.x | Real-time markdown rendering |
| **React Syntax Highlighter** | 15.x | Code syntax highlighting |
| **Remark GFM** | 3.x | GitHub Flavored Markdown support |

### Backend Technologies
| Technology | Version | Purpose |
|------------|---------|---------|
| **FastAPI** | 0.100+ | Modern Python web framework |
| **Python** | 3.10+ | Core backend language |
| **Uvicorn** | 0.20+ | ASGI server |
| **PyJWT** | 2.x | JWT token handling |
| **Pydantic** | 1.x | Data validation and serialization |
| **Python-multipart** | 0.x | File upload handling |

### Development & Deployment
| Technology | Purpose |
|------------|---------|
| **Node.js** | Frontend build system |
| **npm** | Package management |
| **Python venv** | Backend virtual environment |
| **Bash Scripts** | System automation |

---

## 🔄 Architecture Flow

```mermaid
graph TB
    A[User Browser] --> B[React Frontend :3000]
    B --> C[FastAPI Backend :8000]
    C --> D[Enhanced Streaming Engine]
    C --> E[JWT Authentication]
    C --> F[Template Response System]
    
    D --> G[Markdown Formatter]
    G --> H[Streaming Chunks]
    H --> I[Real-time Rendering]
    I --> B
    
    E --> J[Demo User System]
    F --> K[Response Templates]
    K --> L[Context-Aware Selection]
    
    B --> M[Material-UI Components]
    B --> N[ReactMarkdown Renderer]
    B --> O[Conversation Manager]
    
    style A fill:#e1f5fe
    style B fill:#f3e5f5
    style C fill:#e8f5e8
    style D fill:#fff3e0
```

### High-Level Flow
1. **User Authentication** → JWT token generation
2. **Model Selection** → Available AI models loaded
3. **Message Input** → User types message
4. **Streaming Request** → Backend processes with templates
5. **Chunk Generation** → Markdown-formatted chunks created
6. **Real-time Rendering** → Frontend renders markdown as it streams
7. **Conversation Storage** → Message history maintained

---

## 🧩 Component Details

### Frontend Components

#### 1. **ModernChatInterface.tsx** (Main Interface)
```typescript
// Primary chat interface with all features
- Side panel with conversation history
- Model selection dropdown
- File upload functionality
- Real-time streaming display
- Message management
```

**Key Features:**
- Responsive design with Material-UI
- Real-time streaming integration
- Conversation management
- File upload support
- Authentication handling

#### 2. **StreamingTextRenderer.tsx** (Enhanced Streaming)
```typescript
// Real-time markdown rendering during streaming
- ReactMarkdown integration
- Syntax highlighting for code blocks
- Progressive content display
- Streaming cursor animation
```

**Rendering Components:**
- Headers (H1, H2, H3)
- Lists (bulleted and numbered)
- Code blocks with syntax highlighting
- Tables and blockquotes
- Bold/italic text formatting

#### 3. **FinalTextRenderer.tsx** (Complete Rendering)
```typescript
// Final markdown rendering after streaming completes
- Full HTML conversion
- Advanced styling
- Table formatting
- Link handling
```

#### 4. **Authentication Components**
- **Login.tsx** - User authentication interface
- **useAuth.ts** - Authentication hook
- **AuthProvider** - Context provider for auth state

### Backend Components

#### 1. **enhanced_streaming_main.py** (Core Backend)
```python
# FastAPI application with enhanced streaming
- JWT authentication system
- Streaming response generation
- Template-based responses
- CORS configuration
```

**Key Classes:**
- `MarkdownStreamFormatter` - Response formatting
- `StreamChunk` - Streaming data model
- Authentication functions
- API route handlers

#### 2. **Response Template System**
```python
response_templates = {
    "redington_overview": {...},
    "services_detailed": {...},
    "greeting": {...},
    "default": {...}
}
```

**Template Features:**
- Context-aware selection
- Structured markdown content
- Progressive delivery chunks
- User personalization

---

## 📊 Data Flow

### 1. Authentication Flow
```
User Login → Credentials Validation → JWT Token Generation → Token Storage → API Authorization
```

### 2. Streaming Flow
```
User Message → Template Selection → Chunk Generation → Stream Transmission → Real-time Rendering
```

### 3. Message Processing Flow
```
Input Validation → Context Analysis → Template Matching → Content Generation → Markdown Formatting → Chunk Streaming
```

---

## 🔌 API Endpoints

### Authentication Endpoints
| Method | Endpoint | Purpose |
|--------|----------|---------|
| POST | `/api/v1/auth/login` | User authentication |
| GET | `/api/v1/auth/me` | Get current user info |
| POST | `/api/v1/auth/logout` | User logout |

### Chat Endpoints
| Method | Endpoint | Purpose |
|--------|----------|---------|
| POST | `/api/v1/chat/stream` | Enhanced streaming chat |
| GET | `/api/v1/chat/models` | Get available AI models |
| GET | `/api/v1/chat/history/{id}` | Get conversation history |

### Session Management
| Method | Endpoint | Purpose |
|--------|----------|---------|
| GET | `/api/v1/sessions` | Get user sessions |
| POST | `/api/v1/sessions` | Create new session |
| GET | `/api/v1/conversations` | Get conversations |

### System Endpoints
| Method | Endpoint | Purpose |
|--------|----------|---------|
| GET | `/health` | Health check |
| GET | `/docs` | API documentation |

---

## 📁 File Structure

```
redington-chatbot/
├── 📁 backend/
│   ├── 📄 enhanced_streaming_main.py      # Main FastAPI application
│   ├── 📄 requirements.txt                # Python dependencies
│   ├── 📄 start_enhanced.sh              # Backend startup script
│   ├── 📁 venv/                          # Python virtual environment
│   └── 📄 enhanced_backend.log           # Backend logs
│
├── 📁 frontend/
│   ├── 📁 src/
│   │   ├── 📁 components/
│   │   │   ├── 📄 ModernChatInterface.tsx     # Main chat interface
│   │   │   ├── 📄 StreamingTextRenderer.tsx  # Enhanced streaming renderer
│   │   │   ├── 📄 FinalTextRenderer.tsx      # Final markdown renderer
│   │   │   ├── 📄 EnhancedStreamingChat.tsx  # Alternative interface
│   │   │   └── 📄 Login.tsx                  # Authentication component
│   │   ├── 📁 hooks/
│   │   │   ├── 📄 useAuth.ts                 # Authentication hook
│   │   │   └── 📄 useEnhancedStreaming.ts    # Enhanced streaming hook
│   │   ├── 📁 services/
│   │   │   └── 📄 api.ts                     # API service layer
│   │   ├── 📁 types/
│   │   │   └── 📄 index.ts                   # TypeScript type definitions
│   │   └── 📄 App.tsx                        # Main React application
│   ├── 📄 package.json                       # Node.js dependencies
│   └── 📄 frontend_enhanced.log             # Frontend logs
│
├── 📄 start_enhanced_system.sh              # Complete system startup
├── 📄 stop_enhanced_system.sh               # System shutdown
├── 📄 check_enhanced_status.sh              # System status check
├── 📄 test_enhanced_streaming.py            # API testing script
├── 📄 ENHANCED_STREAMING_GUIDE.md           # Implementation guide
├── 📄 ENHANCED_STREAMING_SUMMARY.md         # Feature summary
└── 📄 README.md                             # Project documentation
```

---

## 🚀 Deployment Guide

### Prerequisites
- Node.js 16+
- Python 3.10+
- npm package manager
- Virtual environment support

### Quick Start
```bash
# Start complete system
./start_enhanced_system.sh

# Check system status
./check_enhanced_status.sh

# Stop system
./stop_enhanced_system.sh
```

### Manual Deployment

#### Backend Setup
```bash
cd backend
python3 -m venv venv
source venv/bin/activate
pip install -r requirements.txt
python -m uvicorn enhanced_streaming_main:app --host 0.0.0.0 --port 8000 --reload
```

#### Frontend Setup
```bash
cd frontend
npm install
export REACT_APP_API_URL="http://localhost:8000/api/v1"
npm start
```

### Environment Variables
```bash
# Frontend
REACT_APP_API_URL=http://localhost:8000/api/v1

# Backend (built-in demo configuration)
SECRET_KEY=demo-secret-key-for-enhanced-streaming
```

---

## 📈 Performance Metrics

### Streaming Performance
- **First Chunk Time**: <200ms
- **Chunk Delivery**: 50-150ms per chunk
- **Complete Response**: 2-5 seconds
- **Memory Usage**: Optimized for continuous streaming

### System Requirements
- **RAM**: 2GB minimum, 4GB recommended
- **CPU**: 2 cores minimum
- **Storage**: 1GB for dependencies
- **Network**: HTTP/HTTPS support

---

## 🔧 Monitoring & Debugging

### Log Files
```bash
# Backend logs
tail -f backend/enhanced_backend.log

# Frontend logs
tail -f frontend/frontend_enhanced.log
```

### Health Checks
- Backend: http://localhost:8000/health
- Frontend: http://localhost:3000
- API Docs: http://localhost:8000/docs

### Common Issues & Solutions
1. **Port conflicts** → Use `./stop_enhanced_system.sh` first
2. **Authentication errors** → Check JWT token validity
3. **Streaming issues** → Verify backend connectivity
4. **UI rendering** → Check ReactMarkdown dependencies

---

## 🎯 Key Innovations

### 1. **Enhanced Streaming Architecture**
- Template-based response system
- Real-time markdown rendering
- Progressive content delivery
- Context-aware formatting

### 2. **Dual Rendering System**
- **StreamingTextRenderer** for real-time display
- **FinalTextRenderer** for complete formatting
- Seamless transition between modes

### 3. **Professional UI/UX**
- Material-UI integration
- Responsive design
- Real-time feedback
- Error handling

---

*This documentation provides a comprehensive overview of the Redington AI Bot system architecture, components, and deployment procedures.*
