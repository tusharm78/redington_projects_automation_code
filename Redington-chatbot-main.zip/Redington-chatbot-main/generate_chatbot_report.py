#!/usr/bin/env python3
"""
Generate comprehensive Redington Chatbot usage report for last 3 days
"""

import boto3
import json
from datetime import datetime, timedelta, timezone
from collections import defaultdict

def generate_chatbot_usage_report():
    """Generate detailed chatbot usage report for last 3 days"""
    
    print("📊 REDINGTON CHATBOT - 3 DAY USAGE REPORT")
    print("=" * 60)
    print(f"Report Generated: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}")
    print("=" * 60)
    
    # Calculate date range (last 3 days)
    end_date = datetime.now(timezone.utc)
    start_date = end_date - timedelta(days=3)
    
    print(f"📅 Report Period: {start_date.strftime('%Y-%m-%d')} to {end_date.strftime('%Y-%m-%d')}")
    print()
    
    dynamodb = boto3.resource('dynamodb', region_name='us-east-1')
    
    # Main chatbot tables
    tables = {
        'chat_history': 'Main chat history storage',
        'user_chat_sessions': 'User conversation sessions', 
        'user_active_sessions': 'Active user tracking',
        'active_user_sessions': 'User session tracking'
    }
    
    report_data = {
        'users': {},
        'conversations': [],
        'daily_stats': defaultdict(lambda: {'users': set(), 'messages': 0, 'conversations': 0}),
        'total_stats': {'unique_users': set(), 'total_messages': 0, 'total_conversations': 0}
    }
    
    # Analyze each table
    for table_name, description in tables.items():
        print(f"🔍 Analyzing {table_name} ({description})")
        print("-" * 50)
        
        try:
            table = dynamodb.Table(table_name)
            
            if table_name == 'chat_history':
                analyze_chat_history(table, start_date, end_date, report_data)
            elif table_name == 'user_chat_sessions':
                analyze_user_chat_sessions(table, start_date, end_date, report_data)
            elif table_name in ['user_active_sessions', 'active_user_sessions']:
                analyze_active_sessions(table, start_date, end_date, report_data)
                
        except Exception as e:
            print(f"❌ Error analyzing {table_name}: {e}")
        
        print()
    
    # Generate comprehensive report
    generate_summary_report(report_data, start_date, end_date)
    generate_detailed_user_report(report_data)
    generate_conversation_analysis(report_data)
    
    return report_data

def analyze_chat_history(table, start_date, end_date, report_data):
    """Analyze chat_history table for messages and responses"""
    
    try:
        response = table.scan()
        items = response.get('Items', [])
        
        print(f"📊 Total chat history records: {len(items)}")
        
        recent_messages = []
        
        for item in items:
            # Try to parse timestamp from various possible fields
            timestamp_str = item.get('timestamp') or item.get('created_at') or item.get('date')
            
            if timestamp_str:
                try:
                    # Handle different timestamp formats
                    if 'T' in timestamp_str:
                        timestamp = datetime.fromisoformat(timestamp_str.replace('Z', '+00:00'))
                    else:
                        timestamp = datetime.strptime(timestamp_str, '%Y-%m-%d %H:%M:%S')
                        timestamp = timestamp.replace(tzinfo=timezone.utc)
                    
                    # Check if within last 3 days
                    if start_date <= timestamp <= end_date:
                        user_id = item.get('user_id', 'Unknown')
                        message = item.get('message', item.get('user_message', ''))
                        response = item.get('response', item.get('assistant_response', ''))
                        
                        recent_messages.append({
                            'user_id': user_id,
                            'timestamp': timestamp,
                            'message': message,
                            'response': response,
                            'message_id': item.get('chat_message_id', 'N/A')
                        })
                        
                        # Update statistics
                        date_key = timestamp.strftime('%Y-%m-%d')
                        report_data['daily_stats'][date_key]['users'].add(user_id)
                        report_data['daily_stats'][date_key]['messages'] += 1
                        report_data['total_stats']['unique_users'].add(user_id)
                        report_data['total_stats']['total_messages'] += 1
                        
                        # Update user data
                        if user_id not in report_data['users']:
                            report_data['users'][user_id] = {
                                'messages': [],
                                'total_messages': 0,
                                'first_activity': timestamp,
                                'last_activity': timestamp
                            }
                        
                        report_data['users'][user_id]['messages'].append({
                            'timestamp': timestamp,
                            'message': message[:100] + '...' if len(message) > 100 else message,
                            'response': response[:100] + '...' if len(response) > 100 else response
                        })
                        report_data['users'][user_id]['total_messages'] += 1
                        
                        if timestamp < report_data['users'][user_id]['first_activity']:
                            report_data['users'][user_id]['first_activity'] = timestamp
                        if timestamp > report_data['users'][user_id]['last_activity']:
                            report_data['users'][user_id]['last_activity'] = timestamp
                        
                except Exception as e:
                    continue
        
        print(f"✅ Found {len(recent_messages)} messages in last 3 days")
        
        # Show recent activity summary
        if recent_messages:
            users_active = set(msg['user_id'] for msg in recent_messages)
            print(f"👥 Active users: {len(users_active)}")
            print(f"💬 Total messages: {len(recent_messages)}")
            
            # Show top users
            user_message_counts = defaultdict(int)
            for msg in recent_messages:
                user_message_counts[msg['user_id']] += 1
            
            print("🏆 Top active users:")
            for user, count in sorted(user_message_counts.items(), key=lambda x: x[1], reverse=True)[:5]:
                print(f"   • {user}: {count} messages")
        
    except Exception as e:
        print(f"❌ Error analyzing chat history: {e}")

def analyze_user_chat_sessions(table, start_date, end_date, report_data):
    """Analyze user_chat_sessions table for conversation sessions"""
    
    try:
        response = table.scan()
        items = response.get('Items', [])
        
        print(f"📊 Total chat sessions: {len(items)}")
        
        recent_sessions = []
        
        for item in items:
            timestamp_str = item.get('timestamp') or item.get('created_at')
            
            if timestamp_str:
                try:
                    if 'T' in timestamp_str:
                        timestamp = datetime.fromisoformat(timestamp_str.replace('Z', '+00:00'))
                    else:
                        timestamp = datetime.strptime(timestamp_str, '%Y-%m-%d %H:%M:%S')
                        timestamp = timestamp.replace(tzinfo=timezone.utc)
                    
                    if start_date <= timestamp <= end_date:
                        user_id = item.get('user_id', 'Unknown')
                        chat_id = item.get('chat_id', 'N/A')
                        title = item.get('title', 'No title')
                        
                        recent_sessions.append({
                            'user_id': user_id,
                            'chat_id': chat_id,
                            'title': title,
                            'timestamp': timestamp
                        })
                        
                        # Update conversation stats
                        date_key = timestamp.strftime('%Y-%m-%d')
                        report_data['daily_stats'][date_key]['conversations'] += 1
                        report_data['total_stats']['total_conversations'] += 1
                        
                except Exception as e:
                    continue
        
        print(f"✅ Found {len(recent_sessions)} sessions in last 3 days")
        
        if recent_sessions:
            session_users = set(session['user_id'] for session in recent_sessions)
            print(f"👥 Users with sessions: {len(session_users)}")
            
            # Add to conversations list
            report_data['conversations'] = recent_sessions
        
    except Exception as e:
        print(f"❌ Error analyzing user chat sessions: {e}")

def analyze_active_sessions(table, start_date, end_date, report_data):
    """Analyze active sessions tables for login information"""
    
    try:
        response = table.scan()
        items = response.get('Items', [])
        
        print(f"📊 Total session records: {len(items)}")
        
        recent_logins = []
        
        for item in items:
            login_time_str = item.get('login_time')
            
            if login_time_str:
                try:
                    if 'T' in login_time_str:
                        login_time = datetime.fromisoformat(login_time_str.replace('Z', '+00:00'))
                    else:
                        login_time = datetime.strptime(login_time_str, '%Y-%m-%d %H:%M:%S')
                        login_time = login_time.replace(tzinfo=timezone.utc)
                    
                    if start_date <= login_time <= end_date:
                        username = item.get('username', 'Unknown')
                        status = item.get('status', 'Unknown')
                        last_activity = item.get('last_activity', 'N/A')
                        
                        recent_logins.append({
                            'username': username,
                            'login_time': login_time,
                            'status': status,
                            'last_activity': last_activity
                        })
                        
                except Exception as e:
                    continue
        
        print(f"✅ Found {len(recent_logins)} login sessions in last 3 days")
        
        if recent_logins:
            for login in recent_logins:
                username = login['username']
                if username not in report_data['users']:
                    report_data['users'][username] = {
                        'messages': [],
                        'total_messages': 0,
                        'first_activity': login['login_time'],
                        'last_activity': login['login_time']
                    }
                
                report_data['users'][username]['login_info'] = login
        
    except Exception as e:
        print(f"❌ Error analyzing active sessions: {e}")

def generate_summary_report(report_data, start_date, end_date):
    """Generate executive summary report"""
    
    print("\n" + "=" * 60)
    print("📋 EXECUTIVE SUMMARY")
    print("=" * 60)
    
    total_users = len(report_data['total_stats']['unique_users'])
    total_messages = report_data['total_stats']['total_messages']
    total_conversations = report_data['total_stats']['total_conversations']
    
    print(f"📊 Overall Statistics (Last 3 Days):")
    print(f"   • Total Unique Users: {total_users}")
    print(f"   • Total Messages Exchanged: {total_messages}")
    print(f"   • Total Conversations: {total_conversations}")
    print(f"   • Average Messages per User: {total_messages/max(1,total_users):.1f}")
    
    print(f"\n📅 Daily Breakdown:")
    for date_key in sorted(report_data['daily_stats'].keys()):
        stats = report_data['daily_stats'][date_key]
        print(f"   • {date_key}:")
        print(f"     - Active Users: {len(stats['users'])}")
        print(f"     - Messages: {stats['messages']}")
        print(f"     - Conversations: {stats['conversations']}")

def generate_detailed_user_report(report_data):
    """Generate detailed user activity report"""
    
    print("\n" + "=" * 60)
    print("👥 DETAILED USER ACTIVITY REPORT")
    print("=" * 60)
    
    if not report_data['users']:
        print("ℹ️  No user activity found in the last 3 days")
        return
    
    for i, (user_id, user_data) in enumerate(sorted(report_data['users'].items()), 1):
        print(f"\n{i}. USER: {user_id}")
        print("-" * 40)
        
        print(f"📊 Activity Summary:")
        print(f"   • Total Messages: {user_data['total_messages']}")
        print(f"   • First Activity: {user_data['first_activity'].strftime('%Y-%m-%d %H:%M:%S')}")
        print(f"   • Last Activity: {user_data['last_activity'].strftime('%Y-%m-%d %H:%M:%S')}")
        
        if 'login_info' in user_data:
            login = user_data['login_info']
            print(f"   • Login Status: {login['status']}")
            print(f"   • Login Time: {login['login_time'].strftime('%Y-%m-%d %H:%M:%S')}")
        
        print(f"\n💬 Recent Messages:")
        if user_data['messages']:
            for j, msg in enumerate(user_data['messages'][-5:], 1):  # Show last 5 messages
                print(f"   {j}. [{msg['timestamp'].strftime('%Y-%m-%d %H:%M')}]")
                print(f"      User: {msg['message']}")
                print(f"      Bot: {msg['response']}")
                print()
        else:
            print("   No messages found")

def generate_conversation_analysis(report_data):
    """Generate conversation analysis"""
    
    print("\n" + "=" * 60)
    print("💬 CONVERSATION ANALYSIS")
    print("=" * 60)
    
    if not report_data['conversations']:
        print("ℹ️  No conversation data available")
        return
    
    print(f"📊 Total Conversations: {len(report_data['conversations'])}")
    
    # Group by user
    user_conversations = defaultdict(list)
    for conv in report_data['conversations']:
        user_conversations[conv['user_id']].append(conv)
    
    print(f"👥 Users with Conversations: {len(user_conversations)}")
    
    print(f"\n🏆 Top Conversation Users:")
    for user, convs in sorted(user_conversations.items(), key=lambda x: len(x[1]), reverse=True)[:5]:
        print(f"   • {user}: {len(convs)} conversations")
        
        # Show recent conversation titles
        recent_convs = sorted(convs, key=lambda x: x['timestamp'], reverse=True)[:3]
        for conv in recent_convs:
            print(f"     - [{conv['timestamp'].strftime('%Y-%m-%d %H:%M')}] {conv['title']}")

if __name__ == "__main__":
    try:
        report_data = generate_chatbot_usage_report()
        
        print("\n" + "=" * 60)
        print("✅ REPORT GENERATION COMPLETE")
        print("=" * 60)
        print("📧 This report can be shared with management")
        print("📊 All data extracted from Redington Chatbot DynamoDB tables")
        
    except Exception as e:
        print(f"❌ Error generating report: {e}")
