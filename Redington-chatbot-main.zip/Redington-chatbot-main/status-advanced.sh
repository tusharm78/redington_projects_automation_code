#!/bin/bash

echo "🚀 Redington AI Assistant - Advanced Status Check"
echo "=================================================="

# Check server status
FRONTEND_STATUS=$(curl -s -o /dev/null -w "%{http_code}" http://localhost:3000 2>/dev/null || echo "000")
BACKEND_STATUS=$(curl -s -o /dev/null -w "%{http_code}" http://localhost:8000 2>/dev/null || echo "000")

echo ""
echo "🌐 Server Status:"
echo "Frontend (3000): $([[ $FRONTEND_STATUS == "200" ]] && echo "✅ Running" || echo "❌ Down")"
echo "Backend (8000):  $([[ $BACKEND_STATUS == "200" ]] && echo "✅ Running" || echo "❌ Down")"

# Check authentication
echo ""
echo "🔐 Authentication Test:"
AUTH_RESULT=$(curl -X POST "http://localhost:8000/api/v1/auth/login" \
     -H "Content-Type: application/json" \
     -d '{"username": "tanmay", "password": "Admin@123$"}' \
     -s -w "%{http_code}" -o /tmp/auth_test.json 2>/dev/null)

if [[ $AUTH_RESULT == "200" ]]; then
    echo "✅ Authentication working"
    
    # Test AI models
    echo ""
    echo "🤖 AI Models Available:"
    TOKEN=$(jq -r '.access_token' /tmp/auth_test.json 2>/dev/null)
    if [[ $TOKEN != "null" && $TOKEN != "" ]]; then
        MODELS=$(curl -s -H "Authorization: Bearer $TOKEN" http://localhost:8000/api/v1/chat/models 2>/dev/null | jq -r 'keys[]' 2>/dev/null)
        if [[ $? == 0 ]]; then
            echo "$MODELS" | while read model; do
                echo "  ✅ $model"
            done
        else
            echo "  ⚠️  Could not fetch models"
        fi
    fi
    
    # Test chat functionality
    echo ""
    echo "💬 Chat Test:"
    CHAT_RESULT=$(curl -X POST "http://localhost:8000/api/v1/chat/message" \
         -H "Content-Type: application/json" \
         -H "Authorization: Bearer $TOKEN" \
         -d '{"message": "Hello", "model_name": "Claude 3.7 Sonnet Reasoning"}' \
         -s -w "%{http_code}" -o /tmp/chat_test.json 2>/dev/null)
    
    if [[ $CHAT_RESULT == "200" ]]; then
        echo "✅ Chat functionality working"
        RESPONSE=$(jq -r '.response' /tmp/chat_test.json 2>/dev/null | head -c 100)
        echo "  Sample response: $RESPONSE..."
    else
        echo "❌ Chat functionality failed"
    fi
else
    echo "❌ Authentication failed"
fi

echo ""
echo "🎨 New Features:"
echo "✅ Modern Redington-branded UI"
echo "✅ Claude 3.7 Sonnet Reasoning (Default)"
echo "✅ Advanced welcome screen"
echo "✅ Conversation history sidebar"
echo "✅ File drag & drop support"
echo "✅ Real-time typing indicators"
echo "✅ Professional animations"
echo "✅ Responsive design"
echo "✅ Enhanced error handling"

echo ""
echo "🔗 Access URLs:"
echo "🌐 Frontend: http://localhost:3000"
echo "🔧 Backend:  http://localhost:8000"
echo "📚 API Docs: http://localhost:8000/docs"

echo ""
echo "👤 Login Credentials:"
echo "Username: tanmay"
echo "Password: Admin@123$"

echo ""
echo "🛠️  Management Commands:"
echo "Status:   ./status-advanced.sh"
echo "Restart:  ./start-detached.sh"
echo "Stop:     pkill -f 'uvicorn main:app' && pkill -f 'react-scripts start'"

# Cleanup temp files
rm -f /tmp/auth_test.json /tmp/chat_test.json 2>/dev/null

echo ""
echo "🎉 Redington AI Assistant is ready for advanced usage!"
