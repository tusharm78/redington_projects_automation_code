# Session Management Testing Guide

## Current Status
✅ Backend is running on port 8000
✅ Frontend is running on port 3000  
✅ DynamoDB service is working and returning clean session data
✅ TypeScript errors have been fixed
✅ Sessions service has been updated to handle backend response correctly

## Testing Steps

### Step 1: Access the Application
1. Open your browser and go to: `http://localhost:3000`
2. You should see the login page

### Step 2: Login
1. Try logging in with these potential credentials:
   - Username: `akhil` / Password: `akhil123`
   - Username: `admin` / Password: `admin123`  
   - Username: `test_user` / Password: `test123`
   - Username: `varunesh` / Password: `varunesh123`

### Step 3: Check Browser Console
1. Open browser Developer Tools (F12)
2. Go to Console tab
3. Look for these log messages after login:
   ```
   🔍 Loading conversation history for user: [username]
   📡 Fetching sessions from API...
   ✅ Sessions received: [session data]
   ```

### Step 4: Verify Session Loading
1. After successful login, you should see:
   - Conversations list in the left sidebar
   - For user 'akhil': 5 conversations should appear
   - For user 'test_user': 3 conversations should appear

### Step 5: Test Session Management
1. **Create New Chat**: Click the "New Chat" button
2. **Load Conversation**: Click on any conversation in the sidebar
3. **Delete Conversation**: Click the delete icon next to a conversation
4. **Edit Title**: Click the edit icon next to a conversation title

## If Sessions Don't Load

### Check Console Errors
Look for these error patterns:
- `401 Unauthorized` - Authentication issue
- `403 Forbidden` - Permission issue  
- `Network Error` - Connection issue
- `TypeError` - JavaScript error

### Common Issues & Solutions

1. **No conversations appear**:
   - Check if user is logged in: Look for user info in console
   - Check API calls: Look for 🔍 and 📡 log messages
   - Verify token: Check if `localStorage.getItem('access_token')` returns a value

2. **Delete not working**:
   - Check console for delete API call logs
   - Verify the delete button click is registered
   - Check if conversation disappears from sidebar

3. **Can't load conversation history**:
   - Check if clicking conversation shows loading state
   - Look for API calls to `/chat/history/{chatId}`
   - Verify messages appear in chat area

## Manual Verification Commands

Run these in the browser console after login:

```javascript
// Check if user is authenticated
console.log('User:', JSON.parse(localStorage.getItem('user') || 'null'));
console.log('Token:', localStorage.getItem('access_token'));

// Test sessions API directly
fetch('/api/v1/sessions', {
  headers: {
    'Authorization': `Bearer ${localStorage.getItem('access_token')}`,
    'Content-Type': 'application/json'
  }
})
.then(r => r.json())
.then(data => console.log('Sessions:', data))
.catch(err => console.error('Sessions error:', err));
```

## Expected Results

After successful login and session loading:
- ✅ Sidebar shows list of conversations
- ✅ Clicking conversation loads its messages  
- ✅ New chat button creates new conversation
- ✅ Delete button removes conversation from list
- ✅ Edit title button allows renaming conversations

## If Still Not Working

The issue might be:
1. **Wrong login credentials** - Try different username/password combinations
2. **Database permissions** - Backend can't access DynamoDB
3. **CORS issues** - Frontend can't call backend APIs
4. **Token expiration** - Authentication token has expired

Contact support with:
- Browser console logs
- Network tab showing API calls
- Any error messages displayed
