# Requirements Snapshot

## Python Dependencies (Backend)
```
fastapi==0.104.1
uvicorn[standard]==0.24.0
boto3==1.34.0
python-multipart==0.0.6
python-jose[cryptography]==3.3.0
passlib[bcrypt]==1.7.4
python-dotenv==1.0.0
PyJWT==2.8.0
pydantic==2.5.0
```

## Node.js Dependencies (Frontend)
```json
{
  "dependencies": {
    "@emotion/react": "^11.11.1",
    "@emotion/styled": "^11.11.0",
    "@mui/icons-material": "^5.14.19",
    "@mui/material": "^5.14.20",
    "@types/node": "^16.18.68",
    "@types/react": "^18.2.42",
    "@types/react-dom": "^18.2.17",
    "axios": "^1.6.2",
    "react": "^18.2.0",
    "react-dom": "^18.2.0",
    "react-markdown": "^9.0.1",
    "react-router-dom": "^6.20.1",
    "react-scripts": "5.0.1",
    "typescript": "^4.9.5",
    "uuid": "^9.0.1",
    "web-vitals": "^2.1.4"
  }
}
```

## System Requirements
- Python 3.8+
- Node.js 16+
- AWS CLI configured
- AWS Bedrock access
- AWS Cognito user pool
- DynamoDB table (optional, has memory fallback)

## AWS Services Configuration
- Region: ap-south-1
- Bedrock Model: us.anthropic.claude-3-7-sonnet-20250219-v1:0
- Cognito Pool: ap-south-1_dN18SVYgM
- Cognito Client: 2sscckqddj6vi5ue5big66jefb
