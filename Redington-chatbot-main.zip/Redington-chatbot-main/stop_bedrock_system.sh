#!/bin/bash

# Bedrock Integration System Stop Script
echo "🛑 Stopping Bedrock Integration System"
echo "======================================"

# Function to kill processes on specific ports
kill_port() {
    local port=$1
    local service=$2
    echo "🔄 Stopping $service on port $port..."
    
    # Kill by port
    lsof -ti:$port | xargs kill -9 2>/dev/null || true
    
    # Additional cleanup for specific processes
    if [ "$service" = "Backend" ]; then
        pkill -f "bedrock_main" 2>/dev/null || true
        pkill -f "uvicorn.*8000" 2>/dev/null || true
    elif [ "$service" = "Frontend" ]; then
        pkill -f "react-scripts" 2>/dev/null || true
        pkill -f "npm.*start" 2>/dev/null || true
    fi
    
    sleep 1
    
    # Check if port is now free
    if ! lsof -Pi :$port -sTCP:LISTEN -t >/dev/null ; then
        echo "✅ $service stopped successfully"
    else
        echo "⚠️  $service may still be running on port $port"
    fi
}

# Stop services
kill_port 8000 "Backend"
kill_port 3000 "Frontend"

# Clean up PID files
echo "🧹 Cleaning up PID files..."
rm -f backend.pid frontend.pid

# Clean up log files (optional)
read -p "🗑️  Do you want to clear log files? (y/N): " -n 1 -r
echo
if [[ $REPLY =~ ^[Yy]$ ]]; then
    echo "🧹 Clearing log files..."
    rm -f backend/bedrock_backend.log
    rm -f frontend/frontend_bedrock.log
    echo "✅ Log files cleared"
fi

echo ""
echo "✅ Bedrock Integration System Stopped"
echo "===================================="
echo ""
echo "📋 To restart the system:"
echo "   ./start_bedrock_system.sh"
echo ""
