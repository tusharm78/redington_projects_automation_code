#!/usr/bin/env python3

import sys
import os
sys.path.append('/home/chatbot/Redington-chatbot/backend')

from services.dynamodb_service import DynamoDBService

def test_sessions():
    """Test the sessions functionality"""
    
    # Initialize DynamoDB service
    dynamodb_service = DynamoDBService()
    
    # Test with a known user (you can replace with actual username)
    test_users = ['akhil', 'admin', 'test_user']
    
    for user in test_users:
        print(f"\n=== Testing sessions for user: {user} ===")
        try:
            sessions = dynamodb_service.get_user_chat_sessions(user)
            print(f"Sessions found: {len(sessions)}")
            print(f"Sessions data: {sessions}")
            
            if sessions:
                print("Sample session:")
                for chat_id, title in list(sessions.items())[:3]:
                    print(f"  - {chat_id}: {title}")
            else:
                print("No sessions found for this user")
                
        except Exception as e:
            print(f"Error getting sessions for {user}: {e}")

if __name__ == "__main__":
    test_sessions()
