#!/usr/bin/env python3

import requests
import json
import sys

# Test session management with proper authentication
def test_session_management():
    base_url = "http://localhost:8000"
    
    print("🔍 Testing Session Management...")
    
    # Step 1: Login with tanmay credentials
    print("\n1. Testing Login...")
    login_data = {
        "username": "tanmay",
        "password": "Admin@123$"
    }
    
    try:
        login_response = requests.post(f"{base_url}/api/v1/auth/login", json=login_data)
        print(f"Login Status: {login_response.status_code}")
        
        if login_response.status_code == 200:
            login_result = login_response.json()
            print(f"✅ Login successful!")
            print(f"Access Token: {login_result.get('access_token', 'N/A')[:50]}...")
            
            # Extract token for subsequent requests
            token = login_result.get('access_token')
            headers = {
                'Authorization': f'Bearer {token}',
                'Content-Type': 'application/json'
            }
            
            # Step 2: Test sessions endpoint
            print("\n2. Testing Sessions Endpoint...")
            sessions_response = requests.get(f"{base_url}/api/v1/sessions", headers=headers)
            print(f"Sessions Status: {sessions_response.status_code}")
            
            if sessions_response.status_code == 200:
                sessions_data = sessions_response.json()
                print(f"✅ Sessions retrieved successfully!")
                print(f"Sessions data: {json.dumps(sessions_data, indent=2)}")
                
                # Check if there are any sessions
                if isinstance(sessions_data, dict) and sessions_data:
                    print(f"📊 Found {len(sessions_data)} sessions")
                    for session_id, session_name in sessions_data.items():
                        print(f"  - {session_id}: {session_name}")
                        
                        # Test getting messages for this session
                        print(f"\n3. Testing Messages for Session: {session_id}")
                        messages_response = requests.get(f"{base_url}/api/v1/chat/history/{session_id}", headers=headers)
                        print(f"Messages Status: {messages_response.status_code}")
                        
                        if messages_response.status_code == 200:
                            messages_data = messages_response.json()
                            print(f"✅ Messages retrieved successfully!")
                            messages = messages_data.get('messages', [])
                            print(f"📊 Found {len(messages)} messages in session")
                            
                            # Show first few messages
                            for i, msg in enumerate(messages[:3]):
                                print(f"  Message {i+1}: {msg.get('role')} - {msg.get('content', '')[:100]}...")
                        else:
                            print(f"❌ Failed to get messages: {messages_response.text}")
                        
                        break  # Only test first session
                else:
                    print("📭 No sessions found")
                    
                    # Test creating a new session
                    print("\n4. Testing Session Creation...")
                    create_data = {"chat_title": "Test Session"}
                    create_response = requests.post(f"{base_url}/api/v1/sessions", json=create_data, headers=headers)
                    print(f"Create Session Status: {create_response.status_code}")
                    
                    if create_response.status_code == 200:
                        create_result = create_response.json()
                        print(f"✅ Session created: {create_result}")
                    else:
                        print(f"❌ Failed to create session: {create_response.text}")
                        
            else:
                print(f"❌ Failed to get sessions: {sessions_response.text}")
                
        else:
            print(f"❌ Login failed: {login_response.text}")
            
    except requests.exceptions.ConnectionError:
        print("❌ Connection error - is the backend running on port 8000?")
    except Exception as e:
        print(f"❌ Error: {e}")

if __name__ == "__main__":
    test_session_management()
