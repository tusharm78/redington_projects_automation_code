#!/bin/bash

# Keep the chatbot services running
while true; do
    # Check if backend is running
    if ! curl -s http://localhost:8000/health > /dev/null 2>&1; then
        echo "$(date): Backend down, restarting..."
        pkill -f "python main.py" 2>/dev/null || true
        cd /home/chatbot/RedAIBot/react-bedrock-chatbot/backend
        source venv/bin/activate
        nohup python -u main.py > backend.log 2>&1 &
        sleep 5
    fi
    
    # Check if frontend is accessible
    if ! curl -s http://localhost:3001 > /dev/null 2>&1; then
        echo "$(date): Frontend down, reloading nginx..."
        sudo nginx -s reload
    fi
    
    # Wait 30 seconds before next check
    sleep 30
done
