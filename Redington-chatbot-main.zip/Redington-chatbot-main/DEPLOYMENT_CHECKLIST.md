# ✅ Redington AI Chatbot - Deployment Checklist

## 📋 **Pre-Deployment Checklist**

### **AWS Account Setup**
- [ ] AWS Account with appropriate permissions
- [ ] AWS CLI installed and configured
- [ ] AWS Bedrock access enabled in your region
- [ ] AWS Cognito User Pool created
- [ ] Test user created in Cognito
- [ ] DynamoDB permissions configured

### **Local Development Environment**
- [ ] Python 3.8+ installed
- [ ] Node.js 16+ installed
- [ ] Git installed (optional)

---

## 🚀 **Quick Deployment Steps**

### **Step 1: Extract Package**
```bash
unzip Redington-AI-Chatbot-YYYYMMDD.zip
cd react-bedrock-chatbot
```

### **Step 2: Backend Setup**
```bash
cd backend
python3 -m venv venv
source venv/bin/activate  # Linux/Mac
# OR
venv\Scripts\activate     # Windows
pip install -r requirements.txt
```

### **Step 3: Configure Backend**
Create `.env` file in `backend/` directory:
```env
AWS_DEFAULT_REGION=us-east-1
POOL_ID=your-cognito-pool-id
APP_CLIENT_ID=your-cognito-client-id
APP_CLIENT_SECRET=your-cognito-client-secret
SECRET_KEY=your-secret-key-here
ALLOWED_ORIGINS=["http://localhost:3000"]
```

### **Step 4: Start Backend**
```bash
./start.sh
# Backend runs on http://localhost:8000
```

### **Step 5: Frontend Setup**
```bash
cd ../frontend
npm install
```

### **Step 6: Configure Frontend**
Create/edit `.env` file in `frontend/` directory:
```env
REACT_APP_API_BASE_URL=http://localhost:8000
```

### **Step 7: Start Frontend**
```bash
./start.sh
# Frontend runs on http://localhost:3000
```

### **Step 8: Test Application**
- [ ] Open `http://localhost:3000`
- [ ] Login with: `tanmay` / `Admin@123$`
- [ ] Send a test message
- [ ] Test file upload
- [ ] Test Word document download

---

## 🔧 **Configuration Files**

### **Backend Configuration**
- `backend/.env` - Environment variables
- `backend/config/config.yml` - Model configurations
- `backend/requirements.txt` - Python dependencies

### **Frontend Configuration**
- `frontend/.env` - React environment variables
- `frontend/package.json` - Node.js dependencies

---

## 🎯 **Default Credentials**

### **Test User Account**
- **Username:** `tanmay`
- **Password:** `Admin@123$`

### **API Endpoints**
- **Frontend:** `http://localhost:3000`
- **Backend:** `http://localhost:8000`
- **API Docs:** `http://localhost:8000/docs`

---

## 🔍 **Verification Steps**

### **Backend Health Check**
```bash
curl http://localhost:8000/health
# Should return: {"status": "healthy"}
```

### **Frontend Health Check**
- Open `http://localhost:3000`
- Should show Redington AI login page

### **Authentication Test**
- Login with test credentials
- Should redirect to chat interface

### **Chat Functionality Test**
- Send message: "Hello, test message"
- Should receive AI response
- Check conversation appears in sidebar

### **File Upload Test**
- Upload a PDF or text file
- Should process and respond with file content analysis

### **Word Export Test**
- Click download button (📥) on any AI response
- Should download properly formatted Word document

---

## 🚨 **Common Issues & Solutions**

### **Issue: Backend won't start**
```bash
# Solution: Check Python version and dependencies
python3 --version
pip install -r requirements.txt
```

### **Issue: Frontend build errors**
```bash
# Solution: Clear cache and reinstall
npm cache clean --force
rm -rf node_modules package-lock.json
npm install
```

### **Issue: AWS authentication errors**
```bash
# Solution: Configure AWS credentials
aws configure
aws sts get-caller-identity
```

### **Issue: CORS errors**
- Check `ALLOWED_ORIGINS` in backend `.env`
- Ensure both services are running
- Verify frontend URL matches allowed origins

### **Issue: Port conflicts**
```bash
# Backend: Change port in start.sh
uvicorn main:app --host 0.0.0.0 --port 8001 --reload

# Frontend: Will auto-find next available port
npm start
```

---

## 📊 **Success Indicators**

### **✅ Deployment Successful When:**
- [ ] Backend API responds at `http://localhost:8000`
- [ ] Frontend loads at `http://localhost:3000`
- [ ] Login works with test credentials
- [ ] Chat interface loads properly
- [ ] AI responses are generated
- [ ] File upload works
- [ ] Word document export works
- [ ] Conversation history saves
- [ ] No console errors in browser

### **🎯 Key Features Working:**
- [ ] Real-time streaming responses
- [ ] Professional Word document export
- [ ] File upload and processing
- [ ] Conversation management
- [ ] Smart timestamps
- [ ] Active conversation highlighting
- [ ] Role-based prompting (Presales Expert)

---

## 📞 **Support Information**

### **Application Features:**
- **Frontend:** React + TypeScript + Material-UI
- **Backend:** FastAPI + Python
- **AI Models:** AWS Bedrock (Claude 3.7 Sonnet)
- **Authentication:** AWS Cognito
- **Database:** AWS DynamoDB
- **File Processing:** PDF, DOCX, XLSX, CSV, TXT, Images
- **Export:** Professional Word documents

### **Default Configuration:**
- **Backend Port:** 8000
- **Frontend Port:** 3000
- **Default User:** tanmay / Admin@123$
- **AWS Region:** us-east-1

---

## 🎉 **Deployment Complete!**

Once all checkboxes are marked, your Redington AI Chatbot is ready for use!

**Access URLs:**
- **Main Application:** http://localhost:3000
- **API Documentation:** http://localhost:8000/docs
- **Health Check:** http://localhost:8000/health
