#!/usr/bin/env python3
"""
Create Missing Session Records for Migrated Chat Data
====================================================

This script creates the missing session metadata records that the frontend
needs to display chat history in the left panel. The data migration moved
the chat messages, but didn't create the corresponding session records.

The backend expects session records with:
- chat_id: "SESSION#{session_id}"
- session_data: JSON containing session metadata
- message_count: Number of messages in the session
"""

import boto3
import json
from datetime import datetime
from collections import defaultdict
import uuid

class SessionRecordCreator:
    def __init__(self, region='us-east-1'):
        self.dynamodb = boto3.client('dynamodb', region_name=region)
        self.region = region
        
    def scan_table(self, table_name: str) -> list:
        """Scan entire table and return all items"""
        try:
            response = self.dynamodb.scan(TableName=table_name)
            items = response.get('Items', [])
            
            # Handle pagination
            while 'LastEvaluatedKey' in response:
                response = self.dynamodb.scan(
                    TableName=table_name,
                    ExclusiveStartKey=response['LastEvaluatedKey']
                )
                items.extend(response.get('Items', []))
            
            return items
        except Exception as e:
            print(f"Error scanning table {table_name}: {e}")
            return []
    
    def analyze_missing_sessions(self):
        """Analyze which users need session records created"""
        print("=== ANALYZING MISSING SESSION RECORDS ===")
        
        # Get all data from user_chat_sessions table
        all_items = self.scan_table('user_chat_sessions')
        
        # Separate messages and sessions
        message_records = []
        session_records = []
        
        for item in all_items:
            chat_id = item.get('chat_id', {}).get('S', '')
            if chat_id.startswith('MESSAGE#'):
                message_records.append(item)
            elif chat_id.startswith('SESSION#'):
                session_records.append(item)
        
        print(f"Found {len(message_records)} message records")
        print(f"Found {len(session_records)} session records")
        
        # Group messages by user and session
        user_sessions = defaultdict(lambda: defaultdict(list))
        
        for msg in message_records:
            user_id = msg.get('user_id', {}).get('S', '')
            session_id = msg.get('session_id', {}).get('S', '')
            if user_id and session_id:
                user_sessions[user_id][session_id].append(msg)
        
        # Find sessions that exist in messages but not in session records
        existing_sessions = set()
        for session in session_records:
            user_id = session.get('user_id', {}).get('S', '')
            session_data = session.get('session_data', {}).get('S', '{}')
            try:
                session_info = json.loads(session_data)
                session_id = session_info.get('session_id', '')
                if user_id and session_id:
                    existing_sessions.add(f"{user_id}#{session_id}")
            except:
                pass
        
        # Identify missing sessions
        missing_sessions = []
        for user_id, sessions in user_sessions.items():
            for session_id, messages in sessions.items():
                session_key = f"{user_id}#{session_id}"
                if session_key not in existing_sessions:
                    # Get first and last message timestamps
                    timestamps = [msg.get('timestamp', {}).get('S', '') for msg in messages]
                    timestamps = [ts for ts in timestamps if ts]
                    timestamps.sort()
                    
                    first_message = None
                    for msg in messages:
                        if msg.get('role', {}).get('S') == 'user':
                            first_message = msg.get('content', {}).get('S', '')
                            break
                    
                    missing_sessions.append({
                        'user_id': user_id,
                        'session_id': session_id,
                        'message_count': len(messages),
                        'first_timestamp': timestamps[0] if timestamps else datetime.now().isoformat(),
                        'last_timestamp': timestamps[-1] if timestamps else datetime.now().isoformat(),
                        'first_message': first_message or 'Chat Session',
                        'messages': messages
                    })
        
        return missing_sessions
    
    def create_session_record(self, session_info: dict, dry_run: bool = True):
        """Create a session record in the user_chat_sessions table"""
        user_id = session_info['user_id']
        session_id = session_info['session_id']
        
        # Generate session title from first message or timestamp
        first_message = session_info.get('first_message', 'Chat Session')
        if len(first_message) > 50:
            title = first_message[:47] + "..."
        else:
            title = first_message
        
        # Create session metadata
        session_data = {
            "session_id": session_id,
            "username": user_id,
            "title": title,
            "created_at": session_info['first_timestamp'],
            "updated_at": session_info['last_timestamp'],
            "message_count": session_info['message_count'],
            "last_message": first_message
        }
        
        # Create DynamoDB item
        item = {
            "user_id": {"S": user_id},
            "chat_id": {"S": f"SESSION#{session_id}"},
            "session_data": {"S": json.dumps(session_data)},
            "created_at": {"S": session_info['first_timestamp']},
            "updated_at": {"S": session_info['last_timestamp']},
            "session_id": {"S": session_id},
            "title": {"S": title},
            "message_count": {"N": str(session_info['message_count'])}
        }
        
        if dry_run:
            print(f"  Would create session: {user_id} -> {session_id} ({title})")
            return True
        else:
            try:
                self.dynamodb.put_item(
                    TableName='user_chat_sessions',
                    Item=item
                )
                print(f"  ✅ Created session: {user_id} -> {session_id} ({title})")
                return True
            except Exception as e:
                print(f"  ❌ Error creating session {session_id}: {e}")
                return False
    
    def create_missing_sessions(self, missing_sessions: list, dry_run: bool = True):
        """Create all missing session records"""
        print(f"\n=== {'DRY RUN' if dry_run else 'CREATING'} MISSING SESSION RECORDS ===")
        
        success_count = 0
        error_count = 0
        
        for session_info in missing_sessions:
            if self.create_session_record(session_info, dry_run):
                success_count += 1
            else:
                error_count += 1
        
        print(f"\n{'Would create' if dry_run else 'Created'} {success_count} session records")
        if error_count > 0:
            print(f"Errors: {error_count}")
        
        return success_count, error_count

def main():
    """Main execution function"""
    print("REDINGTON CHATBOT SESSION RECORD CREATOR")
    print("========================================")
    
    creator = SessionRecordCreator()
    
    # Step 1: Analyze missing sessions
    missing_sessions = creator.analyze_missing_sessions()
    
    if not missing_sessions:
        print("\n✅ No missing session records found!")
        return
    
    print(f"\nFound {len(missing_sessions)} missing session records:")
    
    # Group by user for summary
    user_summary = defaultdict(int)
    for session in missing_sessions:
        user_summary[session['user_id']] += 1
    
    for user_id, count in sorted(user_summary.items()):
        print(f"  - {user_id}: {count} sessions")
    
    # Step 2: Execute dry run
    print("\n" + "="*50)
    print("EXECUTING DRY RUN...")
    success_count, error_count = creator.create_missing_sessions(missing_sessions, dry_run=True)
    
    if error_count > 0:
        print(f"\n❌ Errors found during dry run. Please fix before proceeding.")
        return
    
    # Step 3: Execute actual creation
    print("\n" + "="*50)
    print("EXECUTING ACTUAL SESSION CREATION...")
    success_count, error_count = creator.create_missing_sessions(missing_sessions, dry_run=False)
    
    if error_count == 0:
        print(f"\n🎉 SUCCESS! Created {success_count} session records.")
        print("\n✅ Users should now be able to see their chat history in the left panel!")
        
        # Show specific users that were fixed
        print("\nFixed users:")
        for user_id in sorted(user_summary.keys()):
            print(f"  - {user_id}: {user_summary[user_id]} chat sessions now visible")
    else:
        print(f"\n⚠️ Completed with {error_count} errors. Some sessions may not be visible.")

if __name__ == "__main__":
    main()
