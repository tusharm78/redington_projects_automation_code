#!/usr/bin/env python3

import requests
import json
import time

def test_complete_flow():
    base_url = "https://bot.redingtonsolutions.org"
    
    print("🔍 Testing Complete Chat Flow...")
    
    try:
        # Step 1: Login
        print("\n1. 🔐 Login")
        login_response = requests.post(f"{base_url}/api/v1/auth/login", 
                                     json={"username": "tanmay", "password": "Admin@123$"})
        
        if login_response.status_code != 200:
            print(f"❌ Login failed: {login_response.status_code}")
            return
            
        token = login_response.json()["access_token"]
        headers = {"Authorization": f"Bearer {token}", "Content-Type": "application/json"}
        print("✅ Login successful")
        
        # Step 2: Get initial sessions
        print("\n2. 📊 Get Initial Sessions")
        sessions_response = requests.get(f"{base_url}/api/v1/sessions", headers=headers)
        initial_sessions = sessions_response.json().get("sessions", [])
        initial_count = len(initial_sessions)
        print(f"✅ Initial sessions: {initial_count}")
        
        # Step 3: Send a test message (this should create a new session)
        print("\n3. 💬 Send Test Message")
        chat_data = {
            "message": "Hello, this is a test message to verify session creation",
            "session_id": "default",  # This should trigger new session creation
            "model": "Claude 3.7 Sonnet"
        }
        
        # Use streaming endpoint like the frontend does
        stream_response = requests.post(f"{base_url}/api/v1/chat/stream", 
                                      json=chat_data, headers=headers, stream=True)
        
        if stream_response.status_code != 200:
            print(f"❌ Chat failed: {stream_response.status_code}")
            print(f"Response: {stream_response.text}")
            return
            
        print("✅ Chat message sent, processing stream...")
        
        # Process the stream to get session ID
        session_id = None
        for line in stream_response.iter_lines():
            if line:
                line_str = line.decode('utf-8')
                if line_str.startswith('data: '):
                    try:
                        data = json.loads(line_str[6:])
                        if 'session_id' in data:
                            session_id = data['session_id']
                            print(f"📋 Session ID from stream: {session_id}")
                        if data.get('is_complete'):
                            print("✅ Stream completed")
                            break
                    except:
                        pass
        
        # Wait a moment for backend to save
        time.sleep(2)
        
        # Step 4: Get sessions after message
        print("\n4. 📊 Get Sessions After Message")
        sessions_response = requests.get(f"{base_url}/api/v1/sessions", headers=headers)
        final_sessions = sessions_response.json().get("sessions", [])
        final_count = len(final_sessions)
        print(f"✅ Final sessions: {final_count}")
        
        if final_count > initial_count:
            print(f"🎉 New session created! ({initial_count} -> {final_count})")
            
            # Find the new session
            new_sessions = [s for s in final_sessions if s not in initial_sessions]
            if new_sessions:
                new_session = new_sessions[0]
                print(f"📋 New session: {new_session['name']} (ID: {new_session['id']})")
                print(f"📊 Message count: {new_session.get('message_count', 0)}")
                
                # Step 5: Get messages for the new session
                if session_id:
                    print(f"\n5. 📨 Get Messages for Session: {session_id}")
                    messages_response = requests.get(f"{base_url}/api/v1/chat/history/{session_id}", 
                                                   headers=headers)
                    
                    if messages_response.status_code == 200:
                        messages_data = messages_response.json()
                        messages = messages_data.get("messages", [])
                        print(f"✅ Retrieved {len(messages)} messages")
                        
                        for i, msg in enumerate(messages):
                            role = msg.get('role', 'unknown')
                            content = msg.get('content', '')[:50]
                            print(f"  {i+1}. [{role}] {content}...")
                    else:
                        print(f"❌ Failed to get messages: {messages_response.status_code}")
        else:
            print(f"⚠️ No new session created ({initial_count} -> {final_count})")
            
        # Step 6: Check what frontend would see
        print(f"\n6. 🎨 Frontend Filter Test")
        sessions_with_messages = [s for s in final_sessions if s.get('message_count', 0) > 0]
        print(f"📊 Sessions with messages (what UI shows): {len(sessions_with_messages)}")
        
        for i, session in enumerate(sessions_with_messages[:5]):
            name = session.get('name', 'Untitled')[:30]
            count = session.get('message_count', 0)
            print(f"  {i+1}. {name} - {count} messages")
            
    except Exception as e:
        print(f"❌ Error: {e}")

if __name__ == "__main__":
    test_complete_flow()
