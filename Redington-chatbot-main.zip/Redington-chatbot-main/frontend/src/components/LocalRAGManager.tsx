import React, { useState, useEffect } from 'react';
import {
  Box,
  Typography,
  Button,
  Card,
  CardContent,
  Grid,
  LinearProgress,
  Alert,
  Dialog,
  DialogTitle,
  DialogContent,
  DialogActions,
  TextField,
  List,
  ListItem,
  ListItemText,
  ListItemIcon,
  Chip,
  Paper,
  CircularProgress
} from '@mui/material';
import {
  Search as SearchIcon,
  Refresh as RefreshIcon,
  Storage as StorageIcon,
  Description as DocumentIcon,
  CheckCircle as CheckIcon,
  Error as ErrorIcon,
  Info as InfoIcon,
  Build as BuildIcon
} from '@mui/icons-material';
import { apiService } from '../services/api';

interface LocalRAGStats {
  initialized: boolean;
  total_vectors?: number;
  index_directory?: string;
  embedding_model?: string;
  error?: string;
}

interface SearchResult {
  content: string;
  metadata: any;
  similarity_score: number;
}

const LocalRAGManager: React.FC = () => {
  const [stats, setStats] = useState<LocalRAGStats | null>(null);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [success, setSuccess] = useState<string | null>(null);
  
  // Search states
  const [searchDialogOpen, setSearchDialogOpen] = useState(false);
  const [searchQuery, setSearchQuery] = useState('');
  const [searchResults, setSearchResults] = useState<SearchResult[]>([]);
  const [searching, setSearching] = useState(false);

  useEffect(() => {
    loadRAGStats();
  }, []);

  const loadRAGStats = async () => {
    try {
      setLoading(true);
      setError(null);
      const response = await apiService.get('/rag/stats');
      const data = response.data || response;
      setStats(data);
    } catch (err: any) {
      setError(err.message || 'Failed to load RAG statistics');
    } finally {
      setLoading(false);
    }
  };

  const initializeRAG = async () => {
    try {
      setLoading(true);
      setError(null);
      const response = await apiService.post('/rag/initialize');
      const data = response.data || response;
      setSuccess(data.message || 'RAG initialized successfully');
      await loadRAGStats();
    } catch (err: any) {
      setError(err.message || 'Failed to initialize RAG');
    } finally {
      setLoading(false);
    }
  };

  const handleSearch = async () => {
    if (!searchQuery.trim()) return;

    try {
      setSearching(true);
      setError(null);

      const formData = new FormData();
      formData.append('query', searchQuery);
      formData.append('max_results', '5');

      // Use fetch directly for form data
      const token = localStorage.getItem('access_token');
      const response = await fetch('/api/v1/rag/search', {
        method: 'POST',
        headers: {
          'Authorization': `Bearer ${token}`,
        },
        body: formData,
      });

      if (!response.ok) {
        throw new Error(`Search failed: ${response.statusText}`);
      }

      const data = await response.json();
      setSearchResults(data.results || []);
    } catch (err: any) {
      setError(err.message || 'Failed to search knowledge base');
    } finally {
      setSearching(false);
    }
  };

  return (
    <Box sx={{ p: 3 }}>
      <Typography variant="h4" gutterBottom sx={{ display: 'flex', alignItems: 'center', gap: 1 }}>
        <StorageIcon />
        Local RAG Knowledge Base
      </Typography>

      <Alert severity="info" sx={{ mb: 2 }}>
        This RAG system uses your existing FAISS index from the Streamlit application with local document storage.
      </Alert>

      {error && (
        <Alert severity="error" sx={{ mb: 2 }} onClose={() => setError(null)}>
          {error}
        </Alert>
      )}

      {success && (
        <Alert severity="success" sx={{ mb: 2 }} onClose={() => setSuccess(null)}>
          {success}
        </Alert>
      )}

      {loading && <LinearProgress sx={{ mb: 2 }} />}

      <Grid container spacing={3}>
        {/* Statistics Card */}
        <Grid item xs={12} md={6}>
          <Card>
            <CardContent>
              <Typography variant="h6" gutterBottom sx={{ display: 'flex', alignItems: 'center', gap: 1 }}>
                <InfoIcon />
                RAG Statistics
              </Typography>
              
              {stats ? (
                <Box>
                  <Box sx={{ display: 'flex', alignItems: 'center', gap: 1, mb: 1 }}>
                    <Typography variant="body2">Status:</Typography>
                    <Chip 
                      icon={stats.initialized ? <CheckIcon /> : <ErrorIcon />}
                      label={stats.initialized ? 'Initialized' : 'Not Initialized'}
                      color={stats.initialized ? 'success' : 'error'}
                      size="small"
                    />
                  </Box>
                  
                  {stats.initialized && (
                    <>
                      <Typography variant="body2">
                        <strong>Total Vectors:</strong> {stats.total_vectors?.toLocaleString() || 'Unknown'}
                      </Typography>
                      <Typography variant="body2">
                        <strong>Embedding Model:</strong> {stats.embedding_model || 'Unknown'}
                      </Typography>
                      <Typography variant="body2">
                        <strong>Index Location:</strong> {stats.index_directory || 'Unknown'}
                      </Typography>
                    </>
                  )}
                  
                  {stats.error && (
                    <Typography variant="body2" color="error">
                      <strong>Error:</strong> {stats.error}
                    </Typography>
                  )}
                </Box>
              ) : (
                <Typography variant="body2" color="text.secondary">
                  Loading statistics...
                </Typography>
              )}
            </CardContent>
          </Card>
        </Grid>

        {/* Actions Card */}
        <Grid item xs={12} md={6}>
          <Card>
            <CardContent>
              <Typography variant="h6" gutterBottom>
                Actions
              </Typography>
              
              <Box sx={{ display: 'flex', flexDirection: 'column', gap: 2 }}>
                <Button
                  variant="outlined"
                  startIcon={<SearchIcon />}
                  onClick={() => setSearchDialogOpen(true)}
                  disabled={loading || !stats?.initialized}
                >
                  Search Knowledge Base
                </Button>
                
                <Button
                  variant="outlined"
                  startIcon={<RefreshIcon />}
                  onClick={loadRAGStats}
                  disabled={loading}
                >
                  Refresh Stats
                </Button>
                
                <Button
                  variant="contained"
                  startIcon={<BuildIcon />}
                  onClick={initializeRAG}
                  disabled={loading}
                  color="primary"
                >
                  Initialize RAG
                </Button>
              </Box>
            </CardContent>
          </Card>
        </Grid>

        {/* Information Card */}
        <Grid item xs={12}>
          <Card>
            <CardContent>
              <Typography variant="h6" gutterBottom>
                About This RAG System
              </Typography>
              
              <Typography variant="body2" paragraph>
                This RAG (Retrieval-Augmented Generation) system uses the same FAISS index created by your Streamlit application. 
                It provides context-aware responses by searching through your existing document knowledge base.
              </Typography>
              
              <Typography variant="body2" paragraph>
                <strong>Features:</strong>
              </Typography>
              <List dense>
                <ListItem>
                  <ListItemIcon><DocumentIcon /></ListItemIcon>
                  <ListItemText primary="Local FAISS vector store" secondary="Fast similarity search" />
                </ListItem>
                <ListItem>
                  <ListItemIcon><DocumentIcon /></ListItemIcon>
                  <ListItemText primary="Amazon Bedrock embeddings" secondary="High-quality text embeddings using Titan v2" />
                </ListItem>
                <ListItem>
                  <ListItemIcon><DocumentIcon /></ListItemIcon>
                  <ListItemText primary="Automatic context retrieval" secondary="Enhances chat responses with relevant information" />
                </ListItem>
              </List>
            </CardContent>
          </Card>
        </Grid>
      </Grid>

      {/* Search Dialog */}
      <Dialog open={searchDialogOpen} onClose={() => setSearchDialogOpen(false)} maxWidth="md" fullWidth>
        <DialogTitle>Search Knowledge Base</DialogTitle>
        <DialogContent>
          <Box sx={{ mt: 2 }}>
            <TextField
              fullWidth
              label="Search Query"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              onKeyPress={(e) => e.key === 'Enter' && handleSearch()}
              disabled={searching}
            />
            
            <Button
              variant="contained"
              startIcon={searching ? <CircularProgress size={20} /> : <SearchIcon />}
              onClick={handleSearch}
              disabled={!searchQuery.trim() || searching}
              sx={{ mt: 2 }}
            >
              {searching ? 'Searching...' : 'Search'}
            </Button>
            
            {searchResults.length > 0 && (
              <Box sx={{ mt: 3 }}>
                <Typography variant="h6" gutterBottom>
                  Search Results ({searchResults.length})
                </Typography>
                
                {searchResults.map((result, index) => (
                  <Paper key={index} sx={{ p: 2, mb: 2 }}>
                    <Box sx={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', mb: 1 }}>
                      <Typography variant="subtitle2">
                        Document Chunk {index + 1}
                      </Typography>
                      <Chip 
                        label={`Score: ${result.similarity_score.toFixed(3)}`}
                        size="small"
                        color="primary"
                      />
                    </Box>
                    <Typography variant="body2" sx={{ whiteSpace: 'pre-wrap' }}>
                      {result.content}
                    </Typography>
                  </Paper>
                ))}
              </Box>
            )}
          </Box>
        </DialogContent>
        <DialogActions>
          <Button onClick={() => setSearchDialogOpen(false)}>
            Close
          </Button>
        </DialogActions>
      </Dialog>
    </Box>
  );
};

export default LocalRAGManager;
