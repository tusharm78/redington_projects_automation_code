import React from 'react';
import ReactMarkdown from 'react-markdown';
import remarkGfm from 'remark-gfm';
import { Box } from '@mui/material';

const TestMarkdown: React.FC = () => {
  const testContent = `# Test Header

This is **bold text** and this is *italic text*.

## Table Test

| Name | Role | Department |
|------|------|------------|
| John | Developer | IT |
| Jane | Manager | HR |

- List item 1
- List item 2
- List item 3

1. Numbered item 1
2. Numbered item 2
3. Numbered item 3`;

  return (
    <Box sx={{ padding: 2, border: '1px solid red', margin: 2 }}>
      <h3>Test ReactMarkdown Component</h3>
      <ReactMarkdown remarkPlugins={[remarkGfm]}>
        {testContent}
      </ReactMarkdown>
    </Box>
  );
};

export default TestMarkdown;
