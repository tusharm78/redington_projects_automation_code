import React, { useState, useEffect, useRef, useCallback } from 'react';
import { Document, Packer, Paragraph, TextRun, HeadingLevel } from 'docx';
import { saveAs } from 'file-saver';
import { processAndStoreCustomerName } from '../utils/customerNameReplacement';
import {
  Box,
  Container,
  Typography,
  TextField,
  Button,
  Paper,
  Avatar,
  Chip,
  IconButton,
  Drawer,
  List,
  ListItem,
  ListItemText,
  ListItemIcon,
  Divider,
  Select,
  MenuItem,
  FormControl,
  InputLabel,
  Tooltip,
  Badge,
  Card,
  CardContent,
  Fade,
  Slide,
  CircularProgress,
  LinearProgress,
  Fab,
  Menu,
  MenuList,
  ClickAwayListener,
  Popper,
  Grow,
  Stack,
  Alert,
  Dialog,
  DialogTitle,
  DialogContent,
  DialogActions,
  Tab,
  Tabs,
} from '@mui/material';
import {
  Send as SendIcon,
  Stop as StopIcon,
  AttachFile as AttachFileIcon,
  Menu as MenuIcon,
  Settings as SettingsIcon,
  History as HistoryIcon,
  Add as AddIcon,
  Refresh as RefreshIcon,
  SmartToy as BotIcon,
  Person as PersonIcon,
  Psychology as ThinkingIcon,
  Speed as SpeedIcon,
  Memory as MemoryIcon,
  Close as CloseIcon,
  Download as DownloadIcon,
  Share as ShareIcon,
  MoreVert as MoreVertIcon,
  Lightbulb as LightbulbIcon,
  Code as CodeIcon,
  Image as ImageIcon,
  Description as DocumentIcon,
  Logout as LogoutIcon,
  AccountCircle as AccountCircleIcon,
  Delete as DeleteIcon,
  Edit as EditIcon,
  Check as CheckIcon,
  ContentCopy as CopyIcon,
} from '@mui/icons-material';
import { v4 as uuidv4 } from 'uuid';
import { apiService } from '../services/api';
import { ChatMessage, ChatRequest, ModelConfig } from '../types';
import MessageRenderer from './MessageRenderer';
import WordDocumentRenderer from './WordDocumentRenderer';
import LocalRAGManager from './LocalRAGManager';
import { useAuth } from '../hooks';
import { sessionsService, SessionMessage } from '../services/sessions';

// Redington Brand Colors - Updated to match logo
const redingtonTheme = {
  primary: '#00A651', // Redington Green (main)
  secondary: '#1A1A1A', // Dark Gray
  accent: '#66CC99', // Light Green accent
  background: '#F8F9FA', // Light background
  surface: '#FFFFFF', // White surface
  text: '#2C3E50', // Dark text
  textSecondary: '#6C757D', // Secondary text
  success: '#00A651', // Green success
  warning: '#FFC107',
  error: '#DC3545',
  gradient: 'linear-gradient(135deg, #00A651 0%, #66CC99 100%)', // Green gradient
  darkGradient: 'linear-gradient(135deg, #1A1A1A 0%, #2C3E50 100%)',
};

// Pre-sales Professional System Prompt
const PRESALES_SYSTEM_PROMPT = `You are an expert Presales Proposal Generator for **Redington**. Your objective is to create detailed and compelling proposals for prospective clients and new business use cases. You will follow a well-defined structure, centering on the client's specific requirements and the proposed solution.

---
**Proposal Guidelines:**

**Customer Placeholders:**

* Wherever names such as Customer Name, Services Head, Presales/Technical Head, Enterprise Sales, or Technical Contact are to be included, insert placeholders in angle brackets, such as:
  \`<Customer Name>\`, \`<Services Head>\`, etc.
* Do not insert any actual names or contact details. Leave these fields blank for manual input later.
* Proposal content should be presented in **tabular format** wherever applicable.

**PROPOSAL DETAILS SECTION:**
This section should include:

* Proposal Title
* Services Head (Placeholder)
* Presales/Technical Head (Placeholder)
* Enterprise Sales (Placeholder)
* Technical Contact (Placeholder)
* Proposal Creation Date
* Proposal Validity
* Proposal Type
* Commercial Currency (USD)

**TABLE OF CONTENTS:**

* Provide a structured list of all proposal sections.
* Maintain the following formatting:

  * Main Section Headings: **Bold, Uppercase, Numbered (e.g., 1. INTRODUCTION)**
  * Subheadings: **Bold and Capitalized (e.g., 1.1 Overview)**
  * Sub-subheadings: *Italicized with sentence case (e.g., 1.1.1 Key features)*
  * Follow a consistent heading hierarchy throughout.

**EXECUTIVE SUMMARY:**

* Introduction and gratitude
* Key benefits of the proposed solution
* Summary of the client's main requirements
* A call to schedule further discussion

**STATED REQUIREMENT:**

* A detailed paragraph outlining the client's problem and business challenge
* A list of key requirements shared by the customer (in bullet points)

**SUCCESS CRITERIA:**

* List measurable outcomes in bullet format that define success and demonstrate how the solution addresses key pain points

**PROPOSED SOLUTION:**

* Start by summarizing the client's initial issue and the goal they want to achieve
* Break down the solution into multiple subsections with relevant bullet points under each:

  * Account Access
  * Assessment
  * Compute Considerations
  * Security
  * Optimizing Resource Management
  * Enhancing Observability, Logging, and Monitoring
  * Storage
  * Backup

**PROPOSED ARCHITECTURE:**

* Include a high-level design of the architecture (e.g., DNS, CDN, Load Balancer, etc.)
* Add descriptive content that can later be translated into an actual diagram (e.g., in Draw.io)

**SCOPE OF WORK:**

* Provide a detailed list of all tasks, activities, and deliverables for the project
* Cover each phase with specific descriptions, expected outcomes, and assigned responsibilities
* Include granular technical details, such as:

  * Account creation
  * VPC setup
  * IAM configuration
  * Service configuration based on the use case
  * Parameter or setting-level configurations
* Clarify which configurations can be done directly and which require custom implementation (e.g., AWS Lambda@Edge), with examples if possible

**TESTING:**

* Indicate responsibilities (most of which are client-driven)

**RACI MATRIX:**

* Define roles and responsibilities between Redington and the client

**OUT OF SCOPE:**

* Clearly specify exclusions from the engagement

**GENERAL ASSUMPTIONS & DEPENDENCIES:**

* Outline assumptions and dependencies on the client side

**PROJECT TIMELINE:**

* Provide a phase-wise breakdown of the timeline

**PROPOSED COMMERCIALS:**

* Include either a placeholder for pricing or reference a separate commercial document

**BOQ ESTIMATION:**

* Offer a high-level estimation and list of assumptions

**ESCALATION MATRIX:**

* Add a placeholder for escalation contacts

**CLIENT SATISFACTION:**

* Describe how client satisfaction will be ensured or measured


**Constraints & Guidelines:**

* **Company Branding**: You are representing **Redington**, so refer to it as the solution provider where needed
* Always focus on the value delivered to the client
* Use placeholders where details are unknown or client-specific
* Maintain a clear, professional tone
* Never include personal or confidential information.
* Everything will be without any html tag

---

**Start Template Example (for user input):**

"Okay, I'm ready to generate a proposal. Please share the following information for the new client or use case:

* Client Name:
* Specific Requirement or Problem Statement:
* Desired High-Level Solution:
* Mentioned Success Criteria (if any):
* Proposed Timeline (if known):
* Any Other Relevant Details:"`;

interface Conversation {
  id: string;
  title: string;
  lastMessage: string;
  timestamp: string;
  messageCount: number;
}

// Utility function for relative timestamps
const getRelativeTime = (timestamp: string | Date): string => {
  const now = new Date();
  const date = typeof timestamp === 'string' ? new Date(timestamp) : timestamp;
  
  // If invalid date, return default
  if (isNaN(date.getTime())) {
    return 'Recently';
  }
  
  const diffInMs = now.getTime() - date.getTime();
  const diffInMinutes = Math.floor(diffInMs / (1000 * 60));
  const diffInHours = Math.floor(diffInMs / (1000 * 60 * 60));
  const diffInDays = Math.floor(diffInMs / (1000 * 60 * 60 * 24));
  
  if (diffInMinutes < 1) {
    return 'Just now';
  } else if (diffInMinutes < 60) {
    return `${diffInMinutes} minute${diffInMinutes === 1 ? '' : 's'} ago`;
  } else if (diffInHours < 24) {
    return `${diffInHours} hour${diffInHours === 1 ? '' : 's'} ago`;
  } else if (diffInDays === 1) {
    return 'Yesterday';
  } else if (diffInDays < 7) {
    return `${diffInDays} days ago`;
  } else if (diffInDays < 30) {
    const weeks = Math.floor(diffInDays / 7);
    return `${weeks} week${weeks === 1 ? '' : 's'} ago`;
  } else if (diffInDays < 365) {
    const months = Math.floor(diffInDays / 30);
    return `${months} month${months === 1 ? '' : 's'} ago`;
  } else {
    const years = Math.floor(diffInDays / 365);
    return `${years} year${years === 1 ? '' : 's'} ago`;
  }
};

const ModernChatInterface: React.FC = () => {
  // Authentication
  const { user, logout } = useAuth();
  
  // State management
  const [messages, setMessages] = useState<ChatMessage[]>([]);
  const [inputMessage, setInputMessage] = useState('');
  const [loading, setLoading] = useState(false);
  const [isStreaming, setIsStreaming] = useState(false);
  const [streamingMessageId, setStreamingMessageId] = useState<string | null>(null);
  const [streamController, setStreamController] = useState<AbortController | null>(null);
  const [sessionsLoading, setSessionsLoading] = useState(false);
  const [conversationId, setConversationId] = useState<string>('');
  const [selectedModel, setSelectedModel] = useState('Claude 3.7 Sonnet Reasoning');
  const [availableModels, setAvailableModels] = useState<ModelConfig>({});
  const [uploadedFiles, setUploadedFiles] = useState<string[]>([]);
  const [conversations, setConversations] = useState<Conversation[]>([]);
  const [sidebarOpen, setSidebarOpen] = useState(false);
  const [settingsOpen, setSettingsOpen] = useState(false);
  const [settingsTab, setSettingsTab] = useState(0);
  const [selectedRole, setSelectedRole] = useState<'presales' | 'custom'>('presales');
  const [customSystemPrompt, setCustomSystemPrompt] = useState('');
  const [error, setError] = useState('');
  const [isTyping, setIsTyping] = useState(false);
  const [showWelcome, setShowWelcome] = useState(true);
  const [menuAnchorEl, setMenuAnchorEl] = useState<null | HTMLElement>(null);
  const [userMenuAnchorEl, setUserMenuAnchorEl] = useState<null | HTMLElement>(null);
  const [editingConversationId, setEditingConversationId] = useState<string | null>(null);
  const [editingTitle, setEditingTitle] = useState<string>('');

  const messagesEndRef = useRef<HTMLDivElement>(null);
  const fileInputRef = useRef<HTMLInputElement>(null);

  // Auto-scroll to bottom
  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  };

  useEffect(() => {
    scrollToBottom();
  }, [messages]);

  const loadConversationHistory = useCallback(async () => {
    // Load real conversations from DynamoDB
    console.log('🔍 Loading conversation history for user:', user?.username);
    console.log('🔑 Auth token exists:', !!localStorage.getItem('access_token'));
    
    if (!user?.username) {
      console.log('❌ No user found, clearing conversations');
      setConversations([]);
      return;
    }

    setSessionsLoading(true);
    try {
      console.log('📡 Fetching sessions from API...');
      console.log('🌐 API Base URL:', process.env.REACT_APP_API_URL || '/api/v1');
      
      const sessionsResponse = await sessionsService.getUserSessions();
      console.log('✅ Sessions received:', sessionsResponse);
      
      // Handle the response format from backend
      const sessions = sessionsResponse.sessions || sessionsResponse;
      console.log('📊 Sessions array:', sessions);
      console.log('📊 Number of sessions:', Array.isArray(sessions) ? sessions.length : Object.keys(sessions).length);
      
      let conversationList: Conversation[] = [];
      
      if (Array.isArray(sessions)) {
        // Backend returns array format: {sessions: [{id, name, created_at, updated_at}]}
        conversationList = sessions.map((session: any) => {
          const conversation = {
            id: session.id,
            title: session.name || session.title || 'Untitled Chat',
            lastMessage: session.last_message || 'Click to load conversation',
            timestamp: session.updated_at || session.created_at || new Date().toISOString(),
            messageCount: session.message_count || 0,
          };
          console.log('🔄 Creating conversation from session object:', conversation);
          return conversation;
        });
      } else {
        // Fallback for object format: {chatId: title}
        conversationList = Object.entries(sessions).map(([chatId, title]) => {
          const conversation = {
            id: chatId,
            title: typeof title === 'string' ? title : 'Untitled Chat',
            lastMessage: 'Click to load conversation',
            timestamp: new Date().toISOString(),
            messageCount: 0,
          };
          console.log('🔄 Creating conversation from object entry:', conversation);
          return conversation;
        });
      }
      
      console.log('🔄 Converted to conversation list:', conversationList);
      console.log('📝 Setting conversations state with', conversationList.length, 'items');
      console.log('📋 First few conversations:', conversationList.slice(0, 3));
      
      setConversations(conversationList);
      
      // Don't auto-open sidebar - let user open it manually
      // if (conversationList.length > 0) {
      //   setSidebarOpen(true);
      // }
      
      
      // Force a re-render to ensure UI updates
      setTimeout(() => {
        console.log('🎯 Current conversations state after timeout:', conversationList.length);
        console.log('🎯 React state conversations:', conversations.length);
      }, 100);
      
    } catch (error: any) {
      console.error('❌ Error loading conversations:', error);
      console.error('📋 Error details:', {
        message: error?.message,
        status: error?.response?.status,
        data: error?.response?.data
      });
      setConversations([]);
    } finally {
      setSessionsLoading(false);
    }
  }, [user?.username]);

  // Load models on component mount
  useEffect(() => {
    loadAvailableModels();
    // Only generate conversation ID if user is authenticated
    if (user?.username) {
      generateConversationId();
    }
  }, [user?.username]);

  // Load conversations when user changes
  useEffect(() => {
    console.log('🔄 useEffect triggered - user changed');
    console.log('👤 Current user:', user);
    console.log('📧 Username:', user?.username);
    console.log('🔐 Is authenticated:', !!user?.username);
    
    if (user?.username) {
      console.log('✅ User authenticated, loading conversations...');
      loadConversationHistory();
    } else {
      console.log('❌ No user authenticated, skipping conversation load');
    }
  }, [user?.username, loadConversationHistory]);

  // Force load conversations on component mount (for debugging)
  useEffect(() => {
    console.log('🚀 Component mounted, checking auth state...');
    console.log('👤 User on mount:', user);
    console.log('🔑 Token in localStorage:', localStorage.getItem('access_token') ? 'EXISTS' : 'MISSING');
    
    // Force load after a delay to ensure auth is ready
    setTimeout(() => {
      console.log('⏰ Delayed check - User:', user?.username);
      if (user?.username) {
        console.log('🔄 Force loading conversations after delay...');
        loadConversationHistory();
      }
    }, 2000);
  }, [user, loadConversationHistory]);

  // Load initial state from localStorage
  useEffect(() => {
    const savedConversationId = localStorage.getItem('currentConversationId');
    if (savedConversationId && user?.username) {
      console.log('Restoring conversation from localStorage:', savedConversationId);
      setConversationId(savedConversationId);
      // Load the conversation messages
      const restoreConversation = async () => {
        try {
          const sessionMessages = await sessionsService.getSessionMessages(savedConversationId);
          const chatMessages: ChatMessage[] = sessionMessages.map((msg: SessionMessage) => ({
            role: msg.role as 'user' | 'assistant',
            content: msg.content,
            timestamp: new Date(msg.timestamp).toISOString(),
            message_id: msg.message_id,
          }));
          setMessages(chatMessages);
          setShowWelcome(false);
        } catch (error) {
          console.error('Error restoring conversation:', error);
          localStorage.removeItem('currentConversationId');
        }
      };
      restoreConversation();
    }
  }, [user?.username]);

  // Save conversation ID to localStorage when it changes
  useEffect(() => {
    if (conversationId) {
      localStorage.setItem('currentConversationId', conversationId);
    }
  }, [conversationId]);

  // Load saved role and custom prompt from localStorage
  useEffect(() => {
    const savedRole = localStorage.getItem('ai-assistant-role') as 'presales' | 'custom' | null;
    const savedCustomPrompt = localStorage.getItem('ai-assistant-custom-prompt');
    
    if (savedRole) {
      setSelectedRole(savedRole);
    }
    if (savedCustomPrompt) {
      setCustomSystemPrompt(savedCustomPrompt);
    }
  }, []);

  // Save role and custom prompt to localStorage when changed
  useEffect(() => {
    localStorage.setItem('ai-assistant-role', selectedRole);
  }, [selectedRole]);

  useEffect(() => {
    if (customSystemPrompt) {
      localStorage.setItem('ai-assistant-custom-prompt', customSystemPrompt);
    }
  }, [customSystemPrompt]);

  const loadAvailableModels = async () => {
    try {
      const models = await apiService.getAvailableModels();
      setAvailableModels(models);
    } catch (error) {
      console.error('Failed to load models:', error);
      setError('Failed to load AI models');
    }
  };

  const generateConversationId = async () => {
    try {
      // DON'T create a session in the backend yet - just generate a temp ID
      // Session will be created when first message is sent
      const tempId = `temp_${uuidv4()}`;
      console.log('✅ Generated temporary conversation ID:', tempId);
      console.log('⏳ Session will be created when first message is sent');
      setConversationId(tempId);
    } catch (error) {
      console.error('❌ Error generating conversation ID:', error);
      // Fallback to UUID if anything fails
      const fallbackId = `temp_${uuidv4()}`;
      setConversationId(fallbackId);
    }
  };

  // File upload handling - simplified to avoid interference
  const [isDragOver, setIsDragOver] = useState(false);

  const handleDragOver = (e: React.DragEvent) => {
    e.preventDefault();
    e.stopPropagation();
    setIsDragOver(true);
  };

  const handleDragLeave = (e: React.DragEvent) => {
    e.preventDefault();
    e.stopPropagation();
    setIsDragOver(false);
  };

  const handleDrop = (e: React.DragEvent) => {
    e.preventDefault();
    e.stopPropagation();
    setIsDragOver(false);

    const files = Array.from(e.dataTransfer.files);
    files.forEach((file) => {
      // Check file type and size
      const validTypes = ['image/png', 'image/jpg', 'image/jpeg', 'image/gif', 'application/pdf', 'text/plain', 'text/markdown'];
      const maxSize = 10 * 1024 * 1024; // 10MB

      if (validTypes.includes(file.type) && file.size <= maxSize) {
        const reader = new FileReader();
        reader.onload = () => {
          const base64 = reader.result as string;
          setUploadedFiles(prev => [...prev, base64]);
        };
        reader.readAsDataURL(file);
      } else {
        setError(`File ${file.name} is not supported or too large (max 10MB)`);
      }
    });
  };

  const handleOpenSidebar = () => {
    setSidebarOpen(true);
    // Force load conversations when sidebar is opened
    if (user?.username) {
      loadConversationHistory();
    }
  };

  const handleSendMessage = async () => {
    if (!inputMessage.trim() && uploadedFiles.length === 0) return;

    // Throttling variable for smooth streaming updates
    let lastUpdateTime = 0;

    setShowWelcome(false);
    
    // Extract and store customer name for later use in downloads
    const sessionId = conversationId || uuidv4();
    processAndStoreCustomerName(inputMessage, sessionId);
    
    const userMessage: ChatMessage = {
      role: 'user',
      content: inputMessage,
      timestamp: new Date().toISOString(),
      message_id: uuidv4(),
      session_id: sessionId, // Ensure session ID is included
    };

    setMessages(prev => [...prev, userMessage]);
    const currentInput = inputMessage;
    setInputMessage('');
    setLoading(true);
    setIsStreaming(true);
    setIsTyping(true);
    setError('');

    // Create abort controller for stopping the stream
    const controller = new AbortController();
    setStreamController(controller);

    // Add placeholder for AI response
    const aiMessageId = uuidv4();
    setStreamingMessageId(aiMessageId); // Track which message is streaming
    const aiMessage: ChatMessage = {
      role: 'assistant',
      content: '',
      timestamp: new Date().toISOString(),
      message_id: aiMessageId,
      session_id: sessionId, // Include session ID for customer name replacement
    };
    setMessages(prev => [...prev, aiMessage]);

    try {
      const request: ChatRequest = {
        message: currentInput,
        conversation_id: conversationId,
        model_name: selectedModel,
        model_kwargs: {
          max_tokens: availableModels[selectedModel]?.max_tokens || 64000,
          temperature: availableModels[selectedModel]?.temperature || 1.0,
          top_p: availableModels[selectedModel]?.top_p || 1.0,
          top_k: availableModels[selectedModel]?.top_k || 500,
        },
        files: uploadedFiles.length > 0 ? uploadedFiles : undefined,
        system_prompt: selectedRole === 'presales' ? PRESALES_SYSTEM_PROMPT : customSystemPrompt,
      };

      // Use enhanced streaming instead of regular message
      const response = await fetch(`${process.env.REACT_APP_API_URL || '/api/v1'}/chat/stream`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${localStorage.getItem('access_token')}`,
        },
        body: JSON.stringify({
          message: inputMessage,
          conversation_id: conversationId || 'default',
          session_id: conversationId || 'default', // Use the actual conversation ID
          model: selectedModel
        }),
        signal: controller.signal,
      });

      if (!response.ok) {
        throw new Error(`HTTP error! status: ${response.status}`);
      }

      const reader = response.body?.getReader();
      if (!reader) {
        throw new Error('No reader available');
      }

      let fullResponse = '';
      const decoder = new TextDecoder();

      while (true) {
        const { done, value } = await reader.read();
        
        if (done) break;
        
        const chunk = decoder.decode(value, { stream: true });
        const lines = chunk.split('\n');
        
        for (const line of lines) {
          if (line.startsWith('data: ')) {
            try {
              const jsonData = line.slice(6); // Remove 'data: ' prefix
              if (jsonData.trim()) {
                const chunkData = JSON.parse(jsonData);
                
                // Handle enhanced streaming format
                if (chunkData.chunk) {
                  fullResponse += chunkData.chunk;
                  
                  // Throttled update to reduce flickering - update every 3 chunks or on completion
                  const chunkIndex = chunkData.metadata?.chunk_index || 0;
                  const shouldUpdate = chunkIndex % 3 === 0 || chunkData.is_complete;
                  
                  if (shouldUpdate) {
                    setMessages(prev => prev.map(msg => 
                      msg.message_id === aiMessageId 
                        ? { ...msg, content: fullResponse }
                        : msg
                    ));
                  }
                }

                // Check if streaming is complete
                if (chunkData.is_complete) {
                  // Final update to ensure all content is displayed
                  setMessages(prev => prev.map(msg => 
                    msg.message_id === aiMessageId 
                      ? { ...msg, content: fullResponse }
                      : msg
                  ));
                  setIsStreaming(false);
                  setStreamingMessageId(null);
                  setIsTyping(false);
                  break;
                }
              }
            } catch (parseError) {
              console.warn('Failed to parse enhanced chunk data:', parseError);
              // Fallback to old format for compatibility
              const data = line.slice(6);
              
              if (data === '[DONE]') {
                setIsStreaming(false);
                setStreamingMessageId(null);
                setIsTyping(false);
                break;
              }
              
              if (data.startsWith('[CONVERSATION_ID]')) {
                const convId = data.slice(17);
                if (convId && convId !== conversationId) {
                  setConversationId(convId);
                }
                continue;
              }
              
              if (data.startsWith('Error:')) {
                throw new Error(data);
              }
              
              // Old format - just append data with throttling
              fullResponse += data;
              
              // Throttled update to reduce flickering
              const currentTime = Date.now();
              if (!lastUpdateTime || currentTime - lastUpdateTime > 100) { // Update every 100ms max
                setMessages(prev => prev.map(msg => 
                  msg.message_id === aiMessageId 
                    ? { ...msg, content: fullResponse }
                    : msg
                ));
                lastUpdateTime = currentTime;
              }
            }
          }
        }
      }

      setUploadedFiles([]);
      
      // Reload conversation list to show the new/updated conversation
      await loadConversationHistory();
      
    } catch (err: any) {
      if (err.name === 'AbortError') {
        setError('Message generation was stopped.');
        // Don't remove the message when user stops generation - keep what was generated
      } else {
        setError(err.message || 'Failed to send message. Please try again.');
        // Only remove the incomplete AI message on actual errors (not user stops)
        setMessages(prev => prev.filter(msg => msg.message_id !== aiMessageId));
      }
    } finally {
      setLoading(false);
      setIsStreaming(false);
      setStreamingMessageId(null);
      setIsTyping(false);
      setStreamController(null);
    }
  };

  const handleCopyMessage = async (content: string) => {
    try {
      // Strip markdown for clean copying
      const stripMarkdown = (text: string): string => {
        return text
          .replace(/\*\*(.*?)\*\*/g, '$1') // Remove bold
          .replace(/\*(.*?)\*/g, '$1') // Remove italic
          .replace(/#{1,6}\s+/g, '') // Remove headers
          .replace(/`{1,3}(.*?)`{1,3}/g, '$1') // Remove code
          .replace(/\|/g, ' ') // Remove table separators
          .replace(/^\s*[-*+]\s+/gm, '• ') // Convert bullets
          .replace(/^\s*\d+\.\s+/gm, (match) => match) // Keep numbered lists
          .replace(/\[([^\]]+)\]\([^)]+\)/g, '$1') // Convert links to text
          .replace(/\n{3,}/g, '\n\n') // Normalize line breaks
          .trim();
      };

      const cleanText = stripMarkdown(content);
      await navigator.clipboard.writeText(cleanText);
      console.log('Clean text copied to clipboard');
    } catch (err) {
      console.error('Failed to copy message:', err);
      // Fallback for older browsers
      const textArea = document.createElement('textarea');
      const cleanText = content
        .replace(/\*\*(.*?)\*\*/g, '$1')
        .replace(/\*(.*?)\*/g, '$1')
        .replace(/#{1,6}\s+/g, '')
        .replace(/`{1,3}(.*?)`{1,3}/g, '$1')
        .replace(/\|/g, ' ')
        .replace(/^\s*[-*+]\s+/gm, '• ')
        .trim();
      textArea.value = cleanText;
      document.body.appendChild(textArea);
      textArea.select();
      document.execCommand('copy');
      document.body.removeChild(textArea);
    }
  };

  const handleDownloadMessage = async (content: string, messageId?: string) => {
    try {
      // Import Table classes for table support
      const { Table, TableRow, TableCell, WidthType } = await import('docx');
      
      // Enhanced content processing for better Word document formatting
      const processContent = (text: string) => {
        const children: any[] = [];
        const lines = text.split('\n');
        let currentParagraph: string[] = [];
        let inCodeBlock = false;
        let codeBlockContent: string[] = [];
        let inTable = false;
        let tableRows: string[][] = [];
        
        for (let i = 0; i < lines.length; i++) {
          const line = lines[i];
          
          // Handle table rows
          if (line.trim().startsWith('|') && line.trim().endsWith('|')) {
            if (!inTable) {
              // Start of table - finish any current paragraph
              if (currentParagraph.length > 0) {
                children.push(createFormattedParagraph(currentParagraph.join(' ')));
                currentParagraph = [];
              }
              inTable = true;
              tableRows = [];
            }
            
            // Parse table row
            const cells = line.split('|').map(cell => cell.trim()).filter(cell => cell !== '');
            if (cells.length > 0 && !cells.every(cell => cell.match(/^-+$/))) {
              // Skip separator rows (like |------|-------|)
              tableRows.push(cells);
            }
            continue;
          } else if (inTable) {
            // End of table
            if (tableRows.length > 0) {
              children.push(createTable(tableRows));
            }
            inTable = false;
            tableRows = [];
          }
          
          // Handle code blocks
          if (line.trim().startsWith('```')) {
            if (inCodeBlock) {
              // End of code block
              if (codeBlockContent.length > 0) {
                children.push(new Paragraph({
                  children: [new TextRun({
                    text: codeBlockContent.join('\n'),
                    font: 'Courier New',
                    size: 20,
                    color: '333333'
                  })],
                  spacing: { before: 200, after: 200 },
                  shading: {
                    fill: 'F5F5F5'
                  }
                }));
              }
              codeBlockContent = [];
              inCodeBlock = false;
            } else {
              // Start of code block
              if (currentParagraph.length > 0) {
                children.push(createFormattedParagraph(currentParagraph.join(' ')));
                currentParagraph = [];
              }
              inCodeBlock = true;
            }
            continue;
          }
          
          if (inCodeBlock) {
            codeBlockContent.push(line);
            continue;
          }
          
          // Handle headers
          const headerMatch = line.match(/^(#{1,6})\s+(.+)$/);
          if (headerMatch) {
            if (currentParagraph.length > 0) {
              children.push(createFormattedParagraph(currentParagraph.join(' ')));
              currentParagraph = [];
            }
            
            const level = headerMatch[1].length;
            const headingLevel = level === 1 ? HeadingLevel.HEADING_1 :
                               level === 2 ? HeadingLevel.HEADING_2 :
                               level === 3 ? HeadingLevel.HEADING_3 :
                               level === 4 ? HeadingLevel.HEADING_4 :
                               level === 5 ? HeadingLevel.HEADING_5 : HeadingLevel.HEADING_6;
            
            children.push(new Paragraph({
              children: [new TextRun({
                text: headerMatch[2],
                bold: true,
                size: level === 1 ? 32 : level === 2 ? 28 : level === 3 ? 24 : 22,
                color: '000000' // Changed to black
              })],
              heading: headingLevel,
              spacing: { before: 400, after: 200 }
            }));
            continue;
          }
          
          // Special handling for TABLE OF CONTENTS
          if (line.trim() === 'TABLE OF CONTENTS') {
            if (currentParagraph.length > 0) {
              children.push(createFormattedParagraph(currentParagraph.join(' ')));
              currentParagraph = [];
            }
            
            children.push(new Paragraph({
              children: [new TextRun({
                text: 'TABLE OF CONTENTS',
                bold: true,
                size: 28,
                color: '000000'
              })],
              spacing: { before: 400, after: 300 },
              alignment: 'center'
            }));
            
            // Look ahead to process TOC entries that might be on the same line or following lines
            let j = i + 1;
            let tocContent = '';
            
            // Check if TOC content is on the same line (after TABLE OF CONTENTS)
            const remainingLine = line.replace('TABLE OF CONTENTS', '').trim();
            if (remainingLine) {
              tocContent = remainingLine;
            }
            
            // Collect TOC content from following lines until we hit an empty line or new section
            while (j < lines.length) {
              const nextLine = lines[j].trim();
              if (nextLine === '' || nextLine.match(/^#{1,6}\s+/)) {
                break;
              }
              tocContent += ' ' + nextLine;
              j++;
            }
            
            // Process TOC content
            if (tocContent) {
              // Split TOC entries and format them properly
              const tocEntries = tocContent.split(/(?=\d+\.)/);
              
              for (const entry of tocEntries) {
                const cleanEntry = entry.replace(/\*\*/g, '').trim();
                if (cleanEntry) {
                  const indentLevel = (cleanEntry.match(/^\d+\.\d+/) ? 720 : cleanEntry.match(/^\d+\./) ? 360 : 0);
                  
                  children.push(new Paragraph({
                    children: [new TextRun({
                      text: cleanEntry,
                      size: 22,
                      color: '000000'
                    })],
                    spacing: { after: 100 },
                    indent: { left: indentLevel }
                  }));
                }
              }
            }
            
            // Skip the processed lines
            i = j - 1;
            continue;
          }
          
          // Handle bullet points
          const bulletMatch = line.match(/^\s*[-*+•]\s+(.+)$/);
          if (bulletMatch) {
            if (currentParagraph.length > 0) {
              children.push(createFormattedParagraph(currentParagraph.join(' ')));
              currentParagraph = [];
            }
            
            children.push(new Paragraph({
              children: createFormattedTextRuns(`• ${bulletMatch[1]}`),
              spacing: { after: 100 },
              indent: { left: 360 }
            }));
            continue;
          }
          
          // Handle numbered lists
          const numberedMatch = line.match(/^\s*(\d+)\.\s+(.+)$/);
          if (numberedMatch) {
            if (currentParagraph.length > 0) {
              children.push(createFormattedParagraph(currentParagraph.join(' ')));
              currentParagraph = [];
            }
            
            children.push(new Paragraph({
              children: createFormattedTextRuns(`${numberedMatch[1]}. ${numberedMatch[2]}`),
              spacing: { after: 100 },
              indent: { left: 360 }
            }));
            continue;
          }
          
          // Handle empty lines (paragraph breaks)
          if (line.trim() === '') {
            if (currentParagraph.length > 0) {
              children.push(createFormattedParagraph(currentParagraph.join(' ')));
              currentParagraph = [];
            }
            continue;
          }
          
          // Regular text line
          currentParagraph.push(line.trim());
        }
        
        // Handle any remaining table
        if (inTable && tableRows.length > 0) {
          children.push(createTable(tableRows));
        }
        
        // Add any remaining paragraph
        if (currentParagraph.length > 0) {
          children.push(createFormattedParagraph(currentParagraph.join(' ')));
        }
        
        // Add any remaining code block
        if (codeBlockContent.length > 0) {
          children.push(new Paragraph({
            children: [new TextRun({
              text: codeBlockContent.join('\n'),
              font: 'Courier New',
              size: 20,
              color: '333333'
            })],
            spacing: { before: 200, after: 200 },
            shading: {
              fill: 'F5F5F5'
            }
          }));
        }
        
        return children;
      };

      // Create formatted text runs with bold/italic support
      const createFormattedTextRuns = (text: string): TextRun[] => {
        const runs: TextRun[] = [];
        let remainingText = text;
        
        // Process bold text (**text**)
        const boldRegex = /\*\*(.*?)\*\*/g;
        let lastIndex = 0;
        let match;
        
        while ((match = boldRegex.exec(text)) !== null) {
          // Add text before bold
          if (match.index > lastIndex) {
            const beforeText = text.substring(lastIndex, match.index);
            if (beforeText) {
              runs.push(...processItalicText(beforeText));
            }
          }
          
          // Add bold text
          runs.push(new TextRun({
            text: match[1],
            bold: true,
            size: 22
          }));
          
          lastIndex = match.index + match[0].length;
        }
        
        // Add remaining text
        if (lastIndex < text.length) {
          const remainingText = text.substring(lastIndex);
          if (remainingText) {
            runs.push(...processItalicText(remainingText));
          }
        }
        
        return runs.length > 0 ? runs : [new TextRun({ text, size: 22 })];
      };

      // Process italic text (*text*)
      const processItalicText = (text: string): TextRun[] => {
        const runs: TextRun[] = [];
        const italicRegex = /\*(.*?)\*/g;
        let lastIndex = 0;
        let match;
        
        while ((match = italicRegex.exec(text)) !== null) {
          // Add text before italic
          if (match.index > lastIndex) {
            const beforeText = text.substring(lastIndex, match.index);
            if (beforeText) {
              runs.push(new TextRun({ text: beforeText, size: 22 }));
            }
          }
          
          // Add italic text
          runs.push(new TextRun({
            text: match[1],
            italics: true,
            size: 22
          }));
          
          lastIndex = match.index + match[0].length;
        }
        
        // Add remaining text
        if (lastIndex < text.length) {
          const remainingText = text.substring(lastIndex);
          if (remainingText) {
            runs.push(new TextRun({ text: remainingText, size: 22 }));
          }
        }
        
        return runs.length > 0 ? runs : [new TextRun({ text, size: 22 })];
      };

      // Create formatted paragraph
      const createFormattedParagraph = (text: string) => {
        return new Paragraph({
          children: createFormattedTextRuns(text),
          spacing: { after: 200 }
        });
      };

      // Create table from rows
      const createTable = (rows: string[][]) => {
        if (rows.length === 0) return null;
        
        const tableRows = rows.map((row, rowIndex) => {
          return new TableRow({
            children: row.map(cell => 
              new TableCell({
                children: [new Paragraph({
                  children: createFormattedTextRuns(cell),
                  spacing: { after: 0 }
                })],
                shading: rowIndex === 0 ? { fill: 'E8F5E8' } : undefined,
                margins: {
                  top: 100,
                  bottom: 100,
                  left: 100,
                  right: 100
                }
              })
            )
          });
        });
        
        return new Table({
          rows: tableRows,
          width: {
            size: 100,
            type: WidthType.PERCENTAGE
          },
          borders: {
            top: { style: 'single', size: 1, color: '000000' },
            bottom: { style: 'single', size: 1, color: '000000' },
            left: { style: 'single', size: 1, color: '000000' },
            right: { style: 'single', size: 1, color: '000000' },
            insideHorizontal: { style: 'single', size: 1, color: '000000' },
            insideVertical: { style: 'single', size: 1, color: '000000' }
          }
        });
      };

      // Create Word document with enhanced formatting
      const doc = new Document({
        sections: [{
          properties: {
            page: {
              margin: {
                top: 1440,    // 1 inch
                right: 1440,  // 1 inch
                bottom: 1440, // 1 inch
                left: 1440,   // 1 inch
              },
            },
          },
          children: [
            new Paragraph({
              children: [new TextRun({
                text: "Redington AI Response",
                bold: true,
                size: 36,
                color: '000000' // Changed to black
              })],
              spacing: { after: 400 },
              alignment: 'center'
            }),
            new Paragraph({
              children: [new TextRun({
                text: `Generated on: ${new Date().toLocaleString()}`,
                italics: true,
                size: 20,
                color: '666666'
              })],
              spacing: { after: 600 },
              alignment: 'center'
            }),
            new Paragraph({
              children: [new TextRun({
                text: "─".repeat(50),
                color: '000000' // Changed to black
              })],
              spacing: { after: 400 },
              alignment: 'center'
            }),
            ...processContent(content)
          ]
        }]
      });

      // Generate and download the document
      const blob = await Packer.toBlob(doc);
      const timestamp = new Date().toISOString().replace(/[:.]/g, '-').slice(0, 19);
      const fileName = `Redington_AI_Response_${timestamp}.docx`;
      saveAs(blob, fileName);
      
      console.log('Message downloaded as Word document:', fileName);
    } catch (err) {
      console.error('Failed to download message:', err);
      alert('Failed to download the document. Please try again.');
    }
  };

  const handleDownloadConversation = async () => {
    try {
      if (messages.length === 0) {
        alert('No conversation to download.');
        return;
      }

      // Import Table classes for table support
      const { Table, TableRow, TableCell, WidthType } = await import('docx');

      // Helper function to create formatted text runs (same as in handleDownloadMessage)
      const createFormattedTextRuns = (text: string): TextRun[] => {
        const runs: TextRun[] = [];
        
        // Process bold text (**text**)
        const boldRegex = /\*\*(.*?)\*\*/g;
        let lastIndex = 0;
        let match;
        
        while ((match = boldRegex.exec(text)) !== null) {
          // Add text before bold
          if (match.index > lastIndex) {
            const beforeText = text.substring(lastIndex, match.index);
            if (beforeText) {
              runs.push(...processItalicText(beforeText));
            }
          }
          
          // Add bold text
          runs.push(new TextRun({
            text: match[1],
            bold: true,
            size: 22
          }));
          
          lastIndex = match.index + match[0].length;
        }
        
        // Add remaining text
        if (lastIndex < text.length) {
          const remainingText = text.substring(lastIndex);
          if (remainingText) {
            runs.push(...processItalicText(remainingText));
          }
        }
        
        return runs.length > 0 ? runs : [new TextRun({ text, size: 22 })];
      };

      // Process italic text (*text*)
      const processItalicText = (text: string): TextRun[] => {
        const runs: TextRun[] = [];
        const italicRegex = /\*(.*?)\*/g;
        let lastIndex = 0;
        let match;
        
        while ((match = italicRegex.exec(text)) !== null) {
          // Add text before italic
          if (match.index > lastIndex) {
            const beforeText = text.substring(lastIndex, match.index);
            if (beforeText) {
              runs.push(new TextRun({ text: beforeText, size: 22 }));
            }
          }
          
          // Add italic text
          runs.push(new TextRun({
            text: match[1],
            italics: true,
            size: 22
          }));
          
          lastIndex = match.index + match[0].length;
        }
        
        // Add remaining text
        if (lastIndex < text.length) {
          const remainingText = text.substring(lastIndex);
          if (remainingText) {
            runs.push(new TextRun({ text: remainingText, size: 22 }));
          }
        }
        
        return runs.length > 0 ? runs : [new TextRun({ text, size: 22 })];
      };

      // Create Word document with entire conversation
      const doc = new Document({
        sections: [{
          properties: {
            page: {
              margin: {
                top: 1440,    // 1 inch
                right: 1440,  // 1 inch
                bottom: 1440, // 1 inch
                left: 1440,   // 1 inch
              },
            },
          },
          children: [
            new Paragraph({
              children: [new TextRun({
                text: "Redington AI Conversation",
                bold: true,
                size: 36,
                color: '000000' // Changed to black
              })],
              spacing: { after: 400 },
              alignment: 'center'
            }),
            new Paragraph({
              children: [new TextRun({
                text: `Generated on: ${new Date().toLocaleString()}`,
                italics: true,
                size: 20,
                color: '666666'
              })],
              spacing: { after: 300 },
              alignment: 'center'
            }),
            new Paragraph({
              children: [new TextRun({
                text: `Total Messages: ${messages.length}`,
                size: 20,
                color: '666666'
              })],
              spacing: { after: 600 },
              alignment: 'center'
            }),
            new Paragraph({
              children: [new TextRun({
                text: "─".repeat(50),
                color: '000000' // Changed to black
              })],
              spacing: { after: 400 },
              alignment: 'center'
            }),
            ...messages.flatMap((message, index) => [
              new Paragraph({
                children: [new TextRun({
                  text: `${message.role === 'user' ? 'User' : 'AI Assistant'}:`,
                  bold: true,
                  size: 26,
                  color: message.role === 'user' ? '2C3E50' : '00A651'
                })],
                spacing: { before: index === 0 ? 200 : 600, after: 200 }
              }),
              new Paragraph({
                children: [new TextRun({
                  text: message.timestamp ? new Date(message.timestamp).toLocaleString() : new Date().toLocaleString(),
                  italics: true,
                  size: 18,
                  color: '999999'
                })],
                spacing: { after: 300 }
              }),
              ...message.content.split('\n\n').filter(p => p.trim()).map(paragraph => 
                new Paragraph({
                  children: createFormattedTextRuns(paragraph.trim()),
                  spacing: { after: 200 },
                  indent: { left: 360 }
                })
              ),
              new Paragraph({
                children: [new TextRun({
                  text: "─".repeat(30),
                  color: 'CCCCCC'
                })],
                spacing: { before: 200, after: 200 },
                alignment: 'center'
              })
            ])
          ]
        }]
      });

      // Generate and download the document
      const blob = await Packer.toBlob(doc);
      const timestamp = new Date().toISOString().replace(/[:.]/g, '-').slice(0, 19);
      const fileName = `Redington_AI_Conversation_${timestamp}.docx`;
      saveAs(blob, fileName);
      
      console.log('Conversation downloaded as Word document:', fileName);
    } catch (err) {
      console.error('Failed to download conversation:', err);
      alert('Failed to download the conversation. Please try again.');
    }
  };

  const handleStopGeneration = () => {
    if (streamController) {
      streamController.abort();
      setStreamController(null);
      setIsStreaming(false);
      setStreamingMessageId(null);
      setIsTyping(false);
      setLoading(false);
    }
  };

  // const updateConversationList = (convId: string, userMsg: string, aiResponse: string) => {
  //   // Function removed as it's not being used
  // };

  const startNewConversation = async () => {
    setMessages([]);
    setInputMessage(''); // Clear input
    setConversationId(''); // Clear conversation ID to create new one
    setShowWelcome(true);
    setSidebarOpen(false);
    localStorage.removeItem('currentConversationId'); // Clear saved conversation
    
    // Generate new conversation ID (which will create a backend session)
    if (user?.username) {
      await generateConversationId();
    }
  };

  // const clearAllConversations = () => {
  //   // Function removed as it's not being used
  // };

  const deleteConversation = async (chatId: string) => {
    try {
      await sessionsService.deleteSession(chatId);
      
      // Remove from local state
      setConversations(prev => prev.filter(conv => conv.id !== chatId));
      
      // If this was the current conversation, start a new one
      if (conversationId === chatId) {
        startNewConversation();
      }
    } catch (error) {
      console.error('Error deleting conversation:', error);
      setError('Failed to delete conversation');
    }
  };

  const startEditingTitle = (conversation: Conversation) => {
    setEditingConversationId(conversation.id);
    setEditingTitle(conversation.title);
  };

  const cancelEditingTitle = () => {
    setEditingConversationId(null);
    setEditingTitle('');
  };

  const saveEditedTitle = async (chatId: string) => {
    if (!editingTitle.trim()) {
      cancelEditingTitle();
      return;
    }

    try {
      await sessionsService.updateSessionTitle(chatId, editingTitle.trim());
      
      // Update local state
      setConversations(prev => 
        prev.map(conv => 
          conv.id === chatId 
            ? { ...conv, title: editingTitle.trim() }
            : conv
        )
      );
      
      cancelEditingTitle();
    } catch (error) {
      console.error('Error updating conversation title:', error);
      setError('Failed to update conversation title');
      cancelEditingTitle();
    }
  };

  const handleTitleKeyPress = (e: React.KeyboardEvent, chatId: string) => {
    if (e.key === 'Enter') {
      saveEditedTitle(chatId);
    } else if (e.key === 'Escape') {
      cancelEditingTitle();
    }
  };

  const loadConversation = async (conversation: Conversation) => {
    try {
      // Load messages from DynamoDB
      const sessionMessages = await sessionsService.getSessionMessages(conversation.id);
      
      // Convert to ChatMessage format
      const chatMessages: ChatMessage[] = sessionMessages.map((msg: SessionMessage) => ({
        role: msg.role as 'user' | 'assistant',
        content: msg.content,
        timestamp: new Date(msg.timestamp).toISOString(),
        message_id: msg.message_id,
      }));
      
      // Update conversation timestamp with the latest message timestamp
      if (sessionMessages.length > 0) {
        const latestMessage = sessionMessages[sessionMessages.length - 1];
        const updatedConversations = conversations.map(conv => 
          conv.id === conversation.id 
            ? { ...conv, timestamp: new Date(latestMessage.timestamp).toISOString(), messageCount: sessionMessages.length }
            : conv
        );
        setConversations(updatedConversations);
      }
      
      setMessages(chatMessages);
      setConversationId(conversation.id);
      setSidebarOpen(false);
      setShowWelcome(false);
    } catch (error) {
      console.error('Error loading conversation:', error);
      setError('Failed to load conversation');
    }
  };

  const getModelIcon = (modelName: string) => {
    if (modelName.includes('Reasoning') || modelName.includes('Thinking')) {
      return <ThinkingIcon sx={{ color: redingtonTheme.accent }} />;
    }
    if (modelName.includes('Speed') || modelName.includes('Fast')) {
      return <SpeedIcon sx={{ color: redingtonTheme.success }} />;
    }
    return <BotIcon sx={{ color: redingtonTheme.primary }} />;
  };

  const handleLogout = async () => {
    try {
      await logout();
      setUserMenuAnchorEl(null);
      // The app will redirect to login automatically via the AuthProvider
    } catch (error) {
      console.error('Logout failed:', error);
    }
  };

  const handleUserMenuOpen = (event: React.MouseEvent<HTMLElement>) => {
    setUserMenuAnchorEl(event.currentTarget);
  };

  const handleUserMenuClose = () => {
    setUserMenuAnchorEl(null);
  };

  const getUserInitials = (username: string) => {
    return username.charAt(0).toUpperCase();
  };

  const handleKeyPress = (e: React.KeyboardEvent) => {
    if (e.key === 'Enter' && !e.shiftKey) {
      e.preventDefault();
      if (inputMessage.trim() || uploadedFiles.length > 0) {
        handleSendMessage();
      }
    }
  };

  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const value = e.target.value;
    setInputMessage(value);
    
    // Hide welcome screen when user starts typing
    if (value.trim() && showWelcome) {
      setShowWelcome(false);
    }
    // Show welcome screen again if input is cleared and no messages
    if (!value.trim() && messages.length === 0 && !showWelcome) {
      setShowWelcome(true);
    }
  };

  const WelcomeScreen = () => (
    <Fade in={showWelcome}>
      <Box
        sx={{
          display: 'flex',
          flexDirection: 'column',
          alignItems: 'center',
          justifyContent: 'center',
          minHeight: '60vh',
          textAlign: 'center',
          px: 2,
          width: '100%',
          maxWidth: '100%',
        }}
      >
        <Box sx={{ display: 'flex', alignItems: 'center', justifyContent: 'center', gap: 2, mb: 2, width: '100%' }}>
          <img 
            src="/redington-logo.png" 
            alt="Redington Logo" 
            style={{ 
              height: '48px', 
              width: 'auto',
              objectFit: 'contain'
            }} 
          />
          <Typography
            variant="h3"
            sx={{
              fontWeight: 700,
              background: 'linear-gradient(135deg, #00A651 0%, #66CC99 100%)',
              backgroundClip: 'text',
              WebkitBackgroundClip: 'text',
              WebkitTextFillColor: 'transparent',
            }}
          >
            Redington AI
          </Typography>
        </Box>
        <Typography
          variant="h6"
          sx={{ color: redingtonTheme.textSecondary, mb: 4, maxWidth: '100%', width: '100%' }}
        >
          Your intelligent partner for cloud solutions, technology distribution, and IT infrastructure.
        </Typography>
        
        <Box sx={{ width: '100%', maxWidth: '1200px', mb: 4 }}>
          <Stack 
            direction={{ xs: 'column', md: 'row' }} 
            spacing={2} 
            sx={{ 
              justifyContent: 'center',
              alignItems: 'stretch',
              width: '100%'
            }}
          >
            <Card sx={{ p: 3, flex: 1, textAlign: 'center', minHeight: '140px' }}>
              <LightbulbIcon sx={{ color: '#00A651', fontSize: 40, mb: 1 }} />
              <Typography variant="h6" sx={{ fontWeight: 600, mb: 1 }}>Cloud Solutions</Typography>
              <Typography variant="body2" color="textSecondary">
                Expert guidance on cloud migration, hybrid solutions, and digital transformation
              </Typography>
            </Card>
            
            <Card sx={{ p: 3, flex: 1, textAlign: 'center', minHeight: '140px' }}>
              <CodeIcon sx={{ color: '#66CC99', fontSize: 40, mb: 1 }} />
              <Typography variant="h6" sx={{ fontWeight: 600, mb: 1 }}>Technology Distribution</Typography>
              <Typography variant="body2" color="textSecondary">
                Product recommendations, technical specifications, and solution architecture
              </Typography>
            </Card>
            
            <Card sx={{ p: 3, flex: 1, textAlign: 'center', minHeight: '140px' }}>
              <DocumentIcon sx={{ color: '#00A651', fontSize: 40, mb: 1 }} />
              <Typography variant="h6" sx={{ fontWeight: 600, mb: 1 }}>Proposal Generation</Typography>
              <Typography variant="body2" color="textSecondary">
                Create professional proposals, BOQs, and technical documentation
              </Typography>
            </Card>
          </Stack>
        </Box>

        <Typography variant="body1" sx={{ color: redingtonTheme.textSecondary, mb: 2, width: '100%' }}>
          Start a conversation below or try these examples:
        </Typography>
        
        <Box sx={{ width: '100%', maxWidth: '1000px' }}>
          <Stack 
            direction="row" 
            spacing={1} 
            sx={{ 
              flexWrap: 'wrap', 
              justifyContent: 'center',
              '& > *': { mb: 1 }
            }}
          >
          {[
            "What are Redington's latest cloud solutions?",
            "Help me design a hybrid cloud architecture",
            "Compare enterprise storage solutions",
            "Explain digital transformation strategies",
            "What are the best cybersecurity practices?",
            "Help me create a technology proposal"
          ].map((example, index) => (
            <Chip
              key={index}
              label={example}
              onClick={() => {
                setInputMessage(example);
                setShowWelcome(false);
              }}
              sx={{
                m: 0.5,
                '&:hover': {
                  backgroundColor: "#F5F5F5",
                  color: 'white',
                },
              }}
            />
          ))}
          </Stack>
        </Box>
      </Box>
    </Fade>
  );

  return (
    <Box 
      sx={{ display: 'flex', height: '100vh', backgroundColor: redingtonTheme.background, position: 'relative' }}
    >
      {/* Sidebar */}
      <Drawer
        variant="temporary"
        anchor="left"
        open={sidebarOpen}
        onClose={() => setSidebarOpen(false)}
        sx={{
          '& .MuiDrawer-paper': {
            width: 320,
            background: redingtonTheme.darkGradient,
            color: 'white',
          },
        }}
      >
        <Box sx={{ p: 2 }}>
          <Box sx={{ display: 'flex', alignItems: 'center', mb: 3 }}>
            <Box>
              <Typography variant="h6" sx={{ fontWeight: 700, lineHeight: 1.2 }}>
                Redington AI
              </Typography>
              <Typography variant="caption" sx={{ opacity: 0.8, fontSize: '11px' }}>
                Presales Proposal Generator
              </Typography>
            </Box>
          </Box>
          
          <Box sx={{ display: 'flex', gap: 1, mb: 3 }}>
            <Button
              fullWidth
              variant="contained"
              startIcon={<AddIcon />}
              onClick={startNewConversation}
              sx={{
                background: redingtonTheme.gradient,
                '&:hover': { opacity: 0.9 },
              }}
            >
              New Chat
            </Button>
            <IconButton
              onClick={loadConversationHistory}
              disabled={sessionsLoading}
              sx={{
                color: 'white',
                border: '1px solid rgba(255,255,255,0.3)',
                '&:hover': { backgroundColor: 'rgba(255,255,255,0.1)' },
              }}
              title="Refresh conversations"
            >
              {sessionsLoading ? <CircularProgress size={20} sx={{ color: 'white' }} /> : <RefreshIcon />}
            </IconButton>
          </Box>
        </Box>

        <Divider sx={{ borderColor: 'rgba(255,255,255,0.1)' }} />



        <List sx={{ flex: 1, px: 1 }}>
          {(() => {
            console.log('🎨 Rendering List component');
            console.log('🎨 sessionsLoading:', sessionsLoading);
            console.log('🎨 conversations.length:', conversations.length);
            console.log('🎨 conversations:', conversations);
            
            if (sessionsLoading) {
              console.log('🎨 Rendering loading spinner');
              return (
                <Box sx={{ display: 'flex', justifyContent: 'center', py: 4 }}>
                  <CircularProgress size={24} sx={{ color: 'rgba(255,255,255,0.7)' }} />
                </Box>
              );
            } else if (conversations.length === 0) {
              console.log('🎨 Rendering empty state');
              return (
                <Box sx={{ textAlign: 'center', py: 4, px: 2 }}>
                  <Typography variant="body2" sx={{ color: 'rgba(255,255,255,0.6)', mb: 2 }}>
                    No chat sessions found
                  </Typography>
                  <Typography variant="caption" sx={{ color: 'rgba(255,255,255,0.4)' }}>
                    Start a new conversation to begin chatting
                  </Typography>
                </Box>
              );
            } else {
              const conversationsWithMessages = conversations.filter(conv => conv.messageCount > 0);
              console.log('🎨 Rendering conversations list with', conversationsWithMessages.length, 'items');
              return conversationsWithMessages.map((conversation, index) => {
                console.log('🎨 Rendering conversation', index, ':', conversation.title);
                const isEditing = editingConversationId === conversation.id;
                
                return (
            <ListItem
              key={conversation.id}
              sx={{
                borderRadius: 2,
                mb: 1,
                backgroundColor: conversationId === conversation.id ? 'rgba(0, 166, 81, 0.2)' : 'transparent',
                border: conversationId === conversation.id ? '1px solid rgba(0, 166, 81, 0.4)' : '1px solid transparent',
                '&:hover': { 
                  backgroundColor: conversationId === conversation.id 
                    ? 'rgba(0, 166, 81, 0.25)' 
                    : 'rgba(255,255,255,0.1)' 
                },
                display: 'flex',
                alignItems: 'flex-start',
                transition: 'all 0.2s ease-in-out',
              }}
            >
              <ListItemIcon>
                {conversationId === conversation.id ? (
                  <BotIcon sx={{ color: redingtonTheme.primary }} />
                ) : (
                  <HistoryIcon sx={{ color: 'rgba(255,255,255,0.7)' }} />
                )}
              </ListItemIcon>
              
              {isEditing ? (
                <Box sx={{ flex: 1, mr: 1 }}>
                  <TextField
                    value={editingTitle}
                    onChange={(e) => setEditingTitle(e.target.value)}
                    onKeyDown={(e) => handleTitleKeyPress(e, conversation.id)}
                    onBlur={() => saveEditedTitle(conversation.id)}
                    autoFocus
                    fullWidth
                    size="small"
                    variant="outlined"
                    sx={{
                      '& .MuiOutlinedInput-root': {
                        color: 'white',
                        '& fieldset': {
                          borderColor: 'rgba(255,255,255,0.3)',
                        },
                        '&:hover fieldset': {
                          borderColor: 'rgba(255,255,255,0.5)',
                        },
                        '&.Mui-focused fieldset': {
                          borderColor: "#BDBDBD",
                        },
                      },
                    }}
                  />
                </Box>
              ) : (
                <ListItemText
                  onClick={() => loadConversation(conversation)}
                  sx={{ cursor: 'pointer', flex: 1 }}
                  primary={conversation.title}
                  secondary={
                    <Box>
                      <Typography variant="caption" sx={{ color: 'rgba(255,255,255,0.7)' }}>
                        {conversation.lastMessage}
                      </Typography>
                      <Box sx={{ display: 'flex', justifyContent: 'space-between', mt: 0.5 }}>
                        <Typography variant="caption" sx={{ color: 'rgba(255,255,255,0.5)' }}>
                          {getRelativeTime(conversation.timestamp)}
                        </Typography>
                        <Badge badgeContent={conversation.messageCount} color="primary" />
                      </Box>
                    </Box>
                  }
                />
              )}
              
              <Box sx={{ display: 'flex', gap: 0.5 }}>
                {isEditing ? (
                  <>
                    <IconButton
                      size="small"
                      onClick={() => saveEditedTitle(conversation.id)}
                      sx={{ 
                        color: 'rgba(255,255,255,0.7)',
                        '&:hover': { 
                          color: "#757575",
                          backgroundColor: 'rgba(255,255,255,0.1)' 
                        }
                      }}
                    >
                      <CheckIcon fontSize="small" />
                    </IconButton>
                    <IconButton
                      size="small"
                      onClick={cancelEditingTitle}
                      sx={{ 
                        color: 'rgba(255,255,255,0.5)',
                        '&:hover': { 
                          color: 'rgba(255,255,255,0.8)',
                          backgroundColor: 'rgba(255,255,255,0.1)' 
                        }
                      }}
                    >
                      <CloseIcon fontSize="small" />
                    </IconButton>
                  </>
                ) : (
                  <>
                    <IconButton
                      size="small"
                      onClick={(e) => {
                        e.stopPropagation();
                        startEditingTitle(conversation);
                      }}
                      sx={{ 
                        color: 'rgba(255,255,255,0.5)',
                        '&:hover': { 
                          color: "#757575",
                          backgroundColor: 'rgba(255,255,255,0.1)' 
                        }
                      }}
                    >
                      <EditIcon fontSize="small" />
                    </IconButton>
                    <IconButton
                      size="small"
                      onClick={(e) => {
                        e.stopPropagation();
                        deleteConversation(conversation.id);
                      }}
                      sx={{ 
                        color: 'rgba(255,255,255,0.5)',
                        '&:hover': { 
                          color: redingtonTheme.error,
                          backgroundColor: 'rgba(255,255,255,0.1)' 
                        }
                      }}
                    >
                      <DeleteIcon fontSize="small" />
                    </IconButton>
                  </>
                )}
              </Box>
            </ListItem>
                );
              });
            }
          })()}
        </List>
      </Drawer>

      {/* Main Content */}
      <Box sx={{ flex: 1, display: 'flex', flexDirection: 'column' }}>
        {/* Header */}
        <Paper
          elevation={1}
          sx={{
            p: 2,
            background: 'transparent',
            borderBottom: `1px solid ${redingtonTheme.background}`,
          }}
        >
          <Box sx={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between' }}>
            <Box sx={{ display: 'flex', alignItems: 'center' }}>
              <IconButton onClick={handleOpenSidebar} sx={{ mr: 1 }}>
                <MenuIcon />
              </IconButton>
              
              <Box sx={{ display: 'flex', alignItems: 'center' }}>
                <Box>
                  <Box sx={{ display: 'flex', alignItems: 'center', gap: 1.5 }}>
                    <img 
                      src="/redington-logo.png" 
                      alt="Redington Logo" 
                      style={{ 
                        height: '32px', 
                        width: 'auto',
                        objectFit: 'contain'
                      }} 
                    />
                  </Box>
                  <Typography variant="caption" sx={{ color: redingtonTheme.textSecondary }}>
                    Presales Proposal Generator
                  </Typography>
                </Box>
              </Box>
            </Box>

            <Box sx={{ display: 'flex', alignItems: 'center', gap: 1 }}>
              {/* AI Assistant Role Dropdown */}
              <FormControl size="small" sx={{ minWidth: 140 }}>
                <Select
                  value={selectedRole}
                  onChange={(e) => setSelectedRole(e.target.value as 'presales' | 'custom')}
                  displayEmpty
                  sx={{
                    height: 36,
                    '& .MuiOutlinedInput-notchedOutline': {
                      borderColor: 'rgba(0,0,0,0.23)',
                    },
                    '&:hover .MuiOutlinedInput-notchedOutline': {
                      borderColor: "#BDBDBD",
                    },
                    '&.Mui-focused .MuiOutlinedInput-notchedOutline': {
                      borderColor: "#BDBDBD",
                    },
                  }}
                >
                  <MenuItem value="presales">
                    <Box sx={{ display: 'flex', alignItems: 'center', gap: 1 }}>
                      <Typography variant="body2" sx={{ fontWeight: 500 }}>
                        Presales Expert
                      </Typography>
                    </Box>
                  </MenuItem>
                  <MenuItem value="custom">
                    <Box sx={{ display: 'flex', alignItems: 'center', gap: 1 }}>
                      <Typography variant="body2" sx={{ fontWeight: 500 }}>
                        Custom Role
                      </Typography>
                    </Box>
                  </MenuItem>
                </Select>
              </FormControl>

              {/* New Chat Button */}
              <Button
                variant="contained"
                startIcon={<AddIcon />}
                onClick={startNewConversation}
                size="small"
                sx={{
                  background: redingtonTheme.gradient,
                  color: 'white',
                  fontWeight: 600,
                  px: 2,
                  py: 1,
                  borderRadius: 2,
                  textTransform: 'none',
                  '&:hover': { 
                    opacity: 0.9,
                    transform: 'translateY(-1px)',
                    boxShadow: '0 4px 12px rgba(0, 166, 81, 0.3)'
                  },
                  transition: 'all 0.2s ease-in-out'
                }}
              >
                New Chat
              </Button>

              <IconButton onClick={() => setSettingsOpen(true)}>
                <SettingsIcon />
              </IconButton>

              {/* User Authentication Controls */}
              <Tooltip title={`Logged in as ${user?.username || 'User'}`}>
                <IconButton onClick={handleUserMenuOpen} sx={{ ml: 1 }}>
                  <Avatar
                    sx={{
                      width: 36,
                      height: 36,
                      background: redingtonTheme.gradient,
                      fontSize: '1rem',
                      fontWeight: 700,
                      border: `2px solid ${redingtonTheme.surface}`,
                      boxShadow: '0 2px 8px rgba(0,0,0,0.1)',
                      '&:hover': {
                        transform: 'scale(1.05)',
                        transition: 'transform 0.2s ease',
                      },
                    }}
                  >
                    {user?.username ? getUserInitials(user.username) : <AccountCircleIcon />}
                  </Avatar>
                </IconButton>
              </Tooltip>

              {/* User Menu */}
              <Menu
                anchorEl={userMenuAnchorEl}
                open={Boolean(userMenuAnchorEl)}
                onClose={handleUserMenuClose}
                anchorOrigin={{
                  vertical: 'bottom',
                  horizontal: 'right',
                }}
                transformOrigin={{
                  vertical: 'top',
                  horizontal: 'right',
                }}
                PaperProps={{
                  sx: {
                    mt: 1,
                    minWidth: 220,
                    borderRadius: 3,
                    boxShadow: '0 8px 32px rgba(0,0,0,0.12)',
                    border: `1px solid ${redingtonTheme.background}`,
                  },
                }}
              >
                <Box sx={{ px: 3, py: 2, borderBottom: `1px solid ${redingtonTheme.background}` }}>
                  <Box sx={{ display: 'flex', alignItems: 'center', mb: 1 }}>
                    <Avatar
                      sx={{
                        width: 40,
                        height: 40,
                        background: redingtonTheme.gradient,
                        fontSize: '1.1rem',
                        fontWeight: 700,
                        mr: 2,
                      }}
                    >
                      {user?.username ? getUserInitials(user.username) : <AccountCircleIcon />}
                    </Avatar>
                    <Box>
                      <Typography variant="subtitle1" sx={{ fontWeight: 600, color: redingtonTheme.text }}>
                        {user?.username || 'User'}
                      </Typography>
                      <Typography variant="caption" sx={{ color: redingtonTheme.textSecondary }}>
                        {user?.email || 'Redington AI Assistant User'}
                      </Typography>
                    </Box>
                  </Box>
                </Box>
                <MenuItem 
                  onClick={handleLogout} 
                  sx={{ 
                    py: 1.5, 
                    px: 3,
                    '&:hover': {
                      backgroundColor: `${redingtonTheme.error}10`,
                    },
                  }}
                >
                  <LogoutIcon sx={{ mr: 2, color: redingtonTheme.error }} />
                  <Typography sx={{ color: redingtonTheme.error, fontWeight: 500 }}>
                    Logout
                  </Typography>
                </MenuItem>
              </Menu>
            </Box>
          </Box>
        </Paper>

        {/* Messages Area */}
        <Box
          onDragOver={handleDragOver}
          onDragLeave={handleDragLeave}
          onDrop={handleDrop}
          sx={{
            flex: 1,
            overflow: 'auto',
            p: 2,
            background: `linear-gradient(to bottom, ${redingtonTheme.background}, #ffffff)`,
            position: 'relative',
          }}
        >
          {/* Drag overlay */}
          {isDragOver && (
            <Box
              sx={{
                position: 'absolute',
                top: 0,
                left: 0,
                right: 0,
                bottom: 0,
                zIndex: 1000,
                backgroundColor: `${redingtonTheme.primary}20`,
                border: `3px dashed ${redingtonTheme.primary}`,
                borderRadius: 2,
                display: 'flex',
                alignItems: 'center',
                justifyContent: 'center',
                flexDirection: 'column',
                pointerEvents: 'none', // Allow events to pass through
              }}
            >
              <Typography variant="h5" sx={{ color: "#757575", mb: 1, fontWeight: 'bold' }}>
                Drop files here to upload
              </Typography>
              <Typography variant="body2" sx={{ color: redingtonTheme.textSecondary }}>
                Supported: PDF, DOCX, TXT, Images (Max 10MB)
              </Typography>
            </Box>
          )}
          {showWelcome ? (
            <WelcomeScreen />
          ) : (
            <Container maxWidth="md">
              {messages.map((message, index) => (
                <Slide
                  key={message.message_id}
                  direction="up"
                  in={true}
                  timeout={300 + index * 100}
                >
                  <Box
                    sx={{
                      display: 'flex',
                      mb: 3,
                      justifyContent: message.role === 'user' ? 'flex-end' : 'flex-start',
                    }}
                  >
                    {message.role === 'assistant' && (
                      <Avatar
                        sx={{
                          background: redingtonTheme.gradient,
                          mr: 2,
                          mt: 0.5,
                        }}
                      >
                        <BotIcon />
                      </Avatar>
                    )}
                    
                    <Paper
                      elevation={0}
                      sx={{
                        p: 2,
                        maxWidth: '85%',
                        background: message.role === 'user' 
                          ? redingtonTheme.gradient 
                          : 'transparent',
                        color: message.role === 'user' ? 'white' : redingtonTheme.text,
                        borderRadius: 3,
                        boxShadow: 'none !important',
                        border: 'none !important',
                        position: 'relative',
                        // border: message.role === 'assistant' ? `1px solid ${redingtonTheme.primary}20` : undefined,
                      }}
                    >
                      <MessageRenderer 
                        content={message.content} 
                        isStreaming={message.message_id === streamingMessageId && isStreaming}
                      />
                      
                      {/* Action buttons at the end of assistant messages */}
                      {message.role === 'assistant' && (
                        <Box sx={{ 
                          display: 'flex', 
                          justifyContent: 'flex-end', 
                          alignItems: 'center',
                          gap: 1,
                          mt: 2,
                          pt: 1,
                          // borderTop: '1px solid rgba(0,0,0,0.1)'
                        }}>
                          <Tooltip title="Copy to clipboard">
                            <IconButton
                              size="small"
                              onClick={() => handleCopyMessage(message.content)}
                              sx={{
                                opacity: 0.7,
                                '&:hover': {
                                  opacity: 1,
                                  backgroundColor: 'rgba(0,0,0,0.1)',
                                },
                              }}
                            >
                              <CopyIcon fontSize="small" />
                            </IconButton>
                          </Tooltip>
                          
                          <Tooltip title="Download as Word document">
                            <IconButton
                              size="small"
                              onClick={() => handleDownloadMessage(message.content, message.message_id)}
                              sx={{
                                opacity: 0.7,
                                '&:hover': {
                                  opacity: 1,
                                  backgroundColor: 'rgba(0,0,0,0.1)',
                                },
                              }}
                            >
                              <DownloadIcon fontSize="small" />
                            </IconButton>
                          </Tooltip>
                        </Box>
                      )}
                      
                      {/* Timestamp */}
                      <Typography
                        variant="caption"
                        sx={{
                          display: 'block',
                          mt: 1,
                          opacity: 0.7,
                          textAlign: message.role === 'user' ? 'right' : 'left',
                        }}
                      >
                        {message.timestamp ? new Date(message.timestamp).toLocaleTimeString() : new Date().toLocaleTimeString()}
                      </Typography>
                    </Paper>

                    {message.role === 'user' && (
                      <Avatar
                        sx={{
                          background: redingtonTheme.textSecondary,
                          ml: 2,
                          mt: 0.5,
                        }}
                      >
                        <PersonIcon />
                      </Avatar>
                    )}
                  </Box>
                </Slide>
              ))}

              {isTyping && (
                <Box sx={{ display: 'flex', alignItems: 'center', mb: 2 }}>
                  <Avatar sx={{ background: redingtonTheme.gradient, mr: 2 }}>
                    <BotIcon />
                  </Avatar>
                  <Paper
                    elevation={1}
                    sx={{
                      p: 2,
                      background: 'transparent',
                      borderRadius: 3,
                    }}
                  >
                    <Box sx={{ display: 'flex', alignItems: 'center' }}>
                      <CircularProgress size={16} sx={{ mr: 1 }} />
                      <Typography variant="body2" sx={{ color: redingtonTheme.textSecondary }}>
                        AI is thinking...
                      </Typography>
                    </Box>
                  </Paper>
                </Box>
              )}

              <div ref={messagesEndRef} />
            </Container>
          )}
        </Box>

        {/* Input Area */}
        <Paper
          elevation={3}
          sx={{
            p: 2,
            background: 'transparent',
            borderTop: `1px solid ${redingtonTheme.background}`,
          }}
        >
          <Container maxWidth="md">
            {error && (
              <Alert severity="error" sx={{ mb: 2 }} onClose={() => setError('')}>
                {error}
              </Alert>
            )}

            {uploadedFiles.length > 0 && (
              <Box sx={{ mb: 2 }}>
                <Typography variant="caption" sx={{ color: redingtonTheme.textSecondary, mb: 1, display: 'block' }}>
                  Uploaded Files:
                </Typography>
                <Stack direction="row" spacing={1}>
                  {uploadedFiles.map((file, index) => (
                    <Chip
                      key={index}
                      label={`File ${index + 1}`}
                      onDelete={() => setUploadedFiles(prev => prev.filter((_, i) => i !== index))}
                      color="primary"
                      variant="outlined"
                    />
                  ))}
                </Stack>
              </Box>
            )}

            <Box
              sx={{
                position: 'relative',
                borderRadius: 2,
              }}
            >
              <Box sx={{ display: 'flex', alignItems: 'flex-end', gap: 1 }}>
                <TextField
                  fullWidth
                  multiline
                  maxRows={4}
                  value={inputMessage}
                  onChange={handleInputChange}
                  onKeyPress={handleKeyPress}
                  placeholder="Ask me anything about technology solutions..."
                  variant="outlined"
                  disabled={loading}
                  sx={{
                    '& .MuiOutlinedInput-root': {
                      borderRadius: 3,
                      backgroundColor: redingtonTheme.background,
                      '&:hover .MuiOutlinedInput-notchedOutline': {
                        borderColor: "#BDBDBD",
                      },
                      '&.Mui-focused .MuiOutlinedInput-notchedOutline': {
                        borderColor: "#BDBDBD",
                      },
                    },
                  }}
                />

                <Tooltip title="Attach Files">
                  <IconButton
                    onClick={() => fileInputRef.current?.click()}
                    sx={{ 
                      color: "#757575",
                      '&:hover': { backgroundColor: "#F5F5F5" },
                    }}
                  >
                    <AttachFileIcon />
                  </IconButton>
                </Tooltip>

                <Button
                  variant="contained"
                  onClick={isStreaming ? handleStopGeneration : handleSendMessage}
                  disabled={(loading && !isStreaming) || ((!inputMessage.trim() && uploadedFiles.length === 0) && !isStreaming)}
                  sx={{
                    minWidth: 60,
                    height: 56,
                    borderRadius: 3,
                    background: isStreaming ? redingtonTheme.error : redingtonTheme.gradient,
                    '&:hover': { opacity: 0.9 },
                    '&:disabled': { opacity: 0.5 },
                  }}
                >
                  {loading && !isStreaming ? (
                    <CircularProgress size={24} color="inherit" />
                  ) : isStreaming ? (
                    <StopIcon />
                  ) : (
                    <SendIcon />
                  )}
                </Button>
              </Box>
            </Box>

            {loading && (
              <LinearProgress
                sx={{
                  mt: 1,
                  borderRadius: 1,
                  '& .MuiLinearProgress-bar': {
                    background: redingtonTheme.gradient,
                  },
                }}
              />
            )}
          </Container>
        </Paper>
      </Box>

      {/* Hidden file input */}
      <input
        type="file"
        ref={fileInputRef}
        style={{ display: 'none' }}
        multiple
        accept="image/*,.pdf,.txt,.md"
        onChange={(e) => {
          const files = Array.from(e.target.files || []);
          files.forEach((file) => {
            const reader = new FileReader();
            reader.onload = () => {
              const base64 = reader.result as string;
              setUploadedFiles(prev => [...prev, base64]);
            };
            reader.readAsDataURL(file);
          });
        }}
      />

      {/* Settings Dialog */}
      <Dialog 
        open={settingsOpen} 
        onClose={() => setSettingsOpen(false)} 
        maxWidth="md" 
        fullWidth
        PaperProps={{
          sx: {
            height: '80vh',
            maxHeight: '800px'
          }
        }}
      >
        <DialogTitle>
          <Typography variant="h6">Settings & Knowledge Base</Typography>
        </DialogTitle>
        <DialogContent sx={{ p: 0 }}>
          <Box sx={{ borderBottom: 1, borderColor: 'divider' }}>
            <Tabs 
              value={settingsTab} 
              onChange={(e, newValue) => setSettingsTab(newValue)}
              aria-label="settings tabs"
            >
              <Tab label="General" />
              <Tab label="RAG Knowledge Base" />
            </Tabs>
          </Box>
          
          {settingsTab === 0 && (
            <Box sx={{ p: 3 }}>
              <Typography variant="h6" gutterBottom>General Settings</Typography>
              <Typography variant="body2" color="text.secondary" sx={{ mb: 3 }}>
                Configure your AI assistant's role and behavior.
              </Typography>
              
              {/* Role Selection */}
              <Box sx={{ mb: 4 }}>
                <Typography variant="subtitle1" gutterBottom sx={{ fontWeight: 600 }}>
                  AI Assistant Role
                </Typography>
                <FormControl fullWidth sx={{ mb: 2 }}>
                  <InputLabel>Select Role</InputLabel>
                  <Select
                    value={selectedRole}
                    label="Select Role"
                    onChange={(e) => setSelectedRole(e.target.value as 'presales' | 'custom')}
                  >
                    <MenuItem value="presales">
                      <Box>
                        <Typography variant="body1" sx={{ fontWeight: 500 }}>
                          Pre-sales Professional
                        </Typography>
                        <Typography variant="caption" color="text.secondary">
                          Expert in solution architecture, ROI analysis, and proposal generation
                        </Typography>
                      </Box>
                    </MenuItem>
                    <MenuItem value="custom">
                      <Box>
                        <Typography variant="body1" sx={{ fontWeight: 500 }}>
                          Custom Role
                        </Typography>
                        <Typography variant="caption" color="text.secondary">
                          Define your own system prompt and behavior
                        </Typography>
                      </Box>
                    </MenuItem>
                  </Select>
                </FormControl>

                {/* Pre-sales Role Description */}
                {selectedRole === 'presales' && (
                  <Paper 
                    elevation={0} 
                    sx={{ 
                      p: 2, 
                      backgroundColor: '#f8f9fa', 
                      border: '1px solid #e9ecef',
                      borderRadius: 2 
                    }}
                  >
                    <Typography variant="subtitle2" sx={{ fontWeight: 600, mb: 1, color: '#1976d2' }}>
                      Presales Proposal Generator Capabilities:
                    </Typography>
                    <Box sx={{ ml: 1 }}>
                      <Typography variant="body2" sx={{ mb: 0.5 }}>
                        • <strong>Structured Proposals:</strong> Complete proposal documents with all required sections
                      </Typography>
                      <Typography variant="body2" sx={{ mb: 0.5 }}>
                        • <strong>Professional Format:</strong> Table of contents, executive summary, scope of work
                      </Typography>
                      <Typography variant="body2" sx={{ mb: 0.5 }}>
                        • <strong>Technical Details:</strong> Architecture design, RACI matrix, project timeline
                      </Typography>
                      <Typography variant="body2" sx={{ mb: 0.5 }}>
                        • <strong>Commercial Sections:</strong> BOQ estimation, pricing placeholders, assumptions
                      </Typography>
                      <Typography variant="body2">
                        • <strong>Client Placeholders:</strong> Ready-to-customize templates with proper formatting
                      </Typography>
                    </Box>
                  </Paper>
                )}

                {/* Custom Role Input */}
                {selectedRole === 'custom' && (
                  <Box>
                    <Typography variant="subtitle2" gutterBottom sx={{ fontWeight: 600 }}>
                      Custom System Prompt
                    </Typography>
                    <Typography variant="body2" color="text.secondary" sx={{ mb: 2 }}>
                      Define how the AI should behave, its expertise, and communication style.
                    </Typography>
                    <TextField
                      fullWidth
                      multiline
                      rows={8}
                      value={customSystemPrompt}
                      onChange={(e) => setCustomSystemPrompt(e.target.value)}
                      placeholder="Enter your custom system prompt here...

Example:
You are an expert software developer specializing in React and Node.js. Your role is to:
- Provide clean, efficient code solutions
- Explain complex concepts in simple terms
- Follow best practices and modern development patterns
- Help with debugging and optimization

Always provide working code examples and explain your reasoning."
                      variant="outlined"
                      sx={{
                        '& .MuiOutlinedInput-root': {
                          fontFamily: 'monospace',
                          fontSize: '14px',
                        }
                      }}
                    />
                    <Typography variant="caption" color="text.secondary" sx={{ mt: 1, display: 'block' }}>
                      Tip: Be specific about the AI's expertise, communication style, and expected outputs.
                    </Typography>
                  </Box>
                )}
              </Box>

              <Divider sx={{ my: 3 }} />
              
              {/* AI Model Info */}
              <Box sx={{ mt: 3 }}>
                <Typography variant="subtitle1" gutterBottom sx={{ fontWeight: 600 }}>
                  AI Model
                </Typography>
                <Typography variant="body2" color="text.secondary">
                  Currently using: <strong>Claude 3.7 Sonnet Reasoning</strong>
                </Typography>
                <Typography variant="caption" color="text.secondary">
                  Advanced model optimized for complex reasoning and professional tasks.
                </Typography>
              </Box>
            </Box>
          )}
          
          {settingsTab === 1 && (
            <Box sx={{ height: '100%', overflow: 'auto' }}>
              <LocalRAGManager />
            </Box>
          )}
        </DialogContent>
        <DialogActions>
          <Button onClick={() => setSettingsOpen(false)}>
            Close
          </Button>
        </DialogActions>
      </Dialog>
    </Box>
  );
};

export default ModernChatInterface;
