import React, { useMemo } from 'react';
import { Box } from '@mui/material';
import { marked } from 'marked';
import DOMPurify from 'dompurify';

interface FinalTextRendererProps {
  content: string;
}

const FinalTextRenderer: React.FC<FinalTextRendererProps> = ({ content }) => {
  const htmlContent = useMemo(() => {
    if (!content) return '';

    try {
      // Configure marked for better output
      marked.setOptions({
        breaks: true,
        gfm: true,
      });

      // Convert markdown to HTML (handle both sync and async versions)
      const rawHtml = marked.parse ? marked.parse(content) : marked(content);
      
      // Handle if marked returns a Promise (newer versions)
      if (typeof rawHtml === 'string') {
        // Sanitize HTML to prevent XSS
        const cleanHtml = DOMPurify.sanitize(rawHtml);
        return cleanHtml;
      } else {
        // Fallback for async version - just return sanitized content
        const fallbackHtml = content
          .replace(/\*\*(.*?)\*\*/g, '<strong>$1</strong>')
          .replace(/\*(.*?)\*/g, '<em>$1</em>')
          .replace(/#{1,6}\s+(.*)/g, '<h3>$1</h3>')
          .replace(/^\s*[-*+]\s+(.*)$/gm, '<li>$1</li>')
          .replace(/(<li>.*<\/li>)/gs, '<ul>$1</ul>')
          .replace(/\n/g, '<br>');
        
        return DOMPurify.sanitize(fallbackHtml);
      }
    } catch (error) {
      console.error('Error processing markdown:', error);
      // Fallback to simple HTML conversion
      const fallbackHtml = content
        .replace(/\*\*(.*?)\*\*/g, '<strong>$1</strong>')
        .replace(/\*(.*?)\*/g, '<em>$1</em>')
        .replace(/#{1,6}\s+(.*)/g, '<h3>$1</h3>')
        .replace(/^\s*[-*+]\s+(.*)$/gm, '<li>$1</li>')
        .replace(/(<li>.*<\/li>)/gs, '<ul>$1</ul>')
        .replace(/\n/g, '<br>');
      
      return DOMPurify.sanitize(fallbackHtml);
    }
  }, [content]);

  return (
    <Box
      sx={{
        '& h1, & h2, & h3, & h4, & h5, & h6': {
          color: '#2C3E50',
          fontWeight: 'bold',
          marginTop: '2rem',
          marginBottom: '1rem',
          lineHeight: 1.3,
        },
        '& h1': { fontSize: '2.5rem' },
        '& h2': { fontSize: '2rem' },
        '& h3': { fontSize: '1.75rem' },
        '& h4': { fontSize: '1.5rem' },
        '& p': {
          color: '#2C3E50',
          lineHeight: 1.6,
          marginBottom: '1rem',
          textAlign: 'justify',
        },
        '& ul, & ol': {
          color: '#2C3E50',
          paddingLeft: '2rem',
          marginBottom: '1rem',
        },
        '& li': {
          marginBottom: '0.5rem',
          lineHeight: 1.6,
        },
        '& table': {
          width: '100%',
          borderCollapse: 'collapse',
          marginBottom: '2rem',
          border: '1px solid #e0e0e0',
        },
        '& th, & td': {
          padding: '12px',
          textAlign: 'left',
          borderBottom: '1px solid #e0e0e0',
          color: '#2C3E50',
        },
        '& th': {
          backgroundColor: '#f5f5f5',
          fontWeight: 'bold',
          borderBottom: '2px solid #00A651',
        },
        '& tr:hover': {
          backgroundColor: '#f9f9f9',
        },
        '& blockquote': {
          borderLeft: '4px solid #00A651',
          paddingLeft: '1rem',
          margin: '1rem 0',
          fontStyle: 'italic',
          color: '#555',
          backgroundColor: '#f9f9f9',
          padding: '1rem',
        },
        '& code': {
          backgroundColor: '#f4f4f4',
          padding: '2px 4px',
          borderRadius: '3px',
          fontFamily: 'monospace',
          fontSize: '0.9em',
        },
        '& pre': {
          backgroundColor: '#f4f4f4',
          padding: '1rem',
          borderRadius: '5px',
          overflow: 'auto',
          marginBottom: '1rem',
        },
        '& pre code': {
          backgroundColor: 'transparent',
          padding: 0,
        },
        '& strong': {
          fontWeight: 'bold',
          color: '#2C3E50',
        },
        '& em': {
          fontStyle: 'italic',
        },
        '& a': {
          color: '#00A651',
          textDecoration: 'none',
          '&:hover': {
            textDecoration: 'underline',
          },
        },
      }}
      dangerouslySetInnerHTML={{ __html: htmlContent }}
    />
  );
};

export default FinalTextRenderer;
