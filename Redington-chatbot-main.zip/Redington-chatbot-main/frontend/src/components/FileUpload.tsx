import React, { useCallback, useState } from 'react';
import {
  Dialog,
  DialogTitle,
  DialogContent,
  DialogActions,
  Button,
  Box,
  Typography,
  List,
  ListItem,
  ListItemText,
  ListItemSecondaryAction,
  IconButton,
  Alert,
  LinearProgress,
  Chip,
  Grid,
} from '@mui/material';
import { useDropzone } from 'react-dropzone';
import { 
  Delete as DeleteIcon, 
  CloudUpload as UploadIcon,
  InsertDriveFile as FileIcon,
  PictureAsPdf as PdfIcon,
  Description as DocIcon,
  TableChart as ExcelIcon,
  Image as ImageIcon,
} from '@mui/icons-material';

interface FileUploadProps {
  open: boolean;
  onClose: () => void;
  onUpload: (files: string[]) => void;
}

interface UploadedFile {
  name: string;
  size: number;
  type: string;
  content: string; // base64 encoded
}

const FileUpload: React.FC<FileUploadProps> = ({ open, onClose, onUpload }) => {
  const [files, setFiles] = useState<UploadedFile[]>([]);
  const [error, setError] = useState<string>('');
  const [uploading, setUploading] = useState(false);

  const getFileIcon = (type: string) => {
    if (type.includes('pdf')) return <PdfIcon color="error" />;
    if (type.includes('word') || type.includes('document')) return <DocIcon color="primary" />;
    if (type.includes('sheet') || type.includes('excel')) return <ExcelIcon color="success" />;
    if (type.includes('image')) return <ImageIcon color="secondary" />;
    return <FileIcon />;
  };

  const onDrop = useCallback((acceptedFiles: File[]) => {
    setError('');
    setUploading(true);
    
    const processFiles = async () => {
      for (const file of acceptedFiles) {
        // Check file size (limit to 10MB)
        if (file.size > 10 * 1024 * 1024) {
          setError(`File ${file.name} is too large. Maximum size is 10MB.`);
          continue;
        }

        try {
          const base64 = await new Promise<string>((resolve, reject) => {
            const reader = new FileReader();
            reader.onload = () => resolve(reader.result as string);
            reader.onerror = reject;
            reader.readAsDataURL(file);
          });

          const base64Content = base64.split(',')[1]; // Remove data:type;base64, prefix
          
          const uploadedFile: UploadedFile = {
            name: file.name,
            size: file.size,
            type: file.type,
            content: base64Content,
          };

          setFiles(prev => [...prev, uploadedFile]);
        } catch (err) {
          setError(`Failed to process file ${file.name}`);
        }
      }
      setUploading(false);
    };

    processFiles();
  }, []);

  const { getRootProps, getInputProps, isDragActive } = useDropzone({
    onDrop,
    accept: {
      'text/plain': ['.txt'],
      'application/pdf': ['.pdf'],
      'application/vnd.openxmlformats-officedocument.wordprocessingml.document': ['.docx'],
      'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet': ['.xlsx'],
      'text/csv': ['.csv'],
      'image/*': ['.png', '.jpg', '.jpeg', '.gif'],
    },
    multiple: true,
  });

  const removeFile = (index: number) => {
    setFiles(prev => prev.filter((_, i) => i !== index));
  };

  const handleUpload = () => {
    const fileContents = files.map(file => file.content);
    onUpload(fileContents);
    setFiles([]);
    onClose();
  };

  const handleClose = () => {
    setFiles([]);
    setError('');
    onClose();
  };

  const formatFileSize = (bytes: number) => {
    if (bytes === 0) return '0 Bytes';
    const k = 1024;
    const sizes = ['Bytes', 'KB', 'MB', 'GB'];
    const i = Math.floor(Math.log(bytes) / Math.log(k));
    return parseFloat((bytes / Math.pow(k, i)).toFixed(2)) + ' ' + sizes[i];
  };

  const supportedFormats = [
    { name: 'PDF Documents', ext: '.pdf', color: 'error' },
    { name: 'Word Documents', ext: '.docx', color: 'primary' },
    { name: 'Excel Spreadsheets', ext: '.xlsx', color: 'success' },
    { name: 'CSV Files', ext: '.csv', color: 'info' },
    { name: 'Text Files', ext: '.txt', color: 'default' },
    { name: 'Images', ext: '.png, .jpg, .gif', color: 'secondary' },
  ];

  return (
    <Dialog open={open} onClose={handleClose} maxWidth="md" fullWidth>
      <DialogTitle sx={{ pb: 1 }}>
        <Box sx={{ display: 'flex', alignItems: 'center' }}>
          <UploadIcon sx={{ mr: 1 }} />
          Upload Files
        </Box>
      </DialogTitle>
      
      <DialogContent>
        {error && (
          <Alert severity="error" sx={{ mb: 2 }}>
            {error}
          </Alert>
        )}

        {/* Supported Formats */}
        <Box sx={{ mb: 3 }}>
          <Typography variant="subtitle2" gutterBottom>
            📋 Supported Formats:
          </Typography>
          <Grid container spacing={1}>
            {supportedFormats.map((format, index) => (
              <Grid item key={index}>
                <Chip
                  label={`${format.name} (${format.ext})`}
                  size="small"
                  color={format.color as any}
                  variant="outlined"
                />
              </Grid>
            ))}
          </Grid>
        </Box>
        
        {/* Drop Zone */}
        <Box
          {...getRootProps()}
          sx={{
            border: '2px dashed',
            borderColor: isDragActive ? 'primary.main' : 'grey.300',
            borderRadius: 2,
            p: 4,
            textAlign: 'center',
            cursor: 'pointer',
            backgroundColor: isDragActive ? 'primary.light' : 'grey.50',
            transition: 'all 0.2s ease',
            mb: 3,
            '&:hover': {
              borderColor: 'primary.main',
              backgroundColor: 'primary.light',
            },
          }}
        >
          <input {...getInputProps()} />
          <UploadIcon sx={{ fontSize: 48, color: 'primary.main', mb: 2 }} />
          {isDragActive ? (
            <Typography variant="h6" color="primary">
              Drop the files here...
            </Typography>
          ) : (
            <>
              <Typography variant="h6" gutterBottom>
                Drag & drop files here, or click to select
              </Typography>
              <Typography variant="body2" color="textSecondary">
                Maximum file size: 10MB per file
                <br />
                You can upload multiple files at once
              </Typography>
            </>
          )}
        </Box>

        {uploading && (
          <Box sx={{ mb: 2 }}>
            <Typography variant="body2" gutterBottom>
              Processing files...
            </Typography>
            <LinearProgress />
          </Box>
        )}

        {/* File List */}
        {files.length > 0 && (
          <Box>
            <Typography variant="h6" gutterBottom>
              📁 Selected Files ({files.length})
            </Typography>
            <List sx={{ maxHeight: 300, overflow: 'auto' }}>
              {files.map((file, index) => (
                <ListItem key={index} divider sx={{ bgcolor: 'grey.50', mb: 1, borderRadius: 1 }}>
                  <Box sx={{ mr: 2 }}>
                    {getFileIcon(file.type)}
                  </Box>
                  <ListItemText
                    primary={
                      <Typography variant="subtitle2" noWrap>
                        {file.name}
                      </Typography>
                    }
                    secondary={
                      <Box>
                        <Typography variant="caption" color="textSecondary">
                          {formatFileSize(file.size)}
                        </Typography>
                        {file.type && (
                          <Chip
                            label={file.type.split('/')[1]?.toUpperCase() || 'Unknown'}
                            size="small"
                            sx={{ ml: 1, height: 20 }}
                          />
                        )}
                      </Box>
                    }
                  />
                  <ListItemSecondaryAction>
                    <IconButton edge="end" onClick={() => removeFile(index)} color="error">
                      <DeleteIcon />
                    </IconButton>
                  </ListItemSecondaryAction>
                </ListItem>
              ))}
            </List>
          </Box>
        )}
      </DialogContent>
      
      <DialogActions sx={{ p: 3, pt: 1 }}>
        <Button onClick={handleClose} color="inherit">
          Cancel
        </Button>
        <Button
          onClick={handleUpload}
          variant="contained"
          disabled={files.length === 0 || uploading}
          startIcon={<UploadIcon />}
        >
          Upload {files.length > 0 && `(${files.length})`}
        </Button>
      </DialogActions>
    </Dialog>
  );
};

export default FileUpload;
