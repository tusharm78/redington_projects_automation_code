import React, { useState, useEffect, useRef } from 'react';
import {
  Box,
  Paper,
  TextField,
  Button,
  Typography,
  List,
  ListItem,
  Avatar,
  Chip,
  IconButton,
  Select,
  MenuItem,
  FormControl,
  InputLabel,
  AppBar,
  Toolbar,
  Divider,
  Card,
  CardContent,
  Grid,
  Alert,
  CircularProgress,
  Fab,
} from '@mui/material';
import {
  Send as SendIcon,
  AttachFile as AttachFileIcon,
  Person as PersonIcon,
  SmartToy as BotIcon,
  Logout as LogoutIcon,
  Add as AddIcon,
  Delete as DeleteIcon,
  Download as DownloadIcon,
} from '@mui/icons-material';
import { useAuth } from '../hooks/useAuth';
import { ChatMessage, ChatRequest, ModelConfig } from '../types';
import apiService from '../services/api';
import FileUpload from './FileUpload';
import MessageRenderer from './MessageRenderer';
import { v4 as uuidv4 } from 'uuid';

const ChatInterface: React.FC = () => {
  const { user, logout } = useAuth();
  const [messages, setMessages] = useState<ChatMessage[]>([]);
  const [inputMessage, setInputMessage] = useState('');
  const [loading, setLoading] = useState(false);
  const [conversationId, setConversationId] = useState<string>('');
  const [selectedModel, setSelectedModel] = useState('Claude 3.7 Sonnet Reasoning');
  const [availableModels, setAvailableModels] = useState<ModelConfig>({});
  const [uploadedFiles, setUploadedFiles] = useState<string[]>([]);
  const [showFileUpload, setShowFileUpload] = useState(false);
  const [error, setError] = useState<string>('');
  const [conversations, setConversations] = useState<Array<{id: string, title: string, lastMessage: string}>>([]);
  
  const messagesEndRef = useRef<HTMLDivElement>(null);
  const inputRef = useRef<HTMLInputElement>(null);

  useEffect(() => {
    loadAvailableModels();
    setConversationId(uuidv4());
    // Add welcome message
    const welcomeMessage: ChatMessage = {
      role: 'assistant',
      content: `Hello! I'm your Redington AI Assistant. I can help you with:

• **Document Analysis** - Upload PDFs, Word docs, Excel files, and more
• **Code Generation** - Write, debug, and explain code
• **Data Analysis** - Process CSV files and generate insights  
• **General Questions** - Ask me anything!

How can I assist you today?`,
      timestamp: new Date().toISOString(),
      message_id: uuidv4(),
    };
    setMessages([welcomeMessage]);
  }, []);

  useEffect(() => {
    scrollToBottom();
  }, [messages]);

  const loadAvailableModels = async () => {
    try {
      const models = await apiService.getAvailableModels();
      setAvailableModels(models);
    } catch (error) {
      console.error('Failed to load models:', error);
      setError('Failed to load AI models. Please refresh the page.');
    }
  };

  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  };

  const handleSendMessage = async () => {
    if (!inputMessage.trim() && uploadedFiles.length === 0) return;

    const userMessage: ChatMessage = {
      role: 'user',
      content: inputMessage,
      timestamp: new Date().toISOString(),
      message_id: uuidv4(),
    };

    setMessages(prev => [...prev, userMessage]);
    setInputMessage('');
    setLoading(true);
    setError('');

    try {
      const request: ChatRequest = {
        message: inputMessage,
        conversation_id: conversationId,
        model_name: selectedModel,
        model_kwargs: {
          max_tokens: availableModels[selectedModel]?.max_tokens || 4000,
          temperature: availableModels[selectedModel]?.temperature || 0.7,
          top_p: availableModels[selectedModel]?.top_p || 0.9,
          top_k: availableModels[selectedModel]?.top_k || 250,
        },
        files: uploadedFiles.length > 0 ? uploadedFiles : undefined,
      };

      const response = await apiService.sendMessage(request);
      
      const assistantMessage: ChatMessage = {
        role: 'assistant',
        content: response.response,
        timestamp: response.timestamp,
        message_id: response.message_id,
      };

      setMessages(prev => [...prev, assistantMessage]);
      setUploadedFiles([]);
      
      // Update conversation list
      updateConversationList(conversationId, inputMessage, response.response);
      
    } catch (error: any) {
      console.error('Failed to send message:', error);
      setError(error.response?.data?.detail || 'Failed to send message. Please try again.');
      
      const errorMessage: ChatMessage = {
        role: 'assistant',
        content: 'Sorry, I encountered an error processing your message. Please try again.',
        timestamp: new Date().toISOString(),
        message_id: uuidv4(),
      };
      setMessages(prev => [...prev, errorMessage]);
    } finally {
      setLoading(false);
    }
  };

  const updateConversationList = (id: string, userMsg: string, aiMsg: string) => {
    const title = userMsg.length > 50 ? userMsg.substring(0, 50) + '...' : userMsg;
    const lastMessage = aiMsg.length > 100 ? aiMsg.substring(0, 100) + '...' : aiMsg;
    
    setConversations(prev => {
      const existing = prev.find(c => c.id === id);
      if (existing) {
        return prev.map(c => c.id === id ? { ...c, title, lastMessage } : c);
      } else {
        return [{ id, title, lastMessage }, ...prev];
      }
    });
  };

  const handleKeyPress = (e: React.KeyboardEvent) => {
    if (e.key === 'Enter' && !e.shiftKey) {
      e.preventDefault();
      handleSendMessage();
    }
  };

  const handleFileUpload = (files: string[]) => {
    setUploadedFiles(prev => [...prev, ...files]);
    setShowFileUpload(false);
  };

  const removeFile = (index: number) => {
    setUploadedFiles(prev => prev.filter((_, i) => i !== index));
  };

  const startNewConversation = () => {
    setMessages([]);
    setConversationId(uuidv4());
    setUploadedFiles([]);
    setError('');
    
    // Add welcome message for new conversation
    const welcomeMessage: ChatMessage = {
      role: 'assistant',
      content: 'Hello! I\'m ready to help you with a new conversation. What would you like to discuss?',
      timestamp: new Date().toISOString(),
      message_id: uuidv4(),
    };
    setMessages([welcomeMessage]);
  };

  const exportConversation = () => {
    const conversationText = messages.map(msg => 
      `${msg.role === 'user' ? 'You' : 'AI Assistant'}: ${msg.content}\n\n`
    ).join('');
    
    const blob = new Blob([conversationText], { type: 'text/plain' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `conversation-${new Date().toISOString().split('T')[0]}.txt`;
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    URL.revokeObjectURL(url);
  };

  return (
    <Box sx={{ height: '100vh', display: 'flex', flexDirection: 'column', bgcolor: '#f5f5f5' }}>
      {/* Header */}
      <AppBar position="static" elevation={1} sx={{ bgcolor: '#1976d2' }}>
        <Toolbar>
          <BotIcon sx={{ mr: 2 }} />
          <Typography variant="h6" component="div" sx={{ flexGrow: 1 }}>
            🤖 Redington AI Bot
          </Typography>
          
          <FormControl size="small" sx={{ minWidth: 200, mr: 2 }}>
            <InputLabel sx={{ color: 'white' }}>AI Model</InputLabel>
            <Select
              value={selectedModel}
              onChange={(e) => setSelectedModel(e.target.value)}
              sx={{ 
                color: 'white', 
                '.MuiOutlinedInput-notchedOutline': { borderColor: 'rgba(255,255,255,0.5)' },
                '.MuiSvgIcon-root': { color: 'white' }
              }}
            >
              {Object.keys(availableModels).map((model) => (
                <MenuItem key={model} value={model}>
                  {model}
                </MenuItem>
              ))}
            </Select>
          </FormControl>
          
          <Button 
            color="inherit" 
            onClick={startNewConversation} 
            sx={{ mr: 1 }}
            startIcon={<AddIcon />}
          >
            New Chat
          </Button>
          
          <Button 
            color="inherit" 
            onClick={exportConversation} 
            sx={{ mr: 2 }}
            startIcon={<DownloadIcon />}
            disabled={messages.length === 0}
          >
            Export
          </Button>
          
          <Typography variant="body2" sx={{ mr: 2 }}>
            Welcome, {user?.username}
          </Typography>
          <IconButton color="inherit" onClick={logout}>
            <LogoutIcon />
          </IconButton>
        </Toolbar>
      </AppBar>

      {/* Error Alert */}
      {error && (
        <Alert severity="error" onClose={() => setError('')} sx={{ m: 2 }}>
          {error}
        </Alert>
      )}

      {/* Main Content */}
      <Box sx={{ flexGrow: 1, display: 'flex', overflow: 'hidden' }}>
        {/* Sidebar - Conversation History */}
        <Box sx={{ width: 300, bgcolor: 'white', borderRight: 1, borderColor: 'divider', overflow: 'auto' }}>
          <Box sx={{ p: 2, borderBottom: 1, borderColor: 'divider' }}>
            <Typography variant="h6" gutterBottom>
              Recent Conversations
            </Typography>
          </Box>
          <List>
            {conversations.map((conv) => (
              <ListItem 
                key={conv.id} 
                button 
                selected={conv.id === conversationId}
                sx={{ 
                  borderBottom: 1, 
                  borderColor: 'divider',
                  '&.Mui-selected': { bgcolor: 'primary.light', color: 'white' }
                }}
              >
                <Box sx={{ width: '100%' }}>
                  <Typography variant="subtitle2" noWrap>
                    {conv.title}
                  </Typography>
                  <Typography variant="caption" color="textSecondary" noWrap>
                    {conv.lastMessage}
                  </Typography>
                </Box>
              </ListItem>
            ))}
          </List>
        </Box>

        {/* Chat Area */}
        <Box sx={{ flexGrow: 1, display: 'flex', flexDirection: 'column' }}>
          {/* Messages */}
          <Box sx={{ flexGrow: 1, overflow: 'auto', p: 2 }}>
            <List>
              {messages.map((message, index) => (
                <ListItem key={index} sx={{ alignItems: 'flex-start', mb: 2 }}>
                  <Avatar sx={{ mr: 2, mt: 1, bgcolor: message.role === 'user' ? 'primary.main' : 'secondary.main' }}>
                    {message.role === 'user' ? <PersonIcon /> : <BotIcon />}
                  </Avatar>
                  <Box sx={{ flexGrow: 1, maxWidth: 'calc(100% - 60px)' }}>
                    <Box sx={{ display: 'flex', alignItems: 'center', mb: 1 }}>
                      <Typography variant="subtitle2" color="textSecondary">
                        {message.role === 'user' ? 'You' : 'AI Assistant'}
                      </Typography>
                      {message.timestamp && (
                        <Typography variant="caption" color="textSecondary" sx={{ ml: 1 }}>
                          {new Date(message.timestamp).toLocaleTimeString()}
                        </Typography>
                      )}
                    </Box>
                    <Card 
                      elevation={1} 
                      sx={{ 
                        backgroundColor: message.role === 'user' ? '#e3f2fd' : '#f5f5f5',
                        border: message.role === 'user' ? '1px solid #2196f3' : '1px solid #e0e0e0'
                      }}
                    >
                      <CardContent sx={{ p: 2, '&:last-child': { pb: 2 } }}>
                        <MessageRenderer content={message.content} />
                      </CardContent>
                    </Card>
                  </Box>
                </ListItem>
              ))}
              
              {loading && (
                <ListItem sx={{ alignItems: 'flex-start' }}>
                  <Avatar sx={{ mr: 2, mt: 1, bgcolor: 'secondary.main' }}>
                    <BotIcon />
                  </Avatar>
                  <Box sx={{ flexGrow: 1 }}>
                    <Typography variant="subtitle2" color="textSecondary" gutterBottom>
                      AI Assistant
                    </Typography>
                    <Card elevation={1} sx={{ backgroundColor: '#f5f5f5' }}>
                      <CardContent sx={{ display: 'flex', alignItems: 'center', p: 2 }}>
                        <CircularProgress size={20} sx={{ mr: 2 }} />
                        <Typography>Thinking...</Typography>
                      </CardContent>
                    </Card>
                  </Box>
                </ListItem>
              )}
            </List>
            <div ref={messagesEndRef} />
          </Box>

          <Divider />

          {/* File Upload Area */}
          {uploadedFiles.length > 0 && (
            <Box sx={{ p: 2, bgcolor: '#f9f9f9', borderTop: 1, borderColor: 'divider' }}>
              <Typography variant="subtitle2" gutterBottom>
                📎 Uploaded Files ({uploadedFiles.length}):
              </Typography>
              <Box sx={{ display: 'flex', flexWrap: 'wrap', gap: 1 }}>
                {uploadedFiles.map((file, index) => (
                  <Chip
                    key={index}
                    label={`File ${index + 1}`}
                    onDelete={() => removeFile(index)}
                    size="small"
                    color="primary"
                    variant="outlined"
                  />
                ))}
              </Box>
            </Box>
          )}

          {/* Input Area */}
          <Box sx={{ p: 2, bgcolor: 'white', borderTop: 1, borderColor: 'divider' }}>
            <Grid container spacing={1} alignItems="flex-end">
              <Grid item>
                <IconButton
                  onClick={() => setShowFileUpload(true)}
                  disabled={loading}
                  color="primary"
                >
                  <AttachFileIcon />
                </IconButton>
              </Grid>
              <Grid item xs>
                <TextField
                  ref={inputRef}
                  fullWidth
                  multiline
                  maxRows={4}
                  placeholder="Type your message here... (Press Enter to send, Shift+Enter for new line)"
                  value={inputMessage}
                  onChange={(e) => setInputMessage(e.target.value)}
                  onKeyPress={handleKeyPress}
                  disabled={loading}
                  variant="outlined"
                  size="small"
                />
              </Grid>
              <Grid item>
                <Button
                  variant="contained"
                  endIcon={<SendIcon />}
                  onClick={handleSendMessage}
                  disabled={loading || (!inputMessage.trim() && uploadedFiles.length === 0)}
                  sx={{ minWidth: 100, height: 40 }}
                >
                  Send
                </Button>
              </Grid>
            </Grid>
          </Box>
        </Box>
      </Box>

      {/* Floating Action Button for Mobile */}
      <Fab
        color="primary"
        aria-label="new chat"
        sx={{ position: 'fixed', bottom: 16, right: 16, display: { xs: 'flex', md: 'none' } }}
        onClick={startNewConversation}
      >
        <AddIcon />
      </Fab>

      {/* File Upload Dialog */}
      <FileUpload
        open={showFileUpload}
        onClose={() => setShowFileUpload(false)}
        onUpload={handleFileUpload}
      />
    </Box>
  );
};

export default ChatInterface;
