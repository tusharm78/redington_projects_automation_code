import React, { useMemo } from 'react';
import { 
  Typography, 
  Box, 
  Paper, 
  Table, 
  TableBody, 
  TableCell, 
  TableContainer, 
  TableHead, 
  TableRow, 
  Divider 
} from '@mui/material';

interface WordDocumentRendererProps {
  content: string;
  isStreaming?: boolean;
}

const WordDocumentRenderer: React.FC<WordDocumentRendererProps> = ({ 
  content, 
  isStreaming = false 
}) => {
  // Section numbering state
  const sectionCounters = useMemo(() => ({ 1: 0, 2: 0 }), []);
  
  const getNextSectionNumber = (level: number): string => {
    if (level === 1) {
      sectionCounters[1]++;
      sectionCounters[2] = 0;
      return sectionCounters[1].toString();
    } else if (level === 2) {
      sectionCounters[2]++;
      return `${sectionCounters[1]}.${sectionCounters[2]}`;
    }
    return '';
  };

  const processedElements = useMemo(() => {
    if (!content) return [];

    const lines = content.split('\n');
    const elements: JSX.Element[] = [];
    let currentSection = '';
    let inTable = false;
    let tableRows: string[][] = [];
    let tableHeaders: string[] = [];
    let inBulletList = false;
    let bulletItems: string[] = [];
    let currentParagraph = '';

    const addParagraph = () => {
      if (currentParagraph.trim()) {
        elements.push(
          <Typography
            key={`para-${elements.length}`}
            variant="body1"
            sx={{
              mb: 2,
              lineHeight: 1.6,
              textAlign: 'justify',
              fontSize: '11pt',
              fontFamily: '"Aptos Display (Headings)", "Calibri", "Arial", sans-serif',
              color: '#000000',
              textIndent: '0pt',
            }}
          >
            {formatInlineText(currentParagraph.trim())}
          </Typography>
        );
        currentParagraph = '';
      }
    };

    const addBulletList = () => {
      if (bulletItems.length > 0) {
        elements.push(
          <Box
            key={`bullets-${elements.length}`}
            component="ul"
            sx={{
              mb: 2,
              pl: 3,
              listStyleType: 'disc',
              '& li': {
                mb: 0.5,
                lineHeight: 1.6,
                fontSize: '11pt',
                fontFamily: '"Aptos Display (Headings)", "Calibri", "Arial", sans-serif',
                color: '#000000',
              },
            }}
          >
            {bulletItems.map((item, index) => (
              <Typography
                key={index}
                component="li"
                sx={{
                  mb: 0.5,
                  lineHeight: 1.6,
                  fontSize: '11pt',
                  fontFamily: '"Aptos Display (Headings)", "Calibri", "Arial", sans-serif',
                  color: '#000000',
                }}
              >
                {formatInlineText(item)}
              </Typography>
            ))}
          </Box>
        );
        bulletItems = [];
        inBulletList = false;
      }
    };

    const addTable = () => {
      if (tableRows.length > 0) {
        elements.push(
          <TableContainer
            key={`table-${elements.length}`}
            component={Paper}
            elevation={0}
            sx={{
              mb: 3,
              border: '1px solid #000000',
              borderRadius: 0,
            }}
          >
            <Table
              sx={{
                '& .MuiTableCell-root': {
                  border: '1px solid #000000',
                  padding: '8px 12px',
                  fontSize: '11pt',
                  fontFamily: '"Aptos Display (Headings)", "Calibri", "Arial", sans-serif',
                  lineHeight: 1.4,
                },
                '& .MuiTableCell-head': {
                  backgroundColor: '#f2f2f2',
                  fontWeight: 'bold',
                },
              }}
            >
              {tableHeaders.length > 0 && (
                <TableHead>
                  <TableRow>
                    {tableHeaders.map((header, index) => (
                      <TableCell key={index} sx={{ fontWeight: 'bold' }}>
                        {formatInlineText(header)}
                      </TableCell>
                    ))}
                  </TableRow>
                </TableHead>
              )}
              <TableBody>
                {tableRows.map((row, rowIndex) => (
                  <TableRow key={rowIndex}>
                    {row.map((cell, cellIndex) => (
                      <TableCell key={cellIndex}>
                        {formatInlineText(cell)}
                      </TableCell>
                    ))}
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          </TableContainer>
        );
        tableRows = [];
        tableHeaders = [];
        inTable = false;
      }
    };

    lines.forEach((line, index) => {
      const trimmedLine = line.trim();

      // Handle table detection (lines with | separators)
      if (trimmedLine.includes('|') && trimmedLine.split('|').length > 2) {
        addParagraph();
        addBulletList();
        
        const cells = trimmedLine.split('|').map(cell => cell.trim()).filter(cell => cell);
        
        if (!inTable) {
          // First table row - treat as headers
          tableHeaders = cells;
          inTable = true;
        } else if (cells.every(cell => cell.match(/^[-:]+$/))) {
          // Skip separator rows (markdown table separators)
          return;
        } else {
          // Regular table row
          tableRows.push(cells);
        }
        return;
      } else if (inTable) {
        // End of table
        addTable();
      }

      // Handle headers (lines starting with #)
      if (trimmedLine.startsWith('#')) {
        addParagraph();
        addBulletList();
        addTable();
        
        const level = (trimmedLine.match(/^#+/) || [''])[0].length;
        const text = trimmedLine.replace(/^#+\s*/, '');
        
        if (text.trim()) {
          const isMainSection = level <= 2;
          const fontSize = level === 1 ? '16px' : level === 2 ? '16px' : level === 3 ? '16px' : '16px';
          const fontWeight = level <= 2 ? 700 : 600;
          const textTransform = level === 1 ? 'uppercase' : 'none';
          const marginTop = level === 1 ? 4 : level === 2 ? 3 : 2;
          
          elements.push(
            <Box key={`header-${elements.length}`} sx={{ mb: 2, mt: marginTop }}>
              <Typography
                variant={level === 1 ? 'h4' : level === 2 ? 'h5' : 'h6'}
                sx={{
                  fontWeight,
                  color: '#000000',
                  fontSize,
                  lineHeight: 1.2,
                  mb: 1,
                  fontFamily: '"Aptos Display (Headings)", "Calibri", "Arial", sans-serif',
                  textTransform: textTransform as any,
                }}
              >
                {level <= 2 && `${getNextSectionNumber(level)}. `}
                {formatInlineText(text)}
              </Typography>
              {isMainSection && (
                <Divider
                  sx={{
                    borderColor: '#000000',
                    borderWidth: 1,
                    width: '100%',
                    mt: 0.5,
                  }}
                />
              )}
            </Box>
          );
        }
        return;
      }

      // Handle bullet points
      const bulletMatch = trimmedLine.match(/^[*\-•]\s+(.+)$/);
      if (bulletMatch) {
        addParagraph();
        addTable();
        
        if (!inBulletList) {
          inBulletList = true;
        }
        bulletItems.push(bulletMatch[1]);
        return;
      } else if (inBulletList && trimmedLine) {
        // Continue previous bullet item
        if (bulletItems.length > 0) {
          bulletItems[bulletItems.length - 1] += ' ' + trimmedLine;
        }
        return;
      } else if (inBulletList) {
        addBulletList();
      }

      // Handle empty lines
      if (!trimmedLine) {
        addParagraph();
        addBulletList();
        addTable();
        return;
      }

      // Regular paragraph text
      addBulletList();
      addTable();
      currentParagraph += (currentParagraph ? ' ' : '') + trimmedLine;
    });

    // Flush remaining content
    addParagraph();
    addBulletList();
    addTable();

    return elements;
  }, [content, sectionCounters]);

  return (
    <Paper
      elevation={0}
      sx={{
        p: 4,
        backgroundColor: '#ffffff',
        border: '1px solid #d1d1d1',
        borderRadius: 1,
        minHeight: '400px',
        fontFamily: '"Aptos Display (Headings)", "Calibri", "Arial", sans-serif',
        fontSize: '11pt',
        lineHeight: 1.6,
        color: '#000000',
        position: 'relative',
        // Word document styling
        '& *': {
          fontFamily: '"Aptos Display (Headings)", "Calibri", "Arial", sans-serif !important',
        },
        // Page-like appearance
        maxWidth: '8.5in',
        margin: '0 auto',
        boxShadow: '0 0 10px rgba(0,0,0,0.1)',
      }}
    >
      {processedElements}
      
      {isStreaming && (
        <Box
          sx={{
            display: 'inline-flex',
            alignItems: 'center',
            mt: 1,
            opacity: 0.7,
          }}
        >
          <Box
            sx={{
              width: 8,
              height: 8,
              borderRadius: '50%',
              backgroundColor: '#0066cc',
              animation: 'pulse 1.5s ease-in-out infinite',
              '@keyframes pulse': {
                '0%': { opacity: 0.3 },
                '50%': { opacity: 1 },
                '100%': { opacity: 0.3 },
              },
            }}
          />
          <Typography
            variant="caption"
            sx={{
              ml: 1,
              fontSize: '9pt',
              color: '#666666',
              fontStyle: 'italic',
            }}
          >
            Generating document...
          </Typography>
        </Box>
      )}
    </Paper>
  );
};

// Helper function to format inline text (bold, italic, etc.)
const formatInlineText = (text: string): React.ReactNode => {
  const parts = text.split(/(\*\*[^*]+\*\*|\*[^*]+\*|`[^`]+`|<[^>]+>)/);
  
  return parts.map((part, index) => {
    // Bold text
    if (part.startsWith('**') && part.endsWith('**')) {
      return (
        <Box
          key={index}
          component="span"
          sx={{ fontWeight: 700, color: '#000000' }}
        >
          {part.slice(2, -2)}
        </Box>
      );
    }
    
    // Italic text
    if (part.startsWith('*') && part.endsWith('*') && !part.startsWith('**')) {
      return (
        <Box
          key={index}
          component="span"
          sx={{ fontStyle: 'italic', color: '#000000' }}
        >
          {part.slice(1, -1)}
        </Box>
      );
    }
    
    // Code/monospace text
    if (part.startsWith('`') && part.endsWith('`')) {
      return (
        <Box
          key={index}
          component="code"
          sx={{
            backgroundColor: '#f5f5f5',
            border: '1px solid #cccccc',
            borderRadius: 0.5,
            px: 0.5,
            py: 0.25,
            fontFamily: '"Courier New", monospace',
            fontSize: '10pt',
            color: '#000000',
          }}
        >
          {part.slice(1, -1)}
        </Box>
      );
    }
    
    // Placeholders (angle brackets)
    if (part.startsWith('<') && part.endsWith('>')) {
      return (
        <Box
          key={index}
          component="span"
          sx={{
            backgroundColor: '#ffff99',
            border: '1px solid #cccc00',
            borderRadius: 0.5,
            px: 0.5,
            py: 0.25,
            fontWeight: 600,
            color: '#000000',
          }}
        >
          {part}
        </Box>
      );
    }
    
    return part;
  });
};

export default WordDocumentRenderer;
