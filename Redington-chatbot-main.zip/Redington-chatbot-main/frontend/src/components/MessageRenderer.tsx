import React from 'react';
import StreamingTextRenderer from './StreamingTextRenderer';
import FinalTextRenderer from './FinalTextRenderer';

interface MessageRendererProps {
  content: string;
  isStreaming?: boolean;
}

const MessageRenderer: React.FC<MessageRendererProps> = React.memo(({ 
  content, 
  isStreaming = false 
}) => {
  // Dual rendering approach: streaming vs final
  if (isStreaming) {
    // During streaming: optimized real-time rendering
    return <StreamingTextRenderer content={content} />;
  } else {
    // After completion: rich HTML formatting
    return <FinalTextRenderer content={content} />;
  }
});

// Set display name for debugging
MessageRenderer.displayName = 'MessageRenderer';

export default MessageRenderer;
