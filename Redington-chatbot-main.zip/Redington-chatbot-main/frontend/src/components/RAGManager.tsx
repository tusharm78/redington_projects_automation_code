import React, { useState, useEffect } from 'react';
import {
  Box,
  Typography,
  Button,
  Card,
  CardContent,
  Grid,
  LinearProgress,
  Alert,
  Dialog,
  DialogTitle,
  DialogContent,
  DialogActions,
  TextField,
  List,
  ListItem,
  ListItemText,
  ListItemIcon,
  Chip,
  Divider,
  IconButton,
  Tooltip,
  Paper,
  CircularProgress
} from '@mui/material';
import {
  CloudUpload as UploadIcon,
  Search as SearchIcon,
  Refresh as RefreshIcon,
  Storage as StorageIcon,
  Description as DocumentIcon,
  CheckCircle as CheckIcon,
  Error as ErrorIcon,
  Info as InfoIcon,
  Delete as DeleteIcon,
  Build as BuildIcon
} from '@mui/icons-material';
import { apiService } from '../services/api';

interface RAGStats {
  index_initialized: boolean;
  metadata: {
    total_documents: number;
    total_chunks: number;
    last_updated: string;
    document_sources: string[];
  };
  s3_bucket: string;
  vector_count?: number;
}

interface SearchResult {
  content: string;
  metadata: any;
  similarity_score: number;
}

const RAGManager: React.FC = () => {
  const [stats, setStats] = useState<RAGStats | null>(null);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [success, setSuccess] = useState<string | null>(null);
  
  // Upload states
  const [uploadDialogOpen, setUploadDialogOpen] = useState(false);
  const [selectedFiles, setSelectedFiles] = useState<FileList | null>(null);
  const [uploading, setUploading] = useState(false);
  
  // Search states
  const [searchDialogOpen, setSearchDialogOpen] = useState(false);
  const [searchQuery, setSearchQuery] = useState('');
  const [searchResults, setSearchResults] = useState<SearchResult[]>([]);
  const [searching, setSearching] = useState(false);

  useEffect(() => {
    loadRAGStats();
  }, []);

  const loadRAGStats = async () => {
    try {
      setLoading(true);
      setError(null);
      const response = await apiService.get('/rag/stats');
      setStats(response.data || response);
    } catch (err: any) {
      setError(err.message || 'Failed to load RAG statistics');
    } finally {
      setLoading(false);
    }
  };

  const initializeRAG = async (forceRebuild: boolean = false) => {
    try {
      setLoading(true);
      setError(null);
      const response = await apiService.post('/rag/initialize', { force_rebuild: forceRebuild });
      const data = response.data || response;
      setSuccess(data.message || 'RAG initialized successfully');
      await loadRAGStats();
    } catch (err: any) {
      setError(err.message || 'Failed to initialize RAG');
    } finally {
      setLoading(false);
    }
  };

  const handleFileUpload = async () => {
    if (!selectedFiles || selectedFiles.length === 0) return;

    try {
      setUploading(true);
      setError(null);

      const formData = new FormData();
      Array.from(selectedFiles).forEach(file => {
        formData.append('files', file);
      });

      // Use fetch directly for file upload with custom headers
      const token = localStorage.getItem('access_token');
      const response = await fetch('/api/v1/rag/batch-upload', {
        method: 'POST',
        headers: {
          'Authorization': `Bearer ${token}`,
        },
        body: formData,
      });

      if (!response.ok) {
        throw new Error(`Upload failed: ${response.statusText}`);
      }

      const data = await response.json();
      setSuccess(`Successfully uploaded ${data.successful_uploads} out of ${data.total_files} files`);
      setUploadDialogOpen(false);
      setSelectedFiles(null);
      await loadRAGStats();
    } catch (err: any) {
      setError(err.message || 'Failed to upload files');
    } finally {
      setUploading(false);
    }
  };

  const handleSearch = async () => {
    if (!searchQuery.trim()) return;

    try {
      setSearching(true);
      setError(null);

      const formData = new FormData();
      formData.append('query', searchQuery);
      formData.append('max_results', '5');

      // Use fetch directly for form data
      const token = localStorage.getItem('access_token');
      const response = await fetch('/api/v1/rag/search', {
        method: 'POST',
        headers: {
          'Authorization': `Bearer ${token}`,
        },
        body: formData,
      });

      if (!response.ok) {
        throw new Error(`Search failed: ${response.statusText}`);
      }

      const data = await response.json();
      setSearchResults(data.results || []);
    } catch (err: any) {
      setError(err.message || 'Failed to search knowledge base');
    } finally {
      setSearching(false);
    }
  };

  const rebuildIndex = async () => {
    try {
      setLoading(true);
      setError(null);
      const response = await apiService.post('/rag/rebuild-index');
      const data = response.data || response;
      setSuccess(data.message || 'Index rebuilt successfully');
      await loadRAGStats();
    } catch (err: any) {
      setError(err.message || 'Failed to rebuild index');
    } finally {
      setLoading(false);
    }
  };

  const formatDate = (dateString: string) => {
    try {
      return new Date(dateString).toLocaleString();
    } catch {
      return 'Unknown';
    }
  };

  return (
    <Box sx={{ p: 3 }}>
      <Typography variant="h4" gutterBottom sx={{ display: 'flex', alignItems: 'center', gap: 1 }}>
        <StorageIcon />
        RAG Knowledge Base Manager
      </Typography>

      {error && (
        <Alert severity="error" sx={{ mb: 2 }} onClose={() => setError(null)}>
          {error}
        </Alert>
      )}

      {success && (
        <Alert severity="success" sx={{ mb: 2 }} onClose={() => setSuccess(null)}>
          {success}
        </Alert>
      )}

      {loading && <LinearProgress sx={{ mb: 2 }} />}

      <Grid container spacing={3}>
        {/* Statistics Card */}
        <Grid item xs={12} md={6}>
          <Card>
            <CardContent>
              <Typography variant="h6" gutterBottom sx={{ display: 'flex', alignItems: 'center', gap: 1 }}>
                <InfoIcon />
                Index Statistics
              </Typography>
              
              {stats ? (
                <Box>
                  <Box sx={{ display: 'flex', alignItems: 'center', gap: 1, mb: 1 }}>
                    <Typography variant="body2">Status:</Typography>
                    <Chip 
                      icon={stats.index_initialized ? <CheckIcon /> : <ErrorIcon />}
                      label={stats.index_initialized ? 'Initialized' : 'Not Initialized'}
                      color={stats.index_initialized ? 'success' : 'error'}
                      size="small"
                    />
                  </Box>
                  
                  {stats.metadata && (
                    <>
                      <Typography variant="body2">
                        <strong>Documents:</strong> {stats.metadata.total_documents}
                      </Typography>
                      <Typography variant="body2">
                        <strong>Text Chunks:</strong> {stats.metadata.total_chunks}
                      </Typography>
                      {stats.vector_count && (
                        <Typography variant="body2">
                          <strong>Vectors:</strong> {stats.vector_count}
                        </Typography>
                      )}
                      <Typography variant="body2">
                        <strong>Last Updated:</strong> {formatDate(stats.metadata.last_updated)}
                      </Typography>
                      <Typography variant="body2">
                        <strong>S3 Bucket:</strong> {stats.s3_bucket}
                      </Typography>
                    </>
                  )}
                </Box>
              ) : (
                <Typography variant="body2" color="text.secondary">
                  Loading statistics...
                </Typography>
              )}
            </CardContent>
          </Card>
        </Grid>

        {/* Actions Card */}
        <Grid item xs={12} md={6}>
          <Card>
            <CardContent>
              <Typography variant="h6" gutterBottom>
                Actions
              </Typography>
              
              <Box sx={{ display: 'flex', flexDirection: 'column', gap: 2 }}>
                <Button
                  variant="contained"
                  startIcon={<UploadIcon />}
                  onClick={() => setUploadDialogOpen(true)}
                  disabled={loading}
                >
                  Upload Documents
                </Button>
                
                <Button
                  variant="outlined"
                  startIcon={<SearchIcon />}
                  onClick={() => setSearchDialogOpen(true)}
                  disabled={loading || !stats?.index_initialized}
                >
                  Search Knowledge Base
                </Button>
                
                <Button
                  variant="outlined"
                  startIcon={<RefreshIcon />}
                  onClick={loadRAGStats}
                  disabled={loading}
                >
                  Refresh Stats
                </Button>
                
                <Divider />
                
                <Button
                  variant="outlined"
                  startIcon={<BuildIcon />}
                  onClick={() => initializeRAG(false)}
                  disabled={loading}
                  color="primary"
                >
                  Initialize RAG
                </Button>
                
                <Button
                  variant="outlined"
                  startIcon={<BuildIcon />}
                  onClick={() => initializeRAG(true)}
                  disabled={loading}
                  color="warning"
                >
                  Force Rebuild
                </Button>
                
                <Button
                  variant="outlined"
                  startIcon={<RefreshIcon />}
                  onClick={rebuildIndex}
                  disabled={loading}
                  color="secondary"
                >
                  Rebuild from S3
                </Button>
              </Box>
            </CardContent>
          </Card>
        </Grid>

        {/* Document Sources */}
        {stats?.metadata?.document_sources && stats.metadata.document_sources.length > 0 && (
          <Grid item xs={12}>
            <Card>
              <CardContent>
                <Typography variant="h6" gutterBottom>
                  Document Sources ({stats.metadata.document_sources.length})
                </Typography>
                
                <List dense>
                  {stats.metadata.document_sources.slice(0, 10).map((source, index) => (
                    <ListItem key={index}>
                      <ListItemIcon>
                        <DocumentIcon />
                      </ListItemIcon>
                      <ListItemText 
                        primary={source.split('/').pop() || source}
                        secondary={source}
                      />
                    </ListItem>
                  ))}
                  {stats.metadata.document_sources.length > 10 && (
                    <ListItem>
                      <ListItemText 
                        primary={`... and ${stats.metadata.document_sources.length - 10} more documents`}
                        sx={{ fontStyle: 'italic', color: 'text.secondary' }}
                      />
                    </ListItem>
                  )}
                </List>
              </CardContent>
            </Card>
          </Grid>
        )}
      </Grid>

      {/* Upload Dialog */}
      <Dialog open={uploadDialogOpen} onClose={() => setUploadDialogOpen(false)} maxWidth="sm" fullWidth>
        <DialogTitle>Upload Documents to Knowledge Base</DialogTitle>
        <DialogContent>
          <Box sx={{ mt: 2 }}>
            <input
              type="file"
              multiple
              accept=".pdf,.doc,.docx,.txt,.csv,.md"
              onChange={(e) => setSelectedFiles(e.target.files)}
              style={{ width: '100%', padding: '10px', border: '1px dashed #ccc', borderRadius: '4px' }}
            />
            <Typography variant="caption" color="text.secondary" sx={{ mt: 1, display: 'block' }}>
              Supported formats: PDF, DOC, DOCX, TXT, CSV, MD
            </Typography>
            
            {selectedFiles && selectedFiles.length > 0 && (
              <Box sx={{ mt: 2 }}>
                <Typography variant="subtitle2">Selected Files:</Typography>
                {Array.from(selectedFiles).map((file, index) => (
                  <Typography key={index} variant="body2" sx={{ ml: 1 }}>
                    • {file.name} ({(file.size / 1024 / 1024).toFixed(2)} MB)
                  </Typography>
                ))}
              </Box>
            )}
          </Box>
        </DialogContent>
        <DialogActions>
          <Button onClick={() => setUploadDialogOpen(false)} disabled={uploading}>
            Cancel
          </Button>
          <Button 
            onClick={handleFileUpload} 
            variant="contained" 
            disabled={!selectedFiles || selectedFiles.length === 0 || uploading}
            startIcon={uploading ? <CircularProgress size={20} /> : <UploadIcon />}
          >
            {uploading ? 'Uploading...' : 'Upload'}
          </Button>
        </DialogActions>
      </Dialog>

      {/* Search Dialog */}
      <Dialog open={searchDialogOpen} onClose={() => setSearchDialogOpen(false)} maxWidth="md" fullWidth>
        <DialogTitle>Search Knowledge Base</DialogTitle>
        <DialogContent>
          <Box sx={{ mt: 2 }}>
            <TextField
              fullWidth
              label="Search Query"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              onKeyPress={(e) => e.key === 'Enter' && handleSearch()}
              disabled={searching}
            />
            
            <Button
              variant="contained"
              startIcon={searching ? <CircularProgress size={20} /> : <SearchIcon />}
              onClick={handleSearch}
              disabled={!searchQuery.trim() || searching}
              sx={{ mt: 2 }}
            >
              {searching ? 'Searching...' : 'Search'}
            </Button>
            
            {searchResults.length > 0 && (
              <Box sx={{ mt: 3 }}>
                <Typography variant="h6" gutterBottom>
                  Search Results ({searchResults.length})
                </Typography>
                
                {searchResults.map((result, index) => (
                  <Paper key={index} sx={{ p: 2, mb: 2 }}>
                    <Box sx={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', mb: 1 }}>
                      <Typography variant="subtitle2">
                        Source: {result.metadata.source?.split('/').pop() || 'Unknown'}
                      </Typography>
                      <Chip 
                        label={`Score: ${result.similarity_score.toFixed(3)}`}
                        size="small"
                        color="primary"
                      />
                    </Box>
                    <Typography variant="body2" sx={{ whiteSpace: 'pre-wrap' }}>
                      {result.content.substring(0, 500)}
                      {result.content.length > 500 && '...'}
                    </Typography>
                  </Paper>
                ))}
              </Box>
            )}
          </Box>
        </DialogContent>
        <DialogActions>
          <Button onClick={() => setSearchDialogOpen(false)}>
            Close
          </Button>
        </DialogActions>
      </Dialog>
    </Box>
  );
};

export default RAGManager;
