import React, { useState, useEffect } from 'react';
import {
  Box,
  Card,
  CardContent,
  Typography,
  Table,
  TableBody,
  TableCell,
  TableContainer,
  TableHead,
  TableRow,
  Paper,
  Chip,
  Button,
  Grid,
  Alert,
  CircularProgress,
  Dialog,
  DialogTitle,
  DialogContent,
  DialogActions,
  IconButton,
  Tooltip,
  Snackbar
} from '@mui/material';
import {
  Refresh as RefreshIcon,
  Person as PersonIcon,
  ExitToApp as LogoutIcon,
  Info as InfoIcon,
  CleaningServices as CleanupIcon
} from '@mui/icons-material';

interface ActiveUser {
  username: string;
  email: string;
  login_time: string;
  last_activity: string;
  session_duration: string;
  chat_sessions: number;
  messages_sent: number;
  status: string;
}

interface AdminStats {
  total_active_users: number;
  total_sessions_today: number;
  average_session_duration: string;
  most_active_user: string | null;
  active_users: ActiveUser[];
}

interface AdminDashboardProps {
  authToken: string;
  onClose?: () => void;
}

const AdminDashboard: React.FC<AdminDashboardProps> = ({ authToken, onClose }) => {
  const [activeUsers, setActiveUsers] = useState<ActiveUser[]>([]);
  const [stats, setStats] = useState<AdminStats | null>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [selectedUser, setSelectedUser] = useState<string | null>(null);
  const [userDetails, setUserDetails] = useState<any>(null);
  const [detailsLoading, setDetailsLoading] = useState(false);
  const [snackbar, setSnackbar] = useState<{ open: boolean; message: string; severity: 'success' | 'error' }>({
    open: false,
    message: '',
    severity: 'success'
  });

  const API_BASE = process.env.REACT_APP_API_URL || 'http://localhost:8000';

  const fetchActiveUsers = async () => {
    try {
      setLoading(true);
      const response = await fetch(`${API_BASE}/api/v1/admin/active-users`, {
        headers: {
          'Authorization': `Bearer ${authToken}`,
          'Content-Type': 'application/json'
        }
      });

      if (!response.ok) {
        throw new Error(`HTTP ${response.status}: ${response.statusText}`);
      }

      const users = await response.json();
      setActiveUsers(users);
      setError(null);
    } catch (err) {
      console.error('Error fetching active users:', err);
      setError(err instanceof Error ? err.message : 'Failed to fetch active users');
    } finally {
      setLoading(false);
    }
  };

  const fetchAdminStats = async () => {
    try {
      const response = await fetch(`${API_BASE}/api/v1/admin/stats`, {
        headers: {
          'Authorization': `Bearer ${authToken}`,
          'Content-Type': 'application/json'
        }
      });

      if (!response.ok) {
        throw new Error(`HTTP ${response.status}: ${response.statusText}`);
      }

      const data = await response.json();
      setStats(data.stats);
    } catch (err) {
      console.error('Error fetching admin stats:', err);
    }
  };

  const fetchUserDetails = async (username: string) => {
    try {
      setDetailsLoading(true);
      const response = await fetch(`${API_BASE}/api/v1/admin/user-details/${username}`, {
        headers: {
          'Authorization': `Bearer ${authToken}`,
          'Content-Type': 'application/json'
        }
      });

      if (!response.ok) {
        throw new Error(`HTTP ${response.status}: ${response.statusText}`);
      }

      const details = await response.json();
      setUserDetails(details);
    } catch (err) {
      console.error('Error fetching user details:', err);
      setSnackbar({
        open: true,
        message: 'Failed to fetch user details',
        severity: 'error'
      });
    } finally {
      setDetailsLoading(false);
    }
  };

  const forceLogout = async (username: string) => {
    try {
      const response = await fetch(`${API_BASE}/api/v1/admin/force-logout/${username}`, {
        method: 'POST',
        headers: {
          'Authorization': `Bearer ${authToken}`,
          'Content-Type': 'application/json'
        }
      });

      if (!response.ok) {
        throw new Error(`HTTP ${response.status}: ${response.statusText}`);
      }

      setSnackbar({
        open: true,
        message: `User ${username} has been logged out`,
        severity: 'success'
      });

      // Refresh the user list
      fetchActiveUsers();
      setSelectedUser(null);
    } catch (err) {
      console.error('Error forcing logout:', err);
      setSnackbar({
        open: true,
        message: 'Failed to logout user',
        severity: 'error'
      });
    }
  };

  const cleanupSessions = async () => {
    try {
      const response = await fetch(`${API_BASE}/api/v1/admin/cleanup-sessions`, {
        method: 'POST',
        headers: {
          'Authorization': `Bearer ${authToken}`,
          'Content-Type': 'application/json'
        }
      });

      if (!response.ok) {
        throw new Error(`HTTP ${response.status}: ${response.statusText}`);
      }

      setSnackbar({
        open: true,
        message: 'Inactive sessions cleaned up successfully',
        severity: 'success'
      });

      // Refresh the user list
      fetchActiveUsers();
    } catch (err) {
      console.error('Error cleaning up sessions:', err);
      setSnackbar({
        open: true,
        message: 'Failed to cleanup sessions',
        severity: 'error'
      });
    }
  };

  const formatDateTime = (isoString: string) => {
    try {
      return new Date(isoString).toLocaleString();
    } catch {
      return isoString;
    }
  };

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'active':
        return 'success';
      case 'inactive':
        return 'warning';
      default:
        return 'default';
    }
  };

  useEffect(() => {
    fetchActiveUsers();
    fetchAdminStats();

    // Set up auto-refresh every 30 seconds
    const interval = setInterval(() => {
      fetchActiveUsers();
      fetchAdminStats();
    }, 30000);

    return () => clearInterval(interval);
  }, [authToken]);

  useEffect(() => {
    if (selectedUser) {
      fetchUserDetails(selectedUser);
    }
  }, [selectedUser]);

  if (loading && activeUsers.length === 0) {
    return (
      <Box display="flex" justifyContent="center" alignItems="center" minHeight="400px">
        <CircularProgress />
      </Box>
    );
  }

  return (
    <Box sx={{ p: 3 }}>
      {/* Header */}
      <Box display="flex" justifyContent="space-between" alignItems="center" mb={3}>
        <Typography variant="h4" component="h1">
          Admin Dashboard - User Monitoring
        </Typography>
        <Box>
          <Button
            variant="outlined"
            startIcon={<CleanupIcon />}
            onClick={cleanupSessions}
            sx={{ mr: 1 }}
          >
            Cleanup Sessions
          </Button>
          <Button
            variant="contained"
            startIcon={<RefreshIcon />}
            onClick={() => {
              fetchActiveUsers();
              fetchAdminStats();
            }}
            disabled={loading}
          >
            Refresh
          </Button>
        </Box>
      </Box>

      {error && (
        <Alert severity="error" sx={{ mb: 3 }}>
          {error}
        </Alert>
      )}

      {/* Statistics Cards */}
      {stats && (
        <Grid container spacing={3} sx={{ mb: 3 }}>
          <Grid item xs={12} sm={6} md={3}>
            <Card>
              <CardContent>
                <Typography color="textSecondary" gutterBottom>
                  Active Users
                </Typography>
                <Typography variant="h4">
                  {stats.total_active_users}
                </Typography>
              </CardContent>
            </Card>
          </Grid>
          <Grid item xs={12} sm={6} md={3}>
            <Card>
              <CardContent>
                <Typography color="textSecondary" gutterBottom>
                  Total Sessions Today
                </Typography>
                <Typography variant="h4">
                  {stats.total_sessions_today}
                </Typography>
              </CardContent>
            </Card>
          </Grid>
          <Grid item xs={12} sm={6} md={3}>
            <Card>
              <CardContent>
                <Typography color="textSecondary" gutterBottom>
                  Avg Session Duration
                </Typography>
                <Typography variant="h4">
                  {stats.average_session_duration}
                </Typography>
              </CardContent>
            </Card>
          </Grid>
          <Grid item xs={12} sm={6} md={3}>
            <Card>
              <CardContent>
                <Typography color="textSecondary" gutterBottom>
                  Most Active User
                </Typography>
                <Typography variant="h6">
                  {stats.most_active_user || 'N/A'}
                </Typography>
              </CardContent>
            </Card>
          </Grid>
        </Grid>
      )}

      {/* Active Users Table */}
      <Card>
        <CardContent>
          <Typography variant="h6" gutterBottom>
            Currently Active Users ({activeUsers.length})
          </Typography>
          
          {activeUsers.length === 0 ? (
            <Typography color="textSecondary" sx={{ textAlign: 'center', py: 4 }}>
              No active users found
            </Typography>
          ) : (
            <TableContainer component={Paper} sx={{ mt: 2 }}>
              <Table>
                <TableHead>
                  <TableRow>
                    <TableCell>Username</TableCell>
                    <TableCell>Email</TableCell>
                    <TableCell>Login Time</TableCell>
                    <TableCell>Last Activity</TableCell>
                    <TableCell>Duration</TableCell>
                    <TableCell>Sessions</TableCell>
                    <TableCell>Messages</TableCell>
                    <TableCell>Status</TableCell>
                    <TableCell>Actions</TableCell>
                  </TableRow>
                </TableHead>
                <TableBody>
                  {activeUsers.map((user) => (
                    <TableRow key={user.username}>
                      <TableCell>
                        <Box display="flex" alignItems="center">
                          <PersonIcon sx={{ mr: 1, color: 'primary.main' }} />
                          {user.username}
                        </Box>
                      </TableCell>
                      <TableCell>{user.email}</TableCell>
                      <TableCell>{formatDateTime(user.login_time)}</TableCell>
                      <TableCell>{formatDateTime(user.last_activity)}</TableCell>
                      <TableCell>{user.session_duration}</TableCell>
                      <TableCell>{user.chat_sessions}</TableCell>
                      <TableCell>{user.messages_sent}</TableCell>
                      <TableCell>
                        <Chip
                          label={user.status}
                          color={getStatusColor(user.status) as any}
                          size="small"
                        />
                      </TableCell>
                      <TableCell>
                        <Tooltip title="View Details">
                          <IconButton
                            size="small"
                            onClick={() => setSelectedUser(user.username)}
                          >
                            <InfoIcon />
                          </IconButton>
                        </Tooltip>
                        <Tooltip title="Force Logout">
                          <IconButton
                            size="small"
                            color="error"
                            onClick={() => forceLogout(user.username)}
                          >
                            <LogoutIcon />
                          </IconButton>
                        </Tooltip>
                      </TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            </TableContainer>
          )}
        </CardContent>
      </Card>

      {/* User Details Dialog */}
      <Dialog
        open={!!selectedUser}
        onClose={() => setSelectedUser(null)}
        maxWidth="md"
        fullWidth
      >
        <DialogTitle>
          User Details: {selectedUser}
        </DialogTitle>
        <DialogContent>
          {detailsLoading ? (
            <Box display="flex" justifyContent="center" p={3}>
              <CircularProgress />
            </Box>
          ) : userDetails ? (
            <Box>
              <Typography variant="h6" gutterBottom>Session Information</Typography>
              <Grid container spacing={2}>
                <Grid item xs={6}>
                  <Typography><strong>Username:</strong> {userDetails.username}</Typography>
                </Grid>
                <Grid item xs={6}>
                  <Typography><strong>Email:</strong> {userDetails.email}</Typography>
                </Grid>
                <Grid item xs={6}>
                  <Typography><strong>Login Time:</strong> {formatDateTime(userDetails.login_time)}</Typography>
                </Grid>
                <Grid item xs={6}>
                  <Typography><strong>Last Activity:</strong> {formatDateTime(userDetails.last_activity)}</Typography>
                </Grid>
                <Grid item xs={6}>
                  <Typography><strong>Chat Sessions:</strong> {userDetails.chat_sessions}</Typography>
                </Grid>
                <Grid item xs={6}>
                  <Typography><strong>Messages Sent:</strong> {userDetails.messages_sent}</Typography>
                </Grid>
                <Grid item xs={6}>
                  <Typography><strong>Status:</strong> {userDetails.status}</Typography>
                </Grid>
                <Grid item xs={6}>
                  <Typography><strong>Session ID:</strong> {userDetails.session_id}</Typography>
                </Grid>
              </Grid>
            </Box>
          ) : (
            <Typography>No details available</Typography>
          )}
        </DialogContent>
        <DialogActions>
          <Button onClick={() => setSelectedUser(null)}>Close</Button>
          <Button
            color="error"
            onClick={() => selectedUser && forceLogout(selectedUser)}
          >
            Force Logout
          </Button>
        </DialogActions>
      </Dialog>

      {/* Snackbar for notifications */}
      <Snackbar
        open={snackbar.open}
        autoHideDuration={6000}
        onClose={() => setSnackbar({ ...snackbar, open: false })}
      >
        <Alert
          onClose={() => setSnackbar({ ...snackbar, open: false })}
          severity={snackbar.severity}
          sx={{ width: '100%' }}
        >
          {snackbar.message}
        </Alert>
      </Snackbar>
    </Box>
  );
};

export default AdminDashboard;
