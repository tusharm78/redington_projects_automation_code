import React, { useState } from 'react';
import {
  Box,
  Paper,
  TextField,
  Button,
  Typography,
  Container,
  Avatar,
  CircularProgress,
} from '@mui/material';
import SendIcon from '@mui/icons-material/Send';
import SmartToyIcon from '@mui/icons-material/SmartToy';
import PersonIcon from '@mui/icons-material/Person';
import { apiService } from '../services/api';

interface Message {
  id: string;
  role: 'user' | 'assistant';
  content: string;
  timestamp: string;
}

const SimpleChat: React.FC = () => {
  const [messages, setMessages] = useState<Message[]>([]);
  const [inputMessage, setInputMessage] = useState('');
  const [loading, setLoading] = useState(false);

  const redingtonTheme = {
    primary: '#1976d2',
    secondary: '#dc004e',
    background: '#f5f5f5',
    surface: '#ffffff',
    text: '#333333',
    textSecondary: '#666666',
    gradient: 'linear-gradient(135deg, #1976d2 0%, #dc004e 100%)',
  };

  const handleSendMessage = async () => {
    if (!inputMessage.trim()) return;

    const userMessage: Message = {
      id: Date.now().toString(),
      role: 'user',
      content: inputMessage,
      timestamp: new Date().toISOString(),
    };

    setMessages(prev => [...prev, userMessage]);
    const currentInput = inputMessage;
    setInputMessage('');
    setLoading(true);

    try {
      // Call the actual backend API
      const response = await apiService.sendMessage({
        message: currentInput,
        conversation_id: 'simple-chat-session'
      });

      const aiMessage: Message = {
        id: (Date.now() + 1).toString(),
        role: 'assistant',
        content: response.response,
        timestamp: new Date().toISOString(),
      };

      setMessages(prev => [...prev, aiMessage]);
    } catch (error) {
      console.error('Error sending message:', error);
      
      // Fallback message if API fails
      const errorMessage: Message = {
        id: (Date.now() + 1).toString(),
        role: 'assistant',
        content: 'Sorry, I encountered an error while processing your message. Please try again.',
        timestamp: new Date().toISOString(),
      };
      
      setMessages(prev => [...prev, errorMessage]);
    } finally {
      setLoading(false);
    }
  };

  const handleKeyPress = (event: React.KeyboardEvent) => {
    if (event.key === 'Enter' && !event.shiftKey) {
      event.preventDefault();
      handleSendMessage();
    }
  };

  return (
    <Box
      sx={{
        height: '100vh',
        display: 'flex',
        flexDirection: 'column',
        background: `linear-gradient(to bottom, ${redingtonTheme.background}, #ffffff)`,
      }}
    >
      {/* Header */}
      <Paper
        elevation={2}
        sx={{
          p: 2,
          background: redingtonTheme.gradient,
          color: 'white',
        }}
      >
        <Container maxWidth="md">
          <Typography variant="h5" sx={{ fontWeight: 'bold' }}>
            🤖 Redington AI Assistant
          </Typography>
          <Typography variant="body2" sx={{ opacity: 0.9 }}>
            Your intelligent technology solutions partner
          </Typography>
        </Container>
      </Paper>

      {/* Messages Area */}
      <Box
        sx={{
          flex: 1,
          overflow: 'auto',
          p: 2,
        }}
      >
        <Container maxWidth="md">
          {messages.length === 0 ? (
            <Box
              sx={{
                display: 'flex',
                flexDirection: 'column',
                alignItems: 'center',
                justifyContent: 'center',
                height: '100%',
                textAlign: 'center',
              }}
            >
              <SmartToyIcon sx={{ fontSize: 80, color: redingtonTheme.primary, mb: 2 }} />
              <Typography variant="h4" sx={{ mb: 2, color: redingtonTheme.text }}>
                Welcome to Redington AI
              </Typography>
              <Typography variant="body1" sx={{ color: redingtonTheme.textSecondary, mb: 4 }}>
                Ask me anything about technology solutions, business strategies, or get help with your projects.
              </Typography>
              <Typography variant="body2" sx={{ color: redingtonTheme.textSecondary, fontStyle: 'italic' }}>
                Connected to backend API at {process.env.REACT_APP_API_URL || '/api/v1'}
              </Typography>
            </Box>
          ) : (
            messages.map((message) => (
              <Box
                key={message.id}
                sx={{
                  display: 'flex',
                  mb: 3,
                  justifyContent: message.role === 'user' ? 'flex-end' : 'flex-start',
                }}
              >
                {message.role === 'assistant' && (
                  <Avatar
                    sx={{
                      background: redingtonTheme.gradient,
                      mr: 2,
                      mt: 0.5,
                    }}
                  >
                    <SmartToyIcon />
                  </Avatar>
                )}

                <Paper
                  elevation={2}
                  sx={{
                    p: 2,
                    maxWidth: '70%',
                    background: message.role === 'user' 
                      ? redingtonTheme.gradient 
                      : redingtonTheme.surface,
                    color: message.role === 'user' ? 'white' : redingtonTheme.text,
                    borderRadius: 3,
                  }}
                >
                  <Typography variant="body1">
                    {message.content}
                  </Typography>
                  <Typography
                    variant="caption"
                    sx={{
                      display: 'block',
                      mt: 1,
                      opacity: 0.7,
                      textAlign: message.role === 'user' ? 'right' : 'left',
                    }}
                  >
                    {new Date(message.timestamp).toLocaleTimeString()}
                  </Typography>
                </Paper>

                {message.role === 'user' && (
                  <Avatar
                    sx={{
                      background: redingtonTheme.textSecondary,
                      ml: 2,
                      mt: 0.5,
                    }}
                  >
                    <PersonIcon />
                  </Avatar>
                )}
              </Box>
            ))
          )}

          {loading && (
            <Box sx={{ display: 'flex', alignItems: 'center', mb: 2 }}>
              <Avatar sx={{ background: redingtonTheme.gradient, mr: 2 }}>
                <SmartToyIcon />
              </Avatar>
              <Paper
                elevation={1}
                sx={{
                  p: 2,
                  background: redingtonTheme.surface,
                  borderRadius: 3,
                }}
              >
                <Box sx={{ display: 'flex', alignItems: 'center' }}>
                  <CircularProgress size={16} sx={{ mr: 1 }} />
                  <Typography variant="body2" sx={{ color: redingtonTheme.textSecondary }}>
                    AI is thinking...
                  </Typography>
                </Box>
              </Paper>
            </Box>
          )}
        </Container>
      </Box>

      {/* Input Area */}
      <Paper
        elevation={3}
        sx={{
          p: 2,
          background: redingtonTheme.surface,
          borderTop: `1px solid ${redingtonTheme.background}`,
        }}
      >
        <Container maxWidth="md">
          <Box sx={{ display: 'flex', alignItems: 'flex-end', gap: 1 }}>
            <TextField
              fullWidth
              multiline
              maxRows={4}
              value={inputMessage}
              onChange={(e) => setInputMessage(e.target.value)}
              onKeyPress={handleKeyPress}
              placeholder="Ask me anything about technology solutions..."
              variant="outlined"
              disabled={loading}
              sx={{
                '& .MuiOutlinedInput-root': {
                  borderRadius: 3,
                  backgroundColor: redingtonTheme.background,
                  '&:hover .MuiOutlinedInput-notchedOutline': {
                    borderColor: redingtonTheme.primary,
                  },
                  '&.Mui-focused .MuiOutlinedInput-notchedOutline': {
                    borderColor: redingtonTheme.primary,
                  },
                },
              }}
            />

            <Button
              variant="contained"
              onClick={handleSendMessage}
              disabled={loading || !inputMessage.trim()}
              sx={{
                minWidth: 60,
                height: 56,
                borderRadius: 3,
                background: redingtonTheme.gradient,
                '&:hover': { opacity: 0.9 },
                '&:disabled': { opacity: 0.5 },
              }}
            >
              {loading ? (
                <CircularProgress size={24} color="inherit" />
              ) : (
                <SendIcon />
              )}
            </Button>
          </Box>
        </Container>
      </Paper>
    </Box>
  );
};

export default SimpleChat;
