import React from 'react';
import { Box, Paper, Avatar, Typography, Slide } from '@mui/material';
import { Person as PersonIcon, SmartToy as BotIcon } from '@mui/icons-material';
import ResponseActions from './ResponseActions';
import MessageRenderer from './MessageRenderer';
import { detectResponseType, extractContentMetadata } from '../utils/responseTemplates';
import { ChatMessage } from '../types';

interface EnhancedMessageDisplayProps {
  message: ChatMessage;
  isStreaming?: boolean;
  streamingMessageId?: string;
  onSaveMessage?: (messageId: string, tags: string[]) => void;
  onShareMessage?: (content: string, format: string) => void;
  onTranslateMessage?: (content: string, language: string) => void;
}

const redingtonTheme = {
  primary: '#28A745', // Changed from red to green
  secondary: '#1A1A1A',
  accent: '#4CAF50', // Changed from orange to light green
  background: '#F8F9FA',
  surface: '#FFFFFF',
  text: '#2C3E50',
  textSecondary: '#6C757D',
  gradient: 'linear-gradient(135deg, #28A745 0%, #4CAF50 100%)', // Changed to green gradient
};

const EnhancedMessageDisplay: React.FC<EnhancedMessageDisplayProps> = ({
  message,
  isStreaming = false,
  streamingMessageId,
  onSaveMessage,
  onShareMessage,
  onTranslateMessage,
}) => {
  const isCurrentlyStreaming = message.message_id === streamingMessageId && isStreaming;
  
  // Detect message type and extract metadata for assistant messages
  const messageType = message.role === 'assistant' ? detectResponseType(message.content) : 'general';
  const metadata = message.role === 'assistant' ? extractContentMetadata(message.content) : undefined;

  return (
    <Slide direction="up" in={true} mountOnEnter unmountOnExit>
      <Box
        sx={{
          display: 'flex',
          alignItems: 'flex-start',
          mb: 3,
          flexDirection: message.role === 'user' ? 'row-reverse' : 'row',
        }}
      >
        {/* Avatar */}
        {message.role === 'assistant' && (
          <Avatar
            sx={{
              background: redingtonTheme.gradient,
              mr: 2,
              mt: 0.5,
              width: 40,
              height: 40,
            }}
          >
            <BotIcon />
          </Avatar>
        )}

        {/* Message Content */}
        <Box sx={{ flex: 1, maxWidth: '85%' }}>
          {message.role === 'assistant' ? (
            // Simple display for assistant messages
            <Paper
              elevation={1}
              sx={{
                p: 2,
                backgroundColor: redingtonTheme.surface,
                borderRadius: 3,
                border: `1px solid ${redingtonTheme.primary}20`,
              }}
            >
              <MessageRenderer
                content={message.content}
                isStreaming={isCurrentlyStreaming}
              />
              
              <Typography
                variant="caption"
                sx={{
                  display: 'block',
                  mt: 1,
                  color: redingtonTheme.textSecondary,
                  textAlign: 'left',
                }}
              >
                {message.timestamp 
                  ? new Date(message.timestamp).toLocaleTimeString() 
                  : new Date().toLocaleTimeString()
                }
              </Typography>

              {/* Response Actions */}
              {!isCurrentlyStreaming && (
                <Box sx={{ mt: 1, display: 'flex', justifyContent: 'flex-end' }}>
                  <ResponseActions
                    content={message.content}
                    messageId={message.message_id || ''}
                    messageType={messageType as any}
                    sessionId={message.session_id} // Pass session ID for customer name replacement
                    onSave={onSaveMessage}
                    onShare={onShareMessage}
                    onTranslate={onTranslateMessage}
                  />
                </Box>
              )}
            </Paper>
          ) : (
            // Standard display for user messages
            <Paper
              elevation={2}
              sx={{
                p: 2,
                backgroundColor: redingtonTheme.primary,
                color: 'white',
                borderRadius: 3,
                position: 'relative',
                maxWidth: 'fit-content',
                ml: 'auto',
              }}
            >
              <MessageRenderer
                content={message.content}
                isStreaming={false}
              />
              
              <Typography
                variant="caption"
                sx={{
                  display: 'block',
                  mt: 1,
                  opacity: 0.8,
                  textAlign: 'right',
                }}
              >
                {message.timestamp 
                  ? new Date(message.timestamp).toLocaleTimeString() 
                  : new Date().toLocaleTimeString()
                }
              </Typography>
            </Paper>
          )}
        </Box>

        {/* User Avatar */}
        {message.role === 'user' && (
          <Avatar
            sx={{
              background: redingtonTheme.textSecondary,
              ml: 2,
              mt: 0.5,
              width: 40,
              height: 40,
            }}
          >
            <PersonIcon />
          </Avatar>
        )}
      </Box>
    </Slide>
  );
};

export default EnhancedMessageDisplay;
