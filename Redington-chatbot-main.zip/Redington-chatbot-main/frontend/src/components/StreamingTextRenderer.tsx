import React, { useMemo, useCallback, useRef, useEffect } from 'react';
import { Box, Typography } from '@mui/material';
import ReactMarkdown from 'react-markdown';
import { Prism as SyntaxHighlighter } from 'react-syntax-highlighter';
import { tomorrow } from 'react-syntax-highlighter/dist/esm/styles/prism';
import remarkGfm from 'remark-gfm';

interface StreamingTextRendererProps {
  content: string;
}

// TypeScript interfaces for ReactMarkdown components
interface CodeProps {
  node?: any;
  inline?: boolean;
  className?: string;
  children?: React.ReactNode;
  [key: string]: any;
}

interface MarkdownComponentProps {
  node?: any;
  children?: React.ReactNode;
  [key: string]: any;
}

const StreamingTextRenderer: React.FC<StreamingTextRendererProps> = React.memo(({ content }) => {
  const containerRef = useRef<HTMLDivElement>(null);
  const lastContentRef = useRef<string>('');
  
  // Optimize content processing with better memoization
  const processedContent = useMemo(() => {
    if (!content || content === lastContentRef.current) return lastContentRef.current;
    
    let processed = content;
    
    // Fix incomplete markdown structures during streaming
    // Handle incomplete code blocks
    const codeBlockMatches = processed.match(/```[^`]*$/);
    if (codeBlockMatches) {
      processed += '\n```';
    }
    
    // Handle incomplete tables
    const lines = processed.split('\n');
    const lastLine = lines[lines.length - 1];
    if (lastLine && lastLine.includes('|') && !lastLine.trim().endsWith('|')) {
      // Don't modify incomplete table rows to prevent flickering
    }
    
    lastContentRef.current = processed;
    return processed;
  }, [content]);

  // Memoized code component to prevent re-creation
  const CodeComponent = useCallback(({ node, inline, className, children, ...props }: CodeProps) => {
    const match = /language-(\w+)/.exec(className || '');
    return !inline && match ? (
      <Box sx={{ mb: 1.5 }}>
        <SyntaxHighlighter
          style={tomorrow}
          language={match[1]}
          PreTag="div"
          customStyle={{
            borderRadius: 6,
            fontSize: '0.85rem',
            margin: 0,
          }}
          {...props}
        >
          {String(children).replace(/\n$/, '')}
        </SyntaxHighlighter>
      </Box>
    ) : (
      <Box
        component="code"
        sx={{
          bgcolor: '#f4f4f4',
          color: '#2C3E50',
          px: 0.5,
          py: 0.2,
          borderRadius: 0.5,
          fontSize: '0.85rem',
          fontFamily: 'monospace',
          transition: 'none'
        }}
        {...props}
      >
        {children}
      </Box>
    );
  }, []);

  // Memoized markdown components to prevent re-creation
  const markdownComponents = useMemo(() => ({
    h1: ({ children }: MarkdownComponentProps) => (
      <Typography 
        variant="h4" 
        component="h1" 
        sx={{ 
          mb: 1.5, 
          mt: 2, 
          fontWeight: 700, 
          color: '#2C3E50',
          transition: 'none' // Disable transitions to prevent flickering
        }}
      >
        {children}
      </Typography>
    ),
    h2: ({ children }: MarkdownComponentProps) => (
      <Typography 
        variant="h5" 
        component="h2" 
        sx={{ 
          mb: 1.5, 
          mt: 2, 
          fontWeight: 600, 
          color: '#2C3E50',
          transition: 'none'
        }}
      >
        {children}
      </Typography>
    ),
    h3: ({ children }: MarkdownComponentProps) => (
      <Typography 
        variant="h6" 
        component="h3" 
        sx={{ 
          mb: 1, 
          mt: 1.5, 
          fontWeight: 600, 
          color: '#2C3E50',
          transition: 'none'
        }}
      >
        {children}
      </Typography>
    ),
    p: ({ children }: MarkdownComponentProps) => (
      <Typography 
        variant="body1" 
        sx={{ 
          mb: 1, 
          lineHeight: 1.6, 
          color: '#2C3E50',
          transition: 'none'
        }}
      >
        {children}
      </Typography>
    ),
    ul: ({ children }: MarkdownComponentProps) => (
      <Box 
        component="ul" 
        sx={{ 
          mb: 1.5, 
          pl: 2, 
          color: '#2C3E50',
          transition: 'none'
        }}
      >
        {children}
      </Box>
    ),
    ol: ({ children }: MarkdownComponentProps) => (
      <Box 
        component="ol" 
        sx={{ 
          mb: 1.5, 
          pl: 2, 
          color: '#2C3E50',
          transition: 'none'
        }}
      >
        {children}
      </Box>
    ),
    li: ({ children }: MarkdownComponentProps) => (
      <Typography 
        component="li" 
        variant="body1" 
        sx={{ 
          mb: 0.3, 
          lineHeight: 1.5, 
          color: '#2C3E50',
          transition: 'none'
        }}
      >
        {children}
      </Typography>
    ),
    code: CodeComponent,
    blockquote: ({ children }: MarkdownComponentProps) => (
      <Box
        sx={{
          borderLeft: '4px solid #00A651',
          bgcolor: '#f9f9f9',
          p: 1.5,
          mb: 1.5,
          borderRadius: '0 6px 6px 0',
          transition: 'none'
        }}
      >
        <Typography variant="body1" sx={{ fontStyle: 'italic', color: '#555', margin: 0 }}>
          {children}
        </Typography>
      </Box>
    ),
    strong: ({ children }: MarkdownComponentProps) => (
      <Typography component="strong" sx={{ fontWeight: 700, color: '#2C3E50' }}>
        {children}
      </Typography>
    ),
    em: ({ children }: MarkdownComponentProps) => (
      <Typography component="em" sx={{ fontStyle: 'italic', color: '#2C3E50' }}>
        {children}
      </Typography>
    ),
    table: ({ children }: MarkdownComponentProps) => (
      <Box
        component="table"
        sx={{
          width: '100%',
          borderCollapse: 'collapse',
          mb: 1.5,
          border: '1px solid #e0e0e0',
          fontSize: '0.9rem',
          transition: 'none'
        }}
      >
        {children}
      </Box>
    ),
    th: ({ children }: MarkdownComponentProps) => (
      <Box
        component="th"
        sx={{
          p: 1,
          textAlign: 'left',
          borderBottom: '2px solid #00A651',
          bgcolor: '#f5f5f5',
          fontWeight: 'bold',
          color: '#2C3E50',
          transition: 'none'
        }}
      >
        {children}
      </Box>
    ),
    td: ({ children }: MarkdownComponentProps) => (
      <Box
        component="td"
        sx={{
          p: 1,
          textAlign: 'left',
          borderBottom: '1px solid #e0e0e0',
          color: '#2C3E50',
          transition: 'none'
        }}
      >
        {children}
      </Box>
    ),
    a: ({ children, href }: MarkdownComponentProps) => (
      <Box
        component="a"
        href={href}
        target="_blank"
        rel="noopener noreferrer"
        sx={{
          color: '#00A651',
          textDecoration: 'underline',
          '&:hover': {
            textDecoration: 'none',
          },
          transition: 'none'
        }}
      >
        {children}
      </Box>
    ),
    hr: () => (
      <Box
        component="hr"
        sx={{
          border: 'none',
          borderTop: '2px solid #e0e0e0',
          my: 2,
          transition: 'none'
        }}
      />
    ),
  }), [CodeComponent]);

  // Smooth scroll to bottom when content updates
  useEffect(() => {
    if (containerRef.current) {
      const container = containerRef.current;
      const shouldScroll = container.scrollTop + container.clientHeight >= container.scrollHeight - 100;
      
      if (shouldScroll) {
        // Use requestAnimationFrame for smooth scrolling
        requestAnimationFrame(() => {
          container.scrollTo({
            top: container.scrollHeight,
            behavior: 'smooth'
          });
        });
      }
    }
  }, [content]);

  return (
    <Box
      ref={containerRef}
      sx={{
        position: 'relative',
        // Optimize rendering performance
        willChange: 'contents',
        contain: 'layout style',
        // Smooth cursor animation
        '& .streaming-cursor': {
          display: 'inline-block',
          width: '3px',
          height: '1.2em',
          backgroundColor: '#00A651',
          marginLeft: '2px',
          animation: 'streamingBlink 1.2s ease-in-out infinite',
          // Use transform for better performance
          transform: 'translateZ(0)',
        },
        '@keyframes streamingBlink': {
          '0%, 50%': { opacity: 1 },
          '51%, 100%': { opacity: 0.3 },
        },
        // Prevent layout shifts
        '& *': {
          boxSizing: 'border-box',
        },
        // Optimize text rendering
        textRendering: 'optimizeSpeed',
        // Prevent font loading flicker
        fontDisplay: 'swap',
      }}
    >
      <ReactMarkdown
        remarkPlugins={[remarkGfm]}
        components={markdownComponents}
        // Optimize ReactMarkdown performance
        skipHtml={false}
      >
        {processedContent}
      </ReactMarkdown>
      
      {/* Optimized streaming cursor */}
      <span className="streaming-cursor" />
    </Box>
  );
});

// Set display name for debugging
StreamingTextRenderer.displayName = 'StreamingTextRenderer';

export default StreamingTextRenderer;
