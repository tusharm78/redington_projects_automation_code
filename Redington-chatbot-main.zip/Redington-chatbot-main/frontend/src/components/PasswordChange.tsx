import React, { useState } from 'react';
import {
  Box,
  TextField,
  Button,
  Typography,
  Alert,
  CircularProgress,
  Paper,
  Container,
  InputAdornment,
  IconButton,
  Stack,
} from '@mui/material';
import {
  Lock as LockIcon,
  Visibility,
  VisibilityOff,
  Security as SecurityIcon,
} from '@mui/icons-material';
import apiService from '../services/api';

// Redington Brand Colors
const redingtonTheme = {
  primary: '#00A651',
  secondary: '#1A1A1A',
  accent: '#66CC99',
  background: '#F8F9FA',
  surface: '#FFFFFF',
  text: '#2C3E50',
  textSecondary: '#6C757D',
  gradient: 'linear-gradient(135deg, #00A651 0%, #66CC99 100%)',
};

interface PasswordChangeProps {
  username: string;
  session: string;
  onPasswordChanged: (authResponse: any) => void;
  onCancel: () => void;
}

const PasswordChange: React.FC<PasswordChangeProps> = ({
  username,
  session,
  onPasswordChanged,
  onCancel,
}) => {
  console.log('🔑 PasswordChange component rendered');
  console.log('🔑 Props:', { username, session: session ? 'Present' : 'Missing', onPasswordChanged: !!onPasswordChanged, onCancel: !!onCancel });
  
  const [newPassword, setNewPassword] = useState('');
  const [confirmPassword, setConfirmPassword] = useState('');
  const [showPassword, setShowPassword] = useState(false);
  const [showConfirmPassword, setShowConfirmPassword] = useState(false);
  const [error, setError] = useState('');
  const [loading, setLoading] = useState(false);

  const validatePassword = (password: string): string[] => {
    const errors: string[] = [];
    
    if (password.length < 8) {
      errors.push('Password must be at least 8 characters long');
    }
    if (!/[A-Z]/.test(password)) {
      errors.push('Password must contain at least one uppercase letter');
    }
    if (!/[a-z]/.test(password)) {
      errors.push('Password must contain at least one lowercase letter');
    }
    if (!/[0-9]/.test(password)) {
      errors.push('Password must contain at least one number');
    }
    if (!/[!@#$%^&*()_+\-=\[\]{};':"\\|,.<>\/?]/.test(password)) {
      errors.push('Password must contain at least one special character');
    }
    
    return errors;
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError('');
    console.log('🔑 PasswordChange handleSubmit called');

    // Validate passwords match
    if (newPassword !== confirmPassword) {
      setError('Passwords do not match');
      return;
    }

    // Validate password strength
    const passwordErrors = validatePassword(newPassword);
    if (passwordErrors.length > 0) {
      setError(passwordErrors.join('. '));
      return;
    }

    setLoading(true);

    try {
      console.log('🔑 Calling apiService.changePassword');
      const response = await apiService.changePassword(username, newPassword, session);
      console.log('🔑 Password change successful:', response);
      onPasswordChanged(response);
    } catch (err: any) {
      console.error('🔑 Password change error:', err);
      const errorDetail = err.response?.data?.detail;
      setError(errorDetail || 'Failed to change password');
    } finally {
      setLoading(false);
    }
  };

  const passwordStrength = (password: string): { score: number; label: string; color: string } => {
    const errors = validatePassword(password);
    const score = Math.max(0, 5 - errors.length);
    
    if (score === 0) return { score, label: 'Very Weak', color: '#f44336' };
    if (score === 1) return { score, label: 'Weak', color: '#ff9800' };
    if (score === 2) return { score, label: 'Fair', color: '#ff9800' };
    if (score === 3) return { score, label: 'Good', color: '#4caf50' };
    if (score === 4) return { score, label: 'Strong', color: '#4caf50' };
    return { score, label: 'Very Strong', color: '#4caf50' };
  };

  const strength = passwordStrength(newPassword);

  return (
    <Box
      sx={{
        minHeight: '100vh',
        background: redingtonTheme.gradient,
        display: 'flex',
        alignItems: 'center',
        justifyContent: 'center',
        padding: 2,
      }}
    >
      <Container maxWidth="sm">
        <Paper
          elevation={8}
          sx={{
            padding: 4,
            borderRadius: 3,
            background: redingtonTheme.surface,
            boxShadow: '0 8px 32px rgba(0,0,0,0.1)',
          }}
        >
          <Box sx={{ textAlign: 'center', mb: 3 }}>
            <SecurityIcon
              sx={{
                fontSize: 48,
                color: redingtonTheme.primary,
                mb: 2,
              }}
            />
            <Typography
              variant="h4"
              sx={{
                fontWeight: 700,
                color: redingtonTheme.text,
                mb: 1,
              }}
            >
              Set New Password
            </Typography>
            <Typography
              variant="body1"
              sx={{
                color: redingtonTheme.textSecondary,
                mb: 2,
              }}
            >
              Welcome <strong>{username}</strong>! Please set a new password to continue.
            </Typography>
          </Box>

          {error && (
            <Alert severity="error" sx={{ mb: 3 }}>
              {error}
            </Alert>
          )}

          <form onSubmit={handleSubmit}>
            <Stack spacing={3}>
              <TextField
                fullWidth
                type={showPassword ? 'text' : 'password'}
                label="New Password"
                value={newPassword}
                onChange={(e) => setNewPassword(e.target.value)}
                required
                InputProps={{
                  startAdornment: (
                    <InputAdornment position="start">
                      <LockIcon sx={{ color: redingtonTheme.primary }} />
                    </InputAdornment>
                  ),
                  endAdornment: (
                    <InputAdornment position="end">
                      <IconButton
                        onClick={() => setShowPassword(!showPassword)}
                        edge="end"
                      >
                        {showPassword ? <VisibilityOff /> : <Visibility />}
                      </IconButton>
                    </InputAdornment>
                  ),
                }}
                sx={{
                  '& .MuiOutlinedInput-root': {
                    '&:hover fieldset': {
                      borderColor: redingtonTheme.primary,
                    },
                    '&.Mui-focused fieldset': {
                      borderColor: redingtonTheme.primary,
                    },
                  },
                }}
              />

              {newPassword && (
                <Box>
                  <Typography variant="body2" sx={{ mb: 1 }}>
                    Password Strength: <span style={{ color: strength.color, fontWeight: 'bold' }}>
                      {strength.label}
                    </span>
                  </Typography>
                  <Box
                    sx={{
                      width: '100%',
                      height: 4,
                      backgroundColor: '#e0e0e0',
                      borderRadius: 2,
                      overflow: 'hidden',
                    }}
                  >
                    <Box
                      sx={{
                        width: `${(strength.score / 5) * 100}%`,
                        height: '100%',
                        backgroundColor: strength.color,
                        transition: 'all 0.3s ease',
                      }}
                    />
                  </Box>
                </Box>
              )}

              <TextField
                fullWidth
                type={showConfirmPassword ? 'text' : 'password'}
                label="Confirm New Password"
                value={confirmPassword}
                onChange={(e) => setConfirmPassword(e.target.value)}
                required
                InputProps={{
                  startAdornment: (
                    <InputAdornment position="start">
                      <LockIcon sx={{ color: redingtonTheme.primary }} />
                    </InputAdornment>
                  ),
                  endAdornment: (
                    <InputAdornment position="end">
                      <IconButton
                        onClick={() => setShowConfirmPassword(!showConfirmPassword)}
                        edge="end"
                      >
                        {showConfirmPassword ? <VisibilityOff /> : <Visibility />}
                      </IconButton>
                    </InputAdornment>
                  ),
                }}
                sx={{
                  '& .MuiOutlinedInput-root': {
                    '&:hover fieldset': {
                      borderColor: redingtonTheme.primary,
                    },
                    '&.Mui-focused fieldset': {
                      borderColor: redingtonTheme.primary,
                    },
                  },
                }}
              />

              <Box sx={{ display: 'flex', gap: 2 }}>
                <Button
                  variant="outlined"
                  onClick={onCancel}
                  disabled={loading}
                  sx={{
                    flex: 1,
                    borderColor: redingtonTheme.textSecondary,
                    color: redingtonTheme.textSecondary,
                    '&:hover': {
                      borderColor: redingtonTheme.primary,
                      color: redingtonTheme.primary,
                    },
                  }}
                >
                  Cancel
                </Button>
                <Button
                  type="submit"
                  variant="contained"
                  disabled={loading || !newPassword || !confirmPassword}
                  sx={{
                    flex: 2,
                    background: redingtonTheme.gradient,
                    '&:hover': {
                      background: redingtonTheme.gradient,
                      opacity: 0.9,
                    },
                    '&:disabled': {
                      background: '#ccc',
                    },
                  }}
                >
                  {loading ? (
                    <CircularProgress size={24} color="inherit" />
                  ) : (
                    'Set Password'
                  )}
                </Button>
              </Box>
            </Stack>
          </form>

          <Box sx={{ mt: 3, p: 2, backgroundColor: '#f5f5f5', borderRadius: 2 }}>
            <Typography variant="body2" sx={{ fontWeight: 'bold', mb: 1 }}>
              Password Requirements:
            </Typography>
            <Typography variant="body2" component="ul" sx={{ margin: 0, paddingLeft: 2 }}>
              <li>At least 8 characters long</li>
              <li>At least one uppercase letter (A-Z)</li>
              <li>At least one lowercase letter (a-z)</li>
              <li>At least one number (0-9)</li>
              <li>At least one special character (!@#$%^&*)</li>
            </Typography>
          </Box>
        </Paper>
      </Container>
    </Box>
  );
};

export default PasswordChange;
