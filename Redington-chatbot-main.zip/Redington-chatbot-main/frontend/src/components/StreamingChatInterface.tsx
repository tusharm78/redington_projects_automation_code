import React, { useState, useEffect, useRef } from 'react';
import {
  Box,
  Paper,
  TextField,
  IconButton,
  Typography,
  Avatar,
  Chip,
  CircularProgress,
  Alert,
  Snackbar,
} from '@mui/material';
import {
  Send as SendIcon,
  Person as PersonIcon,
  SmartToy as BotIcon,
  Refresh as RefreshIcon,
  Clear as ClearIcon,
} from '@mui/icons-material';
import { useStreamingChat } from '../hooks/useStreamingChat';
import { ChatRequest } from '../types';
import EnhancedMessageDisplay from './EnhancedMessageDisplay';

interface StreamingChatInterfaceProps {
  sessionId?: string;
  conversationId?: string;
}

const StreamingChatInterface: React.FC<StreamingChatInterfaceProps> = ({
  sessionId,
  conversationId,
}) => {
  const [inputMessage, setInputMessage] = useState('');
  const [showError, setShowError] = useState(false);
  const messagesEndRef = useRef<HTMLDivElement>(null);

  const {
    messages,
    isConnected,
    isAuthenticated,
    isStreaming,
    sendMessage,
    connect,
    disconnect,
    clearMessages,
    error,
  } = useStreamingChat();

  // Auto-scroll to bottom when new messages arrive
  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [messages]);

  // Connect on mount
  useEffect(() => {
    connect();
    return () => disconnect();
  }, [connect, disconnect]);

  // Show error snackbar
  useEffect(() => {
    if (error) {
      setShowError(true);
    }
  }, [error]);

  const handleSendMessage = async () => {
    if (!inputMessage.trim() || isStreaming || !isAuthenticated) {
      return;
    }

    const request: ChatRequest = {
      message: inputMessage.trim(),
      conversation_id: conversationId,
      session_id: sessionId,
      model_config: {
        temperature: 0.7,
        max_tokens: 2000,
      },
    };

    try {
      await sendMessage(request);
      setInputMessage('');
    } catch (error) {
      console.error('Failed to send message:', error);
    }
  };

  const handleKeyPress = (event: React.KeyboardEvent) => {
    if (event.key === 'Enter' && !event.shiftKey) {
      event.preventDefault();
      handleSendMessage();
    }
  };

  const getConnectionStatus = () => {
    if (!isConnected) return { color: 'error', text: 'Disconnected' };
    if (!isAuthenticated) return { color: 'warning', text: 'Authenticating...' };
    return { color: 'success', text: 'Connected' };
  };

  const connectionStatus = getConnectionStatus();

  return (
    <Box sx={{ height: '100vh', display: 'flex', flexDirection: 'column' }}>
      {/* Header */}
      <Paper
        elevation={1}
        sx={{
          p: 2,
          borderRadius: 0,
          borderBottom: '1px solid',
          borderColor: 'divider',
        }}
      >
        <Box sx={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between' }}>
          <Box sx={{ display: 'flex', alignItems: 'center', gap: 2 }}>
            <Avatar sx={{ bgcolor: 'primary.main' }}>
              <BotIcon />
            </Avatar>
            <Box>
              <Typography variant="h6" sx={{ fontWeight: 600 }}>
                Redington AI Assistant
              </Typography>
              <Typography variant="caption" color="text.secondary">
                Real-time Streaming Chat
              </Typography>
            </Box>
          </Box>
          
          <Box sx={{ display: 'flex', alignItems: 'center', gap: 1 }}>
            <Chip
              label={connectionStatus.text}
              color={connectionStatus.color as any}
              size="small"
              variant="outlined"
            />
            <IconButton onClick={clearMessages} size="small" title="Clear Chat">
              <ClearIcon />
            </IconButton>
            <IconButton onClick={connect} size="small" title="Reconnect">
              <RefreshIcon />
            </IconButton>
          </Box>
        </Box>
      </Paper>

      {/* Messages Area */}
      <Box
        sx={{
          flex: 1,
          overflow: 'auto',
          p: 2,
          backgroundColor: 'background.default',
        }}
      >
        {messages.length === 0 ? (
          <Box
            sx={{
              display: 'flex',
              flexDirection: 'column',
              alignItems: 'center',
              justifyContent: 'center',
              height: '100%',
              textAlign: 'center',
              color: 'text.secondary',
            }}
          >
            <BotIcon sx={{ fontSize: 64, mb: 2, opacity: 0.5 }} />
            <Typography variant="h6" gutterBottom>
              Welcome to Redington AI Assistant
            </Typography>
            <Typography variant="body2">
              Start a conversation by typing a message below.
              <br />
              Experience real-time streaming responses!
            </Typography>
          </Box>
        ) : (
          <Box sx={{ maxWidth: 800, mx: 'auto' }}>
            {messages.map((message, index) => (
              <Box key={message.id || index} sx={{ mb: 3 }}>
                <Box
                  sx={{
                    display: 'flex',
                    alignItems: 'flex-start',
                    gap: 2,
                    flexDirection: message.role === 'user' ? 'row-reverse' : 'row',
                  }}
                >
                  <Avatar
                    sx={{
                      bgcolor: message.role === 'user' ? 'secondary.main' : 'primary.main',
                      width: 32,
                      height: 32,
                    }}
                  >
                    {message.role === 'user' ? <PersonIcon /> : <BotIcon />}
                  </Avatar>
                  
                  <Paper
                    elevation={1}
                    sx={{
                      p: 2,
                      maxWidth: '70%',
                      bgcolor: message.role === 'user' ? 'primary.main' : 'background.paper',
                      color: message.role === 'user' ? 'primary.contrastText' : 'text.primary',
                      borderRadius: 2,
                      position: 'relative',
                    }}
                  >
                    {message.role === 'assistant' ? (
                      <EnhancedMessageDisplay
                        message={message}
                        isStreaming={isStreaming && index === messages.length - 1}
                      />
                    ) : (
                      <Typography variant="body1" sx={{ whiteSpace: 'pre-wrap' }}>
                        {message.content}
                      </Typography>
                    )}
                    
                    {/* Streaming indicator */}
                    {message.role === 'assistant' && 
                     isStreaming && 
                     index === messages.length - 1 && (
                      <Box
                        sx={{
                          display: 'flex',
                          alignItems: 'center',
                          gap: 1,
                          mt: 1,
                          opacity: 0.7,
                        }}
                      >
                        <CircularProgress size={12} />
                        <Typography variant="caption">
                          AI is typing...
                        </Typography>
                      </Box>
                    )}
                    
                    {/* Message metadata */}
                    <Typography
                      variant="caption"
                      sx={{
                        display: 'block',
                        mt: 1,
                        opacity: 0.7,
                        fontSize: '0.7rem',
                      }}
                    >
                      {new Date(message.timestamp || Date.now()).toLocaleTimeString()}
                      {message.model_used && ` • ${message.model_used}`}
                    </Typography>
                  </Paper>
                </Box>
              </Box>
            ))}
            <div ref={messagesEndRef} />
          </Box>
        )}
      </Box>

      {/* Input Area */}
      <Paper
        elevation={3}
        sx={{
          p: 2,
          borderRadius: 0,
          borderTop: '1px solid',
          borderColor: 'divider',
        }}
      >
        <Box sx={{ maxWidth: 800, mx: 'auto' }}>
          <Box sx={{ display: 'flex', gap: 1, alignItems: 'flex-end' }}>
            <TextField
              fullWidth
              multiline
              maxRows={4}
              value={inputMessage}
              onChange={(e) => setInputMessage(e.target.value)}
              onKeyPress={handleKeyPress}
              placeholder={
                !isConnected
                  ? 'Connecting...'
                  : !isAuthenticated
                  ? 'Authenticating...'
                  : 'Type your message here... (Press Enter to send)'
              }
              disabled={!isConnected || !isAuthenticated || isStreaming}
              variant="outlined"
              sx={{
                '& .MuiOutlinedInput-root': {
                  borderRadius: 3,
                },
              }}
            />
            <IconButton
              onClick={handleSendMessage}
              disabled={!inputMessage.trim() || !isConnected || !isAuthenticated || isStreaming}
              sx={{
                bgcolor: 'primary.main',
                color: 'primary.contrastText',
                '&:hover': {
                  bgcolor: 'primary.dark',
                },
                '&:disabled': {
                  bgcolor: 'action.disabled',
                },
                width: 48,
                height: 48,
              }}
            >
              {isStreaming ? <CircularProgress size={20} color="inherit" /> : <SendIcon />}
            </IconButton>
          </Box>
          
          {/* Status indicators */}
          <Box sx={{ display: 'flex', justifyContent: 'space-between', mt: 1 }}>
            <Typography variant="caption" color="text.secondary">
              {isStreaming
                ? 'AI is generating response...'
                : `${inputMessage.length} characters`}
            </Typography>
            <Typography variant="caption" color="text.secondary">
              Real-time streaming enabled
            </Typography>
          </Box>
        </Box>
      </Paper>

      {/* Error Snackbar */}
      <Snackbar
        open={showError}
        autoHideDuration={6000}
        onClose={() => setShowError(false)}
        anchorOrigin={{ vertical: 'top', horizontal: 'center' }}
      >
        <Alert
          onClose={() => setShowError(false)}
          severity="error"
          sx={{ width: '100%' }}
        >
          {error}
        </Alert>
      </Snackbar>
    </Box>
  );
};

export default StreamingChatInterface;
