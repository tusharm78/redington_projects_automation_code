import React, { useState, useEffect, useRef } from 'react';
import {
  Box,
  Paper,
  TextField,
  IconButton,
  Typography,
  Avatar,
  CircularProgress,
  Alert,
  Chip,
  Divider,
} from '@mui/material';
import {
  Send as SendIcon,
  Person as PersonIcon,
  SmartToy as BotIcon,
  Clear as ClearIcon,
  AutoAwesome as SparkleIcon,
} from '@mui/icons-material';
import ReactMarkdown from 'react-markdown';
import { Prism as SyntaxHighlighter } from 'react-syntax-highlighter';
import { tomorrow } from 'react-syntax-highlighter/dist/esm/styles/prism';
import remarkGfm from 'remark-gfm';
import { useEnhancedStreaming } from '../hooks/useEnhancedStreaming';
import { ChatRequest } from '../types';

// TypeScript interfaces for ReactMarkdown components
interface CodeProps {
  node?: any;
  inline?: boolean;
  className?: string;
  children?: React.ReactNode;
  [key: string]: any;
}

interface MarkdownComponentProps {
  node?: any;
  children?: React.ReactNode;
  [key: string]: any;
}

interface EnhancedStreamingChatProps {
  className?: string;
}

const EnhancedStreamingChat: React.FC<EnhancedStreamingChatProps> = ({ className }) => {
  const [inputMessage, setInputMessage] = useState('');
  const messagesEndRef = useRef<HTMLDivElement>(null);

  const {
    messages,
    isStreaming,
    sendMessage,
    clearMessages,
    error,
    streamingMetadata,
  } = useEnhancedStreaming();

  // Auto-scroll to bottom when new messages arrive
  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [messages]);

  const handleSendMessage = async () => {
    if (!inputMessage.trim() || isStreaming) return;

    const request: ChatRequest = {
      message: inputMessage.trim(),
      conversation_id: 'enhanced-conversation',
      session_id: 'enhanced-session',
    };

    try {
      await sendMessage(request);
      setInputMessage('');
    } catch (error) {
      console.error('Failed to send message:', error);
    }
  };

  const handleKeyPress = (event: React.KeyboardEvent) => {
    if (event.key === 'Enter' && !event.shiftKey) {
      event.preventDefault();
      handleSendMessage();
    }
  };

  const handleQuickAction = (message: string) => {
    setInputMessage(message);
  };

  const quickActions = [
    'Tell me about Redington services',
    'Cloud computing solutions',
    'Cybersecurity offerings',
    'Digital transformation consulting',
    'Data analytics capabilities',
  ];

  return (
    <Box className={className} sx={{ height: '100vh', display: 'flex', flexDirection: 'column' }}>
      {/* Enhanced Header */}
      <Paper
        elevation={3}
        sx={{
          p: 3,
          background: 'linear-gradient(135deg, #1976d2 0%, #1565c0 100%)',
          color: 'white',
          borderRadius: 0,
        }}
      >
        <Box sx={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between' }}>
          <Box sx={{ display: 'flex', alignItems: 'center', gap: 2 }}>
            <Avatar sx={{ bgcolor: 'rgba(255,255,255,0.2)', color: 'white', width: 48, height: 48 }}>
              <BotIcon sx={{ fontSize: 28 }} />
            </Avatar>
            <Box>
              <Typography variant="h5" component="h1" sx={{ fontWeight: 600 }}>
                Redington AI Assistant
              </Typography>
              <Box sx={{ display: 'flex', alignItems: 'center', gap: 1, mt: 0.5 }}>
                <SparkleIcon sx={{ fontSize: 16, opacity: 0.8 }} />
                <Typography variant="body2" sx={{ opacity: 0.9 }}>
                  {isStreaming ? 'AI is crafting your response...' : 'Enhanced Streaming • Ready to help'}
                </Typography>
                {streamingMetadata && (
                  <Chip
                    size="small"
                    label={`${streamingMetadata.chunk_index + 1}/${streamingMetadata.total_chunks}`}
                    sx={{ 
                      bgcolor: 'rgba(255,255,255,0.2)', 
                      color: 'white',
                      fontSize: '0.7rem',
                      height: 20
                    }}
                  />
                )}
              </Box>
            </Box>
          </Box>
          <IconButton
            onClick={clearMessages}
            sx={{ color: 'white', bgcolor: 'rgba(255,255,255,0.1)' }}
            disabled={isStreaming}
          >
            <ClearIcon />
          </IconButton>
        </Box>
      </Paper>

      {/* Messages Area */}
      <Box
        sx={{
          flex: 1,
          overflow: 'auto',
          p: 2,
          backgroundColor: '#f8fafc',
        }}
      >
        {error && (
          <Alert severity="error" sx={{ mb: 2 }}>
            {error}
          </Alert>
        )}

        {messages.length === 0 && (
          <Box
            sx={{
              display: 'flex',
              flexDirection: 'column',
              alignItems: 'center',
              justifyContent: 'center',
              height: '100%',
              textAlign: 'center',
              color: 'text.secondary',
            }}
          >
            <BotIcon sx={{ fontSize: 80, mb: 3, opacity: 0.3, color: 'primary.main' }} />
            <Typography variant="h5" gutterBottom sx={{ fontWeight: 600, color: 'text.primary' }}>
              Welcome to Enhanced AI Assistant
            </Typography>
            <Typography variant="body1" sx={{ mb: 3, maxWidth: 500 }}>
              Experience structured, professional responses with real-time markdown formatting.
              Every response is crafted for clarity and readability.
            </Typography>
            
            {/* Quick Actions */}
            <Box sx={{ display: 'flex', flexWrap: 'wrap', gap: 1, justifyContent: 'center', maxWidth: 600 }}>
              {quickActions.map((action, index) => (
                <Chip
                  key={index}
                  label={action}
                  onClick={() => handleQuickAction(action)}
                  sx={{ 
                    cursor: 'pointer',
                    '&:hover': { bgcolor: 'primary.main', color: 'white' }
                  }}
                />
              ))}
            </Box>
          </Box>
        )}

        {messages.map((message, index) => (
          <Box
            key={message.id}
            sx={{
              display: 'flex',
              mb: 3,
              alignItems: 'flex-start',
              gap: 2,
              flexDirection: message.role === 'user' ? 'row-reverse' : 'row',
            }}
          >
            <Avatar
              sx={{
                bgcolor: message.role === 'user' ? '#10b981' : '#1976d2',
                width: 44,
                height: 44,
                boxShadow: 2,
              }}
            >
              {message.role === 'user' ? <PersonIcon /> : <BotIcon />}
            </Avatar>
            
            <Paper
              elevation={2}
              sx={{
                p: 3,
                maxWidth: '75%',
                backgroundColor: message.role === 'user' ? '#10b981' : 'white',
                color: message.role === 'user' ? 'white' : 'text.primary',
                borderRadius: 3,
                position: 'relative',
                border: message.role === 'assistant' ? '1px solid #e2e8f0' : 'none',
                '&::before': message.role === 'user' ? {
                  content: '""',
                  position: 'absolute',
                  top: 20,
                  right: -8,
                  width: 0,
                  height: 0,
                  borderLeft: '8px solid #10b981',
                  borderTop: '8px solid transparent',
                  borderBottom: '8px solid transparent',
                } : {
                  content: '""',
                  position: 'absolute',
                  top: 20,
                  left: -8,
                  width: 0,
                  height: 0,
                  borderRight: '8px solid white',
                  borderTop: '8px solid transparent',
                  borderBottom: '8px solid transparent',
                },
              }}
            >
              {message.role === 'user' ? (
                <Typography
                  variant="body1"
                  sx={{
                    whiteSpace: 'pre-wrap',
                    wordBreak: 'break-word',
                    fontWeight: 500,
                  }}
                >
                  {message.content}
                </Typography>
              ) : (
                <Box>
                  <ReactMarkdown
                    remarkPlugins={[remarkGfm]}
                    components={{
                      h1: ({ children }: MarkdownComponentProps) => (
                        <Typography variant="h4" component="h1" sx={{ mb: 2, fontWeight: 700, color: 'primary.main' }}>
                          {children}
                        </Typography>
                      ),
                      h2: ({ children }: MarkdownComponentProps) => (
                        <Typography variant="h5" component="h2" sx={{ mb: 2, mt: 3, fontWeight: 600, color: 'primary.main' }}>
                          {children}
                        </Typography>
                      ),
                      h3: ({ children }: MarkdownComponentProps) => (
                        <Typography variant="h6" component="h3" sx={{ mb: 1.5, mt: 2, fontWeight: 600, color: 'text.primary' }}>
                          {children}
                        </Typography>
                      ),
                      p: ({ children }: MarkdownComponentProps) => (
                        <Typography variant="body1" sx={{ mb: 1.5, lineHeight: 1.7 }}>
                          {children}
                        </Typography>
                      ),
                      ul: ({ children }: MarkdownComponentProps) => (
                        <Box component="ul" sx={{ mb: 2, pl: 2 }}>
                          {children}
                        </Box>
                      ),
                      ol: ({ children }: MarkdownComponentProps) => (
                        <Box component="ol" sx={{ mb: 2, pl: 2 }}>
                          {children}
                        </Box>
                      ),
                      li: ({ children }: MarkdownComponentProps) => (
                        <Typography component="li" variant="body1" sx={{ mb: 0.5, lineHeight: 1.6 }}>
                          {children}
                        </Typography>
                      ),
                      code: ({ node, inline, className, children, ...props }: CodeProps) => {
                        const match = /language-(\w+)/.exec(className || '');
                        return !inline && match ? (
                          <Box sx={{ mb: 2 }}>
                            <SyntaxHighlighter
                              style={tomorrow}
                              language={match[1]}
                              PreTag="div"
                              customStyle={{
                                borderRadius: 8,
                                fontSize: '0.875rem',
                              }}
                              {...props}
                            >
                              {String(children).replace(/\n$/, '')}
                            </SyntaxHighlighter>
                          </Box>
                        ) : (
                          <Box
                            component="code"
                            sx={{
                              bgcolor: '#f1f5f9',
                              color: '#1e293b',
                              px: 1,
                              py: 0.5,
                              borderRadius: 1,
                              fontSize: '0.875rem',
                              fontFamily: 'monospace',
                            }}
                            {...props}
                          >
                            {children}
                          </Box>
                        );
                      },
                      blockquote: ({ children }: MarkdownComponentProps) => (
                        <Box
                          sx={{
                            borderLeft: '4px solid #3b82f6',
                            bgcolor: '#eff6ff',
                            p: 2,
                            mb: 2,
                            borderRadius: '0 8px 8px 0',
                          }}
                        >
                          <Typography variant="body1" sx={{ fontStyle: 'italic', color: '#1e40af' }}>
                            {children}
                          </Typography>
                        </Box>
                      ),
                      hr: () => <Divider sx={{ my: 3 }} />,
                      strong: ({ children }: MarkdownComponentProps) => (
                        <Typography component="strong" sx={{ fontWeight: 700, color: 'primary.main' }}>
                          {children}
                        </Typography>
                      ),
                      em: ({ children }: MarkdownComponentProps) => (
                        <Typography component="em" sx={{ fontStyle: 'italic', color: 'text.secondary' }}>
                          {children}
                        </Typography>
                      ),
                    }}
                  >
                    {message.content}
                  </ReactMarkdown>
                  
                  {/* Streaming cursor */}
                  {message.role === 'assistant' && isStreaming && index === messages.length - 1 && (
                    <Box
                      component="span"
                      sx={{
                        display: 'inline-block',
                        width: '3px',
                        height: '1.2em',
                        backgroundColor: 'primary.main',
                        ml: 0.5,
                        animation: 'pulse 1.5s infinite',
                        '@keyframes pulse': {
                          '0%, 50%': { opacity: 1 },
                          '51%, 100%': { opacity: 0.3 },
                        },
                      }}
                    />
                  )}
                </Box>
              )}
            </Paper>
          </Box>
        ))}

        <div ref={messagesEndRef} />
      </Box>

      {/* Enhanced Input Area */}
      <Paper
        elevation={4}
        sx={{
          p: 3,
          backgroundColor: 'white',
          borderRadius: 0,
          borderTop: '1px solid #e2e8f0',
        }}
      >
        <Box sx={{ display: 'flex', gap: 2, alignItems: 'flex-end' }}>
          <TextField
            fullWidth
            multiline
            maxRows={4}
            value={inputMessage}
            onChange={(e) => setInputMessage(e.target.value)}
            onKeyPress={handleKeyPress}
            placeholder="Ask me about Redington's technology solutions..."
            disabled={isStreaming}
            variant="outlined"
            sx={{
              '& .MuiOutlinedInput-root': {
                borderRadius: 3,
                bgcolor: '#f8fafc',
                '&:hover': {
                  bgcolor: '#f1f5f9',
                },
                '&.Mui-focused': {
                  bgcolor: 'white',
                },
              },
            }}
          />
          <IconButton
            onClick={handleSendMessage}
            disabled={!inputMessage.trim() || isStreaming}
            sx={{
              bgcolor: 'primary.main',
              color: 'white',
              width: 48,
              height: 48,
              '&:hover': {
                bgcolor: 'primary.dark',
              },
              '&:disabled': {
                bgcolor: 'action.disabled',
              },
            }}
          >
            {isStreaming ? <CircularProgress size={24} color="inherit" /> : <SendIcon />}
          </IconButton>
        </Box>
        
        {/* Quick Actions Row */}
        {messages.length === 0 && (
          <Box sx={{ mt: 2, display: 'flex', gap: 1, flexWrap: 'wrap' }}>
            <Typography variant="caption" sx={{ color: 'text.secondary', mr: 1, alignSelf: 'center' }}>
              Quick start:
            </Typography>
            {quickActions.slice(0, 3).map((action, index) => (
              <Chip
                key={index}
                label={action}
                size="small"
                onClick={() => handleQuickAction(action)}
                sx={{ 
                  cursor: 'pointer',
                  fontSize: '0.75rem',
                  '&:hover': { bgcolor: 'primary.main', color: 'white' }
                }}
              />
            ))}
          </Box>
        )}
      </Paper>
    </Box>
  );
};

export default EnhancedStreamingChat;
