import React, { useState, useEffect } from 'react';
import { BrowserRouter as Router, Routes, Route, Navigate } from 'react-router-dom';
import { ThemeProvider, createTheme } from '@mui/material/styles';
import { 
  CssBaseline, 
  CircularProgress, 
  Box, 
  AppBar, 
  Toolbar, 
  Typography, 
  Button, 
  Menu, 
  MenuItem,
  IconButton,
  Badge
} from '@mui/material';
import {
  AccountCircle as AccountIcon,
  AdminPanelSettings as AdminIcon,
  ExitToApp as LogoutIcon,
  Dashboard as DashboardIcon
} from '@mui/icons-material';
import { AuthProvider, useAuth } from '../hooks';
import { Login } from './';
import ModernChatInterface from './ModernChatInterface';
import AdminDashboard from './AdminDashboard';
import '../styles/streaming-optimizations.css';
import '../styles/no-shadow-border.css';

// Redington Brand Theme with Green Colors
const redingtonTheme = createTheme({
  palette: {
    primary: {
      main: '#28A745', // Green instead of Red
      light: '#4CAF50', // Light Green
      dark: '#1B7A31', // Dark Green
      contrastText: '#FFFFFF',
    },
    secondary: {
      main: '#1A1A1A', // Dark Gray
      light: '#2C3E50',
      dark: '#000000',
      contrastText: '#FFFFFF',
    },
    background: {
      default: '#F8F9FA',
      paper: '#FFFFFF',
    },
    text: {
      primary: '#2C3E50',
      secondary: '#6C757D',
    },
    success: {
      main: '#28A745',
    },
    warning: {
      main: '#FFC107',
    },
    error: {
      main: '#4CAF50', // Changed from red to green
    },
  },
  typography: {
    fontFamily: 'Calibri, Calibri Body, Segoe UI, Roboto, Helvetica, Arial, sans-serif',
    h1: {
      fontWeight: 700,
      fontSize: '2.5rem',
    },
    h2: {
      fontWeight: 600,
      fontSize: '2rem',
    },
    h3: {
      fontWeight: 600,
      fontSize: '1.75rem',
    },
    h4: {
      fontWeight: 600,
      fontSize: '1.5rem',
    },
    h5: {
      fontWeight: 500,
      fontSize: '1.25rem',
    },
    h6: {
      fontWeight: 500,
      fontSize: '1rem',
    },
    body1: {
      fontSize: '1rem',
      lineHeight: 1.6,
    },
    body2: {
      fontSize: '0.875rem',
      lineHeight: 1.5,
    },
  },
  components: {
    MuiButton: {
      styleOverrides: {
        root: {
          textTransform: 'none',
          borderRadius: 8,
          fontWeight: 500,
        },
        contained: {
          boxShadow: 'none',
          '&:hover': {
            boxShadow: '0 2px 8px rgba(40, 167, 69, 0.3)',
          },
        },
      },
    },
    MuiCard: {
      styleOverrides: {
        root: {
          borderRadius: 12,
          boxShadow: '0 2px 12px rgba(0, 0, 0, 0.08)',
        },
      },
    },
    MuiTextField: {
      styleOverrides: {
        root: {
          '& .MuiOutlinedInput-root': {
            borderRadius: 8,
          },
        },
      },
    },
  },
});

// Admin user list (should match backend)
const ADMIN_USERS = [
  'admin',
  'administrator', 
  'redington_admin',
];

interface AppHeaderProps {
  user: any;
  onLogout: () => void;
  onToggleAdmin: () => void;
  showingAdmin: boolean;
  activeUsersCount?: number;
}

const AppHeader: React.FC<AppHeaderProps> = ({ 
  user, 
  onLogout, 
  onToggleAdmin, 
  showingAdmin,
  activeUsersCount = 0
}) => {
  const [anchorEl, setAnchorEl] = useState<null | HTMLElement>(null);
  const isAdmin = ADMIN_USERS.includes(user?.username);

  const handleMenu = (event: React.MouseEvent<HTMLElement>) => {
    setAnchorEl(event.currentTarget);
  };

  const handleClose = () => {
    setAnchorEl(null);
  };

  const handleLogout = () => {
    handleClose();
    onLogout();
  };

  const handleToggleAdmin = () => {
    handleClose();
    onToggleAdmin();
  };

  return (
    <AppBar position="static" sx={{ bgcolor: 'primary.main' }}>
      <Toolbar>
        <Typography variant="h6" component="div" sx={{ flexGrow: 1 }}>
          {showingAdmin ? 'Admin Dashboard - User Monitoring' : 'Redington AI Bot'}
        </Typography>
        
        {isAdmin && (
          <Button
            color="inherit"
            startIcon={showingAdmin ? <DashboardIcon /> : <AdminIcon />}
            onClick={onToggleAdmin}
            sx={{ mr: 2 }}
          >
            {showingAdmin ? 'Back to Chat' : (
              <Badge badgeContent={activeUsersCount} color="error">
                Admin Panel
              </Badge>
            )}
          </Button>
        )}
        
        <div>
          <IconButton
            size="large"
            aria-label="account of current user"
            aria-controls="menu-appbar"
            aria-haspopup="true"
            onClick={handleMenu}
            color="inherit"
          >
            <AccountIcon />
          </IconButton>
          <Menu
            id="menu-appbar"
            anchorEl={anchorEl}
            anchorOrigin={{
              vertical: 'top',
              horizontal: 'right',
            }}
            keepMounted
            transformOrigin={{
              vertical: 'top',
              horizontal: 'right',
            }}
            open={Boolean(anchorEl)}
            onClose={handleClose}
          >
            <MenuItem disabled>
              <Typography variant="body2">
                {user?.username} ({user?.email})
              </Typography>
            </MenuItem>
            {isAdmin && (
              <MenuItem onClick={handleToggleAdmin}>
                <AdminIcon sx={{ mr: 1 }} />
                {showingAdmin ? 'Back to Chat' : 'Admin Dashboard'}
              </MenuItem>
            )}
            <MenuItem onClick={handleLogout}>
              <LogoutIcon sx={{ mr: 1 }} />
              Logout
            </MenuItem>
          </Menu>
        </div>
      </Toolbar>
    </AppBar>
  );
};

const AppContent: React.FC = () => {
  const { user, logout } = useAuth();
  const [showingAdmin, setShowingAdmin] = useState(false);
  const [activeUsersCount, setActiveUsersCount] = useState(0);
  const isAdmin = ADMIN_USERS.includes(user?.username || '');

  // Fetch active users count for admin badge
  useEffect(() => {
    if (isAdmin && user) {
      const fetchActiveUsersCount = async () => {
        try {
          const token = localStorage.getItem('access_token');
          if (!token) return;
          
          const response = await fetch(`${process.env.REACT_APP_API_URL || 'http://localhost:8000'}/api/v1/admin/active-users`, {
            headers: {
              'Authorization': `Bearer ${token}`,
              'Content-Type': 'application/json'
            }
          });
          
          if (response.ok) {
            const users = await response.json();
            setActiveUsersCount(users.length);
          }
        } catch (error) {
          console.error('Error fetching active users count:', error);
        }
      };

      fetchActiveUsersCount();
      
      // Update count every 30 seconds
      const interval = setInterval(fetchActiveUsersCount, 30000);
      return () => clearInterval(interval);
    }
  }, [isAdmin, user]);

  const handleLogout = async () => {
    try {
      const token = localStorage.getItem('access_token');
      if (token) {
        // Call logout API to record logout in activity monitor
        await fetch(`${process.env.REACT_APP_API_URL || 'http://localhost:8000'}/api/v1/auth/logout`, {
          method: 'POST',
          headers: {
            'Authorization': `Bearer ${token}`,
            'Content-Type': 'application/json'
          }
        });
      }
    } catch (error) {
      console.error('Error during logout:', error);
    } finally {
      logout();
      setShowingAdmin(false);
    }
  };

  const handleToggleAdmin = () => {
    setShowingAdmin(!showingAdmin);
  };

  const token = localStorage.getItem('access_token');
  
  if (!user || !token) {
    return <Login />;
  }

  return (
    <Box sx={{ flexGrow: 1 }}>
      <AppHeader 
        user={user} 
        onLogout={handleLogout}
        onToggleAdmin={handleToggleAdmin}
        showingAdmin={showingAdmin}
        activeUsersCount={activeUsersCount}
      />
      
      <Box sx={{ height: 'calc(100vh - 64px)' }}>
        {showingAdmin && isAdmin ? (
          <AdminDashboard 
            authToken={token} 
            onClose={() => setShowingAdmin(false)}
          />
        ) : (
          <ModernChatInterface />
        )}
      </Box>
    </Box>
  );
};

const LoadingScreen: React.FC = () => (
  <Box
    display="flex"
    justifyContent="center"
    alignItems="center"
    minHeight="100vh"
    bgcolor="background.default"
  >
    <CircularProgress size={60} />
  </Box>
);

const App: React.FC = () => {
  return (
    <ThemeProvider theme={redingtonTheme}>
      <CssBaseline />
      <AuthProvider>
        <Router>
          <Routes>
            <Route path="/" element={<AppContent />} />
            <Route path="/login" element={<Login />} />
            <Route path="*" element={<Navigate to="/" replace />} />
          </Routes>
        </Router>
      </AuthProvider>
    </ThemeProvider>
  );
};

export default App;
