import React, { useState, useEffect } from 'react';
import { Box, Button, Typography, List, ListItem, ListItemText } from '@mui/material';
import { sessionsService } from '../services/sessions';
import { useAuth } from '../hooks/useAuth';

interface SimpleSession {
  id: string;
  title: string;
}

const SessionsDebugTest: React.FC = () => {
  const [sessions, setSessions] = useState<SimpleSession[]>([]);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string>('');
  const [rawData, setRawData] = useState<any>(null);
  const { user } = useAuth();

  const testSessionsLoad = async () => {
    console.log('🧪 SESSIONS DEBUG TEST STARTED');
    console.log('👤 Current user:', user);
    console.log('🔑 Token exists:', !!localStorage.getItem('access_token'));
    
    setLoading(true);
    setError('');
    
    try {
      console.log('📡 Making API call...');
      const rawSessions = await sessionsService.getUserSessions();
      console.log('✅ Raw sessions received:', rawSessions);
      setRawData(rawSessions);
      
      const sessionsList = Object.entries(rawSessions).map(([id, title]) => ({
        id,
        title: title as string
      }));
      
      console.log('🔄 Converted sessions:', sessionsList);
      setSessions(sessionsList);
      console.log('✅ State updated with', sessionsList.length, 'sessions');
      
    } catch (err: any) {
      console.error('❌ Error loading sessions:', err);
      setError(err.message || 'Failed to load sessions');
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    console.log('🚀 SessionsDebugTest mounted');
    if (user?.username) {
      console.log('✅ User authenticated, auto-loading sessions');
      testSessionsLoad();
    }
  }, [user?.username]);

  return (
    <Box sx={{ p: 3, bgcolor: '#1a1a1a', color: 'white', minHeight: '100vh' }}>
      <Typography variant="h4" sx={{ mb: 3, color: '#FF6B35' }}>
        🧪 Sessions Debug Test
      </Typography>
      
      <Box sx={{ mb: 3, p: 2, bgcolor: '#2a2a2a', borderRadius: 2 }}>
        <Typography variant="h6" sx={{ mb: 2 }}>Debug Info:</Typography>
        <Typography>User: {user?.username || 'Not logged in'}</Typography>
        <Typography>Token: {localStorage.getItem('access_token') ? 'Present' : 'Missing'}</Typography>
        <Typography>Sessions Count: {sessions.length}</Typography>
        <Typography>Loading: {loading ? 'Yes' : 'No'}</Typography>
        <Typography>Error: {error || 'None'}</Typography>
      </Box>

      <Button 
        variant="contained" 
        onClick={testSessionsLoad}
        disabled={loading}
        sx={{ mb: 3, bgcolor: '#FF6B35' }}
      >
        {loading ? 'Loading...' : 'Test Load Sessions'}
      </Button>

      {rawData && (
        <Box sx={{ mb: 3, p: 2, bgcolor: '#2a2a2a', borderRadius: 2 }}>
          <Typography variant="h6" sx={{ mb: 2 }}>Raw API Response:</Typography>
          <pre style={{ fontSize: '12px', overflow: 'auto' }}>
            {JSON.stringify(rawData, null, 2)}
          </pre>
        </Box>
      )}

      <Box sx={{ mb: 3 }}>
        <Typography variant="h6" sx={{ mb: 2 }}>Sessions List ({sessions.length} items):</Typography>
        {sessions.length === 0 ? (
          <Typography sx={{ color: '#888' }}>No sessions loaded</Typography>
        ) : (
          <List sx={{ bgcolor: '#2a2a2a', borderRadius: 2 }}>
            {sessions.map((session, index) => (
              <ListItem key={session.id} sx={{ borderBottom: '1px solid #444' }}>
                <ListItemText 
                  primary={`${index + 1}. ${session.title}`}
                  secondary={`ID: ${session.id}`}
                  sx={{ 
                    '& .MuiListItemText-primary': { color: 'white' },
                    '& .MuiListItemText-secondary': { color: '#888' }
                  }}
                />
              </ListItem>
            ))}
          </List>
        )}
      </Box>
    </Box>
  );
};

export default SessionsDebugTest;
