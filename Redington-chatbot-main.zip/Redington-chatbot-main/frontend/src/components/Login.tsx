import React, { useState, useEffect } from 'react';
import {
  Box,
  TextField,
  Button,
  Typography,
  Alert,
  CircularProgress,
  Avatar,
  Container,
  Paper,
  Fade,
  Slide,
  Stack,
} from '@mui/material';
import {
  Person as PersonIcon,
  Lock as LockIcon,
  SmartToy as BotIcon,
  Security as SecurityIcon,
  Speed as SpeedIcon,
  Psychology as PsychologyIcon,
} from '@mui/icons-material';
import { useAuth } from '../hooks/useAuth';
import PasswordChange from './PasswordChange';
import apiService from '../services/api';

// Redington Brand Colors - Updated to match chatbot theme
const redingtonTheme = {
  primary: '#00A651', // Redington Green (main)
  secondary: '#1A1A1A', // Dark Gray
  accent: '#66CC99', // Light Green accent
  background: '#F8F9FA', // Light background
  surface: '#FFFFFF', // White surface
  text: '#2C3E50', // Dark text
  textSecondary: '#6C757D', // Secondary text
  gradient: 'linear-gradient(135deg, #00A651 0%, #66CC99 100%)', // Green gradient
  darkGradient: 'linear-gradient(135deg, #1A1A1A 0%, #2C3E50 100%)',
};

const Login: React.FC = () => {
  const [username, setUsername] = useState('');
  const [password, setPassword] = useState('');
  const [error, setError] = useState('');
  const [loading, setLoading] = useState(false);
  const [passwordChangeRequired, setPasswordChangeRequired] = useState(false);
  const [challengeSession, setChallengeSession] = useState('');
  const { login } = useAuth();

  console.log('🔑 Login component state:', { passwordChangeRequired, challengeSession: challengeSession ? 'Present' : 'Missing' });

  useEffect(() => {
    console.log('🔑 passwordChangeRequired changed to:', passwordChangeRequired);
    console.log('🔑 challengeSession changed to:', challengeSession ? 'Present' : 'Missing');
  }, [passwordChangeRequired, challengeSession]);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError('');
    setLoading(true);

    console.log('🔥 Starting login process...');

    try {
      console.log('🔥 Calling login with credentials:', { username, password: '***' });
      await login({ username, password });
      console.log('🔥 Login successful - this should not happen for password change required');
    } catch (err: any) {
      console.log('🔥 ===== LOGIN ERROR CAUGHT =====');
      console.log('🔥 Full error object:', err);
      console.log('🔥 Error name:', err.name);
      console.log('🔥 Error message:', err.message);
      console.log('🔥 Error response exists:', !!err.response);
      console.log('🔥 Error response:', err.response);
      
      if (err.response) {
        console.log('🔥 Response status:', err.response.status);
        console.log('🔥 Response data:', err.response.data);
        console.log('🔥 Response headers:', err.response.headers);
      }
      
      // Handle the error
      if (err.response && err.response.status === 400) {
        const responseData = err.response.data;
        const errorDetail = responseData?.detail;
        
        console.log('🔥 ===== 400 ERROR DETECTED =====');
        console.log('🔥 Response data:', responseData);
        console.log('🔥 Error detail:', errorDetail);
        console.log('🔥 Error detail type:', typeof errorDetail);
        console.log('🔥 Error detail keys:', errorDetail ? Object.keys(errorDetail) : 'N/A');
        
        if (errorDetail) {
          console.log('🔥 errorDetail.error:', errorDetail.error);
          console.log('🔥 errorDetail.session:', errorDetail.session);
          console.log('🔥 errorDetail.message:', errorDetail.message);
        }
        
        // Check if it's a password change challenge - be more flexible
        const isPasswordChangeRequired = errorDetail && 
            (errorDetail.error === 'password_change_required' || 
             (typeof errorDetail === 'object' && errorDetail.error === 'password_change_required'));
        
        console.log('🔥 Password change required check result:', isPasswordChangeRequired);
        
        if (isPasswordChangeRequired) {
          console.log('🔥 ===== PASSWORD CHANGE REQUIRED DETECTED! =====');
          console.log('🔥 Session token:', errorDetail.session);
          console.log('🔥 Setting passwordChangeRequired to true');
          console.log('🔥 Setting challengeSession to:', errorDetail.session);
          
          // Set the password change state
          setPasswordChangeRequired(true);
          setChallengeSession(errorDetail.session || '');
          setError(''); // Clear any error message
          
          console.log('🔥 State should be updated now');
          console.log('🔥 Exiting error handler early');
          return; // Exit early to prevent setting error message
        } else {
          console.log('🔥 Password change NOT detected - will show error message');
        }
        
        // Also check if the error message contains password change info
        if (typeof errorDetail === 'string' && errorDetail.includes('password')) {
          console.log('🔥 String error detail contains password - might be password change');
        }
      } else {
        console.log('🔥 Not a 400 error or no response - status:', err.response?.status);
      }
      
      // If we get here, it's a regular error
      console.log('🔥 ===== SETTING REGULAR ERROR MESSAGE =====');
      const errorMessage = err.response?.data?.detail || 
                          err.response?.data?.message || 
                          err.message || 
                          'Login failed. Please check your credentials.';
      console.log('🔥 Error message to display:', errorMessage);
      setError(typeof errorMessage === 'string' ? errorMessage : 'Login failed. Please check your credentials.');
      
    } finally {
      setLoading(false);
    }
  };

  const handlePasswordChanged = async (authResponse: any) => {
    try {
      // Set the auth token and user info
      apiService.setAuthToken(authResponse.access_token);
      
      // Update the auth context by calling login with the new credentials
      // This will trigger the useAuth hook to update the user state
      window.location.reload(); // Simple way to refresh the auth state
    } catch (error) {
      console.error('Error handling password change:', error);
      setError('Password changed but login failed. Please try logging in again.');
      setPasswordChangeRequired(false);
    }
  };

  const handleCancelPasswordChange = () => {
    setPasswordChangeRequired(false);
    setChallengeSession('');
    setError('');
  };

  // Show password change form if required
  if (passwordChangeRequired) {
    console.log('🔑 Rendering PasswordChange component');
    console.log('🔑 Username:', username);
    console.log('🔑 Session:', challengeSession ? 'Present' : 'Missing');
    
    return (
      <PasswordChange
        username={username}
        session={challengeSession}
        onPasswordChanged={handlePasswordChanged}
        onCancel={handleCancelPasswordChange}
      />
    );
  }

  console.log('🔑 Rendering Login form');

  return (
    <Box
      sx={{
        minHeight: '100vh',
        background: redingtonTheme.gradient,
        display: 'flex',
        alignItems: 'center',
        justifyContent: 'center',
        position: 'relative',
        overflow: 'hidden',
      }}
    >
      {/* Background Pattern */}
      <Box
        sx={{
          position: 'absolute',
          top: 0,
          left: 0,
          right: 0,
          bottom: 0,
          opacity: 0.1,
          backgroundImage: `url("data:image/svg+xml,%3Csvg width='60' height='60' viewBox='0 0 60 60' xmlns='http://www.w3.org/2000/svg'%3E%3Cg fill='none' fill-rule='evenodd'%3E%3Cg fill='%23ffffff' fill-opacity='0.4'%3E%3Ccircle cx='30' cy='30' r='2'/%3E%3C/g%3E%3C/g%3E%3C/svg%3E")`,
        }}
      />

      <Container maxWidth="lg">
        <Box sx={{ display: 'flex', alignItems: 'center', gap: 8 }}>
          {/* Left Side - Branding */}
          <Slide direction="right" in={true} timeout={800}>
            <Box sx={{ flex: 1, color: 'white', display: { xs: 'none', md: 'block' } }}>
              <Fade in={true} timeout={1200}>
                <Box>
                  <Box sx={{ display: 'flex', alignItems: 'center', justifyContent: 'flex-start', gap: 2, mb: 4 }}>
                    <img 
                      src="/redington-logo.png" 
                      alt="Redington Logo" 
                      style={{ 
                        height: '50px', 
                        width: 'auto',
                        objectFit: 'contain'
                      }} 
                    />
                    <Typography
                      variant="h2"
                      sx={{
                        fontWeight: 700,
                        textShadow: '0 2px 4px rgba(0,0,0,0.3)',
                      }}
                    >
                      AI Assistant
                    </Typography>
                  </Box>
                  
                  <Typography
                    variant="h5"
                    sx={{
                      mb: 4,
                      opacity: 0.9,
                      fontWeight: 400,
                      lineHeight: 1.4,
                    }}
                  >
                    Your intelligent partner for technology solutions, 
                    product recommendations, and technical support.
                  </Typography>

                  <Stack spacing={3}>
                    <Box sx={{ display: 'flex', alignItems: 'center' }}>
                      <PsychologyIcon sx={{ fontSize: 40, mr: 2, opacity: 0.8 }} />
                      <Box>
                        <Typography variant="h6" sx={{ fontWeight: 600 }}>
                          Advanced AI Reasoning
                        </Typography>
                        <Typography variant="body2" sx={{ opacity: 0.8 }}>
                          Powered by Claude 3.7 Sonnet with thinking capabilities
                        </Typography>
                      </Box>
                    </Box>

                    <Box sx={{ display: 'flex', alignItems: 'center' }}>
                      <SecurityIcon sx={{ fontSize: 40, mr: 2, opacity: 0.8 }} />
                      <Box>
                        <Typography variant="h6" sx={{ fontWeight: 600 }}>
                          Enterprise Security
                        </Typography>
                        <Typography variant="body2" sx={{ opacity: 0.8 }}>
                          Secure authentication with AWS Cognito
                        </Typography>
                      </Box>
                    </Box>

                    <Box sx={{ display: 'flex', alignItems: 'center' }}>
                      <SpeedIcon sx={{ fontSize: 40, mr: 2, opacity: 0.8 }} />
                      <Box>
                        <Typography variant="h6" sx={{ fontWeight: 600 }}>
                          Real-time Responses
                        </Typography>
                        <Typography variant="body2" sx={{ opacity: 0.8 }}>
                          Fast, intelligent responses for your business needs
                        </Typography>
                      </Box>
                    </Box>
                  </Stack>
                </Box>
              </Fade>
            </Box>
          </Slide>

          {/* Right Side - Login Form */}
          <Slide direction="left" in={true} timeout={800}>
            <Box sx={{ flex: { xs: 1, md: 0.6 } }}>
              <Paper
                elevation={24}
                sx={{
                  p: 4,
                  borderRadius: 4,
                  background: 'rgba(255, 255, 255, 0.95)',
                  backdropFilter: 'blur(10px)',
                  border: '1px solid rgba(255, 255, 255, 0.2)',
                }}
              >
                <Box sx={{ textAlign: 'center', mb: 4 }}>
                  <Avatar
                    sx={{
                      width: 60,
                      height: 60,
                      background: redingtonTheme.gradient,
                      mx: 'auto',
                      mb: 2,
                    }}
                  >
                    <BotIcon sx={{ fontSize: 30 }} />
                  </Avatar>
                  
                  <Typography
                    variant="h4"
                    sx={{
                      fontWeight: 700,
                      color: redingtonTheme.text,
                      mb: 1,
                    }}
                  >
                    Welcome Back
                  </Typography>
                  
                  <Typography
                    variant="body1"
                    sx={{ color: redingtonTheme.textSecondary }}
                  >
                    Sign in to access your AI assistant
                  </Typography>
                </Box>

                {error && (
                  <Fade in={!!error}>
                    <Alert 
                      severity="error" 
                      sx={{ 
                        mb: 3,
                        borderRadius: 2,
                        '& .MuiAlert-message': {
                          fontSize: '0.9rem',
                        },
                      }}
                    >
                      {error}
                    </Alert>
                  </Fade>
                )}

                <Box component="form" onSubmit={handleSubmit}>
                  <TextField
                    margin="normal"
                    required
                    fullWidth
                    id="username"
                    label="Username"
                    name="username"
                    autoComplete="username"
                    autoFocus
                    value={username}
                    onChange={(e) => setUsername(e.target.value)}
                    disabled={loading}
                    InputProps={{
                      startAdornment: (
                        <PersonIcon sx={{ color: redingtonTheme.textSecondary, mr: 1 }} />
                      ),
                    }}
                    sx={{
                      mb: 2,
                      '& .MuiOutlinedInput-root': {
                        borderRadius: 2,
                        '&:hover .MuiOutlinedInput-notchedOutline': {
                          borderColor: redingtonTheme.primary,
                        },
                        '&.Mui-focused .MuiOutlinedInput-notchedOutline': {
                          borderColor: redingtonTheme.primary,
                          borderWidth: 2,
                        },
                      },
                    }}
                  />
                  
                  <TextField
                    margin="normal"
                    required
                    fullWidth
                    name="password"
                    label="Password"
                    type="password"
                    id="password"
                    autoComplete="current-password"
                    value={password}
                    onChange={(e) => setPassword(e.target.value)}
                    disabled={loading}
                    InputProps={{
                      startAdornment: (
                        <LockIcon sx={{ color: redingtonTheme.textSecondary, mr: 1 }} />
                      ),
                    }}
                    sx={{
                      mb: 3,
                      '& .MuiOutlinedInput-root': {
                        borderRadius: 2,
                        '&:hover .MuiOutlinedInput-notchedOutline': {
                          borderColor: redingtonTheme.primary,
                        },
                        '&.Mui-focused .MuiOutlinedInput-notchedOutline': {
                          borderColor: redingtonTheme.primary,
                          borderWidth: 2,
                        },
                      },
                    }}
                  />

                  <Button
                    type="submit"
                    fullWidth
                    variant="contained"
                    disabled={loading}
                    sx={{
                      py: 1.5,
                      fontSize: '1.1rem',
                      fontWeight: 600,
                      borderRadius: 2,
                      background: redingtonTheme.gradient,
                      boxShadow: '0 4px 20px rgba(0, 166, 81, 0.3)',
                      '&:hover': {
                        background: redingtonTheme.darkGradient,
                        boxShadow: '0 6px 24px rgba(0, 166, 81, 0.4)',
                        transform: 'translateY(-1px)',
                      },
                      '&:disabled': {
                        opacity: 0.7,
                        transform: 'none',
                      },
                      transition: 'all 0.3s ease',
                    }}
                  >
                    {loading ? (
                      <Box sx={{ display: 'flex', alignItems: 'center' }}>
                        <CircularProgress size={20} color="inherit" sx={{ mr: 1 }} />
                        Signing In...
                      </Box>
                    ) : (
                      'Sign In'
                    )}
                  </Button>
                </Box>
              </Paper>
            </Box>
          </Slide>
        </Box>
      </Container>
    </Box>
  );
};

export default Login;
