import axios, { AxiosInstance, AxiosResponse } from 'axios';
import { 
  AuthRequest, 
  AuthResponse, 
  ChatRequest, 
  ChatResponse, 
  ChatMessage, 
  UserInfo,
  ModelConfig 
} from '../types';

class ApiService {
  private api: AxiosInstance;
  private baseURL = process.env.REACT_APP_API_URL || '/api/v1';

  constructor() {
    console.log('🔧 ApiService initialized with baseURL:', this.baseURL);
    console.log('🔧 process.env.REACT_APP_API_URL:', process.env.REACT_APP_API_URL);
    
    this.api = axios.create({
      baseURL: this.baseURL,
      headers: {
        'Content-Type': 'application/json',
      },
    });

    // Add request interceptor to include auth token
    this.api.interceptors.request.use(
      (config) => {
        console.log('🔧 Making API request to:', config.baseURL + (config.url || ''));
        const token = localStorage.getItem('access_token');
        if (token) {
          config.headers.Authorization = `Bearer ${token}`;
        }
        return config;
      },
      (error) => Promise.reject(error)
    );

    // Add response interceptor to handle auth errors
    this.api.interceptors.response.use(
      (response) => response,
      (error) => {
        if (error.response?.status === 401) {
          localStorage.removeItem('access_token');
          window.location.href = '/login';
        }
        return Promise.reject(error);
      }
    );
  }

  // Authentication methods
  async login(credentials: AuthRequest): Promise<AuthResponse> {
    console.log('🌐 apiService.login called with:', { username: credentials.username, password: '***' });
    try {
      console.log('🌐 Making POST request to /auth/login...');
      const response: AxiosResponse<AuthResponse> = await this.api.post('/auth/login', credentials);
      console.log('🌐 Login request succeeded:', response.status, response.data);
      return response.data;
    } catch (error) {
      console.log('🌐 apiService.login error:', error);
      console.log('🌐 Re-throwing error to useAuth');
      throw error;
    }
  }

  async changePassword(username: string, newPassword: string, session: string): Promise<AuthResponse> {
    const response: AxiosResponse<AuthResponse> = await this.api.post('/auth/change-password', {
      username,
      new_password: newPassword,
      session
    });
    return response.data;
  }

  async getCurrentUser(): Promise<UserInfo> {
    const response: AxiosResponse<UserInfo> = await this.api.get('/auth/me');
    return response.data;
  }

  async logout(): Promise<void> {
    await this.api.post('/auth/logout');
    localStorage.removeItem('access_token');
  }

  // Chat methods
  async sendMessage(request: ChatRequest): Promise<ChatResponse> {
    const response: AxiosResponse<ChatResponse> = await this.api.post('/chat/message', request);
    return response.data;
  }

  async getConversationHistory(conversationId: string): Promise<ChatMessage[]> {
    const response: AxiosResponse<ChatMessage[]> = await this.api.get(`/chat/history/${conversationId}`);
    return response.data;
  }

  async getAvailableModels(): Promise<ModelConfig> {
    const response: AxiosResponse<ModelConfig> = await this.api.get('/chat/models');
    return response.data;
  }

  // Streaming chat
  async streamMessage(request: ChatRequest): Promise<ReadableStream> {
    const response = await fetch(`${this.baseURL}/chat/stream`, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'Authorization': `Bearer ${localStorage.getItem('access_token')}`,
      },
      body: JSON.stringify(request),
    });

    if (!response.ok) {
      throw new Error(`HTTP error! status: ${response.status}`);
    }

    return response.body!;
  }

  // Utility methods
  setAuthToken(token: string): void {
    localStorage.setItem('access_token', token);
  }

  getAuthToken(): string | null {
    return localStorage.getItem('access_token');
  }

  isAuthenticated(): boolean {
    return !!this.getAuthToken();
  }

  // Generic HTTP methods for other services
  async get<T = any>(url: string): Promise<{ data: T }> {
    const response = await this.api.get(url);
    return response;
  }

  async post<T = any>(url: string, data?: any): Promise<{ data: T }> {
    const response = await this.api.post(url, data);
    return response;
  }

  async put<T = any>(url: string, data?: any): Promise<{ data: T }> {
    const response = await this.api.put(url, data);
    return response;
  }

  async delete<T = any>(url: string): Promise<{ data: T }> {
    const response = await this.api.delete(url);
    return response;
  }
}

export const apiService = new ApiService();
export default apiService;
