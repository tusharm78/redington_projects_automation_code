import { io, Socket } from 'socket.io-client';
import { ChatRequest } from '../types';

export interface StreamingChatResponse {
  conversation_id?: string;
  session_id?: string;
  message_id?: string;
  timestamp?: string;
  model_used?: string;
  chunk: string;
  is_complete: boolean;
  full_response?: string;
}

export interface ChatStartResponse {
  conversation_id?: string;
  session_id?: string;
  message_id?: string;
  timestamp?: string;
  model_used?: string;
}

class SocketService {
  private socket: Socket | null = null;
  private baseURL = process.env.REACT_APP_API_URL?.replace('/api/v1', '') || 'http://localhost:8000';
  private isConnected = false;
  private authToken: string | null = null;

  // Event callbacks
  private onConnectCallback?: () => void;
  private onDisconnectCallback?: () => void;
  private onAuthSuccessCallback?: (data: any) => void;
  private onAuthErrorCallback?: (error: string) => void;
  private onChatStartCallback?: (data: ChatStartResponse) => void;
  private onChatChunkCallback?: (data: StreamingChatResponse) => void;
  private onChatErrorCallback?: (error: string) => void;

  constructor() {
    console.log('🔧 SocketService initialized with baseURL:', this.baseURL);
  }

  connect(): Promise<void> {
    return new Promise((resolve, reject) => {
      if (this.socket && this.isConnected) {
        resolve();
        return;
      }

      console.log('🔌 Connecting to Socket.IO server...');
      
      this.socket = io(this.baseURL, {
        transports: ['websocket', 'polling'],
        timeout: 20000,
        forceNew: true
      });

      this.socket.on('connect', () => {
        console.log('✅ Connected to Socket.IO server');
        this.isConnected = true;
        this.onConnectCallback?.();
        
        // Auto-authenticate if token is available
        const token = localStorage.getItem('access_token');
        if (token) {
          this.authenticate(token);
        }
        
        resolve();
      });

      this.socket.on('disconnect', () => {
        console.log('❌ Disconnected from Socket.IO server');
        this.isConnected = false;
        this.onDisconnectCallback?.();
      });

      this.socket.on('connect_error', (error) => {
        console.error('❌ Socket.IO connection error:', error);
        this.isConnected = false;
        reject(error);
      });

      this.socket.on('auth-success', (data) => {
        console.log('✅ Authentication successful:', data);
        this.onAuthSuccessCallback?.(data);
      });

      this.socket.on('auth-error', (data) => {
        console.error('❌ Authentication failed:', data.error);
        this.onAuthErrorCallback?.(data.error);
      });

      this.socket.on('chat-start', (data: ChatStartResponse) => {
        console.log('🚀 Chat response started:', data);
        this.onChatStartCallback?.(data);
      });

      this.socket.on('chat-chunk', (data: StreamingChatResponse) => {
        this.onChatChunkCallback?.(data);
      });

      this.socket.on('chat-error', (data) => {
        console.error('❌ Chat error:', data.error);
        this.onChatErrorCallback?.(data.error);
      });
    });
  }

  disconnect() {
    if (this.socket) {
      console.log('🔌 Disconnecting from Socket.IO server...');
      this.socket.disconnect();
      this.socket = null;
      this.isConnected = false;
    }
  }

  authenticate(token: string) {
    if (!this.socket || !this.isConnected) {
      console.error('❌ Cannot authenticate: not connected');
      return;
    }

    this.authToken = token;
    this.socket.emit('authenticate', { token });
  }

  sendMessage(request: ChatRequest): Promise<void> {
    return new Promise((resolve, reject) => {
      if (!this.socket || !this.isConnected) {
        reject(new Error('Not connected to server'));
        return;
      }

      if (!this.authToken) {
        reject(new Error('Not authenticated'));
        return;
      }

      console.log('📤 Sending message via Socket.IO:', request);
      
      this.socket.emit('send_message', {
        message: request.message,
        conversation_id: request.conversation_id,
        session_id: request.session_id,
        model_config: request.model_config
      });

      resolve();
    });
  }

  // Event listener setters
  onConnect(callback: () => void) {
    this.onConnectCallback = callback;
  }

  onDisconnect(callback: () => void) {
    this.onDisconnectCallback = callback;
  }

  onAuthSuccess(callback: (data: any) => void) {
    this.onAuthSuccessCallback = callback;
  }

  onAuthError(callback: (error: string) => void) {
    this.onAuthErrorCallback = callback;
  }

  onChatStart(callback: (data: ChatStartResponse) => void) {
    this.onChatStartCallback = callback;
  }

  onChatChunk(callback: (data: StreamingChatResponse) => void) {
    this.onChatChunkCallback = callback;
  }

  onChatError(callback: (error: string) => void) {
    this.onChatErrorCallback = callback;
  }

  isSocketConnected(): boolean {
    return this.isConnected && this.socket?.connected === true;
  }
}

// Export singleton instance
export const socketService = new SocketService();
export default socketService;
