import { apiService } from './api';

export interface ChatSession {
  chat_id: string;
  chat_title: string;
  created_at?: number;
  updated_at?: number;
}

export interface SessionMessage {
  message_id: string;
  role: 'user' | 'assistant';
  content: string;
  timestamp: number;
  has_context?: boolean;
  user_prompt?: string;
  images?: string[];
}

class SessionsService {
  private baseUrl = '/sessions';

  async getUserSessions(): Promise<any> {
    try {
      console.log('🔍 Fetching user sessions from backend...');
      const response = await apiService.get(this.baseUrl);
      console.log('✅ Sessions response:', response.data);
      
      // Return the raw response so the frontend can handle the conversion
      return response.data;
    } catch (error) {
      console.error('❌ Error fetching user sessions:', error);
      throw error;
    }
  }

  async createSession(chatTitle?: string): Promise<{ chat_id: string; message: string }> {
    try {
      console.log('🔍 Creating new session with title:', chatTitle);
      const response = await apiService.post(this.baseUrl, {
        title: chatTitle || 'New Chat Session'
      });
      console.log('✅ Session created:', response.data);
      
      // Backend returns {id, name, created_at, updated_at}
      // Frontend expects {chat_id, message}
      return {
        chat_id: response.data.id,
        message: 'Session created successfully'
      };
    } catch (error) {
      console.error('❌ Error creating session:', error);
      throw error;
    }
  }

  async deleteSession(chatId: string): Promise<{ message: string }> {
    try {
      console.log('🔍 Deleting session:', chatId);
      const response = await apiService.delete(`${this.baseUrl}/${chatId}`);
      console.log('✅ Session deleted:', response.data);
      return response.data;
    } catch (error) {
      console.error('❌ Error deleting session:', error);
      throw error;
    }
  }

  async updateSessionTitle(chatId: string, newTitle: string): Promise<{ message: string }> {
    try {
      console.log('🔍 Updating session title:', chatId, newTitle);
      const response = await apiService.put(`${this.baseUrl}/${chatId}`, {
        title: newTitle
      });
      console.log('✅ Session title updated:', response.data);
      return response.data;
    } catch (error) {
      console.error('❌ Error updating session title:', error);
      throw error;
    }
  }

  async getSessionMessages(chatId: string): Promise<SessionMessage[]> {
    try {
      console.log('🔍 Fetching messages for session:', chatId);
      // Use the correct backend endpoint for chat history
      const response = await apiService.get(`/chat/history/${chatId}`);
      console.log('✅ Messages response:', response.data);
      
      // Backend returns {messages: [{id, role, content, timestamp, model}], conversation_id}
      // Frontend expects SessionMessage[]
      const messages = response.data.messages || [];
      
      const convertedMessages: SessionMessage[] = messages.map((msg: any) => ({
        message_id: msg.id,
        role: msg.role,
        content: msg.content,
        timestamp: new Date(msg.timestamp).getTime() / 1000, // Convert to seconds
        has_context: false,
        user_prompt: msg.role === 'user' ? msg.content : undefined
      }));
      
      console.log('🔄 Converted messages to frontend format:', convertedMessages);
      return convertedMessages;
    } catch (error) {
      console.error('❌ Error fetching session messages:', error);
      throw error;
    }
  }

  async getSessionInfo(chatId: string): Promise<ChatSession | null> {
    try {
      console.log('🔍 Fetching session info:', chatId);
      // Get session info from sessions list
      const sessions = await this.getUserSessions();
      const sessionTitle = sessions[chatId];
      
      if (sessionTitle) {
        return {
          chat_id: chatId,
          chat_title: sessionTitle,
          created_at: Date.now() / 1000,
          updated_at: Date.now() / 1000
        };
      }
      
      return null;
    } catch (error) {
      console.error('❌ Error fetching session info:', error);
      return null;
    }
  }
}

export const sessionsService = new SessionsService();
