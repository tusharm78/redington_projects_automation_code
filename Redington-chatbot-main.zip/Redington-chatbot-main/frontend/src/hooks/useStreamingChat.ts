import { useState, useEffect, useCallback, useRef } from 'react';
import { socketService, StreamingChatResponse, ChatStartResponse } from '../services/socketService';
import { ChatMessage, ChatRequest } from '../types';

interface UseStreamingChatReturn {
  messages: ChatMessage[];
  isConnected: boolean;
  isAuthenticated: boolean;
  isStreaming: boolean;
  sendMessage: (request: ChatRequest) => Promise<void>;
  connect: () => Promise<void>;
  disconnect: () => void;
  clearMessages: () => void;
  error: string | null;
}

export const useStreamingChat = (): UseStreamingChatReturn => {
  const [messages, setMessages] = useState<ChatMessage[]>([]);
  const [isConnected, setIsConnected] = useState(false);
  const [isAuthenticated, setIsAuthenticated] = useState(false);
  const [isStreaming, setIsStreaming] = useState(false);
  const [error, setError] = useState<string | null>(null);
  
  // Use refs to store current streaming message
  const currentStreamingMessage = useRef<ChatMessage | null>(null);
  const streamingContent = useRef<string>('');

  const connect = useCallback(async () => {
    try {
      await socketService.connect();
    } catch (error) {
      console.error('Failed to connect:', error);
      setError('Failed to connect to server');
    }
  }, []);

  const disconnect = useCallback(() => {
    socketService.disconnect();
  }, []);

  const sendMessage = useCallback(async (request: ChatRequest) => {
    if (!isConnected || !isAuthenticated) {
      throw new Error('Not connected or authenticated');
    }

    // Add user message to chat
    const userMessage: ChatMessage = {
      id: Date.now().toString(),
      content: request.message,
      role: 'user',
      timestamp: new Date().toISOString(),
    };

    setMessages(prev => [...prev, userMessage]);
    setError(null);
    setIsStreaming(true);

    // Reset streaming state
    currentStreamingMessage.current = null;
    streamingContent.current = '';

    try {
      await socketService.sendMessage(request);
    } catch (error) {
      console.error('Failed to send message:', error);
      setError('Failed to send message');
      setIsStreaming(false);
    }
  }, [isConnected, isAuthenticated]);

  const clearMessages = useCallback(() => {
    setMessages([]);
    currentStreamingMessage.current = null;
    streamingContent.current = '';
  }, []);

  // Setup socket event listeners
  useEffect(() => {
    socketService.onConnect(() => {
      console.log('✅ Socket connected');
      setIsConnected(true);
      setError(null);
    });

    socketService.onDisconnect(() => {
      console.log('❌ Socket disconnected');
      setIsConnected(false);
      setIsAuthenticated(false);
      setIsStreaming(false);
    });

    socketService.onAuthSuccess((data) => {
      console.log('✅ Authentication successful:', data);
      setIsAuthenticated(true);
      setError(null);
    });

    socketService.onAuthError((error) => {
      console.error('❌ Authentication failed:', error);
      setIsAuthenticated(false);
      setError(`Authentication failed: ${error}`);
    });

    socketService.onChatStart((data: ChatStartResponse) => {
      console.log('🚀 Chat started:', data);
      
      // Create new assistant message
      const assistantMessage: ChatMessage = {
        id: data.message_id || Date.now().toString(),
        content: '',
        role: 'assistant',
        timestamp: data.timestamp || new Date().toISOString(),
        conversation_id: data.conversation_id,
        session_id: data.session_id,
        model_used: data.model_used,
      };

      currentStreamingMessage.current = assistantMessage;
      streamingContent.current = '';
      
      setMessages(prev => [...prev, assistantMessage]);
    });

    socketService.onChatChunk((data: StreamingChatResponse) => {
      if (data.is_complete) {
        // Streaming complete
        console.log('✅ Streaming complete');
        setIsStreaming(false);
        
        if (currentStreamingMessage.current && data.full_response) {
          // Update with final content
          setMessages(prev => 
            prev.map(msg => 
              msg.id === currentStreamingMessage.current?.id 
                ? { ...msg, content: data.full_response! }
                : msg
            )
          );
        }
        
        currentStreamingMessage.current = null;
        streamingContent.current = '';
      } else {
        // Append chunk to streaming content
        streamingContent.current += data.chunk;
        
        if (currentStreamingMessage.current) {
          setMessages(prev => 
            prev.map(msg => 
              msg.id === currentStreamingMessage.current?.id 
                ? { ...msg, content: streamingContent.current }
                : msg
            )
          );
        }
      }
    });

    socketService.onChatError((error) => {
      console.error('❌ Chat error:', error);
      setError(`Chat error: ${error}`);
      setIsStreaming(false);
      currentStreamingMessage.current = null;
      streamingContent.current = '';
    });

    // Auto-authenticate on mount if token exists
    const token = localStorage.getItem('access_token');
    if (token && socketService.isSocketConnected()) {
      socketService.authenticate(token);
    }

    return () => {
      // Cleanup is handled by the service
    };
  }, []);

  // Auto-authenticate when connected and token is available
  useEffect(() => {
    if (isConnected && !isAuthenticated) {
      const token = localStorage.getItem('access_token');
      if (token) {
        socketService.authenticate(token);
      }
    }
  }, [isConnected, isAuthenticated]);

  return {
    messages,
    isConnected,
    isAuthenticated,
    isStreaming,
    sendMessage,
    connect,
    disconnect,
    clearMessages,
    error,
  };
};
