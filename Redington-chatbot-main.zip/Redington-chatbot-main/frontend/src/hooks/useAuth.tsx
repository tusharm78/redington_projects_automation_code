import { useState, useEffect, useContext, createContext, ReactNode } from 'react';
import { UserInfo, AuthRequest } from '../types';
import apiService from '../services/api';

interface AuthContextType {
  user: UserInfo | null;
  login: (credentials: AuthRequest) => Promise<void>;
  logout: () => Promise<void>;
  loading: boolean;
  isAuthenticated: boolean;
}

const AuthContext = createContext<AuthContextType | undefined>(undefined);

export const AuthProvider = ({ children }: { children: ReactNode }) => {
  const [user, setUser] = useState<UserInfo | null>(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const initAuth = async () => {
      if (apiService.isAuthenticated()) {
        try {
          const userInfo = await apiService.getCurrentUser();
          setUser(userInfo);
        } catch (error) {
          console.error('Failed to get user info:', error);
          apiService.logout();
        }
      }
      setLoading(false);
    };

    initAuth();
  }, []);

  const login = async (credentials: AuthRequest) => {
    console.log('🔐 useAuth.login called with:', { username: credentials.username, password: '***' });
    try {
      console.log('🔐 Calling apiService.login...');
      const response = await apiService.login(credentials);
      console.log('🔐 apiService.login succeeded:', response);
      
      apiService.setAuthToken(response.access_token);
      console.log('🔐 Auth token set');
      
      const userInfo = await apiService.getCurrentUser();
      console.log('🔐 User info retrieved:', userInfo);
      setUser(userInfo);
      console.log('🔐 User state updated');
    } catch (error) {
      console.log('🔐 useAuth.login error caught:', error);
      console.log('🔐 Re-throwing error to Login component');
      throw error;
    }
  };

  const logout = async () => {
    try {
      await apiService.logout();
      setUser(null);
    } catch (error) {
      console.error('Logout error:', error);
    }
  };

  const value = {
    user,
    login,
    logout,
    loading,
    isAuthenticated: !!user,
  };

  return <AuthContext.Provider value={value}>{children}</AuthContext.Provider>;
};

export const useAuth = () => {
  const context = useContext(AuthContext);
  if (context === undefined) {
    throw new Error('useAuth must be used within an AuthProvider');
  }
  return context;
};
