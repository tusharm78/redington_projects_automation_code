import { useState, useCallback, useRef } from 'react';
import { ChatMessage, ChatRequest } from '../types';

interface StreamingMetadata {
  chunk_index: number;
  total_chunks: number;
  timestamp: string;
  error?: boolean;
}

interface UseEnhancedStreamingReturn {
  messages: ChatMessage[];
  isStreaming: boolean;
  sendMessage: (request: ChatRequest) => Promise<void>;
  clearMessages: () => void;
  error: string | null;
  streamingMetadata: StreamingMetadata | null;
}

export const useEnhancedStreaming = (): UseEnhancedStreamingReturn => {
  const [messages, setMessages] = useState<ChatMessage[]>([]);
  const [isStreaming, setIsStreaming] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [streamingMetadata, setStreamingMetadata] = useState<StreamingMetadata | null>(null);
  const abortControllerRef = useRef<AbortController | null>(null);

  const sendMessage = useCallback(async (request: ChatRequest) => {
    try {
      setError(null);
      setIsStreaming(true);
      setStreamingMetadata(null);

      // Cancel any existing stream
      if (abortControllerRef.current) {
        abortControllerRef.current.abort();
      }

      // Create new abort controller
      abortControllerRef.current = new AbortController();

      // Add user message immediately
      const userMessage: ChatMessage = {
        id: Date.now().toString(),
        content: request.message,
        role: 'user',
        timestamp: new Date().toISOString(),
      };

      setMessages(prev => [...prev, userMessage]);

      // Create AI message placeholder
      const aiMessageId = (Date.now() + 1).toString();
      const aiMessage: ChatMessage = {
        id: aiMessageId,
        content: '',
        role: 'assistant',
        timestamp: new Date().toISOString(),
      };

      setMessages(prev => [...prev, aiMessage]);

      // Get auth token
      const token = localStorage.getItem('access_token');
      if (!token) {
        throw new Error('Authentication required');
      }

      // Start streaming
      const response = await fetch('/api/v1/chat/stream', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${token}`,
        },
        body: JSON.stringify(request),
        signal: abortControllerRef.current.signal,
      });

      if (!response.ok) {
        throw new Error(`HTTP error! status: ${response.status}`);
      }

      const reader = response.body?.getReader();
      if (!reader) {
        throw new Error('No response body');
      }

      const decoder = new TextDecoder();
      let accumulatedContent = '';

      try {
        while (true) {
          const { done, value } = await reader.read();
          
          if (done) break;

          const chunk = decoder.decode(value, { stream: true });
          const lines = chunk.split('\n');

          for (const line of lines) {
            if (line.startsWith('data: ')) {
              try {
                const jsonData = line.slice(6); // Remove 'data: ' prefix
                if (jsonData.trim()) {
                  const chunkData = JSON.parse(jsonData);
                  
                  // Update metadata
                  if (chunkData.metadata) {
                    setStreamingMetadata(chunkData.metadata);
                  }

                  // Handle error chunks
                  if (chunkData.metadata?.error) {
                    setError('Failed to generate response');
                    accumulatedContent += chunkData.chunk;
                  } else {
                    // Accumulate content
                    accumulatedContent += chunkData.chunk;
                  }
                  
                  // Update the AI message with accumulated content
                  setMessages(prev => 
                    prev.map(msg => 
                      msg.id === aiMessageId 
                        ? { ...msg, content: accumulatedContent }
                        : msg
                    )
                  );

                  // Check if streaming is complete
                  if (chunkData.is_complete) {
                    setIsStreaming(false);
                    setStreamingMetadata(null);
                    break;
                  }
                }
              } catch (parseError) {
                console.warn('Failed to parse chunk data:', parseError);
                // Continue processing other chunks
              }
            }
          }
        }
      } finally {
        reader.releaseLock();
      }

    } catch (err) {
      console.error('Enhanced streaming error:', err);
      
      if (err instanceof Error && err.name === 'AbortError') {
        // Request was aborted, don't show error
        return;
      }
      
      const errorMessage = err instanceof Error ? err.message : 'Failed to send message';
      setError(errorMessage);
      
      // Add error message to chat
      const errorMessageObj: ChatMessage = {
        id: (Date.now() + 2).toString(),
        content: `❌ **Error**: ${errorMessage}`,
        role: 'assistant',
        timestamp: new Date().toISOString(),
      };
      
      setMessages(prev => [...prev, errorMessageObj]);
    } finally {
      setIsStreaming(false);
      setStreamingMetadata(null);
      abortControllerRef.current = null;
    }
  }, []);

  const clearMessages = useCallback(() => {
    // Cancel any ongoing stream
    if (abortControllerRef.current) {
      abortControllerRef.current.abort();
    }
    
    setMessages([]);
    setError(null);
    setIsStreaming(false);
    setStreamingMetadata(null);
  }, []);

  return {
    messages,
    isStreaming,
    sendMessage,
    clearMessages,
    error,
    streamingMetadata,
  };
};
