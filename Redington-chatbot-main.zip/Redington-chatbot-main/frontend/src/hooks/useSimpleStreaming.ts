import { useState, useCallback } from 'react';
import { ChatMessage, ChatRequest } from '../types';
import { apiService } from '../services/api';

interface UseSimpleStreamingReturn {
  messages: ChatMessage[];
  isStreaming: boolean;
  sendMessage: (request: ChatRequest) => Promise<void>;
  clearMessages: () => void;
  error: string | null;
}

export const useSimpleStreaming = (): UseSimpleStreamingReturn => {
  const [messages, setMessages] = useState<ChatMessage[]>([]);
  const [isStreaming, setIsStreaming] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const sendMessage = useCallback(async (request: ChatRequest) => {
    try {
      setError(null);
      setIsStreaming(true);

      // Add user message immediately
      const userMessage: ChatMessage = {
        id: Date.now().toString(),
        content: request.message,
        role: 'user',
        timestamp: new Date().toISOString(),
      };

      setMessages(prev => [...prev, userMessage]);

      // Create AI message placeholder
      const aiMessageId = (Date.now() + 1).toString();
      const aiMessage: ChatMessage = {
        id: aiMessageId,
        content: '',
        role: 'assistant',
        timestamp: new Date().toISOString(),
      };

      setMessages(prev => [...prev, aiMessage]);

      // Start streaming
      const stream = await apiService.streamMessage(request);
      const reader = stream.getReader();
      const decoder = new TextDecoder();

      let accumulatedContent = '';

      while (true) {
        const { done, value } = await reader.read();
        
        if (done) break;

        const chunk = decoder.decode(value, { stream: true });
        const lines = chunk.split('\n');

        for (const line of lines) {
          if (line.startsWith('data: ')) {
            const content = line.slice(6); // Remove 'data: ' prefix
            if (content.trim()) {
              accumulatedContent += content;
              
              // Update the AI message with accumulated content
              setMessages(prev => 
                prev.map(msg => 
                  msg.id === aiMessageId 
                    ? { ...msg, content: accumulatedContent }
                    : msg
                )
              );
            }
          }
        }
      }

      setIsStreaming(false);
    } catch (err) {
      console.error('Streaming error:', err);
      setError(err instanceof Error ? err.message : 'Failed to send message');
      setIsStreaming(false);
    }
  }, []);

  const clearMessages = useCallback(() => {
    setMessages([]);
    setError(null);
  }, []);

  return {
    messages,
    isStreaming,
    sendMessage,
    clearMessages,
    error,
  };
};
