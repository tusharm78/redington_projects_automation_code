/**
 * Utility functions for customer name replacement in downloaded documents
 */

/**
 * Extract customer name from user message using various patterns
 */
export const extractCustomerName = (userMessage: string): string | null => {
  if (!userMessage) return null;
  
  // Improved patterns to better capture company names
  const patterns = [
    // "for [Company Name]" - captures multi-word company names
    /for\s+([A-Za-z][A-Za-z0-9\s&.-]{1,30}?)(?:\s+(?:company|corp|corporation|inc|incorporated|ltd|limited|llc|pvt|private|technologies|tech|systems|solutions|services|group|international|global))?(?:\s|$|[.,!?])/i,
    // "customer name is [Company Name]"
    /customer\s+(?:name\s+is\s+|is\s+)([A-Za-z][A-Za-z0-9\s&.-]{1,30}?)(?:\s+(?:company|corp|corporation|inc|incorporated|ltd|limited|llc|pvt|private|technologies|tech|systems|solutions|services|group|international|global))?(?:\s|$|[.,!?])/i,
    // "client is [Company Name]"
    /client\s+(?:name\s+is\s+|is\s+)([A-Za-z][A-Za-z0-9\s&.-]{1,30}?)(?:\s+(?:company|corp|corporation|inc|incorporated|ltd|limited|llc|pvt|private|technologies|tech|systems|solutions|services|group|international|global))?(?:\s|$|[.,!?])/i,
    // "proposal for [Company Name]"
    /proposal\s+for\s+([A-Za-z][A-Za-z0-9\s&.-]{1,30}?)(?:\s+(?:company|corp|corporation|inc|incorporated|ltd|limited|llc|pvt|private|technologies|tech|systems|solutions|services|group|international|global))?(?:\s|$|[.,!?])/i,
    // "company name is [Company Name]"
    /(?:company|organization|firm)\s+(?:name\s+is\s+|is\s+|called\s+)([A-Za-z][A-Za-z0-9\s&.-]{1,30}?)(?:\s|$|[.,!?])/i,
    // More specific patterns for common phrasings
    /for\s+(?:the\s+)?company\s+([A-Za-z][A-Za-z0-9\s&.-]{1,30}?)(?:\s|$|[.,!?])/i,
    /for\s+customer\s+([A-Za-z][A-Za-z0-9\s&.-]{1,30}?)(?:\s+(?:company|corp|corporation|inc|incorporated|ltd|limited|llc|pvt|private))?(?:\s|$|[.,!?])/i,
  ];
  
  for (const pattern of patterns) {
    const match = userMessage.match(pattern);
    if (match) {
      let customerName = match[1].trim();
      // Clean up the customer name
      customerName = customerName.replace(/\s+/g, ' '); // Remove extra spaces
      customerName = customerName.replace(/^(a|an|the)\s+/i, ''); // Remove articles
      
      // Convert to proper case
      customerName = customerName.split(' ')
        .map(word => word.charAt(0).toUpperCase() + word.slice(1).toLowerCase())
        .join(' ');
      
      // Filter out common words that aren't company names
      const excludedWords = new Set([
        'the', 'and', 'or', 'but', 'with', 'from', 'this', 'that', 'they', 'them',
        'customer', 'client', 'company', 'name', 'called', 'any', 'some', 'all',
        'without', 'proposal', 'create', 'generate', 'need', 'want', 'make'
      ]);
      
      // Validate it's not too short and not an excluded word
      if (customerName.length >= 2 && 
          !excludedWords.has(customerName.toLowerCase()) &&
          !customerName.toLowerCase().startsWith('a ') &&
          !customerName.toLowerCase().startsWith('an ') &&
          !customerName.toLowerCase().startsWith('the ')) {
        return customerName;
      }
    }
  }
  
  return null;
};

/**
 * Replace customer name placeholders in content
 */
export const replaceCustomerNamePlaceholders = (
  content: string, 
  customerName: string | null
): string => {
  if (!customerName) {
    return content;
  }
  
  // Replace all instances of <Customer Name> with the actual customer name
  return content.replace(/<Customer Name>/g, customerName);
};

/**
 * Get processed content with customer name replacement for downloads
 */
export const getProcessedContentForDownload = (
  originalContent: string,
  userMessage?: string
): string => {
  if (!userMessage) {
    return originalContent;
  }
  
  const customerName = extractCustomerName(userMessage);
  return replaceCustomerNamePlaceholders(originalContent, customerName);
};

/**
 * Store customer name in session storage for later use
 */
export const storeCustomerNameForSession = (sessionId: string, customerName: string | null): void => {
  if (customerName) {
    sessionStorage.setItem(`customer_name_${sessionId}`, customerName);
  }
};

/**
 * Retrieve customer name from session storage
 */
export const getCustomerNameFromSession = (sessionId: string): string | null => {
  return sessionStorage.getItem(`customer_name_${sessionId}`);
};

/**
 * Extract customer name from user message and store it for the session
 */
export const processAndStoreCustomerName = (userMessage: string, sessionId: string): string | null => {
  const customerName = extractCustomerName(userMessage);
  storeCustomerNameForSession(sessionId, customerName);
  return customerName;
};
