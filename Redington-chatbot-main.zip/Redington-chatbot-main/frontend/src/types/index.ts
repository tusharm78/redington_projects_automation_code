export interface ChatMessage {
  id?: string;
  role: 'user' | 'assistant';
  content: string;
  timestamp?: string;
  message_id?: string;
  conversation_id?: string;
  session_id?: string;
  model_used?: string;
}

export interface ChatRequest {
  message: string;
  conversation_id?: string;
  session_id?: string;
  model_name?: string;
  model_config?: {
    max_tokens?: number;
    temperature?: number;
    top_p?: number;
    top_k?: number;
  };
  model_kwargs?: {
    max_tokens: number;
    temperature: number;
    top_p: number;
    top_k: number;
  };
  files?: string[];
  system_prompt?: string;
}

export interface ChatResponse {
  response: string;
  conversation_id: string;
  message_id: string;
  model_used: string;
  timestamp: string;
}

export interface AuthRequest {
  username: string;
  password: string;
}

export interface AuthResponse {
  access_token: string;
  token_type: string;
  expires_in: number;
}

export interface UserInfo {
  username: string;
  email?: string;
  groups?: string[];
}

export interface ModelConfig {
  [key: string]: {
    model_id: string;
    input_format: string;
    thinking: number;
    temperature: number;
    top_p?: number;
    top_k: number;
    max_tokens: number;
    memory_window: number;
    max_top_k: number;
  };
}
