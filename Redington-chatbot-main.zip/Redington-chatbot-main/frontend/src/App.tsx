import React from 'react';
import { BrowserRouter as Router, Routes, Route, Navigate } from 'react-router-dom';
import { ThemeProvider, createTheme } from '@mui/material/styles';
import { CssBaseline, CircularProgress, Box } from '@mui/material';
import { AuthProvider, useAuth } from './hooks';
import { Login } from './components';
import ModernChatInterface from './components/ModernChatInterface';
import EnhancedStreamingChat from './components/EnhancedStreamingChat';
import SessionsDebugTest from './components/SessionsDebugTest';
import './styles/streaming-optimizations.css';
import './styles/no-shadow-border.css';

// Redington Brand Theme with Green Colors
const redingtonTheme = createTheme({
  palette: {
    primary: {
      main: '#28A745', // Green instead of Red
      light: '#4CAF50', // Light Green
      dark: '#1B7A31', // Dark Green
      contrastText: '#FFFFFF',
    },
    secondary: {
      main: '#1A1A1A', // Dark Gray
      light: '#2C3E50',
      dark: '#000000',
      contrastText: '#FFFFFF',
    },
    background: {
      default: '#F8F9FA',
      paper: '#FFFFFF',
    },
    text: {
      primary: '#2C3E50',
      secondary: '#6C757D',
    },
    success: {
      main: '#28A745',
    },
    warning: {
      main: '#FFC107',
    },
    error: {
      main: '#4CAF50', // Changed from red to green
    },
  },
  typography: {
    fontFamily: 'Calibri, Calibri Body, Segoe UI, Roboto, Helvetica, Arial, sans-serif',
    h1: {
      fontWeight: 700,
      fontSize: '2.5rem', // 40px - Main page titles
      lineHeight: 1.2,
      letterSpacing: '-0.02em',
    },
    h2: {
      fontWeight: 600,
      fontSize: '2rem', // 32px - Section headers
      lineHeight: 1.3,
      letterSpacing: '-0.01em',
    },
    h3: {
      fontWeight: 600,
      fontSize: '1.75rem', // 28px - Subsection headers
      lineHeight: 1.3,
    },
    h4: {
      fontWeight: 600,
      fontSize: '1.5rem', // 24px - Component titles
      lineHeight: 1.4,
    },
    h5: {
      fontWeight: 600,
      fontSize: '1.25rem', // 20px - Card titles, dialog headers
      lineHeight: 1.4,
    },
    h6: {
      fontWeight: 600,
      fontSize: '1.125rem', // 18px - Small headers, labels
      lineHeight: 1.4,
    },
    body1: {
      fontSize: '1rem', // 16px - Default body text
      lineHeight: 1.6,
      fontFamily: 'Calibri, Calibri Body, Segoe UI, Roboto, Helvetica, Arial, sans-serif',
    },
    body2: {
      fontSize: '0.875rem', // 14px - Secondary text
      lineHeight: 1.5,
      fontFamily: 'Calibri, Calibri Body, Segoe UI, Roboto, Helvetica, Arial, sans-serif',
    },
  },
  components: {
    MuiButton: {
      styleOverrides: {
        root: {
          textTransform: 'none',
          borderRadius: 12,
          fontWeight: 600,
          padding: '10px 24px',
          boxShadow: 'none',
          '&:hover': {
            boxShadow: '0 4px 12px rgba(40, 167, 69, 0.3)', // Green shadow
          },
        },
        contained: {
          background: 'linear-gradient(135deg, #28A745 0%, #4CAF50 100%)', // Green gradient
          '&:hover': {
            background: 'linear-gradient(135deg, #1B7A31 0%, #28A745 100%)', // Darker green gradient on hover
          },
        },
      },
    },
    MuiCard: {
      styleOverrides: {
        root: {
          borderRadius: 16,
          boxShadow: '0 4px 20px rgba(0, 0, 0, 0.08)',
          border: '1px solid rgba(0, 0, 0, 0.05)',
        },
      },
    },
    MuiPaper: {
      styleOverrides: {
        root: {
          borderRadius: 12,
          boxShadow: '0 2px 12px rgba(0, 0, 0, 0.08)',
        },
      },
    },
    MuiTextField: {
      styleOverrides: {
        root: {
          '& .MuiOutlinedInput-root': {
            borderRadius: 12,
            '&:hover .MuiOutlinedInput-notchedOutline': {
              borderColor: '#28A745', // Green border on hover
            },
            '&.Mui-focused .MuiOutlinedInput-notchedOutline': {
              borderColor: '#28A745', // Green border when focused
              borderWidth: 2,
            },
          },
        },
      },
    },
    MuiChip: {
      styleOverrides: {
        root: {
          borderRadius: 8,
          fontWeight: 500,
        },
      },
    },
    MuiAvatar: {
      styleOverrides: {
        root: {
          fontWeight: 600,
        },
      },
    },
  },
});

const ProtectedRoute: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const { isAuthenticated, loading } = useAuth();

  if (loading) {
    return (
      <Box
        display="flex"
        justifyContent="center"
        alignItems="center"
        minHeight="100vh"
        flexDirection="column"
        sx={{
          background: 'linear-gradient(135deg, #28A745 0%, #4CAF50 100%)', // Green gradient
          color: 'white',
        }}
      >
        <Box
          sx={{
            width: 80,
            height: 80,
            borderRadius: '50%',
            background: 'rgba(255, 255, 255, 0.2)',
            display: 'flex',
            alignItems: 'center',
            justifyContent: 'center',
            mb: 3,
            fontSize: '2rem',
            fontWeight: 700,
          }}
        >
          R
        </Box>
        <CircularProgress size={60} sx={{ color: 'white', mb: 2 }} />
        <Box sx={{ textAlign: 'center' }}>
          <div style={{ fontSize: '1.2rem', fontWeight: 600 }}>Loading Redington AI Assistant...</div>
          <div style={{ fontSize: '0.9rem', opacity: 0.8, marginTop: '8px' }}>
            Initializing advanced AI capabilities
          </div>
        </Box>
      </Box>
    );
  }

  return isAuthenticated ? <>{children}</> : <Navigate to="/login" replace />;
};

const PublicRoute: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const { isAuthenticated, loading } = useAuth();

  if (loading) {
    return (
      <Box
        display="flex"
        justifyContent="center"
        alignItems="center"
        minHeight="100vh"
        flexDirection="column"
        sx={{
          background: 'linear-gradient(135deg, #28A745 0%, #4CAF50 100%)', // Green gradient
          color: 'white',
        }}
      >
        <CircularProgress size={60} sx={{ color: 'white' }} />
        <Box mt={2} sx={{ textAlign: 'center' }}>
          <div style={{ fontSize: '1.1rem', fontWeight: 600 }}>Loading...</div>
        </Box>
      </Box>
    );
  }

  return !isAuthenticated ? <>{children}</> : <Navigate to="/" replace />;
};

const AppContent: React.FC = () => {
  return (
    <Router>
      <Routes>
        <Route
          path="/login"
          element={
            <PublicRoute>
              <Login />
            </PublicRoute>
          }
        />
        <Route
          path="/debug"
          element={
            <ProtectedRoute>
              <SessionsDebugTest />
            </ProtectedRoute>
          }
        />
        <Route
          path="/streaming"
          element={
            <ProtectedRoute>
              <EnhancedStreamingChat />
            </ProtectedRoute>
          }
        />
        <Route
          path="/enhanced"
          element={
            <ProtectedRoute>
              <EnhancedStreamingChat />
            </ProtectedRoute>
          }
        />
        <Route
          path="/"
          element={
            <ProtectedRoute>
              <ModernChatInterface />
            </ProtectedRoute>
          }
        />
        <Route path="*" element={<Navigate to="/" replace />} />
      </Routes>
    </Router>
  );
};

const App: React.FC = () => {
  return (
    <ThemeProvider theme={redingtonTheme}>
      <CssBaseline />
      <AuthProvider>
        <AppContent />
      </AuthProvider>
    </ThemeProvider>
  );
};

export default App;
