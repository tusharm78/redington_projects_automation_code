#!/bin/bash

echo "🚀 Testing Real-time Streaming Functionality"
echo "============================================="
echo ""

# Get auth token
echo "🔐 Authenticating..."
TOKEN=$(curl -s -X POST "http://localhost:8000/api/v1/auth/login" \
  -H "Content-Type: application/json" \
  -d '{"username":"tanmay","password":"Admin@123$"}' | jq -r '.access_token')

if [ "$TOKEN" = "null" ] || [ -z "$TOKEN" ]; then
  echo "❌ Authentication failed"
  exit 1
fi

echo "✅ Authentication successful"
echo ""

# Test streaming
echo "💬 Testing streaming response (word-by-word)..."
echo "Question: 'Write a short poem about AI'"
echo ""
echo "📡 Streaming Response:"
echo "====================="

curl -X POST "http://localhost:8000/api/v1/chat/stream" \
  -H "Authorization: Bearer $TOKEN" \
  -H "Content-Type: application/json" \
  -d '{"message":"Write a short poem about AI","model_name":"Claude 3.7 Sonnet Reasoning"}' \
  2>/dev/null | while IFS= read -r line; do
    if [[ $line == data:* ]]; then
      content="${line#data: }"
      if [[ $content == "[DONE]" ]]; then
        echo ""
        echo "✅ Stream completed successfully!"
        break
      elif [[ $content == "[CONVERSATION_ID]"* ]]; then
        conv_id="${content#[CONVERSATION_ID]}"
        echo ""
        echo "🆔 Conversation ID: $conv_id"
      elif [[ $content == "Error:"* ]]; then
        echo ""
        echo "❌ Error: $content"
        break
      else
        # Print streaming content without newline to show real-time effect
        printf "%s" "$content"
      fi
    fi
  done

echo ""
echo ""
echo "🎉 Streaming test completed!"
echo ""
echo "✨ Features demonstrated:"
echo "  ✅ Real-time word-by-word streaming"
echo "  ✅ Conversation ID tracking"
echo "  ✅ Proper stream completion"
echo "  ✅ DynamoDB message persistence"
echo ""
echo "🌐 Access the full UI at: http://localhost:3000"
