#!/usr/bin/env python3
"""
Generate detailed table format report for Redington Chatbot usage - Last 5 Days
"""

import boto3
import json
from datetime import datetime, timedelta, timezone
from collections import defaultdict

def generate_5day_table_report():
    """Generate detailed table format report for last 5 days"""
    
    print("📊 REDINGTON CHATBOT - 5 DAY USER ACTIVITY TABLE REPORT")
    print("=" * 80)
    print(f"Report Generated: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}")
    
    # Calculate date range (last 5 days)
    end_date = datetime.now(timezone.utc)
    start_date = end_date - timedelta(days=5)
    
    print(f"📅 Report Period: {start_date.strftime('%Y-%m-%d')} to {end_date.strftime('%Y-%m-%d')}")
    print("=" * 80)
    
    dynamodb = boto3.resource('dynamodb', region_name='us-east-1')
    
    # Initialize user data structure
    user_data = defaultdict(lambda: {
        'total_conversations': 0,
        'total_messages': 0,
        'first_activity': None,
        'last_activity': None,
        'daily_breakdown': defaultdict(lambda: {'conversations': 0, 'messages': 0}),
        'login_sessions': 0,
        'status': 'Unknown',
        'sample_queries': []
    })
    
    # Analyze chat_history table
    print("🔍 Analyzing chat_history table...")
    try:
        chat_table = dynamodb.Table('chat_history')
        response = chat_table.scan()
        chat_items = response.get('Items', [])
        
        for item in chat_items:
            timestamp_str = item.get('message_timestamp')
            if timestamp_str:
                try:
                    # Convert timestamp from milliseconds
                    timestamp = datetime.fromtimestamp(int(timestamp_str) / 1000, tz=timezone.utc)
                    
                    if start_date <= timestamp <= end_date:
                        user_id = item.get('user_id', 'Unknown')
                        role = item.get('role', 'unknown')
                        content = item.get('content', item.get('user_prompt', ''))
                        
                        # Update user data
                        if role == 'user':  # Only count user messages
                            user_data[user_id]['total_messages'] += 1
                            date_key = timestamp.strftime('%Y-%m-%d')
                            user_data[user_id]['daily_breakdown'][date_key]['messages'] += 1
                            
                            # Store sample queries
                            if len(user_data[user_id]['sample_queries']) < 3 and content:
                                user_data[user_id]['sample_queries'].append(content[:100] + '...' if len(content) > 100 else content)
                        
                        # Update activity timestamps
                        if user_data[user_id]['first_activity'] is None or timestamp < user_data[user_id]['first_activity']:
                            user_data[user_id]['first_activity'] = timestamp
                        if user_data[user_id]['last_activity'] is None or timestamp > user_data[user_id]['last_activity']:
                            user_data[user_id]['last_activity'] = timestamp
                            
                except Exception as e:
                    continue
        
        print(f"✅ Processed {len(chat_items)} chat history records")
        
    except Exception as e:
        print(f"❌ Error analyzing chat_history: {e}")
    
    # Analyze user_chat_sessions table
    print("🔍 Analyzing user_chat_sessions table...")
    try:
        sessions_table = dynamodb.Table('user_chat_sessions')
        response = sessions_table.scan()
        session_items = response.get('Items', [])
        
        for item in session_items:
            timestamp_str = item.get('timestamp')
            if timestamp_str:
                try:
                    if 'T' in timestamp_str:
                        timestamp = datetime.fromisoformat(timestamp_str.replace('Z', '+00:00'))
                    else:
                        timestamp = datetime.strptime(timestamp_str, '%Y-%m-%d %H:%M:%S')
                        timestamp = timestamp.replace(tzinfo=timezone.utc)
                    
                    if start_date <= timestamp <= end_date:
                        user_id = item.get('user_id', 'Unknown')
                        
                        # Update conversation count
                        user_data[user_id]['total_conversations'] += 1
                        date_key = timestamp.strftime('%Y-%m-%d')
                        user_data[user_id]['daily_breakdown'][date_key]['conversations'] += 1
                        
                        # Update activity timestamps
                        if user_data[user_id]['first_activity'] is None or timestamp < user_data[user_id]['first_activity']:
                            user_data[user_id]['first_activity'] = timestamp
                        if user_data[user_id]['last_activity'] is None or timestamp > user_data[user_id]['last_activity']:
                            user_data[user_id]['last_activity'] = timestamp
                            
                except Exception as e:
                    continue
        
        print(f"✅ Processed {len(session_items)} session records")
        
    except Exception as e:
        print(f"❌ Error analyzing user_chat_sessions: {e}")
    
    # Analyze active sessions
    print("🔍 Analyzing user_active_sessions table...")
    try:
        active_table = dynamodb.Table('user_active_sessions')
        response = active_table.scan()
        active_items = response.get('Items', [])
        
        for item in active_items:
            username = item.get('username', 'Unknown')
            status = item.get('status', 'Unknown')
            login_time_str = item.get('login_time')
            
            if login_time_str:
                try:
                    login_time = datetime.fromisoformat(login_time_str.replace('Z', '+00:00'))
                    if start_date <= login_time <= end_date:
                        user_data[username]['login_sessions'] += 1
                        user_data[username]['status'] = status
                        
                        if user_data[username]['first_activity'] is None or login_time < user_data[username]['first_activity']:
                            user_data[username]['first_activity'] = login_time
                        if user_data[username]['last_activity'] is None or login_time > user_data[username]['last_activity']:
                            user_data[username]['last_activity'] = login_time
                            
                except Exception as e:
                    continue
        
        print(f"✅ Processed {len(active_items)} active session records")
        
    except Exception as e:
        print(f"❌ Error analyzing user_active_sessions: {e}")
    
    # Generate table report
    generate_table_output(user_data, start_date, end_date)
    
    return user_data

def generate_table_output(user_data, start_date, end_date):
    """Generate formatted table output"""
    
    print("\n" + "=" * 120)
    print("📋 USER ACTIVITY SUMMARY TABLE")
    print("=" * 120)
    
    # Summary table header
    print(f"{'USER':<15} {'CONVERSATIONS':<13} {'MESSAGES':<10} {'LOGINS':<8} {'STATUS':<12} {'FIRST ACTIVITY':<20} {'LAST ACTIVITY':<20}")
    print("-" * 120)
    
    # Sort users by total activity (conversations + messages)
    sorted_users = sorted(user_data.items(), 
                         key=lambda x: x[1]['total_conversations'] + x[1]['total_messages'], 
                         reverse=True)
    
    total_conversations = 0
    total_messages = 0
    total_logins = 0
    
    for user_id, data in sorted_users:
        total_conversations += data['total_conversations']
        total_messages += data['total_messages']
        total_logins += data['login_sessions']
        
        first_activity = data['first_activity'].strftime('%Y-%m-%d %H:%M') if data['first_activity'] else 'N/A'
        last_activity = data['last_activity'].strftime('%Y-%m-%d %H:%M') if data['last_activity'] else 'N/A'
        
        print(f"{user_id:<15} {data['total_conversations']:<13} {data['total_messages']:<10} {data['login_sessions']:<8} {data['status']:<12} {first_activity:<20} {last_activity:<20}")
    
    # Summary row
    print("-" * 120)
    print(f"{'TOTAL':<15} {total_conversations:<13} {total_messages:<10} {total_logins:<8} {'ALL':<12} {'SUMMARY':<20} {'STATISTICS':<20}")
    
    # Daily breakdown table
    print("\n" + "=" * 100)
    print("📅 DAILY BREAKDOWN TABLE")
    print("=" * 100)
    
    # Generate date range for columns
    date_range = []
    current_date = start_date
    while current_date <= end_date:
        date_range.append(current_date.strftime('%Y-%m-%d'))
        current_date += timedelta(days=1)
    
    # Daily breakdown header
    header = f"{'USER':<15}"
    for date in date_range:
        header += f"{date[-5:]:<12}"  # Show MM-DD only
    header += f"{'TOTAL':<8}"
    print(header)
    print("-" * 100)
    
    # Daily breakdown data
    for user_id, data in sorted_users:
        row = f"{user_id:<15}"
        daily_total = 0
        for date in date_range:
            conversations = data['daily_breakdown'][date]['conversations']
            messages = data['daily_breakdown'][date]['messages']
            activity = conversations + messages
            daily_total += activity
            row += f"{activity if activity > 0 else '-':<12}"
        row += f"{daily_total:<8}"
        print(row)
    
    # Detailed user information
    print("\n" + "=" * 120)
    print("👤 DETAILED USER INFORMATION")
    print("=" * 120)
    
    for user_id, data in sorted_users:
        if data['total_conversations'] > 0 or data['total_messages'] > 0:
            print(f"\n🔹 USER: {user_id}")
            print(f"   📊 Activity Summary:")
            print(f"      • Total Conversations: {data['total_conversations']}")
            print(f"      • Total Messages: {data['total_messages']}")
            print(f"      • Login Sessions: {data['login_sessions']}")
            print(f"      • Current Status: {data['status']}")
            
            if data['first_activity'] and data['last_activity']:
                duration = data['last_activity'] - data['first_activity']
                print(f"      • Activity Period: {duration.days} days, {duration.seconds//3600} hours")
            
            if data['sample_queries']:
                print(f"   💬 Sample Queries:")
                for i, query in enumerate(data['sample_queries'], 1):
                    print(f"      {i}. {query}")
    
    # Statistics summary
    print("\n" + "=" * 80)
    print("📈 STATISTICS SUMMARY")
    print("=" * 80)
    print(f"📊 Total Active Users: {len([u for u in user_data.values() if u['total_conversations'] > 0 or u['total_messages'] > 0])}")
    print(f"💬 Total Conversations: {total_conversations}")
    print(f"📝 Total Messages: {total_messages}")
    print(f"🔐 Total Login Sessions: {total_logins}")
    print(f"📅 Analysis Period: 5 days")
    
    if len(user_data) > 0:
        avg_conversations = total_conversations / len(user_data)
        avg_messages = total_messages / len(user_data)
        print(f"📊 Average Conversations per User: {avg_conversations:.1f}")
        print(f"📊 Average Messages per User: {avg_messages:.1f}")
    
    # Top performers
    if sorted_users:
        print(f"\n🏆 Top Performer: {sorted_users[0][0]} ({sorted_users[0][1]['total_conversations']} conversations, {sorted_users[0][1]['total_messages']} messages)")
        
        # Most active day
        all_daily_activity = defaultdict(int)
        for user_id, data in user_data.items():
            for date, activity in data['daily_breakdown'].items():
                all_daily_activity[date] += activity['conversations'] + activity['messages']
        
        if all_daily_activity:
            most_active_day = max(all_daily_activity.items(), key=lambda x: x[1])
            print(f"📅 Most Active Day: {most_active_day[0]} ({most_active_day[1]} total activities)")

if __name__ == "__main__":
    try:
        user_data = generate_5day_table_report()
        
        print("\n" + "=" * 80)
        print("✅ TABLE REPORT GENERATION COMPLETE")
        print("=" * 80)
        print("📧 This report can be shared with management")
        print("📊 All data extracted from Redington Chatbot DynamoDB tables")
        
    except Exception as e:
        print(f"❌ Error generating report: {e}")
