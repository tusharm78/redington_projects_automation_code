#!/usr/bin/env python3
"""
Diagnostic script to check DynamoDB session synchronization issues
"""

import boto3
import json
import sys
from datetime import datetime
from boto3.dynamodb.conditions import Key

def diagnose_dynamodb_sessions():
    """Diagnose DynamoDB session synchronization issues"""
    
    print("🔍 DynamoDB Session Synchronization Diagnostic")
    print("=" * 50)
    
    try:
        # Connect to DynamoDB
        dynamodb = boto3.resource("dynamodb", region_name="us-east-1")
        table_name = "user_chat_sessions"
        table = dynamodb.Table(table_name)
        
        print(f"✅ Connected to DynamoDB table: {table_name}")
        
        # Get table info
        table_info = table.describe()
        print(f"📊 Table Status: {table_info['Table']['TableStatus']}")
        print(f"📊 Item Count: {table_info['Table']['ItemCount']}")
        print(f"📊 Table Size: {table_info['Table']['TableSizeBytes']} bytes")
        print()
        
        # Scan all items to analyze structure
        print("🔍 Scanning all items in table...")
        response = table.scan()
        items = response.get('Items', [])
        
        print(f"📊 Total items found: {len(items)}")
        print()
        
        # Analyze item types
        sessions = []
        messages = []
        unknown_items = []
        
        for item in items:
            chat_id = item.get('chat_id', '')
            user_id = item.get('user_id', '')
            
            if chat_id.startswith('SESSION#'):
                sessions.append(item)
            elif chat_id.startswith('MESSAGE#'):
                messages.append(item)
            else:
                unknown_items.append(item)
        
        print(f"📊 Sessions found: {len(sessions)}")
        print(f"📊 Messages found: {len(messages)}")
        print(f"📊 Unknown items: {len(unknown_items)}")
        print()
        
        # Analyze sessions by user
        users = {}
        for session in sessions:
            user_id = session.get('user_id', 'unknown')
            if user_id not in users:
                users[user_id] = {'sessions': [], 'messages': 0}
            users[user_id]['sessions'].append(session)
        
        # Count messages per user
        for message in messages:
            user_id = message.get('user_id', 'unknown')
            if user_id not in users:
                users[user_id] = {'sessions': [], 'messages': 0}
            users[user_id]['messages'] += 1
        
        print("👥 Users and their sessions:")
        for user_id, data in users.items():
            print(f"  User: {user_id}")
            print(f"    Sessions: {len(data['sessions'])}")
            print(f"    Messages: {data['messages']}")
            
            # Check for empty sessions
            empty_sessions = 0
            for session in data['sessions']:
                message_count = session.get('message_count', 0)
                if message_count == 0:
                    empty_sessions += 1
            
            if empty_sessions > 0:
                print(f"    ⚠️  Empty sessions: {empty_sessions}")
            print()
        
        # Check for specific issues
        print("🔍 Checking for common issues:")
        
        # Issue 1: Sessions without messages
        empty_sessions = []
        for session in sessions:
            message_count = session.get('message_count', 0)
            if message_count == 0:
                empty_sessions.append(session)
        
        if empty_sessions:
            print(f"⚠️  Found {len(empty_sessions)} empty sessions:")
            for session in empty_sessions[:5]:  # Show first 5
                session_id = session.get('session_id', 'unknown')
                title = session.get('title', 'No title')
                created_at = session.get('created_at', 'Unknown')
                print(f"    - {session_id}: '{title}' (created: {created_at})")
            if len(empty_sessions) > 5:
                print(f"    ... and {len(empty_sessions) - 5} more")
        else:
            print("✅ No empty sessions found")
        
        # Issue 2: Orphaned messages
        session_ids = {s.get('session_id') for s in sessions}
        orphaned_messages = []
        
        for message in messages:
            # Extract session ID from MESSAGE#session_id#message_id format
            chat_id = message.get('chat_id', '')
            if chat_id.startswith('MESSAGE#'):
                parts = chat_id.split('#')
                if len(parts) >= 2:
                    msg_session_id = parts[1]
                    if msg_session_id not in session_ids:
                        orphaned_messages.append(message)
        
        if orphaned_messages:
            print(f"⚠️  Found {len(orphaned_messages)} orphaned messages (messages without sessions)")
        else:
            print("✅ No orphaned messages found")
        
        # Issue 3: Sessions with inconsistent data
        inconsistent_sessions = []
        for session in sessions:
            # Check if session_data JSON exists and is consistent
            if 'session_data' in session:
                try:
                    session_data = json.loads(session['session_data'])
                    # Check consistency between direct fields and JSON data
                    direct_title = session.get('title', '')
                    json_title = session_data.get('title', '')
                    if direct_title != json_title:
                        inconsistent_sessions.append(session)
                except json.JSONDecodeError:
                    inconsistent_sessions.append(session)
        
        if inconsistent_sessions:
            print(f"⚠️  Found {len(inconsistent_sessions)} sessions with inconsistent data")
        else:
            print("✅ All sessions have consistent data")
        
        print()
        
        # Sample session structure
        if sessions:
            print("📋 Sample session structure:")
            sample_session = sessions[0]
            for key, value in sample_session.items():
                if key == 'session_data' and isinstance(value, str):
                    try:
                        parsed_data = json.loads(value)
                        print(f"  {key}: {json.dumps(parsed_data, indent=4)}")
                    except:
                        print(f"  {key}: {value}")
                else:
                    print(f"  {key}: {value}")
        
        return {
            'total_items': len(items),
            'sessions': len(sessions),
            'messages': len(messages),
            'empty_sessions': len(empty_sessions),
            'orphaned_messages': len(orphaned_messages),
            'inconsistent_sessions': len(inconsistent_sessions),
            'users': list(users.keys())
        }
        
    except Exception as e:
        print(f"❌ Error connecting to DynamoDB: {e}")
        return None

def test_backend_api():
    """Test backend API session endpoints"""
    import requests
    
    print("\n🔍 Testing Backend API Session Endpoints")
    print("=" * 50)
    
    base_url = "http://localhost:8000/api/v1"
    
    # Test health endpoint (if exists)
    try:
        response = requests.get(f"{base_url}/health", timeout=5)
        if response.status_code == 200:
            print("✅ Backend health check passed")
        else:
            print(f"⚠️  Backend health check returned: {response.status_code}")
    except:
        print("⚠️  Backend health endpoint not available")
    
    # Test sessions endpoint (requires auth)
    try:
        response = requests.get(f"{base_url}/sessions", timeout=5)
        print(f"📊 Sessions endpoint status: {response.status_code}")
        if response.status_code == 401:
            print("   (Expected - requires authentication)")
        elif response.status_code == 200:
            print(f"   Response: {response.json()}")
    except Exception as e:
        print(f"❌ Error testing sessions endpoint: {e}")

if __name__ == "__main__":
    print("🚀 Starting DynamoDB Session Diagnostic")
    print("=" * 60)
    
    # Diagnose DynamoDB
    result = diagnose_dynamodb_sessions()
    
    # Test backend API
    test_backend_api()
    
    print("\n📋 Summary:")
    if result:
        print(f"  Total DynamoDB items: {result['total_items']}")
        print(f"  Sessions: {result['sessions']}")
        print(f"  Messages: {result['messages']}")
        print(f"  Empty sessions: {result['empty_sessions']}")
        print(f"  Users: {len(result['users'])}")
        
        if result['empty_sessions'] > 0:
            print(f"\n⚠️  ISSUE FOUND: {result['empty_sessions']} empty sessions")
            print("   These sessions appear in the UI but have no messages")
        
        if result['orphaned_messages'] > 0:
            print(f"\n⚠️  ISSUE FOUND: {result['orphaned_messages']} orphaned messages")
            print("   These messages exist without corresponding sessions")
        
        if result['inconsistent_sessions'] > 0:
            print(f"\n⚠️  ISSUE FOUND: {result['inconsistent_sessions']} inconsistent sessions")
            print("   These sessions have mismatched data between fields and JSON")
    
    print("\n✅ Diagnostic complete!")
