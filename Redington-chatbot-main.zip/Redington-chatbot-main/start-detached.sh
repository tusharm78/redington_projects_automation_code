#!/bin/bash

echo "🚀 Starting Redington AI Chatbot Servers (Detached Mode)..."

# Kill any existing processes
echo "Stopping existing servers..."
pkill -f "uvicorn main:app" 2>/dev/null
pkill -f "react-scripts start" 2>/dev/null
sleep 3

# Start Backend in detached mode
echo "Starting backend server..."
cd /home/chatbot/RedAIBot/react-bedrock-chatbot/backend
source venv/bin/activate
setsid uvicorn main:app --host 0.0.0.0 --port 8000 --reload > backend.log 2>&1 < /dev/null &
BACKEND_PID=$!
disown

# Wait for backend to start
sleep 8

# Start Frontend in detached mode
echo "Starting frontend server..."
cd /home/chatbot/RedAIBot/react-bedrock-chatbot/frontend
setsid npm start > frontend.log 2>&1 < /dev/null &
FRONTEND_PID=$!
disown

# Wait for servers to fully start
echo "Waiting for servers to initialize..."
sleep 20

# Check server status
echo "Checking server status..."
BACKEND_STATUS=$(curl -s -o /dev/null -w "%{http_code}" http://localhost:8000 2>/dev/null || echo "000")
FRONTEND_STATUS=$(curl -s -o /dev/null -w "%{http_code}" http://localhost:3000 2>/dev/null || echo "000")

echo ""
echo "=== SERVER STATUS ==="
echo "Backend (Port 8000): $([[ $BACKEND_STATUS == "200" ]] && echo "✅ Running" || echo "❌ Failed - Status: $BACKEND_STATUS")"
echo "Frontend (Port 3000): $([[ $FRONTEND_STATUS == "200" ]] && echo "✅ Running" || echo "❌ Failed - Status: $FRONTEND_STATUS")"
echo ""

if [[ $BACKEND_STATUS == "200" && $FRONTEND_STATUS == "200" ]]; then
    echo "🎉 SUCCESS! Both servers are running in background"
    echo ""
    echo "=== ACCESS URLs ==="
    echo "🌐 Frontend: http://localhost:3000"
    echo "🔧 Backend API: http://localhost:8000"
    echo "📚 API Docs: http://localhost:8000/docs"
    echo ""
    echo "=== LOGIN CREDENTIALS ==="
    echo "Username: tanmay"
    echo "Password: Admin@123$"
    echo ""
    echo "=== MANAGEMENT ==="
    echo "View backend logs: tail -f /home/chatbot/RedAIBot/react-bedrock-chatbot/backend/backend.log"
    echo "View frontend logs: tail -f /home/chatbot/RedAIBot/react-bedrock-chatbot/frontend/frontend.log"
    echo "Stop servers: pkill -f 'uvicorn main:app' && pkill -f 'react-scripts start'"
    echo "Check status: ps aux | grep -E '(uvicorn|react-scripts)' | grep -v grep"
else
    echo "❌ Some servers failed to start. Check logs:"
    echo "Backend log: tail /home/chatbot/RedAIBot/react-bedrock-chatbot/backend/backend.log"
    echo "Frontend log: tail /home/chatbot/RedAIBot/react-bedrock-chatbot/frontend/frontend.log"
fi
