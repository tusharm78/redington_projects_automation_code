#!/usr/bin/env python3
"""
Debug script to analyze user session issues
"""

import boto3
import json
from datetime import datetime, timezone
import sys

def analyze_user_sessions():
    """Analyze current user sessions in DynamoDB"""
    
    print("🔍 ANALYZING USER SESSIONS")
    print("=" * 50)
    
    # Connect to DynamoDB
    dynamodb = boto3.resource('dynamodb', region_name='us-east-1')
    
    # Check both tables
    tables_to_check = [
        'user_active_sessions',
        'user_chat_sessions'
    ]
    
    for table_name in tables_to_check:
        print(f"\n📊 TABLE: {table_name}")
        print("-" * 30)
        
        try:
            table = dynamodb.Table(table_name)
            
            # Scan the table
            response = table.scan()
            items = response.get('Items', [])
            
            print(f"Total items: {len(items)}")
            
            if table_name == 'user_active_sessions':
                print("\n👥 ACTIVE USER SESSIONS:")
                for item in items:
                    username = item.get('username', 'Unknown')
                    status = item.get('status', 'Unknown')
                    login_time = item.get('login_time', 'Unknown')
                    last_activity = item.get('last_activity', 'Unknown')
                    
                    # Parse session data if available
                    session_data_str = item.get('session_data', {})
                    if isinstance(session_data_str, dict) and 'S' in session_data_str:
                        try:
                            session_data = json.loads(session_data_str['S'])
                            email = session_data.get('email', 'Unknown')
                            ip_address = session_data.get('ip_address', 'Unknown')
                            user_agent = session_data.get('user_agent', 'Unknown')
                        except:
                            email = 'Parse Error'
                            ip_address = 'Parse Error'
                            user_agent = 'Parse Error'
                    else:
                        email = 'No session data'
                        ip_address = 'No session data'
                        user_agent = 'No session data'
                    
                    print(f"  • {username} ({email})")
                    print(f"    Status: {status}")
                    print(f"    Login: {login_time}")
                    print(f"    Last Activity: {last_activity}")
                    print(f"    IP: {ip_address}")
                    print(f"    User Agent: {user_agent}")
                    print()
            
            elif table_name == 'user_chat_sessions':
                print("\n💬 CHAT SESSIONS (last 10):")
                # Sort by timestamp if available
                sorted_items = sorted(items, key=lambda x: x.get('timestamp', ''), reverse=True)[:10]
                
                for item in sorted_items:
                    user_id = item.get('user_id', 'Unknown')
                    chat_id = item.get('chat_id', 'Unknown')
                    timestamp = item.get('timestamp', 'Unknown')
                    title = item.get('title', 'No title')
                    
                    print(f"  • {user_id}: {title[:50]}...")
                    print(f"    Chat ID: {chat_id}")
                    print(f"    Timestamp: {timestamp}")
                    print()
                    
        except Exception as e:
            print(f"❌ Error accessing {table_name}: {e}")
    
    # Check what's creating these sessions
    print("\n🔍 INVESTIGATING SESSION CREATION")
    print("-" * 40)
    
    # Look for test users
    test_users = ['demo', 'user', 'meenal', 'tanmay']
    
    for user in test_users:
        print(f"\n👤 USER: {user}")
        
        # Check if this user exists in chat sessions
        try:
            chat_table = dynamodb.Table('user_chat_sessions')
            response = chat_table.query(
                KeyConditionExpression=boto3.dynamodb.conditions.Key('user_id').eq(user)
            )
            chat_sessions = response.get('Items', [])
            print(f"  Chat sessions: {len(chat_sessions)}")
            
            if chat_sessions:
                latest_session = max(chat_sessions, key=lambda x: x.get('timestamp', ''))
                print(f"  Latest session: {latest_session.get('timestamp', 'Unknown')}")
                print(f"  Latest title: {latest_session.get('title', 'No title')}")
        
        except Exception as e:
            print(f"  ❌ Error checking chat sessions: {e}")

def check_backend_integration():
    """Check if the backend is properly integrated with user monitoring"""
    
    print("\n🔧 BACKEND INTEGRATION CHECK")
    print("=" * 40)
    
    backend_files = [
        '/home/chatbot/Redington-chatbot/backend/enhanced_bedrock_main.py',
        '/home/chatbot/Redington-chatbot/backend/user_activity_monitor.py'
    ]
    
    for file_path in backend_files:
        try:
            with open(file_path, 'r') as f:
                content = f.read()
                
            print(f"\n📄 FILE: {file_path}")
            
            # Check for key imports and usage
            checks = [
                ('UserActivityMonitor import', 'from user_activity_monitor import UserActivityMonitor' in content or 'import user_activity_monitor' in content),
                ('user_active_sessions table', 'user_active_sessions' in content),
                ('user_login function', 'user_login' in content),
                ('user_logout function', 'user_logout' in content),
                ('activity tracking', 'track_activity' in content or 'update_activity' in content)
            ]
            
            for check_name, result in checks:
                status = "✅" if result else "❌"
                print(f"  {status} {check_name}")
                
        except Exception as e:
            print(f"  ❌ Error reading {file_path}: {e}")

if __name__ == "__main__":
    try:
        analyze_user_sessions()
        check_backend_integration()
        
        print("\n💡 RECOMMENDATIONS:")
        print("-" * 20)
        print("1. The 'demo' and 'user' accounts appear to be test accounts")
        print("2. The 'tanmay' user was force logged out but may not be properly tracked on re-login")
        print("3. Check if the main backend file is integrated with UserActivityMonitor")
        print("4. Verify that login/logout events are properly recorded")
        
    except Exception as e:
        print(f"❌ Script error: {e}")
        sys.exit(1)
