#!/bin/bash

# Enhanced System Status Check
echo "🔍 Enhanced Redington AI Bot - System Status"
echo "============================================="

# Function to check if port is in use
check_service() {
    local port=$1
    local service=$2
    local url=$3
    
    if lsof -Pi :$port -sTCP:LISTEN -t >/dev/null ; then
        echo "✅ $service: Running on port $port"
        if [ ! -z "$url" ]; then
            echo "   🔗 URL: $url"
        fi
        return 0
    else
        echo "❌ $service: Not running on port $port"
        return 1
    fi
}

# Check Backend
echo ""
echo "🔧 Backend Status:"
if check_service 8000 "Enhanced Streaming Backend" "http://localhost:8000"; then
    # Test backend health
    if curl -s http://localhost:8000/health > /dev/null 2>&1; then
        echo "   ✅ Health check: PASSED"
    else
        echo "   ⚠️  Health check: FAILED"
    fi
    
    # Check API docs
    if curl -s http://localhost:8000/docs > /dev/null 2>&1; then
        echo "   📖 API Docs: Available at http://localhost:8000/docs"
    fi
else
    echo "   💡 Start with: cd backend && ./start_enhanced.sh"
fi

# Check Frontend
echo ""
echo "🎨 Frontend Status:"
if check_service 3000 "Enhanced Frontend" "http://localhost:3000"; then
    echo "   ✅ React app: Running"
else
    echo "   💡 Start with: cd frontend && npm start"
fi

# Check log files
echo ""
echo "📋 Log Files:"
if [ -f "backend/enhanced_backend.log" ]; then
    backend_size=$(du -h backend/enhanced_backend.log | cut -f1)
    echo "✅ Backend log: $backend_size (backend/enhanced_backend.log)"
else
    echo "❌ Backend log: Not found"
fi

if [ -f "frontend/frontend_enhanced.log" ]; then
    frontend_size=$(du -h frontend/frontend_enhanced.log | cut -f1)
    echo "✅ Frontend log: $frontend_size (frontend/frontend_enhanced.log)"
else
    echo "❌ Frontend log: Not found"
fi

# Check PID files
echo ""
echo "🔢 Process IDs:"
if [ -f "backend.pid" ]; then
    backend_pid=$(cat backend.pid)
    if ps -p $backend_pid > /dev/null 2>&1; then
        echo "✅ Backend PID: $backend_pid (running)"
    else
        echo "⚠️  Backend PID: $backend_pid (not running)"
    fi
else
    echo "❌ Backend PID: Not found"
fi

if [ -f "frontend.pid" ]; then
    frontend_pid=$(cat frontend.pid)
    if ps -p $frontend_pid > /dev/null 2>&1; then
        echo "✅ Frontend PID: $frontend_pid (running)"
    else
        echo "⚠️  Frontend PID: $frontend_pid (not running)"
    fi
else
    echo "❌ Frontend PID: Not found"
fi

# System summary
echo ""
echo "📊 System Summary:"
backend_running=$(lsof -Pi :8000 -sTCP:LISTEN -t >/dev/null && echo "true" || echo "false")
frontend_running=$(lsof -Pi :3000 -sTCP:LISTEN -t >/dev/null && echo "true" || echo "false")

if [ "$backend_running" = "true" ] && [ "$frontend_running" = "true" ]; then
    echo "🎉 Status: FULLY OPERATIONAL"
    echo "🌐 Access: http://localhost:3000"
    echo "🔐 Demo Login: demo/demo123"
elif [ "$backend_running" = "true" ]; then
    echo "⚠️  Status: BACKEND ONLY"
    echo "💡 Start frontend: cd frontend && npm start"
elif [ "$frontend_running" = "true" ]; then
    echo "⚠️  Status: FRONTEND ONLY"
    echo "💡 Start backend: cd backend && ./start_enhanced.sh"
else
    echo "❌ Status: SYSTEM DOWN"
    echo "💡 Start system: ./start_enhanced_system.sh"
fi

echo ""
echo "🛠️  Management Commands:"
echo "   Start system:  ./start_enhanced_system.sh"
echo "   Stop system:   ./stop_enhanced_system.sh"
echo "   View logs:     tail -f backend/enhanced_backend.log"
echo "   Check status:  ./check_enhanced_status.sh"
echo ""
