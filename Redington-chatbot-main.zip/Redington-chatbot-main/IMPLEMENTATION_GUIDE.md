# Redington Chatbot Data Migration & Backend Fix Implementation Guide

## Overview

This guide addresses the critical data inconsistency issue where users' chat history is stored across different DynamoDB tables (`chat_history` vs `user_chat_sessions`), causing some users like **akhil** to have missing chat history in the frontend.

## Problem Analysis

Based on our investigation, we identified:

### Data Storage Inconsistency
- **Users only in chat_history**: admin, rahuraman
- **Users only in user_chat_sessions**: akhil, ajit, subashini, sharmila, ganesh, rahu, nanthini, demo, sachin, shubham, syed, test_user
- **Users in both tables**: meenal, tanmay

### Root Cause
The backend has inconsistent logic that sometimes stores chat data in `chat_history` table and sometimes in `user_chat_sessions` table. The frontend likely queries only the `chat_history` table, causing users whose data is in `user_chat_sessions` to see empty chat history.

## Solution Overview

### Phase 1: Data Migration
Migrate all chat data to the primary `chat_history` table to ensure consistency.

### Phase 2: Backend Standardization
Update backend code to use only `chat_history` table for all future chat operations.

### Phase 3: Cleanup & Validation
Clean up deprecated tables and validate the fix.

---

## Phase 1: Data Migration

### Step 1: Run Migration Analysis

```bash
cd /home/chatbot/Redington-chatbot
python3 data_migration_solution.py
```

This will:
- Analyze current data inconsistency
- Create a detailed migration plan
- Execute a dry run to validate the migration
- Show exactly what will be migrated

### Step 2: Review Migration Plan

The script will output:
- Users to migrate from `user_chat_sessions` to `chat_history`
- Users requiring deduplication (data in both tables)
- Users to preserve (already in `chat_history` only)

### Step 3: Execute Actual Migration

After reviewing the dry run results, uncomment the migration execution lines in the script:

```python
# Uncomment these lines in data_migration_solution.py
confirm = input("\nProceed with actual migration? (yes/no): ")
if confirm.lower() == 'yes':
    print("EXECUTING ACTUAL MIGRATION...")
    actual_results = migrator.execute_migration(plan, dry_run=False)
```

### Expected Results
- **akhil's 16 conversation records** will be migrated to `chat_history`
- **ajit, subashini, and other affected users** will have their data migrated
- **meenal and tanmay** will have their data deduplicated
- All users will have consistent chat history access

---

## Phase 2: Backend Code Updates

### Step 1: Update Chat Service

Replace `app/services/chat_service.py` with the standardized version from `backend_fixes.py`:

```python
# Key changes:
- Single table usage: chat_history only
- Standardized data structure
- Consistent conversation_id handling
- Proper error handling
```

### Step 2: Update API Endpoints

Replace `app/api/chat.py` with updated endpoints:

```python
# Key changes:
- All endpoints use chat_service
- No direct table access
- Consistent response format
- Proper error handling
```

### Step 3: Update Data Models

Replace `app/models/chat.py` with standardized models:

```python
# Key changes:
- Consistent field naming
- Proper validation
- Backward compatibility
```

### Step 4: Add Database Utilities

Add `app/utils/database.py` for validation and conversion:

```python
# Features:
- Record validation
- Legacy record conversion
- Migration utilities
```

### Step 5: Update Configuration

Add to `app/core/config.py`:

```python
PRIMARY_CHAT_TABLE: str = "chat_history"
DEPRECATED_CHAT_TABLES: List[str] = ["user_chat_sessions", "user_active_sessions"]
ENABLE_LEGACY_SUPPORT: bool = False
```

---

## Phase 3: Testing & Validation

### Step 1: Test in Development

1. **Deploy updated backend code**
2. **Test chat functionality**:
   ```bash
   # Test user with migrated data
   curl -X GET "http://localhost:8000/api/v1/chat/history" \
        -H "Authorization: Bearer <akhil_token>"
   ```
3. **Verify all users can see their chat history**
4. **Test new chat message storage**

### Step 2: Validate Migration Success

```python
# Run validation script
python3 -c "
from data_migration_solution import ChatDataMigrator
migrator = ChatDataMigrator()
analysis = migrator.analyze_data_inconsistency()
print('Users only in user_chat_sessions:', len(analysis['only_in_user_chat_sessions']))
print('Should be 0 after successful migration')
"
```

### Step 3: Production Deployment

1. **Schedule maintenance window**
2. **Deploy backend updates**
3. **Monitor application logs**
4. **Verify user chat history access**

---

## Verification Checklist

### ✅ Data Migration Verification
- [ ] All users from `user_chat_sessions` migrated to `chat_history`
- [ ] No data loss during migration
- [ ] Conversation continuity preserved
- [ ] Duplicate data properly handled

### ✅ Backend Code Verification
- [ ] All chat operations use `chat_history` table only
- [ ] No new data stored in `user_chat_sessions`
- [ ] API endpoints return consistent data
- [ ] Error handling works properly

### ✅ User Experience Verification
- [ ] **akhil** can see all 16 conversations
- [ ] **ajit, subashini, and other affected users** can see their chat history
- [ ] **meenal and tanmay** see complete deduplicated history
- [ ] New chat messages are stored correctly
- [ ] No performance degradation

---

## Rollback Plan

If issues occur during migration:

### Step 1: Immediate Rollback
```bash
# Revert backend code to previous version
git checkout HEAD~1 -- app/services/chat_service.py app/api/chat.py

# Restart application
./backend/start.sh
```

### Step 2: Data Rollback (if needed)
```python
# The original data in user_chat_sessions is preserved
# Users will temporarily see the old inconsistent behavior
# Re-run migration after fixing issues
```

---

## Monitoring & Maintenance

### Key Metrics to Monitor
- Chat message storage success rate
- User chat history retrieval success rate
- API response times
- Error rates in chat operations

### Log Monitoring
```bash
# Monitor for any references to deprecated tables
grep -r "user_chat_sessions" /home/chatbot/Redington-chatbot/backend/app/
grep -r "user_active_sessions" /home/chatbot/Redington-chatbot/backend/app/
```

### Performance Monitoring
- Monitor `chat_history` table read/write capacity
- Watch for any DynamoDB throttling
- Monitor API response times

---

## Post-Migration Cleanup

After confirming successful migration (recommended: 1-2 weeks):

### Step 1: Archive Deprecated Tables
```python
# Optional: Export data for backup
aws dynamodb scan --table-name user_chat_sessions > user_chat_sessions_backup.json

# Consider table deletion after thorough validation
# aws dynamodb delete-table --table-name user_chat_sessions
```

### Step 2: Remove Legacy Code
- Remove any remaining references to `user_chat_sessions`
- Clean up deprecated configuration options
- Update documentation

---

## Success Criteria

The migration is successful when:

1. **All users can access their complete chat history**
2. **No data loss occurred during migration**
3. **New chat messages are stored consistently in `chat_history` table**
4. **No performance degradation**
5. **No errors in application logs related to chat operations**

---

## Contact & Support

For issues during implementation:
1. Check application logs first
2. Verify DynamoDB table access permissions
3. Ensure AWS credentials are properly configured
4. Test with a single user before full deployment

This comprehensive solution addresses the root cause of missing chat history and ensures consistent data storage going forward.
