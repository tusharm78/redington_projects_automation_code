#!/bin/bash

echo "🔧 Applying Chat Session Management Fixes..."
echo "================================================"

# Create backup directory
BACKUP_DIR="./session_fixes_backup_$(date +%Y%m%d_%H%M%S)"
mkdir -p "$BACKUP_DIR"

echo "📦 Creating backups in $BACKUP_DIR..."

# Backup original files
if [ -f "backend/session_manager.py" ]; then
    cp "backend/session_manager.py" "$BACKUP_DIR/session_manager.py.backup"
    echo "✅ Backed up session_manager.py"
fi

if [ -f "backend/enhanced_bedrock_main.py" ]; then
    cp "backend/enhanced_bedrock_main.py" "$BACKUP_DIR/enhanced_bedrock_main.py.backup"
    echo "✅ Backed up enhanced_bedrock_main.py"
fi

if [ -f "frontend/src/services/sessions.ts" ]; then
    cp "frontend/src/services/sessions.ts" "$BACKUP_DIR/sessions.ts.backup"
    echo "✅ Backed up sessions.ts"
fi

echo ""
echo "🔄 Applying fixes..."

# Apply backend fixes
if [ -f "backend/session_manager_fixed.py" ]; then
    cp "backend/session_manager_fixed.py" "backend/session_manager.py"
    echo "✅ Applied fixed session_manager.py"
else
    echo "❌ session_manager_fixed.py not found!"
    exit 1
fi

if [ -f "backend/enhanced_bedrock_main_fixed.py" ]; then
    cp "backend/enhanced_bedrock_main_fixed.py" "backend/enhanced_bedrock_main.py"
    echo "✅ Applied fixed enhanced_bedrock_main.py"
else
    echo "❌ enhanced_bedrock_main_fixed.py not found!"
    exit 1
fi

# Apply frontend fixes
if [ -f "frontend/src/services/sessions_fixed.ts" ]; then
    cp "frontend/src/services/sessions_fixed.ts" "frontend/src/services/sessions.ts"
    echo "✅ Applied fixed sessions.ts"
else
    echo "❌ sessions_fixed.ts not found!"
    exit 1
fi

echo ""
echo "🔄 Restarting services..."

# Stop existing services
echo "🛑 Stopping backend services..."
if [ -f "./stop_bedrock_system.sh" ]; then
    ./stop_bedrock_system.sh
elif [ -f "backend/stop_bedrock_streaming.sh" ]; then
    cd backend && ./stop_bedrock_streaming.sh && cd ..
else
    echo "⚠️ No stop script found, manually kill backend processes"
    pkill -f "enhanced_bedrock_main"
    pkill -f "bedrock_streaming"
fi

# Wait a moment
sleep 2

# Start backend
echo "🚀 Starting fixed backend..."
if [ -f "./start_bedrock_system.sh" ]; then
    ./start_bedrock_system.sh
elif [ -f "backend/start_bedrock_streaming.sh" ]; then
    cd backend && ./start_bedrock_streaming.sh && cd ..
else
    echo "🔧 Starting backend manually..."
    cd backend
    nohup python enhanced_bedrock_main.py > backend_fixed.log 2>&1 &
    echo $! > backend_fixed.pid
    cd ..
fi

# Wait for backend to start
echo "⏳ Waiting for backend to start..."
sleep 5

# Test backend health
echo "🏥 Testing backend health..."
if command -v curl &> /dev/null; then
    HEALTH_RESPONSE=$(curl -s http://localhost:8000/api/v1/health 2>/dev/null)
    if [[ $HEALTH_RESPONSE == *"healthy"* ]]; then
        echo "✅ Backend is healthy!"
        echo "📊 Health check response:"
        echo "$HEALTH_RESPONSE" | python -m json.tool 2>/dev/null || echo "$HEALTH_RESPONSE"
    else
        echo "⚠️ Backend health check failed or not responding"
        echo "Response: $HEALTH_RESPONSE"
    fi
else
    echo "⚠️ curl not available, skipping health check"
fi

# Frontend restart (if needed)
if [ -d "frontend" ]; then
    echo ""
    echo "🌐 Frontend fixes applied. If frontend is running, restart it:"
    echo "   cd frontend && npm start"
fi

echo ""
echo "🎉 Session fixes applied successfully!"
echo ""
echo "📋 What was fixed:"
echo "   ✅ Empty sessions no longer created until first message"
echo "   ✅ Deleted sessions won't reappear after refresh"
echo "   ✅ Chat titles now persist properly after updates"
echo "   ✅ Only sessions with messages appear in UI"
echo "   ✅ Sessions only written to DynamoDB when needed"
echo ""
echo "🧪 Test the fixes:"
echo "   1. Click 'New Chat' multiple times - no empty sessions should appear"
echo "   2. Send a message - session should appear in sidebar"
echo "   3. Edit chat title - should persist after refresh"
echo "   4. Delete a chat - should not reappear after refresh"
echo ""
echo "📁 Backups saved in: $BACKUP_DIR"
echo "🔄 To rollback: ./rollback_session_fixes.sh $BACKUP_DIR"

# Create rollback script
cat > rollback_session_fixes.sh << EOF
#!/bin/bash
BACKUP_DIR=\$1
if [ -z "\$BACKUP_DIR" ] || [ ! -d "\$BACKUP_DIR" ]; then
    echo "Usage: \$0 <backup_directory>"
    exit 1
fi

echo "🔄 Rolling back session fixes from \$BACKUP_DIR..."

if [ -f "\$BACKUP_DIR/session_manager.py.backup" ]; then
    cp "\$BACKUP_DIR/session_manager.py.backup" "backend/session_manager.py"
    echo "✅ Restored session_manager.py"
fi

if [ -f "\$BACKUP_DIR/enhanced_bedrock_main.py.backup" ]; then
    cp "\$BACKUP_DIR/enhanced_bedrock_main.py.backup" "backend/enhanced_bedrock_main.py"
    echo "✅ Restored enhanced_bedrock_main.py"
fi

if [ -f "\$BACKUP_DIR/sessions.ts.backup" ]; then
    cp "\$BACKUP_DIR/sessions.ts.backup" "frontend/src/services/sessions.ts"
    echo "✅ Restored sessions.ts"
fi

echo "🔄 Restart your services to complete rollback"
EOF

chmod +x rollback_session_fixes.sh

echo "✅ Rollback script created: ./rollback_session_fixes.sh"
