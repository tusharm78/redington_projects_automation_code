#!/usr/bin/env python3
"""
Test authentication for user varunesh
"""
import sys
import os
import asyncio
import boto3
from dotenv import load_dotenv

# Add backend to path
sys.path.append('/home/chatbot/Redington-chatbot/backend')

# Load environment variables
load_dotenv('/home/chatbot/Redington-chatbot/backend/.env')

from cognito_auth_improved import CognitoAuth

async def test_varunesh_authentication():
    """Test authentication with varunesh credentials"""
    
    # Test credentials
    username = "varunesh"
    password = "Varuesh@123"  # The temporary password you mentioned
    
    print("=== Testing Varunesh Authentication ===")
    print(f"Username: {username}")
    print(f"Pool ID: {os.getenv('POOL_ID')}")
    print(f"Region: {os.getenv('AWS_DEFAULT_REGION')}")
    print()
    
    try:
        # Initialize auth handler
        auth = CognitoAuth()
        print("✓ CognitoAuth initialized successfully")
        
        # Test authentication
        print(f"Attempting to authenticate user: {username}")
        result = await auth.authenticate_user(username, password)
        
        print("✓ Authentication successful!")
        print(f"User info: {result.get('user_info', {})}")
        print(f"Token expires in: {result.get('expires_in')} seconds")
        
        return True
        
    except Exception as e:
        print(f"✗ Authentication failed: {str(e)}")
        
        # Additional debugging - check user status directly
        try:
            print("\n=== User Status Check ===")
            cognito_client = boto3.client('cognito-idp', region_name=os.getenv('AWS_DEFAULT_REGION'))
            
            user_info = cognito_client.admin_get_user(
                UserPoolId=os.getenv('POOL_ID'),
                Username=username
            )
            
            print(f"User Status: {user_info.get('UserStatus')}")
            print(f"User Enabled: {user_info.get('Enabled')}")
            print(f"User Attributes: {user_info.get('UserAttributes', [])}")
            
            # Check if user needs password change
            if user_info.get('UserStatus') == 'FORCE_CHANGE_PASSWORD':
                print("\n⚠️  User requires password change!")
                print("This user needs to set a permanent password.")
                
                # Test the password change challenge handling
                print("\n=== Testing Password Change Challenge ===")
                try:
                    import hmac
                    import hashlib
                    import base64
                    
                    def calculate_secret_hash(username, client_id, client_secret):
                        message = username + client_id
                        dig = hmac.new(
                            client_secret.encode('utf-8'),
                            message.encode('utf-8'),
                            hashlib.sha256
                        ).digest()
                        return base64.b64encode(dig).decode()
                    
                    client_id = os.getenv('APP_CLIENT_ID')
                    client_secret = os.getenv('APP_CLIENT_SECRET')
                    secret_hash = calculate_secret_hash(username, client_id, client_secret)
                    
                    # Try to initiate auth to get the challenge
                    auth_response = cognito_client.initiate_auth(
                        ClientId=client_id,
                        AuthFlow='USER_PASSWORD_AUTH',
                        AuthParameters={
                            'USERNAME': username,
                            'PASSWORD': password,
                            'SECRET_HASH': secret_hash
                        }
                    )
                    
                    if 'ChallengeName' in auth_response:
                        print(f"✓ Challenge received: {auth_response['ChallengeName']}")
                        print(f"Session: {auth_response.get('Session', '')[:50]}...")
                        return {
                            'challenge': auth_response['ChallengeName'],
                            'session': auth_response.get('Session', ''),
                            'username': username
                        }
                    
                except Exception as challenge_error:
                    print(f"Challenge test failed: {str(challenge_error)}")
                
        except Exception as debug_error:
            print(f"Debug check failed: {str(debug_error)}")
        
        return False

if __name__ == "__main__":
    print("Testing Varunesh Authentication")
    print("=" * 40)
    
    result = asyncio.run(test_varunesh_authentication())
    
    print("\n" + "=" * 40)
    if result == True:
        print("✓ Authentication successful - user can log in normally")
    elif isinstance(result, dict) and result.get('challenge'):
        print("⚠️  Password change required")
        print(f"Challenge: {result['challenge']}")
        print("The UI should show a password change form.")
    else:
        print("✗ Authentication failed")
        print("Please check the error messages above.")
