#!/usr/bin/env python3

import requests
import json
import sys
import os

# Add backend path
sys.path.append('/home/chatbot/Redington-chatbot/backend')

def test_session_api():
    """Test the session API directly"""
    
    base_url = "http://localhost:8000/api/v1"
    
    # Test 1: Check if API is responding
    try:
        response = requests.get(f"{base_url}/health", timeout=5)
        print(f"✅ API Health Check: {response.status_code}")
    except Exception as e:
        print(f"❌ API Health Check Failed: {e}")
        return
    
    # Test 2: Try sessions endpoint without auth (should fail)
    try:
        response = requests.get(f"{base_url}/sessions", timeout=5)
        print(f"🔒 Sessions without auth: {response.status_code} - {response.text[:100]}")
    except Exception as e:
        print(f"❌ Sessions API error: {e}")
    
    # Test 3: Check DynamoDB directly
    try:
        from services.dynamodb_service import dynamodb_service
        sessions = dynamodb_service.get_user_chat_sessions('akhil')
        print(f"📊 Direct DynamoDB test: {len(sessions)} sessions found")
        if sessions:
            print(f"   Sample: {list(sessions.items())[0]}")
    except Exception as e:
        print(f"❌ DynamoDB test failed: {e}")

if __name__ == "__main__":
    test_session_api()
