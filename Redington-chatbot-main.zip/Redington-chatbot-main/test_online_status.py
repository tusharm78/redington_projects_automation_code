#!/usr/bin/env python3
"""
Test script to verify online status detection
"""

import boto3
import json
from datetime import datetime, timedelta

def test_table_access():
    """Test DynamoDB table access"""
    print("🧪 Testing DynamoDB Table Access")
    print("=" * 40)
    
    try:
        dynamodb = boto3.resource('dynamodb', region_name='us-east-1')
        table = dynamodb.Table('user_chat_sessions')
        
        # Test table access
        table.load()
        print("✅ Successfully connected to user_chat_sessions table")
        
        # Check table status
        print(f"📊 Table status: {table.table_status}")
        print(f"📊 Item count: {table.item_count}")
        
        return table
        
    except Exception as e:
        print(f"❌ Failed to access table: {e}")
        return None

def create_test_activity(table, username):
    """Create test activity for a user"""
    print(f"\n🎯 Creating test activity for {username}")
    
    try:
        current_time = datetime.utcnow().isoformat()
        chat_id = f"test-{username}-{int(datetime.utcnow().timestamp())}"
        
        table.put_item(
            Item={
                'user_id': username,
                'chat_id': chat_id,
                'session_id': chat_id,
                'created_at': current_time,
                'last_activity': current_time,
                'message_data': json.dumps({
                    'message_id': f'test-{int(datetime.utcnow().timestamp())}',
                    'role': 'user',
                    'content': f'Test activity for {username} - should show as online',
                    'timestamp': current_time
                })
            }
        )
        
        print(f"✅ Created test activity for {username}")
        print(f"   Chat ID: {chat_id}")
        print(f"   Timestamp: {current_time}")
        
        return True
        
    except Exception as e:
        print(f"❌ Failed to create test activity: {e}")
        return False

def check_user_activity(table, username):
    """Check user activity in table"""
    print(f"\n🔍 Checking activity for {username}")
    
    try:
        from boto3.dynamodb.conditions import Key
        
        response = table.query(
            KeyConditionExpression=Key("user_id").eq(username)
        )
        
        items = response.get('Items', [])
        print(f"📊 Found {len(items)} records for {username}")
        
        if items:
            latest_activity = None
            for item in items:
                activity_time = item.get('last_activity', item.get('created_at'))
                if activity_time:
                    if not latest_activity or activity_time > latest_activity:
                        latest_activity = activity_time
            
            if latest_activity:
                activity_dt = datetime.fromisoformat(latest_activity.replace('Z', '+00:00'))
                time_diff = (datetime.utcnow() - activity_dt.replace(tzinfo=None)).total_seconds()
                
                print(f"   Latest activity: {latest_activity}")
                print(f"   Time since activity: {time_diff/60:.1f} minutes ago")
                
                if time_diff < 600:  # 10 minutes
                    print(f"   🟢 {username} should show as ONLINE")
                else:
                    print(f"   🔴 {username} should show as OFFLINE")
            else:
                print(f"   ⚪ No activity timestamps found")
        else:
            print(f"   ⚪ No records found for {username}")
            
    except Exception as e:
        print(f"❌ Error checking activity: {e}")

def test_admin_api():
    """Test admin API response"""
    print(f"\n🌐 Testing Admin API")
    
    import requests
    
    try:
        # Login as admin
        login_response = requests.post("https://bot.redingtonsolutions.org/admin-api/api/v1/auth/login", 
                                     json={"username": "admin", "password": "admin123"})
        
        if login_response.status_code == 200:
            token = login_response.json()["access_token"]
            print("✅ Admin login successful")
            
            # Get users
            users_response = requests.get("https://bot.redingtonsolutions.org/admin-api/api/v1/admin/active-users",
                                        headers={"Authorization": f"Bearer {token}"})
            
            if users_response.status_code == 200:
                users = users_response.json()
                print(f"✅ Retrieved {len(users)} users from API")
                
                # Check tanmay's status
                tanmay = next((u for u in users if u['username'] == 'tanmay'), None)
                if tanmay:
                    print(f"\n👤 Tanmay's status in API:")
                    print(f"   Status: {tanmay['status']}")
                    print(f"   Messages: {tanmay['messages_sent']}")
                    print(f"   Sessions: {tanmay['chat_sessions']}")
                    print(f"   Last activity: {tanmay['last_activity']}")
                else:
                    print("❌ Tanmay not found in API response")
            else:
                print(f"❌ Failed to get users: {users_response.status_code}")
        else:
            print(f"❌ Admin login failed: {login_response.status_code}")
            
    except Exception as e:
        print(f"❌ Error testing admin API: {e}")

if __name__ == "__main__":
    print("🚀 Testing Online Status Detection")
    print("=" * 50)
    
    # Test table access
    table = test_table_access()
    
    if table:
        # Create test activity for tanmay
        if create_test_activity(table, "tanmay"):
            # Check the activity
            check_user_activity(table, "tanmay")
            
            # Test admin API
            test_admin_api()
            
            print(f"\n🎉 Test completed!")
            print(f"📋 Next steps:")
            print(f"   1. Visit: https://bot.redingtonsolutions.org/admin/")
            print(f"   2. Login with: admin / admin123")
            print(f"   3. Look for tanmay in the user list")
            print(f"   4. He should now show as 'online' with recent activity")
        else:
            print("❌ Failed to create test activity")
    else:
        print("❌ Cannot proceed without table access")
