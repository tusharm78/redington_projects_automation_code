# AWS_serverless_Lambda_CD

buildspec.yml - This file contains the build instructions for CodeBuild


template.yml - This file contains the CloudFormation template to create the Lambda function


buildspec-deploy.yml - This file contains the deployment instructions for CodeBuild

pipeline.yml - This file contains the CloudFormation template to create the CodePipeline
