# ----------------------------------------------------------#
#-----creating virtual machine - "credilio-dev-api" VM------#
# ----------------------------------------------------------#
resource "aws_instance" "ec2_credilio-dev-api" {
  subnet_id                   = aws_subnet.dev_subnet_1a.id
  associate_public_ip_address = false
  ami                         = "ami-0b9093ea00a0fed92"           #ubuntu 24.04 ami id
  instance_type               = "t4g.medium"                      #add the required instance size here
  root_block_device {
  volume_size = var.credilio-dev-api_os_disk
    encrypted = true
    delete_on_termination = true
    volume_type = "gp3"
    tags = {
      Name = "credilio-dev-api_os_disk"
      CreatedThrough = "Terraform_Automation"
    }
  }
  
#here we are referencing the aws key pair which we have created in keypair.tf config file
key_name              = var.credilio-dev-api_key

vpc_security_group_ids = [aws_security_group.sg_credilio-dev-api.id]
  
  #here we are attaching tags to our resources
  tags = {
    "Name" = "credilio-dev-api"
     Created-by  = "Terraform_Automation"

  }
}

# ----------------------------------------------------------- #
#-----creating security group for "credilio-dev-api"  VM------#
# ----------------------------------------------------------- #

# Create Security Group - SSH Traffic
resource "aws_security_group" "sg_credilio-dev-api" {
  vpc_id      = aws_vpc.vpc-go.id
  name        = "sg_credilio-dev-api"
  description = "VM SSH"

# inbound ssh port
  ingress {
    description = "Allow Port 22"
    from_port   = 22
    to_port     = 22
    protocol    = "tcp"
    cidr_blocks = ["0.0.0.0/0"]
  }

# inbound port 3333
  ingress {
    description = "Allow Port 3333"
    from_port   = 3333
    to_port     = 3333
    protocol    = "tcp"
    cidr_blocks = ["0.0.0.0/0"]
  }

# inbound port 3334
  ingress {
    description = "Allow Port 3334"
    from_port   = 3334
    to_port     = 3334
    protocol    = "tcp"
    cidr_blocks = ["0.0.0.0/0"]
  }

#outbound port 
  egress {
    description = "Allow all IP and Ports outbound"
    from_port   = 0
    to_port     = 0
    protocol    = "-1"
    cidr_blocks = ["0.0.0.0/0"]
  }

  tags = {
    Name = "sg_credilio-dev-api"
    CreatedThrough = "Terraform Automation"
  }
}
