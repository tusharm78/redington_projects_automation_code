#variable for region
variable "aws_region" {
    description = "Enter the region"
    type = string
    default = "ap-south-1"      # enter the value according to your requirement
}

#variable for CIDR range for VPC
variable "aws_vpc" {
    description = "Enter the VPC CIDR range"
    type = string
    default="10.1.0.0/16"     # enter the CIDR range value according to your requirement
}

#variable for availability zone1
variable "aws_availability_zone1" {
    description = "Enter the availabilty zone"
    type = string
    default = "ap-south-1a"
}

#variable for availability zone2
variable "aws_availability_zone2" {
    description = "Enter the availabilty zone"
    type = string
    default = "ap-south-1b"
}

#variable for public subnet in AZ-1a
variable "PublicSubnet_1" {
    description = "Enter the subnet range"
    type = string
    default = "10.1.0.0/20"  # enter the subnet range value according to your requirement
  
}
#variable for public subnet in AZ-1b
variable "PublicSubnet_2" {
    description = "Enter the subnet range"
    type = string
    default = "10.1.16.0/20"  # enter the subnet range value according to your requirement
  
}

#variable for dev private subnet 1 in AZ-1a
variable "Subnet_Dev_Private_1a" {
  description = "Enter the subnet range"
    type = string
    default = "10.1.32.0/20"   # enter the subnet range value according to your requirement
}

#variable for dev private subnet 2 in AZ-1a
variable "Subnet_Dev_Private_2a" {
  description = "Enter the subnet range"
    type = string
    default = "10.1.64.0/20"   # enter the subnet range value according to your requirement
}

#variable for dev private subnet 3 in AZ-1a
variable "Subnet_Dev_Private_3a" {
  description = "Enter the subnet range"
    type = string
    default = "10.1.96.0/20"   # enter the subnet range value according to your requirement
}

#variable for dev private subnet 1 in AZ-1b
variable "Subnet_Dev_Private_1b" {
  description = "Enter the subnet range"
    type = string
    default = "10.1.48.0/20"    # enter the subnet range value according to your requirement
}

#variable for dev private subnet 2 in AZ-1b
variable "Subnet_Dev_Private_2b" {
  description = "Enter the subnet range"
    type = string
    default = "10.1.80.0/20"    # enter the subnet range value according to your requirement
}

#variable for dev private subnet 3 in AZ-1b
variable "Subnet_Dev_Private_3b" {
  description = "Enter the subnet range"
    type = string
    default = "10.1.112.0/20"    # enter the subnet range value according to your requirement
}

#--------------------------------------------------------------------------#
#--------------creating variable for ec2 nonprod_vpn ----------------------#
#--------------------------------------------------------------------------#
variable "nonprod_vpn_key" {
  description = "Enter the Key pair name"
  type = string
  default = "nonprod_vpn_key.pem"                        #create keypair with required name
}

#creating variable for os disk for ec2_nonprod-vpn
variable "nonprod-vpn_os_disk" {
  description = "Enter the os disk size"               #EC2 OS Disk in terms of numbers ex:20gb --> 20
  type = number
  default = "20"
}

#-----------------------------------------------------------------------------#

#--------------------------------------------------------------------------#
#-------------creating variable for ec2  credilio-dev-api VM---------------#
#--------------------------------------------------------------------------#
variable "credilio-dev-api_key" {
  description = "Enter the Key pair name"
  type = string
  default = "credilio-dev-api_key.pem"                        #create keypair with required name
}

#creating variable for os disk for ec2_credilio-dev-api
variable "credilio-dev-api_os_disk" {
  description = "Enter the os disk size"                    #EC2 OS Disk in terms of numbers ex:20gb --> 20
  type = number
  default = "30"
}

#-----------------------------------------------------------------------------#

#--------------------------------------------------------------------------#
#-------------creating variable for ec2  credilio-qa-api VM---------------#
#--------------------------------------------------------------------------#
variable "credilio-qa-api_key" {
  description = "Enter the Key pair name"
  type = string
  default = "credilio-qa-api_key.pem"                        #create keypair with required name
}

#creating variable for os disk for ec2_credilio-qa-api
variable "credilio-qa-api_os_disk" {
  description = "Enter the os disk size"                    #EC2 OS Disk in terms of numbers ex:20gb --> 20
  type = number
  default = "30"
}

#-----------------------------------------------------------------------------#

#-----------------------------------------------------------------------------#

#--------------------------------------------------------------------------#
#-------------creating variable for ec2  credilio-vapt-api VM---------------#
#--------------------------------------------------------------------------#
variable "credilio-vapt-api_key" {
  description = "Enter the Key pair name"
  type = string
  default = "credilio-vapt-api_key.pem"                        #create keypair with required name
}

#creating variable for os disk for ec2_credilio-vapt-api
variable "credilio-vapt-api_os_disk" {
  description = "Enter the os disk size"                    #EC2 OS Disk in terms of numbers ex:20gb --> 20
  type = number
  default = "20"
}

#-----------------------------------------------------------------------------#

#--------------------------------------------------------------------------#
#-------------creating variable for ec2  db-proxy VM-----------------------#
#--------------------------------------------------------------------------#
variable "db-proxy_key" {
  description = "Enter the Key pair name"
  type = string
  default = "db-proxy.pem"                        #create keypair with required name
}

#creating variable for os disk for ec2_db-proxy
variable "db-proxy_os_disk" {
  description = "Enter the os disk size"                    #EC2 OS Disk in terms of numbers ex:20gb --> 20
  type = number
  default = "20"
}

#-----------------------------------------------------------------------------#


#--------------------------------------------------------------------------#
#-------------creating variable for ec2  lender-proxy VM-----------------------#
#--------------------------------------------------------------------------#
variable "lender-proxy_key" {
  description = "Enter the Key pair name"
  type = string
  default = "lender-proxy.pem"                        #create keypair with required name
}

#creating variable for os disk for ec2_lender-proxy
variable "lender-proxy_os_disk" {
  description = "Enter the os disk size"                    #EC2 OS Disk in terms of numbers ex:20gb --> 20
  type = number
  default = "20"
}

#-----------------------------------------------------------------------------#

#--------------------------------------------------------------------------#
#-------------creating variable for ec2 sbm-accops-non-prod VM-----------------------#
#--------------------------------------------------------------------------#
variable "sbm-accops-non-prod_key" {
  description = "Enter the Key pair name"
  type = string
  default = "sbm-accops-non-prod.pem"                        #create keypair with required name
}

#creating variable for os disk for ec2_sbm-accops-non-prod
variable "sbm-accops-non-prod_os_disk" {
  description = "Enter the os disk size"                    #EC2 OS Disk in terms of numbers ex:20gb --> 20
  type = number
  default = "20"
}

#-----------------------------------------------------------------------------#