#### this file is configuration for creating a S3 bucket & dynamodb table needed for backend
#### do not make any modifications 


## dynamo db table
resource "aws_dynamodb_table" "terraform-state-lock-DO-NOT-DELETE" {
    name = "terraform-state-lock-DO-NOT-DELETE"
    billing_mode = "PAY_PER_REQUEST"
    hash_key = "LockID"

    attribute {
      name = "LockID"
      type = "S"
    }
}