# ------------------------------------------------#
# creates key pair for sbm-accops-non-prod server
# ------------------------------------------------#

resource "aws_key_pair" "sbm-accops-non-prod_key" {
key_name = var.sbm-accops-non-prod_key
public_key = tls_private_key.rsa_sbm-accops-non-prod.public_key_openssh
}

#key pair which has been created above is encrypted with RSA algorithm 4096 bits, we can change this accroding to requirement 
resource "tls_private_key" "rsa_sbm-accops-non-prod" {
algorithm = "RSA"
rsa_bits  = 4096
}

#this creates a file in our working directory and download the aws key pair which we have created above
resource "local_file" "sbm-accops-non-prod_key" {
content  = tls_private_key.rsa_sbm-accops-non-prod.private_key_pem
filename = var.sbm-accops-non-prod_key
depends_on = [aws_key_pair.sbm-accops-non-prod_key]
}
