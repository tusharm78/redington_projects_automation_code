# --------------------------------------- #
# creates key pair for credilio-dev-api server
# --------------------------------------- #

resource "aws_key_pair" "credilio-dev-api_key" {
key_name = var.credilio-dev-api_key
public_key = tls_private_key.rsa_credilio-dev-api.public_key_openssh
}

#key pair which has been created above is encrypted with RSA algorithm 4096 bits, we can change this accroding to requirement 
resource "tls_private_key" "rsa_credilio-dev-api" {
algorithm = "RSA"
rsa_bits  = 4096
}

#this creates a file in our working directory and download the aws key pair which we have created above
resource "local_file" "credilio-dev-api_key" {
content  = tls_private_key.rsa_credilio-dev-api.private_key_pem
filename = var.credilio-dev-api_key
depends_on = [aws_key_pair.credilio-dev-api_key]
}
