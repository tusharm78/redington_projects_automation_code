# -------------------------------------- #
# Create VPC for DEV environmnet
# -------------------------------------- #
resource "aws_vpc" "vpc-go" {
    cidr_block = var.aws_vpc
    enable_dns_hostnames = true
   tags = {
        Name        = "VPC_Credilio"
        Created-by  = "Terraform_Automation"
    }
}

#creating public subnet 1
resource "aws_subnet" "Public-Subnet_1a" {
  vpc_id                  = aws_vpc.vpc-go.id
  cidr_block              = var.PublicSubnet_1
  availability_zone       = var.aws_availability_zone1
  map_public_ip_on_launch = true
  tags = {
    Name = "Subnet_Public_1"
    Created-by  = "Terraform_Automation"
  }
}

#creating public subnet 2
resource "aws_subnet" "Public-Subnet_1b" {
  vpc_id                  = aws_vpc.vpc-go.id
  cidr_block              = var.PublicSubnet_2
  availability_zone       = var.aws_availability_zone2
  map_public_ip_on_launch = true
  tags = {
    Name = "Subnet_Public_2"
    Created-by  = "Terraform_Automation"
  }
}


#creating private subnet 1 for dev environmnet in availability zone 1a
resource "aws_subnet" "dev_subnet_1a" {
  vpc_id                  = aws_vpc.vpc-go.id
  cidr_block              = var.Subnet_Dev_Private_1a
  availability_zone       = var.aws_availability_zone1
  map_public_ip_on_launch = false
  tags = {
    Name = "Subnet_Dev_Private_1a"
    Created-by  = "Terraform_Automation"
    Environment = "Development"
  }
}

#creating private subnet 2 for dev environmnet in availability zone 1a
resource "aws_subnet" "dev_subnet_2a" {
  vpc_id                  = aws_vpc.vpc-go.id
  cidr_block              = var.Subnet_Dev_Private_2a
  availability_zone       = var.aws_availability_zone1
  map_public_ip_on_launch = false
  tags = {
    Name = "Subnet_Dev_Private_2a"
    Created-by  = "Terraform_Automation"
    Environment = "Development"
  }
}

#creating private subnet 3 for dev environmnet in availability zone 1a
resource "aws_subnet" "dev_subnet_3a" {
  vpc_id                  = aws_vpc.vpc-go.id
  cidr_block              = var.Subnet_Dev_Private_3a
  availability_zone       = var.aws_availability_zone1
  map_public_ip_on_launch = false
  tags = {
    Name = "Subnet_Dev_Private_3a"
    Created-by  = "Terraform_Automation"
    Environment = "Development"
  }
}

#creating private subnet 1 for dev environmnet in availability zone 1b
resource "aws_subnet" "dev_subnet_1b" {
  vpc_id                  = aws_vpc.vpc-go.id
  cidr_block              = var.Subnet_Dev_Private_1b
  availability_zone       = var.aws_availability_zone2
  map_public_ip_on_launch = false
  tags = {
    Name = "Subnet_Dev_Private_1b"
    Created-by  = "Terraform_Automation"
    Environment = "Development"
  }
}

#creating private subnet 2 for dev environmnet in availability zone 1b
resource "aws_subnet" "dev_subnet_2b" {
  vpc_id                  = aws_vpc.vpc-go.id
  cidr_block              = var.Subnet_Dev_Private_2b
  availability_zone       = var.aws_availability_zone2
  map_public_ip_on_launch = false
  tags = {
    Name = "Subnet_Dev_Private_2b"
    Created-by  = "Terraform_Automation"
    Environment = "Development"
  }
}

#creating private subnet 3 for dev environmnet in availability zone 1b
resource "aws_subnet" "dev_subnet_3b" {
  vpc_id                  = aws_vpc.vpc-go.id
  cidr_block              = var.Subnet_Dev_Private_3b
  availability_zone       = var.aws_availability_zone2
  map_public_ip_on_launch = false
  tags = {
    Name = "Subnet_Dev_Private_3b"
    Created-by  = "Terraform_Automation"
    Environment = "Development"
  }
}

# Creating Internet Gateway
resource "aws_internet_gateway" "vpc-igw" {
  vpc_id = aws_vpc.vpc-go.id
  tags = {
    Name = "IGW-Credilio"
    Created-by  = "Terraform_Automation"
  }
}

# Create a NAT gateway in the public subnet
resource "aws_eip" "nat_eip" {
  domain = "vpc"
  tags = {
    Name = "eip_nat_gw"
  }
}

resource "aws_nat_gateway" "nat" {
  allocation_id = aws_eip.nat_eip.id
  subnet_id     = aws_subnet.Public-Subnet_1a.id
  tags = {
    Name = "Ngw_Credilio"
    Created-by  = "Terraform_Automation"
  }
}

# Create one extra public ip
resource "aws_eip" "nonprod_eip" {
  domain = "vpc"
  tags = {
    Name = "eip_nonprod"
  }
}

#creating public route table
resource "aws_route_table" "rt_public" {
  vpc_id = aws_vpc.vpc-go.id

  tags = {
    Name    = "RT-Public"   # Route table for Public subnet is created
    Created-by  = "Terraform_Automation"
  }
}
#associating public route table with respective public subnet 1
resource "aws_route_table_association" "public_rt_1" {
  route_table_id = aws_route_table.rt_public.id     # public route table is associated with respective public subnet
  subnet_id      = aws_subnet.Public-Subnet_1a.id
}

#associating public route table with respective public subnet 2
resource "aws_route_table_association" "public_rt_2" {
  route_table_id = aws_route_table.rt_public.id     # public route table is associated with respective public subnet
  subnet_id      = aws_subnet.Public-Subnet_1b.id
}

#creating dev-private-subnet route table
resource "aws_route_table" "rt_dev_private" {
  vpc_id = aws_vpc.vpc-go.id

  tags = {
    Name    = "RT-Dev-Private"   # Route table for Dev Private subnet is created
    Created-by  = "Terraform_Automation"
  }
}
#associating dev-private-subnet route table with respective dev private subnet 1
resource "aws_route_table_association" "Dev-Private_rt_1" {
  route_table_id = aws_route_table.rt_dev_private.id    # dev private route table is associated with respective dev private subnet
  subnet_id      = aws_subnet.dev_subnet_1a.id
}

#associating dev-private-subnet route table with respective dev private subnet 2
resource "aws_route_table_association" "Dev-Private_rt_2" {
  route_table_id = aws_route_table.rt_dev_private.id    # dev private route table is associated with respective dev private subnet
  subnet_id      = aws_subnet.dev_subnet_2a.id
}

#associating dev-private-subnet route table with respective dev private subnet 3
resource "aws_route_table_association" "Dev-Private_rt_3" {
  route_table_id = aws_route_table.rt_dev_private.id    # dev private route table is associated with respective dev private subnet
  subnet_id      = aws_subnet.dev_subnet_3a.id
}

#associating dev-private-subnet route table with respective dev private subnet 1
resource "aws_route_table_association" "Dev-Private_rt_4" {
  route_table_id = aws_route_table.rt_dev_private.id    # dev private route table is associated with respective dev private subnet
  subnet_id      = aws_subnet.dev_subnet_1b.id
}

#associating dev-private-subnet route table with respective dev private subnet 2
resource "aws_route_table_association" "Dev-Private_rt_5" {
  route_table_id = aws_route_table.rt_dev_private.id    # dev private route table is associated with respective dev private subnet
  subnet_id      = aws_subnet.dev_subnet_2b.id
}

#associating dev-private-subnet route table with respective dev private subnet 3
resource "aws_route_table_association" "Dev-Private_rt_6" {
  route_table_id = aws_route_table.rt_dev_private.id    # dev private route table is associated with respective dev private subnet
  subnet_id      = aws_subnet.dev_subnet_3b.id
}

# Create Route in Route Table for Internet Access
resource "aws_route" "public_rt" {
  route_table_id         = aws_route_table.rt_public.id
  destination_cidr_block = "0.0.0.0/0"
  gateway_id             = aws_internet_gateway.vpc-igw.id
}

# Create Route in Route Table for NAT GW
resource "aws_route" "private_rt" {
  route_table_id         = aws_route_table.rt_dev_private.id
  destination_cidr_block = "0.0.0.0/0"
  nat_gateway_id = aws_nat_gateway.nat.id
}