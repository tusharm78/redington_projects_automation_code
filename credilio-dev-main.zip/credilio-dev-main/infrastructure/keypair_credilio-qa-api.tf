# --------------------------------------- #
# creates key pair for credilio-qa-api server
# --------------------------------------- #

resource "aws_key_pair" "credilio-qa-api_key" {
key_name = var.credilio-qa-api_key
public_key = tls_private_key.rsa_credilio-qa-api.public_key_openssh
}

#key pair which has been created above is encrypted with RSA algorithm 4096 bits, we can change this accroding to requirement 
resource "tls_private_key" "rsa_credilio-qa-api" {
algorithm = "RSA"
rsa_bits  = 4096
}

#this creates a file in our working directory and download the aws key pair which we have created above
resource "local_file" "credilio-qa-api_key" {
content  = tls_private_key.rsa_credilio-qa-api.private_key_pem
filename = var.credilio-qa-api_key
depends_on = [aws_key_pair.credilio-qa-api_key]
}
