# ------------------------------------ #
####  backend configuration  #####
# ------------------------------------ #
terraform {
  backend "s3" {
    bucket = "do-not-delete-credilio-terraform-backend"        #replace with the project specific bucketname
    key    = "statefile/infrastructure/terraform.tfstate"
    region = "ap-south-1"                                          #replce the region
    dynamodb_table = "terraform-state-lock-DO-NOT-DELETE"  
    profile = "dev-sso"        #do not change the dynamoDB table name
  }
}