# ------------------------------------------------#
# creates key pair for db-proxy server
# ------------------------------------------------#

resource "aws_key_pair" "db-proxy_key" {
key_name = var.db-proxy_key
public_key = tls_private_key.rsa_db-proxy.public_key_openssh
}

#key pair which has been created above is encrypted with RSA algorithm 4096 bits, we can change this accroding to requirement 
resource "tls_private_key" "rsa_db-proxy" {
algorithm = "RSA"
rsa_bits  = 4096
}

#this creates a file in our working directory and download the aws key pair which we have created above
resource "local_file" "db-proxy_key" {
content  = tls_private_key.rsa_db-proxy.private_key_pem
filename = var.db-proxy_key
depends_on = [aws_key_pair.db-proxy_key]
}
