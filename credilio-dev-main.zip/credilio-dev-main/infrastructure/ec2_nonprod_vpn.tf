# ------------------------------------- #
#creating virtual machine - nonprod VPN VM
# ------------------------------------- #
resource "aws_instance" "ec2_nonprod-vpn" {
  subnet_id                   = aws_subnet.Public-Subnet_1a.id
  associate_public_ip_address = true
  ami                         = "ami-02d26659fd82cf299"           #ubuntu 24.04 ami id
  instance_type               = "t3a.medium"                    #add the required instance size here
  root_block_device {
  volume_size = var.nonprod-vpn_os_disk
    encrypted = true
    delete_on_termination = true
    volume_type = "gp3"
    tags = {
      Name = "nonprod-vpn_os_disk"
      CreatedThrough = "Terraform_Automation"
    }
  }
user_data = file("userdata.sh")
  
#here we are referencing the aws key pair which we have created in keypair.tf config file
key_name              = var.nonprod_vpn_key

vpc_security_group_ids = [aws_security_group.sg_nonprod_vpn.id]
  
  #here we are attaching tags to our resources
  tags = {
    "Name" = "dev-vpn"
     Created-by  = "Terraform_Automation"

  }
}

# ----------------------------------------------------------- #
#this creates and attach a elastic public ip to NON PROD VPN VM
# ----------------------------------------------------------- #
resource "aws_eip" "nonprod-vpn_public_ip" {
  domain = "vpc"
  instance = aws_instance.ec2_nonprod-vpn.id
    tags = {
    Name = "eip_nonprod_vpn"
    Created-by  = "Terraform_Automation"
  }
}

# ----------------------------------------------------------- #
#creating security group for NON PROD VPN VM
# ----------------------------------------------------------- #
# Create Security Group - SSH Traffic
resource "aws_security_group" "sg_nonprod_vpn" {
  vpc_id      = aws_vpc.vpc-go.id
  name        = "sg_nonprod_vpn"
  description = "VM SSH"

# inbound ssh port
  ingress {
    description = "Allow Port 22"
    from_port   = 22
    to_port     = 22
    protocol    = "tcp"
    cidr_blocks = ["0.0.0.0/0"]
  }

# inbound port 80
  ingress {
    description = "Allow Port 80"
    from_port   = 80
    to_port     = 80
    protocol    = "tcp"
    cidr_blocks = ["0.0.0.0/0"]
  }

# inbound port 443
  ingress {
    description = "Allow Port 443"
    from_port   = 443
    to_port     = 443
    protocol    = "tcp"
    cidr_blocks = ["0.0.0.0/0"]
  }

# inbound port 11501
  ingress {
    description = "Allow Port 11501"
    from_port   = 11501
    to_port     = 11501
    protocol    = "udp"
    cidr_blocks = ["0.0.0.0/0"]
  }

# inbound port 1194
  ingress {
    description = "Allow Port 1194"
    from_port   = 1194
    to_port     = 1194
    protocol    = "udp"
    cidr_blocks = ["0.0.0.0/0"]
  }
#outbound port 
  egress {
    description = "Allow all IP and Ports outbound"
    from_port   = 0
    to_port     = 0
    protocol    = "-1"
    cidr_blocks = ["0.0.0.0/0"]
  }

  tags = {
    Name = "sg_nonprod_vpn"
    CreatedThrough = "Terraform Automation"
  }
}
