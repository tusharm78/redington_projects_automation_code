resource "aws_cloudfront_origin_access_control" "s3" {
  name                              = "dev_s3"
  description                       = "dev_s3"
  origin_access_control_origin_type = "s3"
  signing_behavior                  = "always"
  signing_protocol                  = "sigv4"
}
 
 
resource "aws_cloudfront_distribution" "cdn" {
  enabled             = true
 
  origin {
    domain_name              = "dev-credilio.s3.ap-south-1.amazonaws.com"  
    origin_id                = "myS3Origin"
    origin_access_control_id = aws_cloudfront_origin_access_control.s3.id
  }
 
  default_cache_behavior {
    allowed_methods  = ["GET", "HEAD"]
    cached_methods   = ["GET", "HEAD"]
    target_origin_id = "myS3Origin"
 
    forwarded_values {
      query_string = false
      cookies {
        forward = "none"
      }
    }
 
    viewer_protocol_policy = "redirect-to-https"
    min_ttl                = 0
    default_ttl            = 3600
    max_ttl                = 86400
  }
 
  restrictions {
    geo_restriction {
      restriction_type = "none"
    }
  }
 
  viewer_certificate {
    cloudfront_default_certificate = true
  }
}