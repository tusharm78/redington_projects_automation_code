#Creating S3 Buckets for NON-PROD Accounts

# resource "aws_s3_bucket" "credilio_fluentbit" {
#   bucket = "credilio-fluentbit"

#   tags = {
#     Name       = "credilio-fluentbit"
#     Created-by = "Terraform_Automation"
#   }
# }

resource "aws_s3_bucket" "credilio_temp_certificates" {
  bucket = "credilio-temp-certificates"

  tags = {
    Name       = "credilio-temp-certificates"
    Created-by = "Terraform_Automation"
  }
}

resource "aws_s3_bucket" "dev_credilio_admin_report" {
  bucket = "dev-credilio-admin-report"

  tags = {
    Name       = "dev-credilio-admin-report"
    Created-by = "Terraform_Automation"
  }
}

resource "aws_s3_bucket" "gcf_v2_sources" {
  bucket = "gcf-v2-sources-18254753993-asia-south1"

  tags = {
    Name       = "gcf-v2-sources-18254753993-asia-south1"
    Created-by = "Terraform_Automation"
  }
}

resource "aws_s3_bucket" "gcf_v2_uploads" {
  bucket = "gcf-v2-uploads-18254753993-asia-south1"

  tags = {
    Name       = "gcf-v2-uploads-18254753993-asia-south1"
    Created-by = "Terraform_Automation"
  }
}

# resource "aws_s3_bucket" "gcf_v2_uploads_appspot" {
#   bucket = "gcf-v2-uploads-18254753993.asia-south1.cloudfunctions.appspot.com"

#   tags = {
#     Name       = "gcf-v2-uploads-18254753993.asia-south1.cloudfunctions.appspot.com"
#     Created-by = "Terraform_Automation"
#   }
# }

resource "aws_s3_bucket" "novio_temp_certificate" {
  bucket = "novio-temp-certificate"

  tags = {
    Name       = "novio-temp-certificate"
    Created-by = "Terraform_Automation"
  }
}
