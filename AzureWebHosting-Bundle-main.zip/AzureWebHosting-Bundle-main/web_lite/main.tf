

resource "aws_s3_bucket_website_configuration" "example-config" {
  bucket = aws_s3_bucket.weblitered123.bucket
  index_document {
    suffix = "index.html"
  }
}
resource "aws_s3_bucket_policy" "example-policy" {
  bucket = aws_s3_bucket.weblitered123.id
 policy = jsonencode({

    "Version": "2012-10-17",
    "Statement": [
      {
        "Sid" : "PublicReadGetObject",
       "Effect" : "Allow",
        "Principal" : "*",
        "Action" : "s3:GetObject",
        "Resource": [
                "arn:aws:s3:::${var.S3Bucketname}/*"
        ]
      }
    ]
})
}



 resource "aws_s3_bucket_public_access_block" "accessblock" {
  bucket = aws_s3_bucket.weblitered123.id

  block_public_acls       = false
  block_public_policy     = false
  ignore_public_acls      = false
  restrict_public_buckets = false
}

