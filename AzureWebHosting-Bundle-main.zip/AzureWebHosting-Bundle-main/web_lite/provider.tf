
 terraform {
  required_version = "> 0.14"
  required_providers {
    aws = {
      source  = "hashicorp/aws"
      version = "> 3.0"
    }
  }
}


# Provider Block
provider "aws" {
  region     = var.aws_region
 
  access_key = "AKIA2XI5PNE6XVJS73US"
  secret_key = "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"
}
