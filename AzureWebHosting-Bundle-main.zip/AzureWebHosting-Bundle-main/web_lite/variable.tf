variable "aws_region" {
    description = "Enter the AWS Region where you want your resources to be created"
    type = string
    default = "us-east-1"
}

variable "resource_tags_name" {
  description = "Tags for resources"
  type = string
  default = "WebLite_Pack_Redington"
}

variable "resource_tags_value" {
  description = "Tags for resources"
  type = string
  default = "Production_Environment"
}

variable "S3Bucketname" {
    type = string
  description = "Name of the S3 Bucket"
  default = "webbundlelite007"
}


variable "resource_tags_name" {
  description = "Tags for resources"
  type = string
  default = "Dynamic_Starter_Pack_Redington"
}

variable "resource_tags_value" {
  description = "Tags for resources"
  type = string
  default = "Production_Environment"
}

variable "creation_date" {
  description ="Creation Date"
  type = string
  default = "value"

}

