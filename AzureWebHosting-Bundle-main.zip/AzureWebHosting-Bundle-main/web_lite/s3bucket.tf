resource "aws_s3_bucket" "weblitered123" {
  bucket = var.S3Bucketname

tags_all = merge({ Pack_Name = var.resource_tags_name }, { Created_by = "Terraform Automation", Distributor_name = "Redington" } , { creation_date = "Mention the date here"})
}