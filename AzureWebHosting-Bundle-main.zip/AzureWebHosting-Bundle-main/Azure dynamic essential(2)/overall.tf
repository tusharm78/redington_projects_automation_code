

# Define availability zones
resource "azurerm_availability_set" "azavset" {
  name                = "example-availability-set"
  location            = data.azurerm_resource_group.rg_name.location
  resource_group_name = data.azurerm_resource_group.rg_name.name

  platform_fault_domain_count = 2
  platform_update_domain_count = 2
}

# Define virtual network
resource "azurerm_virtual_network" "azvnet" {
  name                = "example-vnet"
  address_space       = ["10.0.0.0/16"]
  location            = data.azurerm_resource_group.rg_name.location
  resource_group_name = data.azurerm_resource_group.rg_name.name
}

# Define subnet
resource "azurerm_subnet" "azsub" {
  name                 = "example-subnet"
  resource_group_name  = data.azurerm_resource_group.rg_name.name
  virtual_network_name = azurerm_virtual_network.azvnet.name
  address_prefixes     = ["10.0.1.0/24"]
}

# Define public IP addresses for VMs
resource "azurerm_public_ip" "azpip" {
  count                = 2
  name                 = "example-publicip-${count.index}"
  location             = data.azurerm_resource_group.rg_name.location
  resource_group_name  = data.azurerm_resource_group.rg_name.name
  allocation_method    = "Static"
  sku = "Standard"
}

# Define network interfaces for VMs
resource "azurerm_network_interface" "aznic" {
  count                = 2
  name                 = "example-nic-${count.index}"
  location             = data.azurerm_resource_group.rg_name.location
  resource_group_name  = data.azurerm_resource_group.rg_name.name

  ip_configuration {
    name                          = "example-nic-ipconfig"
    
    subnet_id                     = azurerm_subnet.azsub.id
    private_ip_address_allocation = "Dynamic"
   # public_ip_address_id          = azurerm_public_ip.azpip[count.index].id
    # public_ip_address_id = azurerm_public_ip.azpip[count.index + 1].id
  }
}

# Define virtual machines
resource "azurerm_virtual_machine" "azvm" {
  count                = 2
  name                 = "example-vm-${count.index}"
  location             = data.azurerm_resource_group.rg_name.location
  resource_group_name  = data.azurerm_resource_group.rg_name.name
  availability_set_id  = azurerm_availability_set.azavset.id
  network_interface_ids = [azurerm_network_interface.aznic[count.index].id]

  vm_size              = "Standard_B1S"
  delete_os_disk_on_termination = true

  storage_image_reference {
    publisher = "Canonical"
    offer     = "UbuntuServer"
    sku       = "18.04-LTS"
    version   = "latest"
  }

  storage_os_disk {
    name              = "example-osdisk-${count.index}"
    caching           = "ReadWrite"
    create_option     = "FromImage"
    managed_disk_type = "Standard_LRS"
  }

  os_profile {
    computer_name  = "example-vm-${count.index}"
    admin_username = "adminuser"
    admin_password = "Password123"
  }

  os_profile_linux_config {
    disable_password_authentication = false
  }
}

# Define Azure Load Balancer
resource "azurerm_lb" "azlb" {
  name                = "example-lb"
  location            = data.azurerm_resource_group.rg_name.location
  resource_group_name = data.azurerm_resource_group.rg_name.name
  sku                 = "Standard"

  frontend_ip_configuration {
    name                 = "example-lb-frontip"
   # subnet_id            = azurerm_subnet.azsub.id
    #private_ip_address   = "10.0.1.100"
   # public_ip_address_id = azurerm_public_ip.azpip[count.index].id
  public_ip_address_id = azurerm_public_ip.azpip[0].id
#public_ip_address_id = azurerm_public_ip.azpip[count.index].id
  }

  
}

# Define Azure Load Balancer Backend Pool
resource "azurerm_lb_backend_address_pool" "azlbbap" {
  name                = "example-lb-backendpool"
  loadbalancer_id     = azurerm_lb.azlb.id
  #resource_group_name = data.azurerm_resource_group.rg_name.name
  #virtual_network_id = azurerm_virtual_network.azvnet.id

}

# Define Azure Load Balancer Rule
resource "azurerm_lb_rule" "azlbru" {
  name                           = "example-lb-rule"
  #resource_group_name            =data.azurerm_resource_group.rg_name.name
  loadbalancer_id                = azurerm_lb.azlb.id
  backend_address_pool_ids        = [azurerm_lb_backend_address_pool.azlbbap.id]
  protocol                       = "Tcp"
  frontend_port                  = 80
  backend_port                   = 80
  frontend_ip_configuration_name = azurerm_lb.azlb.frontend_ip_configuration[0].name
  
}


# Define Azure CDN
resource "azurerm_cdn_profile" "cdnprof" {
  name                = "example-cdn-profile"
  location            =data.azurerm_resource_group.rg_name.location
  resource_group_name = data.azurerm_resource_group.rg_name.name
  sku                 = "Standard_Microsoft"
}

# Define Azure CDN endpoint
resource "azurerm_cdn_endpoint" "example" {
  name                = "example-cdn-endpoint"
  location            = data.azurerm_resource_group.rg_name.location
  resource_group_name = data.azurerm_resource_group.rg_name.name
  profile_name        = azurerm_cdn_profile.cdnprof.name
  #origin_host_header  = azurerm_lb.azlb.frontend_ip_configuration[0].fqdn
  #origins             = [azurerm_lb.azlb.frontend_ip_configuration[0].fqdn]
   origin_host_header  = "${azurerm_public_ip.azpip[0].ip_address}.ip"
     is_http_allowed     = true
  is_https_allowed    = true
  #origins             = [azurerm_lb.azlb.frontend_ip_configuration[0].name]
    #origin_host_header  = azurerm_public_ip.azpip[0].ip_address
  #origins             = [azurerm_public_ip.azpip[0].ip_address]


  origin {
    name = "CDN"
    host_name = "${azurerm_public_ip.azpip[0].ip_address}"

  }
/*
   web_application_firewall {
    policy_id = azurerm_web_application_firewall_policy.azwafp.id
  }
  */
}
/*

# Define custom domain name for CDN
resource "azurerm_cdn_custom_domain" "cdncustdo" {
  name                = "cdn.example.com"
  resource_group_name = data.azurerm_resource_group.rg_name.name
  profile_name        = azurerm_cdn_profile.cdnprof.name
  endpoint_name       = azurerm_cdn_endpoint.example.name
}

*/
  

resource "azurerm_dns_zone" "dnsz" {
  name                = "bobthebuild.com"
  resource_group_name = data.azurerm_resource_group.rg_name.name
}

resource "azurerm_dns_cname_record" "dnscr" {
  name                = "cdnep"
  zone_name           = azurerm_dns_zone.dnsz.name
  resource_group_name = data.azurerm_resource_group.rg_name.name
  ttl                 = 3600
  target_resource_id  = azurerm_cdn_endpoint.example.id
}

resource "azurerm_cdn_endpoint_custom_domain" "cdnecd" {
  name            = "example-domain"
  cdn_endpoint_id = azurerm_cdn_endpoint.example.id
  host_name       = "${azurerm_dns_cname_record.dnscr.name}.${azurerm_dns_zone.dnsz.name}"
}










/*
# Attach WAF to CDN
resource "azurerm_cdn_endpoint" "example" {
  name                = "example-cdn-endpoint"
  resource_group_name = azurerm_resource_group.example.name
  profile_name        = azurerm_cdn_profile.example.name
  origin_host_header  = azurerm_lb.example.frontend_ip_configuration[0].fqdn
  origins             = [azurerm_lb.example.frontend_ip_configuration[0].fqdn]
  web_application_firewall {
    policy_id = azurerm_application_gateway_waf_policy.example.id
  }
}
*/


/*
resource "azurerm_web_application_firewall_policy" "azwafp" {
  name                = "example-waf-policy"
  resource_group_name =data.azurerm_resource_group.rg_name.name
  location            = data.azurerm_resource_group.rg_name.location
 custom_rules {
    name      = "Rule1"
    priority  = 1
    rule_type = "MatchRule"

    match_conditions {
      match_variables {
        variable_name = "RemoteAddr"
      }

      operator           = "IPMatch"
      negation_condition = false
      match_values       = ["192.168.1.0/24", "10.0.0.1"]
    }

        action = "Allow"
  }
 managed_rules {
    exclusion {
      match_variable          = "RequestHeaderNames"
      selector                = "x-company-secret-header"
      selector_match_operator = "Equals"
    }
    exclusion {
      match_variable          = "RequestCookieNames"
      selector                = "too-tasty"
      selector_match_operator = "EndsWith"
    }
 

  managed_rule_set {
      type    = "OWASP"
      version = "3.2"
      rule_group_override {
        rule_group_name = "REQUEST-920-PROTOCOL-ENFORCEMENT"
        rule {
          id      = "920300"
          enabled = true
          action  = "Log"
        }

        rule {
          id      = "920440"
          enabled = true
          action  = "Block"
    }
      }
  }
}
}
*/
/*
resource "azurerm_cdn_endpoint_waf_association" "cdnwafassoc" {
  name                         = "example-waf-association"
  resource_group_name          = data.azurerm_resource_group.rg_name.name
  cdn_profile_name             = azurerm_cdn_profile.cdnprof.name
  cdn_endpoint_name            = azurerm_cdn_endpoint.example.name
  web_application_firewall_id  = azurerm_web_application_firewall_policy.azwafp.id
}



*/