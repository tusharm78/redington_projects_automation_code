resource "azurerm_subnet" "appgw_subnet" {
  name                 = "appgw-subnet"
  resource_group_name  = data.azurerm_resource_group.rg_name.name
  virtual_network_name = azurerm_virtual_network.azvnet.name
  address_prefixes      = ["10.0.2.0/24"]
}


locals {
  backend_address_pool_name      = "${azurerm_virtual_network.azvnet.name}-beap"
  frontend_port_name             = "${azurerm_virtual_network.azvnet.name}-feport"
  frontend_ip_configuration_name = "${azurerm_virtual_network.azvnet.name}-feip"
  http_setting_name              = "${azurerm_virtual_network.azvnet.name}-be-htst"
  listener_name                  = "${azurerm_virtual_network.azvnet.name}-httplstn"
  request_routing_rule_name      = "${azurerm_virtual_network.azvnet.name}-rqrt"
  redirect_configuration_name    = "${azurerm_virtual_network.azvnet.name}-rdrcfg"
}

resource "azurerm_application_gateway" "network" {
  name                = "example-appgateway"
  resource_group_name = data.azurerm_resource_group.rg_name.name
  location            = data.azurerm_resource_group.rg_name.location

  sku {
    name     = "WAF_v2"
    tier     = "WAF_v2"
    capacity = 2
  }

  gateway_ip_configuration {
    name      = "my-gateway-ip-configuration"
    subnet_id = azurerm_subnet.appgw_subnet.id
  }

  frontend_port {
    name = local.frontend_port_name
    port = 80
  }

  frontend_ip_configuration {
    name                 = local.frontend_ip_configuration_name
    public_ip_address_id = azurerm_public_ip.azpip[1].id
  }

  backend_address_pool {
    name = local.backend_address_pool_name
  }

  backend_http_settings {
    name                  = local.http_setting_name
    cookie_based_affinity = "Disabled"
    path                  = "/path1/"
    port                  = 80
    protocol              = "Http"
    request_timeout       = 60
  }

  http_listener {
    name                           = local.listener_name
    frontend_ip_configuration_name = local.frontend_ip_configuration_name
    frontend_port_name             = local.frontend_port_name
    protocol                       = "Http"
  }

  request_routing_rule {
    name                       = local.request_routing_rule_name
    rule_type                  = "Basic"
    http_listener_name         = local.listener_name
    backend_address_pool_name  = local.backend_address_pool_name
    backend_http_settings_name = local.http_setting_name
    priority = 1
  }

 waf_configuration {
  enabled          = true
  firewall_mode    = "Detection"
  rule_set_type    = "OWASP"
  rule_set_version = "3.0"
  #waf_policy_id    = azurerm_application_gateway_waf_policy.mypoli.id
}

}