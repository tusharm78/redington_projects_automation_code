# Create an Azure SQL Server
/*resource "azurerm_sql_server" "azsql" {
  name                         = "mysqlserver"
  resource_group_name          = data.azurerm_resource_group.rg_name.location
  location                     = data.azurerm_resource_group.rg_name.name
  version                      = "12.0"
  administrator_login          = "adminuser"
  administrator_login_password = "password"
}

# Create an Azure SQL Database
resource "azurerm_sql_database" "sqldb" {
  name                  = "mysqldb"
  resource_group_name   = data.azurerm_resource_group.rg_name.location
  location              = data.azurerm_resource_group.rg_name.name
  server_name           = azurerm_sql_server.azsql.name
  edition               = "Standard"
  requested_service_objective_name = "S0"
}



# Create an Azure App Service Plan
resource "azurerm_app_service_plan" "appsp1" {
  name                = "example-appservice-plan"
  location            = data.azurerm_resource_group.rg_name.location
  resource_group_name =  data.azurerm_resource_group.rg_name.name
  sku {
    tier = "Standard"
    size = "S1"
  }
}

# Create an Azure App Service
resource "azurerm_app_service" "aps" {
  name                = "example-appservice"
  location            = data.azurerm_resource_group.rg_name.location
  resource_group_name = data.azurerm_resource_group.rg_name.name
  app_service_plan_id = azurerm_app_service_plan.appsp1.id
   site_config {
    always_on             = true
    linux_fx_version      = "DOTNET|5.0"
    connection_string     = azurerm_sql_database.sqldb.connection_string
    use_32_bit_worker_process = true
  }
}
*/

/*


# Configure autoscaling for the App Service
resource "azurerm_monitor_autoscale_setting" "app_autoscale" {
  name                = "myapp-autoscale"
  resource_group_name = data.azurerm_resource_group.rg_name.name
  location            = data.azurerm_resource_group.rg_name.location
  target_resource_id  = azurerm_app_service.aps.id

  profile {
    name = "default"
    capacity {
      default = 1
      minimum = 1
      maximum = 10
    }
    rule {
      metric_trigger {
        metric_name        = "CpuPercentage"
        metric_resource_id = azurerm_app_service.aps.id
        time_grain         = "PT1M"
        statistic          = "Average"
        time_window        = "PT5M"
        time_aggregation   = "Average"
        operator           = "GreaterThan"
        threshold          = 70
      }
      scale_action {
        direction = "Increase"
        type      = "ChangeCount"
        value     = "1"
        cooldown  = "PT1M"
      }
    }
  }
}

# Output the connection string of the SQL Database
output "sql_db_connection_string" {
  value = azurerm_sql_database.sqldb.connection_string
}
*/


/*
# Create an Azure CDN profile
resource "azurerm_cdn_profile" "example" {
  name                = "example-cdn-profile"
  location            = azurerm_resource_group.example.location
  resource_group_name = azurerm_resource_group.example.name
  sku                 = "Standard_Akamai"
}

# Create an Azure CDN endpoint
resource "azurerm_cdn_endpoint" "example" {
  name                = "example-cdn-endpoint"
  location            = azurerm_resource_group.example.location
  resource_group_name = azurerm_resource_group.example.name
  profile_name        = azurerm_cdn_profile.example.name
  origin_host_header  = azurerm_app_service.example.default_site_hostname
  origin_host_header_cdn = azurerm_app_service.example.default_site_hostname
  origin_path         = "/"
  is_http_allowed     = false
  is_https_allowed    = true
}

# Create an Azure DNS zone
resource "azurerm_dns_zone" "example" {
  name                = "example-domain.com"
  resource_group_name = azurerm_resource_group.example.name
}

# Create an Azure DNS record for the CDN endpoint
resource "azurerm_dns_a_record" "example" {
  name                = "@"
  zone_name           = azurerm_dns_zone.example.name
  resource_group_name = azurerm_resource_group.example.name
  ttl                 = 300
  records             = [azurerm_cdn_endpoint.example.host_name]
}

# Output the CDN endpoint hostname
output "cdn_endpoint_hostname" {
  value = azurerm_cdn_endpoint.example.host_name
}
*/