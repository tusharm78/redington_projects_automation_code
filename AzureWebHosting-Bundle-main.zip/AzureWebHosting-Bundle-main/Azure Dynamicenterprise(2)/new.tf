# Virtual Network and subnet
resource "azurerm_virtual_network" "vnet" {
  name                = "tf-vnet"
  address_space       = ["10.0.0.0/16"]
  location            = data.azurerm_resource_group.rg_name.location
  resource_group_name = data.azurerm_resource_group.rg_name.name
}

resource "azurerm_subnet" "vnet" {
  name                 = "tf-subnet"
  resource_group_name  =data.azurerm_resource_group.rg_name.name
  virtual_network_name = azurerm_virtual_network.vnet.name
  address_prefixes     = ["10.0.1.0/24"]
  service_endpoints    = ["Microsoft.Sql"]

  delegation {
    name = "vnet-delegation"

    service_delegation {
      name    = "Microsoft.Web/serverFarms"
      actions = ["Microsoft.Network/virtualNetworks/subnets/action"]
    }
  }
}




resource "azurerm_mssql_server" "db" {
  name                         = "tf-dbsrv"
  resource_group_name          = data.azurerm_resource_group.rg_name.name
  location                     = data.azurerm_resource_group.rg_name.location
  version                      = "12.0"
  administrator_login          = var.sql-login
  administrator_login_password = var.sql-password
  public_network_access_enabled = true
}

resource "azurerm_mssql_database" "db" {
  name           = "tf-db"
  server_id      = azurerm_mssql_server.db.id
  collation      = "SQL_Latin1_General_CP1_CI_AS"
  read_scale     = false
  sku_name       = "S0"
  #storage_account_type = "LRS"

  threat_detection_policy {
    state = "Enabled"
    #email_addresses = [var.sql-threat-email]
  }
}

resource "azurerm_mssql_server_transparent_data_encryption" "db" {
  server_id = azurerm_mssql_server.db.id
}

resource "azurerm_mssql_virtual_network_rule" "db" {
  name      = "tf-db-vnet"
  server_id = azurerm_mssql_server.db.id
  subnet_id = azurerm_subnet.vnet.id
}

# App Service Plan + Slots
resource "azurerm_app_service_plan" "asp" {
  name                = "tf-asp"
  location            = data.azurerm_resource_group.rg_name.location
  resource_group_name = data.azurerm_resource_group.rg_name.name
  kind = "Windows"
  reserved = false

  sku {
    tier = "Standard"
    size = "S1"
  }
  
}
/*
resource "azurerm_service_plan" "example" {
  name                = "tf-asp"
  resource_group_name = data.azurerm_resource_group.rg_name.name
  location            = data.azurerm_resource_group.rg_name.location
  os_type             = "Windows"
  sku_name            = "S1"
}
*/

resource "azurerm_app_service" "app" {
  name                = "tf-app-sourabh"
  location            = data.azurerm_resource_group.rg_name.location
  resource_group_name = data.azurerm_resource_group.rg_name.name
  app_service_plan_id = azurerm_app_service_plan.asp.id

  https_only = false

  site_config {
    always_on = false
    dotnet_framework_version = "v5.0"
    http2_enabled = true

  }
}
  




/*
# Configure autoscaling for the App Service
resource "azurerm_monitor_autoscale_setting" "app_autoscale" {
  name                = "myapp-autoscale"
  resource_group_name = data.azurerm_resource_group.rg_name.name
  location            = data.azurerm_resource_group.rg_name.location
  target_resource_id  = azurerm_app_service_plan.asp.id

  profile {
    name = "default"
    capacity {
      default = 1
      minimum = 1
      maximum = 2
    }
    rule {
      metric_trigger {
        metric_name        = "CpuPercentage"
        metric_resource_id = azurerm_app_service.app.id
        time_grain         = "PT1M"
        statistic          = "Average"
        time_window        = "PT5M"
        time_aggregation   = "Average"
        operator           = "GreaterThan"
        threshold          = 70
      }
      scale_action {
        direction = "Increase"
        type      = "ChangeCount"
        value     = "1"
        cooldown  = "PT1M"
      }
    }
  }
}
*/


# Create the App Service Autoscale settings
resource "azurerm_monitor_autoscale_setting" "appserviceplan1_autoscale" {
  #name                      ="{var.prefix}-{var.AppService1_AutoscaleSetting}"
name = "myautoscale"
  location                  =data.azurerm_resource_group.rg_name.location
  resource_group_name       =data.azurerm_resource_group.rg_name.name
   target_resource_id       = azurerm_app_service_plan.asp.id
   profile {
                name = "defaultProfile"

                capacity {
                            default = 1
                            minimum = 1
                            maximum = 2
                        }
        


                # Increase the Instance count by 1 when CPU usage is 85% consitanty for  5 mins
                rule {
                        metric_trigger {
                                            metric_name        = "CpuPercentage"
                                            metric_resource_id = azurerm_app_service_plan.asp.id
                                            time_grain         = "PT1M"
                                            statistic          = "Average"
                                            time_window        = "PT5M"
                                            time_aggregation   = "Average"
                                            operator           = "GreaterThan"
                                            threshold          = 85
                                        }

                        scale_action {
                                            direction = "Increase"
                                            type      = "ChangeCount"
                                            value     = "1"
                                            cooldown  = "PT1M"
                                        }
                    }

                # Decrease the Instance count by 1 when CPU usage is 40% or less consitanty for  5 mins
                rule {
                        metric_trigger {
                                            metric_name        = "CpuPercentage"
                                            metric_resource_id = azurerm_app_service_plan.asp.id
                                           #metric_resource_id = azurerm_service_plan.example.id
                                            time_grain         = "PT1M"
                                            statistic          = "Average"
                                            time_window        = "PT5M"
                                            time_aggregation   = "Average"
                                            operator           = "LessThan"
                                            threshold          = 40
                                        }

                        scale_action {
                                            direction = "Decrease"
                                            type      = "ChangeCount"
                                            value     = "1"
                                            cooldown  = "PT1M"
                                        }
                    }


                # Increase the Instance count by 1 when Memory usage is 85% consitanty for  5 mins
                rule {
                        metric_trigger {
                                            metric_name        = "MemoryPercentage"
                                            metric_resource_id = azurerm_app_service_plan.asp.id
                                            time_grain         = "PT1M"
                                            statistic          = "Average"
                                            time_window        = "PT5M"
                                            time_aggregation   = "Average"
                                            operator           = "GreaterThan"
                                            threshold          = 85
                                        }

                        scale_action {
                                            direction = "Increase"
                                            type      = "ChangeCount"
                                            value     = "1"
                                            cooldown  = "PT1M"
                                        }
                    }

                # Decrease the Instance count by 1 when Memory usage is 40% or less consitanty for  5 mins
                rule {
                        metric_trigger {
                                            metric_name        = "MemoryPercentage"
                                            metric_resource_id = azurerm_app_service_plan.asp.id
                                            time_grain         = "PT1M"
                                            statistic          = "Average"
                                            time_window        = "PT5M"
                                            time_aggregation   = "Average"
                                            operator           = "LessThan"
                                            threshold          = 40
                                        }

                        scale_action {
                                            direction = "Decrease"
                                            type      = "ChangeCount"
                                            value     = "1"
                                            cooldown  = "PT1M"
                                        }
                    }

   }


}


resource "azurerm_app_service_virtual_network_swift_connection" "app" {
  app_service_id = azurerm_app_service.app.id
  subnet_id      = azurerm_subnet.vnet.id
}

resource "azurerm_app_service_slot" "app-staging" {
  name                = "staging"
  app_service_name    = azurerm_app_service.app.name
  location            = data.azurerm_resource_group.rg_name.location
  resource_group_name = data.azurerm_resource_group.rg_name.name
  app_service_plan_id = azurerm_app_service_plan.asp.id

  https_only = true

  site_config {
    always_on = false
    dotnet_framework_version = "v5.0"
    http2_enabled = true
    websockets_enabled = false
  }
}

resource "azurerm_app_service_slot_virtual_network_swift_connection" "app-staging" {
  slot_name      = azurerm_app_service_slot.app-staging.name
  app_service_id = azurerm_app_service.app.id
  subnet_id      = azurerm_subnet.vnet.id
}
/*
resource "azurerm_mssql_firewall_rule" "app" {
  name                = "tf-appservice-firewall-rule"
  resource_group_name = data.azurerm_resource_group.rg_name.name
  server_id           = azurerm_mssql_server.db.id
  start_ip_address    = azurerm_app_service.app.outbound_ip_addresses[0]
  end_ip_address      = azurerm_app_service.app.outbound_ip_addresses[0]
}
*/


variable "sql-login" {
  type = string
  default = "adminuser"
}

variable "sql-password" {
  type = string
  default = "password@123"
}

variable "sql-threat-email" {
  type = string
  default = "sourabhp151"
}


