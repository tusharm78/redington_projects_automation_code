

# Create an Azure CDN profile
resource "azurerm_cdn_profile" "cdnprof" {
  name                = "example-cdn-profile"
  location            = data.azurerm_resource_group.rg_name.location
  resource_group_name = data.azurerm_resource_group.rg_name.name
  sku                 = "Standard_Microsoft"
}

/*
# Create an Azure CDN endpoint
resource "azurerm_cdn_endpoint" "cdnend" {
  name                = "example-cdn-endpoint"
  location            = data.azurerm_resource_group.rg_name.location
  resource_group_name = data.azurerm_resource_group.rg_name.name
  profile_name        = azurerm_cdn_profile.cdnprof.name
  origin_host_header  = azurerm_app_service.app.default_site_hostname
  origin_host_header_cdn = azurerm_app_service.app.default_site_hostname
  origin_path         = "/"
  is_http_allowed     = false
  is_https_allowed    = true
}
*/
/*
resource "azurerm_cdn_endpoint" "example" {
  name                = var.cdn_endpoint_name
  profile_name        = azurerm_cdn_profile.cdnprof.name
  resource_group_name = data.azurerm_resource_group.rg_name.name
  location            = data.azurerm_resource_group.rg_name.location
  origin_host_header  = azurerm_app_service.app.default_site_hostname
  origins {
    name  = "origin"
    host_name  = azurerm_app_service.app.default_site_hostname

    https = {
      enabled      = true
      minimum_tls_version = "1.2"
    }
  }
}
*/

resource "azurerm_cdn_endpoint" "example" {
  name                = "example-cdn-endpoint"
  profile_name        = azurerm_cdn_profile.cdnprof.name
  resource_group_name = data.azurerm_resource_group.rg_name.name
  location            = data.azurerm_resource_group.rg_name.location
  is_http_allowed     = true

  origin {
    name     = "example-app-service"
    #host_name = "azurerm_app_service.app.default_site_hostname"
 host_name = "tf-app-lobex.azurewebsites.net"
  }

  tags = {
    environment = "production"
  }
}


output "appservicehost" {
  value = azurerm_app_service.app.default_site_hostname

}
/*
resource "azurerm_cdn_endpoint_custom_domain" "custom_domain" {
  name                = "bobthebuild.com"
  profile_name        = azurerm_cdn_profile.cdnprof.name
  endpoint_name       = "cdn-endpoint-name"
  host_name           = "www.example.com"
  custom_https_provisioning_state = "Succeeded"
  custom_https_parameters {
    certificate_source = "AzureKeyVault"
    vault_name         = "keyvault-name"
    secret_name        = "secret-name"
    secret_version     = "secret-version"
  }
}
*/