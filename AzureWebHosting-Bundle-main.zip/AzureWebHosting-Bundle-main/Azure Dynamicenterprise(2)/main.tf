data "azurerm_resource_group" "rg_name" {
name = "Sourabh-RG"
#location = "Central India"
}

output "id" {
value = data.azurerm_resource_group.rg_name.id
}