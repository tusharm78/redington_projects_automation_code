resource "azurerm_dns_zone" "dnsz" {
  name                = "bobthebuild.com"
  resource_group_name = data.azurerm_resource_group.rg_name.name
}

resource "azurerm_dns_cname_record" "dnscr" {
  name                = "cdnep"
  zone_name           = azurerm_dns_zone.dnsz.name
  resource_group_name = data.azurerm_resource_group.rg_name.name
  ttl                 = 3600
  target_resource_id  = azurerm_cdn_endpoint.example.id
}

resource "azurerm_cdn_endpoint_custom_domain" "cdnecd" {
  name            = "example-domain"
  cdn_endpoint_id = azurerm_cdn_endpoint.example.id
  host_name       = "${azurerm_dns_cname_record.dnscr.name}.${azurerm_dns_zone.dnsz.name}"
}


#Domain Mapping
/*
resource "azurerm_app_service_custom_hostname_binding" "custom_domain" {
  hostname                             = "www.bobthebuild.com"
  app_service_name                     = azurerm_app_service.app.name
  resource_group_name                  = data.azurerm_resource_group.rg_name.name
  certificate_thumbprint               = null
  ssl_state                            = "Disabled"
  host_ssl_state                       = "Disabled"
  min_tls_version                      = "1.2"
  enable_private_ip_address            = false
  ip_based_ssl                         = false
  ssl_certificates                     = null
  use_ip_based_ssl                     = false

}
*/

resource "azurerm_app_service_custom_hostname_binding" "test" {
  hostname            = "bobthebuild"
  app_service_name    = "${azurerm_app_service.app.name}"
  resource_group_name = "${data.azurerm_resource_group.rg_name.name}"
}
