

resource "azurerm_dns_zone" "dnsz" {
  name                = "bobthebuild.com"
  resource_group_name = data.azurerm_resource_group.rg_name.name
}

resource "azurerm_dns_cname_record" "dnscr" {
  name                = "cdnep"
  zone_name           = azurerm_dns_zone.dnsz.name
  resource_group_name = data.azurerm_resource_group.rg_name.name
  ttl                 = 3600
  target_resource_id  = azurerm_cdn_endpoint.example.id
}


resource "azurerm_cdn_endpoint_custom_domain" "cdnecd" {
  name            = "example-domain"
  cdn_endpoint_id = azurerm_cdn_endpoint.example.id
  host_name       = "${azurerm_dns_cname_record.dnscr.name}.${azurerm_dns_zone.dnsz.name}"
  cdn_managed_https {
    certificate_type = "Dedicated"
    tls_version = "TLS12"
    protocol_type = "ServerNameIndication"
  }
}

























/*
# Create a CNAME record
resource "azurerm_dns_cname_record" "examplecname" {
  name                = "cdn"
  zone_name           = azurerm_dns_zone.dns_zone.name
  resource_group_name = data.azurerm_resource_group.rg_name.name
  ttl                 = 300
  cname               = "yourcdnendpoint.azureedge.net"
}
  
# Create an ALIAS record set
resource "azurerm_dns_record_set" "dnsset" {
  #name                = "@"
  name            = "bobthebuild.com"
  zone_name           = azurerm_dns_zone.dns_zone.name
  resource_group_name = data.azurerm_resource_group.rg_name.name
  ttl                 = 300

  alias {
    name      = azurerm_dns_cname_record.examplecname.name
    type      = "CNAME"
    ttl       = 300
    alias_tier = "Standard"
  }
}
*/
/*
resource "azurerm_dns_a_record" "dns_a" {
  name                = "bobthebuild"
  zone_name           = azurerm_dns_zone.dns_zone.name
  resource_group_name = data.azurerm_resource_group.rg_name.name
  ttl                 = 300
  records             = [azurerm_public_ip.ip_public.ip_address]
}


resource "azurerm_dns_cname_record" "example" {
  name                = "cdn"
  zone_name           = azurerm_dns_zone.dns_zone.name
  resource_group_name = data.azurerm_resource_group.rg_name.name
  ttl                 = 300
  record  {
    #cname = azurerm_cdn_endpoint.example.host_name
    cname = "yourcdnendpoint.azureedge.net"
  }
  
}
*/



/*
resource "azurerm_cdn_endpoint_custom_domain" "example" {
  name            = "www.bobthebuild.com"
  cdn_endpoint_id = azurerm_cdn_endpoint.example.id
  host_name       = "${azurerm_dns_cname_record.example.name}"
}
*/
/*
resource "azurerm_dns_cname_record" "example" {
  name                = "cdn"
  zone_name           = azurerm_dns_zone.dns_zone.name
  resource_group_name = data.azurerm_resource_group.rg_name.name
  ttl                 = 300
  alias {
    name       = azurerm_cdn_endpoint.example.host_name
    type       = "Microsoft.CDN/profiles/endpoints"
    dns_zone_id = azurerm_cdn_profile.example.id
  }
}
*/

/*
output "dns-nameserevrs" {
  value= azurerm_dns_zone.dns_zone.name_servers

}
*/
