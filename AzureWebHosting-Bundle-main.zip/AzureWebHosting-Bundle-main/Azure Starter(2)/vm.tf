# Set your Azure credentials using environment variables or Azure CLI
/*
# Provider configuration
provider "azurerm" {
  features {}
}
*/

# Virtual machine
resource "azurerm_virtual_machine" "azurevm" {
  name                  = "my-vm"
  location              = data.azurerm_resource_group.rg_name.location
  resource_group_name   = data.azurerm_resource_group.rg_name.name
  network_interface_ids = [azurerm_network_interface.example.id]
  #vm_size               = "Standard_DS2_v2"
  vm_size   = "Standard_B1S"
  delete_os_disk_on_termination = "true"

  storage_image_reference {
    publisher = "Canonical"
    offer     = "UbuntuServer"
    sku       = "18.04-LTS"
    version   = "latest"
  }

  # Install Apache and deploy website content
/*provisioner "remote-exec" {
  inline = [
    "sudo apt-get update",
    "sudo apt-get install -y apache2",
    "echo 'Hello, World!' | sudo tee /var/www/html/index.html"
  ]
}

  connection {
    type        = "ssh"
    host        = azurerm_public_ip.ip_public.ip_address
    user        = "adminuser"
    password    = "Password1234"
    agent       = false
    #private_key = file("~/.ssh/id_rsa")
  }

}
*/

  storage_os_disk {
    name              = "vms-osdisk"
    caching           = "ReadWrite"
    create_option     = "FromImage"
    managed_disk_type = "Standard_LRS"
    
  }

  os_profile {
    computer_name  = "my-vm"
    admin_username = "adminuser"
    admin_password = "Password1234"
    custom_data    = file("azure-user-data.sh")
  }

  os_profile_linux_config {
    disable_password_authentication = false
  }
  depends_on = [ azurerm_virtual_network.vnet ]
}





