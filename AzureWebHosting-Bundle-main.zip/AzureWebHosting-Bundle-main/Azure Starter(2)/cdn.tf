
# Azure CDN

resource "azurerm_cdn_profile" "cdn_profile" {
  name                = "mycdnprofile"
  location            = data.azurerm_resource_group.rg_name.location
  resource_group_name = data.azurerm_resource_group.rg_name.name
  sku                 = "Standard_Microsoft"

  tags = {
    environment = "production"
  }
}
resource "random_string" "azurerm_cdn_endpoint_name" {
  length  = 10
  lower   = true
  numeric = false
  special = false
  upper   = false
}

 #Create an Azure CDN endpoint and associate it with the virtual machine's hostname
resource "azurerm_cdn_endpoint" "example" {
  #name                = "yourcdnendpoint"
   name                          = "cdn-endpoint-${random_string.azurerm_cdn_endpoint_name.result}"
  profile_name        = azurerm_cdn_profile.cdn_profile.name
  resource_group_name = data.azurerm_resource_group.rg_name.name
  location            = data.azurerm_resource_group.rg_name.location
  

  origin {
    name      = "my-vm-origin"
    #host_name = azurerm_public_ip.ip_public.ip_address
    host_name = "${azurerm_public_ip.ip_public.ip_address}"
    http_port = 80
    https_port = 443
#origins             = ["${azurerm_public_ip.example.ip_address}"]
  }
origin_host_header = azurerm_public_ip.ip_public.ip_address
#origin_host_header  = azurerm_virtual_machine.azurevm.hostname
depends_on = [ azurerm_virtual_network.vnet,azurerm_virtual_machine.azurevm ]

}

output "public_ip" {
  value = azurerm_public_ip.ip_public.ip_address
}







  
    #origin_host_header = azurerm_public_ip.ip_public.ip_address
   # origin_path = "/"
    #content_path = "/"
   # content_types_to_compress = ["text/html"]
 
  /*
 delivery_rule {
    name  = "EnforceHTTPS"
    order = 1

    request_scheme_condition {
      operator     = "Equal"
      match_values = ["HTTP" , "HTTPS"]
    }

    url_redirect_action {
      redirect_type = "Found"
      protocol      = "Http"
    }
}*/
/*
  custom_domain {
    name           = "www.bobthebuild.com"
    host_name      = azurerm_dns_cname_record.example.name
    #use_https      = true
    certificate_source = "AzureCDN"
  }
*/













