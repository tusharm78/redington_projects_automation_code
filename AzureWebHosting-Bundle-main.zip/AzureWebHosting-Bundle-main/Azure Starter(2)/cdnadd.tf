
/*
resource "azurerm_cdn_profile" "example" {
  name                = "example-cdn-profile"
  location            = azurerm_resource_group.example.location
  resource_group_name = azurerm_resource_group.example.name
  sku                 = "Standard_Akamai"
}

resource "azurerm_cdn_endpoint" "example" {
  name                = "example-cdn-endpoint"
  location            = azurerm_resource_group.example.location
  resource_group_name = azurerm_resource_group.example.name
  profile_name        = azurerm_cdn_profile.example.name
  origin_host_header  = azurerm_virtual_machine.example.domain_name


 origin {
    name      = "example-origin"
    host_name = azurerm_virtual_machine.example.public_ip_address
    http_port = 80
    https_port = 443
    origin_path = "/"
    content_path = "/"
    content_types_to_compress = []
  }

  delivery_rule {
    name              = "example-delivery-rule"
    order             = 0
    request_scheme    = "Http"
    cache_behavior    = "BypassCache"
    query_string_caching_behavior = "IgnoreQueryString"
    rules_engine_action {
      name                 = "CacheBehaviorBypassCache"
      cache_behavior       = "BypassCache"
      dynamic_compression  = "Disabled"
      dynamic_compression_algorithm = ""
    }
  }
  

 
}
*/