# Traffic Manager
/*
resource "azurerm_traffic_manager_profile" "traffic_profile" {
  name                = "example-traffic-manager"
  resource_group_name = data.azurerm_resource_group.rg_name.name
  profile_status      = "Enabled"
  traffic_routing_method = "Weighted"

  tags = {
    environment = "production"
  }
}

resource "azurerm_traffic_manager_endpoint" "traffic_endpoint" {
  name                      = "example-traffic-manager-endpoint"
  resource_group_name       = data.azurerm_resource_group.rg_name.name
  profile_name              = azurerm_traffic_manager_profile.traffic_profile.name
  target_resource_id        = azurerm_virtual_machine.azurevm.id
  type                      = "azureEndpoints"
  priority                  = 1
  weight                    = 1000
  min_child_endpoints       = 1
  max_return             = 1
  endpoint_monitor_status   = "Online"
}
*/