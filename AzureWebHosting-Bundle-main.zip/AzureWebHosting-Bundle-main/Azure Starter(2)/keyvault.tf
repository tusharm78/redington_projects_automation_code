/*data "azurerm_client_config" "current" {}



resource "azurerm_key_vault" "key" {
  name                        = "webexpresskeyvault007"
  location                    = data.azurerm_resource_group.rg_name.location
  resource_group_name         = data.azurerm_resource_group.rg_name.name
  enabled_for_disk_encryption = true
  tenant_id                   = data.azurerm_client_config.current.tenant_id
  soft_delete_retention_days  = 7
  purge_protection_enabled    = false

  sku_name = "standard"

  access_policy {
    tenant_id = data.azurerm_client_config.current.tenant_id
    object_id = data.azurerm_client_config.current.object_id

    key_permissions = [
      "Get",
    ]

    secret_permissions = [
      "Get",
    ]
     storage_permissions = [
      "Get",
    ]
  }
}

# Create a self-signed certificate
resource "azurerm_key_vault_certificate" "vault" {
  name         = "my-self-signed-cert"
  key_vault_id = azurerm_key_vault.key.id
  certificate_policy {
    issuer_parameters {
      name = "Self"
    }
    x509_certificate_properties {
      subject     = "CN=bobthebuild.com"
      key_usage = "digitalSignature"
      validity_in_months = 12
    }
  }
}
*/
/*
# Define the secret properties block
resource "azurerm_key_vault_secret" "secret" {
  name         = "example-secret"
  value        = "your_secret_value"
  key_vault_id = azurerm_key_vault.key.id
  secret_properties {
    content_type = "text/plain"
    enabled      = true
    expires      = "2030-12-31T23:59:59Z"
    not_before   = "2023-01-01T00:00:00Z"
    recoverable_days = 10
  }
}
*/