
# Virtual network
resource "azurerm_virtual_network" "vnet" {
  name                = "example-vnet"
  resource_group_name = data.azurerm_resource_group.rg_name.name
  location            = data.azurerm_resource_group.rg_name.location
  address_space       = ["10.0.0.0/16"]
}

# Subnet
resource "azurerm_subnet" "subnet" {
  name                 = "example-subnet"
  resource_group_name  = data.azurerm_resource_group.rg_name.name
  virtual_network_name = azurerm_virtual_network.vnet.name
  address_prefixes      = ["10.0.1.0/24"]
}

resource "azurerm_subnet_network_security_group_association" "frontend" {
  subnet_id                 = azurerm_subnet.subnet.id
  network_security_group_id = azurerm_network_security_group.nsg.id
}

# Public IP
resource "azurerm_public_ip" "ip_public" {
  name                = "example-publicip"
  location            = data.azurerm_resource_group.rg_name.location
  resource_group_name = data.azurerm_resource_group.rg_name.name
  #sku = "Standard"
  allocation_method   = "Static"
  domain_name_label = "azuwebdynamic"
  
}

# Network interface
resource "azurerm_network_interface" "example" {
  name                      = "example-nic"
  location                  = data.azurerm_resource_group.rg_name.location
  resource_group_name       = data.azurerm_resource_group.rg_name.name

  ip_configuration {
    name                          = "example-ipconfig"
    subnet_id                     = azurerm_subnet.subnet.id
    private_ip_address_allocation = "Dynamic"
    public_ip_address_id          = azurerm_public_ip.ip_public.id
    
  }

}






