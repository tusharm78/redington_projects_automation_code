resource "azurerm_virtual_network" "vnet" {
  name                = "example-vnet"
  address_space       = ["10.0.0.0/16"]
  location            = data.azurerm_resource_group.rg_name.location
  resource_group_name =data.azurerm_resource_group.rg_name.name
}

resource "azurerm_subnet" "subnet1" {
  name                 = "example-subnet"
  resource_group_name  = data.azurerm_resource_group.rg_name.name
  virtual_network_name = azurerm_virtual_network.vnet.name
  address_prefixes     = ["10.0.1.0/24"]
}

resource "azurerm_availability_set" "az1" {
  name                = "my-availability-set-1"
  location            = data.azurerm_resource_group.rg_name.location
  resource_group_name = data.azurerm_resource_group.rg_name.name
}

resource "azurerm_availability_set" "az2" {
  name                = "my-availability-set-2"
  location            = data.azurerm_resource_group.rg_name.location
  resource_group_name = data.azurerm_resource_group.rg_name.name
}
/*
resource "azurerm_network_interface" "nic1" {
  count               = 2
  name                = "example-nic-${count.index}"
  location            = data.azurerm_resource_group.rg_name.location
  resource_group_name = data.azurerm_resource_group.rg_name.name

  ip_configuration {
    name                          = "internal"
    subnet_id                     = azurerm_subnet.subnet1.id
    private_ip_address_allocation = "Dynamic"
   #  backend_address_pool_id = "${azurerm_lb_backend_address_pool.nic.id}"
}
}
*/

resource "azurerm_public_ip" "ip_public" {
  name                = "example-publicip"
  location            = data.azurerm_resource_group.rg_name.location
  resource_group_name = data.azurerm_resource_group.rg_name.name
  sku = "Standard"
  allocation_method   = "Static"
  domain_name_label = "azuwebdynamic"
  
}

resource "azurerm_network_interface" "nic11" {
  name                = "example-nic-1"
  location            = data.azurerm_resource_group.rg_name.location
  resource_group_name = data.azurerm_resource_group.rg_name.name

  ip_configuration {
    name                          = "example-ip-configuration1"
    subnet_id                     = azurerm_subnet.subnet1.id
    private_ip_address_allocation = "Dynamic"
  #public_ip_address_id          = azurerm_public_ip.ip_public.id
  
  }
}

resource "azurerm_network_interface" "nic22" {
  name                = "example-nic-2"
  location            = data.azurerm_resource_group.rg_name.location
  resource_group_name = data.azurerm_resource_group.rg_name.name

  ip_configuration {
    name                          = "example-ip-configuration2"
    subnet_id                     = azurerm_subnet.subnet1.id
    private_ip_address_allocation = "Dynamic"
    #public_ip_address_id          = azurerm_public_ip.ip_public.id
  }
}