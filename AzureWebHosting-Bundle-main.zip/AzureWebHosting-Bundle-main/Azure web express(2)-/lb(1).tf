/*resource "azurerm_public_ip" "pip1" {
  name                = "ipforlb-publicip"
  location            = data.azurerm_resource_group.rg_name.location
  resource_group_name = data.azurerm_resource_group.rg_name.name
  allocation_method   = "Static"
}

resource "azurerm_lb" "lb2" {
  name                = "example-lb"
  location            = data.azurerm_resource_group.rg_name.location
  resource_group_name = data.azurerm_resource_group.rg_name.name

  frontend_ip_configuration {
    name                 = "example-lb-feip"
    public_ip_address_id = azurerm_public_ip.pip1.id
  }
}


# Create a backend pool for the load balancer
resource "azurerm_lb_backend_address_pool" "backend2" {
  name                = "example-lb-backend-pool"
  loadbalancer_id     = azurerm_lb.lb2.id
  #resource_group_name = data.azurerm_resource_group.rg_name.name
virtual_network_id = azurerm_virtual_network.vnet.id

}
*/
/*
# Create a health probe for the load balancer
resource "azurerm_lb_probe" "probe1" {
  name                = "example-lb-probe"
  #resource_group_name = data.azurerm_resource_group.rg_name.name
  loadbalancer_id     = azurerm_lb.lb2.id
  protocol            = "Tcp"
  port                = 80
}


# Create a load balancing rule for the load balancer
resource "azurerm_lb_rule" "example" {
  name                           = "my-lb-rule"
  #resource_group_name            = data.azurerm_resource_group.rg_name.name
  loadbalancer_id                = azurerm_lb.lb2.id
  #backend_address_pool_id        = azurerm_lb_backend_address_pool.backend2.id
  backend_port                   = 80
 # frontend_ip_configuration_name = azurerm_lb.lb2.frontend_ip_configuration[0].name
  frontend_ip_configuration_name = "example-lb-feip"
  frontend_port                  = 80
  protocol                       = "Tcp"
}
# Output the public IP address of the load balancer
output "load_balancer_public_ip" {
  value = azurerm_public_ip.pip1.ip_address
}

*/


/*

resource "azurerm_lb" "lb3" {
  name                = "TestLoadBalancer"
  location            = data.azurerm_resource_group.rg_name.location
  resource_group_name = data.azurerm_resource_group.rg_name.name

  frontend_ip_configuration {
    name                 = "PublicIPAddress"
    public_ip_address_id = azurerm_public_ip.pip1.id
  }
}

resource "azurerm_lb_rule" "rule3 {
  loadbalancer_id                = azurerm_lb.lb3.id
  name                           = "LBRule"
  protocol                       = "Tcp"
  frontend_port                  = 3389
  backend_port                   = 3389
  frontend_ip_configuration_name = "PublicIPAddress"
}
*/