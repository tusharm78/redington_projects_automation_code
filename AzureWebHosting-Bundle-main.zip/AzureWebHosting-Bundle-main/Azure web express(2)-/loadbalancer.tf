resource "azurerm_lb" "loadbalance" {
  name                = "example-lb"
  location            = data.azurerm_resource_group.rg_name.location
  resource_group_name = data.azurerm_resource_group.rg_name.name
  sku                 = "Standard"

  frontend_ip_configuration {
    
        name                 = "my-lb-feip"
    public_ip_address_id = azurerm_public_ip.ip_public.id
  }
}
/*
resource "azurerm_lb_backend_address_pool_address" "example" {
  name                    = "example"
  backend_address_pool_id = azurerm_lb_backend_address_pool.lbbackaddpool.id
  virtual_network_id      = azurerm_virtual_network.vnet.id
  ip_address              = "10.0.0.1"
}
*/

resource "azurerm_lb_backend_address_pool" "lbbackaddpool" {
  name                = "azure-lb-backend-pool"
  loadbalancer_id     = azurerm_lb.loadbalance.id
  #resource_group_name = data.azurerm_resource_group.rg_name.name
  virtual_network_id = azurerm_virtual_network.vnet.id
  #backend_addresses = [    "10.0.1.4", "10.0.1.5",]
  #ip_address = [    "10.0.1.4", "10.0.1.5",]
 #backend_ip_configurations {
     #name                  = "example-ip-configuration1"
     #network_interface_ids = ["azurerm_network_interface.nic11.id" ,"azurerm_network_interface.nic22.id" ]
 #  } 
   
   }
   
/*
resource "azurerm_lb_backend_address_pool" "lbbackaddpool" {
  name                = "azure-lb-backend-pool"
  loadbalancer_id     = azurerm_lb.loadbalance.id

  backend_address {
    ip_address = azurerm_network_interface.nic11.private_ip_address
  }

  backend_address {
    ip_address = azurerm_network_interface.nic22.private_ip_address
  }
}
*/

output "firstnic11" {
  value = azurerm_network_interface.nic11.id
}


resource "azurerm_lb_probe" "lbprobe" {
  name                = "azure-lb-probe"
  protocol            = "Tcp"
  port                = 80
  loadbalancer_id     = azurerm_lb.loadbalance.id
  #resource_group_name = data.azurerm_resource_group.rg_name.name
}

resource "azurerm_lb_rule" "lbrule" {
  name                           = "azure-lb-rule"
  protocol                       = "Tcp"
  frontend_port                  = 80
  backend_port                   = 80
  #frontend_ip_configuration_name = azurerm_lb.loadbalance.frontend_ip_configuration[0].name
  frontend_ip_configuration_name = "my-lb-feip"
  #backend_address_pool_id        = azurerm_lb_backend_address_pool.lbbackaddpool.id
  probe_id                       = azurerm_lb_probe.lbprobe.id
  loadbalancer_id                = azurerm_lb.loadbalance.id
  #resource_group_name            = data.azurerm_resource_group.rg_name.name
 # backend_address_pool_ids = [ azurerm_lb_backend_address_pool.lbbackaddpool.id ]
 backend_address_pool_ids = [ "${azurerm_lb_backend_address_pool.lbbackaddpool.id}" ]
}

/*
resource "azurerm_network_interface_backend_address_pool_association" "nicbe1" {
  network_interface_id            = azurerm_network_interface.nic11.id
  ip_configuration_name           = azurerm_network_interface.nic11.ip_configuration[0].name
 # ip_configuration_name            = "example-ip-configuration1"
  backend_address_pool_id         = azurerm_lb_backend_address_pool.lbbackaddpool.id
 # backend_address_pool_id = "10.0.0.4"
  #resource_group_name             = data.azurerm_resource_group.rg_name.name
}



resource "azurerm_network_interface_backend_address_pool_association" "nicbe2" {
  network_interface_id            = azurerm_network_interface.nic22.id
 ip_configuration_name           = azurerm_network_interface.nic22.ip_configuration[0].name
  #ip_configuration_name            = "example-ip-configuration2"
  backend_address_pool_id         = azurerm_lb_backend_address_pool.lbbackaddpool.id
   #backend_address_pool_id = "10.0.0.5"
  #resource_group_name             = data.azurerm_resource_group.rg_name.name
}
*/
