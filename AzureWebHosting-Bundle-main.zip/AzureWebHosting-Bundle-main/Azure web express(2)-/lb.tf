/*resource "azurerm_lb" "lb1" {
  name                = "example-lb"
  location            = data.azurerm_resource_group.rg_name.location
  resource_group_name = data.azurerm_resource_group.rg_name.name
  sku                 = "Standard"

  frontend_ip_configuration {
    name                 = "PublicIPAddress"
    public_ip_address_id = azurerm_public_ip.pip1.id
  }
}


resource "azurerm_lb_backend_address_pool" "backend1" {
  name                = "example-backendpool"
  loadbalancer_id     = azurerm_lb.lb1.id
  #resource_group_name = data.azurerm_resource_group.rg_name.name
}

resource "azurerm_lb_rule" "rule1" {
  name                           = "example-lbrule"
  #resource_group_name            = data.azurerm_resource_group.rg_name.name
  loadbalancer_id                = azurerm_lb.lb1.id
  backend_address_pool_id        = azurerm_lb_backend_address_pool.backend1.id
  frontend_ip_configuration_name = azurerm_lb.lb1.frontend_ip_configuration[0].name
  frontend_port                  = 80
  backend_port                   = 80
  protocol                       = "Tcp"
}

output "load_balancer_ip" {
  value = azurerm_lb.lb1.frontend_ip_configuration[0].public_ip_address_id
}
*/