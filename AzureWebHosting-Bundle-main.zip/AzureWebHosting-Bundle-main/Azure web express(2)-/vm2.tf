
resource "azurerm_virtual_machine" "vm2" {
  #count               = 2
  name                = "my-vm-2"
  location            = data.azurerm_resource_group.rg_name.location
  resource_group_name = data.azurerm_resource_group.rg_name.name
   availability_set_id   = azurerm_availability_set.az2.id
  network_interface_ids = [azurerm_network_interface.nic22.id]
 # network_interface_ids = [
  # azurerm_network_interface.nic1[count.index].id
  #]
  vm_size              = "Standard_B1s"
delete_os_disk_on_termination = "true"
  storage_image_reference {
    publisher = "Canonical"
    offer     = "UbuntuServer"
    sku       = "18.04-LTS"
    version   = "latest"
  }

  storage_os_disk {
    name              = "express-osdisk-22"
    create_option = "FromImage"
    caching           = "ReadWrite"
  managed_disk_type = "Standard_LRS"
  }

  os_profile {
    computer_name  = "example-vm-22"
    admin_username = "adminuser"
    admin_password = "Password1234"
     custom_data    = file("azure-user-data1.sh")
  }
 os_profile_linux_config {
    disable_password_authentication = false
  }
/*
  provisioner "remote-exec" {
    inline = [
      "sudo apt-get update",
      "sudo apt-get install -y nginx",
      "sudo systemctl start nginx"
    ]
  }
  */
  depends_on = [ azurerm_virtual_network.vnet ]

}