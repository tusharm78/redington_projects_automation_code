resource "aws_eks_node_group" "spot_node_group" {
  cluster_name    = aws_eks_cluster.eks_cluster.name
  node_group_name = "spot-node-group"
  node_role_arn   = aws_iam_role.eks_node_group_role.arn
  subnet_ids      = aws_subnet.eks_subnet[*].id

  scaling_config {
    desired_size = 2
    max_size     = 3
    min_size     = 1
  }

  instance_types = ["t3.medium"]

  capacity_type = "SPOT"

  remote_access {
    ec2_ssh_key = var.key_name
  }

  tags = {
    Name = "spot-node-group"
  }
}
