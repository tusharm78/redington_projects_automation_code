variable "key_name" {
  description = "SSH key name to access the EKS nodes"
  type        = string
}
