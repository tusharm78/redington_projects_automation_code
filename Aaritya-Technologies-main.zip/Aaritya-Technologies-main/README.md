# Aaritya-Technologies

Steps to Deploy
Initialize Terraform:


terraform init
Review the Plan:


terraform plan
Apply the Configuration:


terraform apply
