module "eks" {
  source          = "terraform-aws-modules/eks/aws"
  cluster_name    = "my-eks-cluster"
  cluster_version = "1.27"

  vpc_id     = aws_vpc.eks_vpc.id
  subnet_ids = aws_subnet.eks_subnet[*].id

  cluster_role_arn = aws_iam_role.eks_cluster_role.arn

  node_groups = {
    eks_nodes = {
      desired_capacity = 2
      max_capacity     = 3
      min_capacity     = 1

      instance_type = "m6g.xlarge"

      key_name = var.key_name

      node_group_role_arn = aws_iam_role.eks_node_group_role.arn
    }
  }
}
