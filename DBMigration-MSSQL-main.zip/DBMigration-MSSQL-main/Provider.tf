terraform {
  required_version = "> 0.14"
  required_providers {
    aws = {
      source  = "hashicorp/aws"
      version = "~> 3.0"
    }
  }
}

# Provider Block
provider "aws" {
  region     = "ap-south-1"
  profile    = "default"
  access_key = "AKIA2XI5PNE6WGWVUGWP"
  secret_key = "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"

}
