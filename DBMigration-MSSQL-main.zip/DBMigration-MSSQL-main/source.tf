 resource "aws_dms_endpoint" "sourceep" {

  #certificate_arn            = "arn:aws:acm:us-east-1:123456789012:certificate/12345678-1234-1234-1234-123456789012"

  database_name               = "StudentDB"

  endpoint_id                 = "sourcedemoid"

  endpoint_type               = "source"

  engine_name                 = "sqlserver"

  extra_connection_attributes = ""

  #kms_key_arn                = "arn:aws:kms:us-east-1:123456789012:key/12345678-1234-1234-1234-123456789012"

  password                    = "sa@123"

  port                        = 1433

  server_name                 = "172.27.232.5"

  ssl_mode                    = "none"



 tags = {

    Name = "sourceendpointtest"

  }

 username = "sa"

}
