resource "aws_dms_endpoint" "targetep" {
  database_name               = "StudentDB"
  endpoint_id                 = "targetdemoid"
  endpoint_type               = "target"
  engine_name                 = "sqlserver"
  extra_connection_attributes = ""
  password                    = "Password123"
  port                        = 1433
 server_name                 = replace(aws_db_instance.referencename.endpoint, ":1433", "")
  ssl_mode                    = "none"

  tags = {
    Name = "targetendpointtest"
  }

  username = "admin"
}


#  resource "aws_dms_endpoint" "targetep" {

#   #certificate_arn            = "arn:aws:acm:us-east-1:123456789012:certificate/12345678-1234-1234-1234-123456789012"

#   database_name               = "StudentDB"

#   endpoint_id                 = "targetdemoid"

#   endpoint_type               = "target"

#   engine_name                 = "sqlserver"

#   extra_connection_attributes = ""

#   #kms_key_arn                = "arn:aws:kms:us-east-1:123456789012:key/12345678-1234-1234-1234-123456789012"

#   password                    = "Password123"

#   port                        = 1433

#   server_name                 = "targetdb.cnih4rw4cygc.ap-south-1.rds.amazonaws.com"

#   ssl_mode                    = "none"



#  tags = {

#     Name = "targetendpointtest-pulkit"

#   }

#  username = "admin"

# }
