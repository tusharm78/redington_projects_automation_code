resource "aws_dms_replication_subnet_group" "replsubnetgroup" {
  replication_subnet_group_id          = "replnsng"
  replication_subnet_group_description = "Replication subnet group for DMS"
  
  subnet_ids = ["subnet-032193b594af7b9dc", "subnet-038db2ff67508f6bc"] 

  tags = {
    Name = "DMS Replication Subnet Group"
  }
}

resource "aws_dms_replication_instance" "replserver" {
  replication_instance_class    = "dms.t3.medium"
  replication_subnet_group_id   = aws_dms_replication_subnet_group.replsubnetgroup.replication_subnet_group_id
  replication_instance_id       = "demoinstancefortfnew"
  allocated_storage             = 50
  engine_version                = "3.5.3"
  multi_az                      = false
  publicly_accessible           = false
  apply_immediately             = false
  auto_minor_version_upgrade    = false
  allow_major_version_upgrade   = false
  vpc_security_group_ids        = ["sg-01d55b3aade34c607"]
}













# resource "aws_dms_replication_subnet_group" "replsubnetgroup" {
#   name       = "replnsng"
#   description = "Replication subnet group for DMS"
#   subnet_ids = ["subnet-032193b594af7b9dc", "subnet-038db2ff67508f6bc"]  # Replace with actual subnet IDs

#   tags = {
#     Name = "DMS Replication Subnet Group"
#   }
# }

# resource "aws_dms_replication_instance" "replserver" {
#   replication_instance_class   = "dms.t3.medium"
#   replication_subnet_group_id  = aws_dms_replication_subnet_group.replsubnetgroup.id
#   replication_instance_id      = "demoinstancefortfnew"
#   allocated_storage            = 50
#   engine_version               = "3.5.3"
#   multi_az                     = false
#   publicly_accessible          = false
#   apply_immediately            = false
#   auto_minor_version_upgrade   = false
#   allow_major_version_upgrade  = false
#   #availability_zone = "ap-south-1a"
#   vpc_security_group_ids       = ["sg-01d55b3aade34c607"]
# }






#  resource "aws_dms_replication_instance" "replserver" {

#   replication_instance_class = "dms.t3.medium"

#   replication_subnet_group_id = "replnsng"

#   replication_instance_id = "demoinstancefortfnew"

#   allocated_storage = 50

#   engine_version = "3.5.3"

#   multi_az = false

#   publicly_accessible = false

#   apply_immediately = false

#   auto_minor_version_upgrade = false

#   allow_major_version_upgrade = false

#   #availability_zone = "ap-south-1a"

#   vpc_security_group_ids = [ "sg-01d55b3aade34c607" ]

# }
