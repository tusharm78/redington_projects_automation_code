# resource "aws_dms_replication_task" "dbmigrationtest" {
#   #cdc_start_time            = 1484346890
#   migration_type            = "cdc"
#   replication_instance_arn  = aws_dms_replication_instance.replserver.replication_instance_arn
#   replication_task_id       = "test-dms-replication-task"

#   source_endpoint_arn       = aws_dms_endpoint.sourceep.endpoint_arn
#   target_endpoint_arn       = aws_dms_endpoint.targetep.endpoint_arn

#   table_mappings = jsonencode({
#     rules = [
#       {
#         "rule-type"   = "selection"
#         "rule-id"     = "1"
#         "rule-name"   = "1"
#         "object-locator" = {
#           "schema-name" = "%"
#           "table-name"  = "%"
#         }
#         "rule-action" = "include"
#       }
#     ]
#   })

#   tags = {
#     Name = "test-dbmigration"
#   }
# }


# resource "null_resource" "start_dms_task" {
#   depends_on = [aws_dms_replication_task.dbmigrationtest]

#   provisioner "local-exec" {
#     command = "aws dms start-replication-task --replication-task-arn ${aws_dms_replication_task.dbmigrationtest.replication_task_arn} --start-replication-task-type start-replication"
#   }
# }

# resource "null_resource" "start_dms_task" {
#   depends_on = [aws_dms_replication_task.dbmigrationtest]

#   provisioner "local-exec" {
#     command = <<EOT
#       aws dms start-replication-task \
#         --replication-task-arn ${aws_dms_replication_task.dbmigrationtest.replication_task_arn} \
#         --start-replication-task-type start-replication
#     EOT
#   }
# }






 resource "aws_dms_replication_task" "dbmigrationtest" {

   cdc_start_time            = 1484346880

   migration_type            = "full-load"

   replication_instance_arn  = aws_dms_replication_instance.replserver.replication_instance_arn
   replication_task_id       = "test-dms-replication-task-pul"

   # replication_task_settings = "..."

   source_endpoint_arn       = aws_dms_endpoint.sourceep.endpoint_arn

   table_mappings            = "{\"rules\":[{\"rule-type\":\"selection\",\"rule-id\":\"1\",\"rule-name\":\"1\",\"object-locator\":{\"schema-name\":\"%\",\"table-name\":\"%\"},\"rule-action\":\"include\"}]}"


   tags = {

     Name = "test-pulkit"

   }



   target_endpoint_arn = aws_dms_endpoint.targetep.endpoint_arn

 }