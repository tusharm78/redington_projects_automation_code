 resource "aws_db_subnet_group" "demodbsng" {
  name       = "demodbsng"
  description = "DB subnet group for RDS"
 
  subnet_ids = ["subnet-032193b594af7b9dc", "subnet-038db2ff67508f6bc"] # Replace with your subnet IDs
 
  tags = {
    Name = "demodbsng"
  }
}
 
resource "aws_db_instance" "referencename" {
  engine              = "sqlserver-ex"
  engine_version      = "16.00.4150.1.v1"
  identifier          = "database-1"
  name                = ""
  username            = "admin"
  password            = "Password123"
  instance_class      = "db.t3.micro"
  storage_type        = "gp2"
  allocated_storage   = 20
  max_allocated_storage = 0
 
  vpc_security_group_ids = ["sg-01d55b3aade34c607"]
  publicly_accessible    = false
  db_subnet_group_name   = aws_db_subnet_group.demodbsng.name
 
  multi_az                     = false
  performance_insights_enabled  = false
  deletion_protection           = false
  skip_final_snapshot           = true
}



















# ###resource "aws_db_instance" "referencename" {

#   engine              = "sqlserver-ex"

#   engine_version      = "16.00.4150.1.v1"

#   identifier          = "database-1"

#   name                = ""

#   username            = "admin"

#   password            = "Password123"

#   instance_class      = "db.t3.micro"

#   storage_type        = "gp2"

#   allocated_storage   = 20

#   max_allocated_storage = 0

#   #network_type = "IPV4"

#   #vpc_id = aws_vpc.vpcname.id

#   vpc_security_group_ids = ["sg-01d55b3aade34c607"]

#   publicly_accessible = false

#   db_subnet_group_name   = "demodbsng"

#   multi_az = "false"  #not supported for Express Ed

#   performance_insights_enabled = false

#   deletion_protection =  false

#   skip_final_snapshot = true

# }
# ####