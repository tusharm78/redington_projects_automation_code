# Quick Start Guide - POC Setup

## For Your 3-Account POC

### Step 1: Update Configuration (5 minutes)

1. **Edit deployment script:**
   ```bash
   cd /home/ubuntu/aws/solution/scripts
   nano deploy-cross-account-roles.sh
   ```
   - Replace `YOUR_DEPLOYMENT_ACCOUNT_ID` with your deployment account ID
   - Update `TARGET_ACCOUNTS` with your 2 master account IDs

2. **Edit Python script:**
   ```bash
   nano ../lambda/credential_rotation.py
   ```
   - Update the `load_target_accounts()` method with your account IDs

### Step 2: Deploy Cross-Account Roles (10 minutes)

**For each of your 2 master accounts:**

1. Login to AWS Console
2. Go to CloudFormation
3. Create Stack → Upload template: `templates/cross-account-role.yaml`
4. Parameters:
   - DeploymentAccountId: `YOUR_DEPLOYMENT_ACCOUNT_ID`
   - ExternalId: `credential-rotation-2024`
5. Check "I acknowledge IAM resources" → Create

### Step 3: Deploy Infrastructure (5 minutes)

**In your deployment account:**
```bash
cd /home/ubuntu/aws/solution/scripts
./deploy-infrastructure.sh
```

### Step 4: Test Everything (5 minutes)

```bash
python3 test-rotation.py
```

### Step 5: Manual Test Run (5 minutes)

```bash
aws lambda invoke --function-name CredentialRotationTrigger response.json
cat response.json
```

## Total Setup Time: ~30 minutes

## What Gets Created:

**In Target Accounts:**
- IAM Role: `CredentialRotationExecutionRole`

**In Deployment Account:**
- S3 Bucket for artifacts
- Lambda function for triggering
- CodeBuild project for execution
- EventBridge rule (90-day schedule)
- Secrets Manager secrets (after first run)

## Expected Results:

✅ Passwords rotated for BIZ_OPS users
✅ Access keys rotated for Portal_Access users  
✅ New credentials stored in Secrets Manager
✅ Audit logs in CloudWatch

## Cost for POC:
- ~$1-2 per month for 2 accounts
- Mainly Secrets Manager storage costs

## Next Steps After POC:
1. Scale to all 500+ accounts
2. Add monitoring/alerting
3. Implement backup procedures
4. Train operations team
