# AWS Multi-Account Credential Rotation - Setup Guide

## Overview
This guide walks you through setting up automated credential rotation for 500+ AWS payer accounts using a centralized deployment approach.

## Prerequisites

### 1. Deployment Account Setup
- AWS CLI configured with admin permissions
- Python 3.9+ installed
- Boto3 library installed

### 2. Target Account Requirements
- Admin access to create IAM roles (temporary)
- BIZ_OPS and Portal_Access users must exist
- Console access enabled for BIZ_OPS user
- Programmatic access enabled for Portal_Access user

## Step-by-Step Deployment

### Phase 1: Prepare the Environment

1. **Clone/Download the solution:**
   ```bash
   cd /home/ubuntu/aws/solution
   ```

2. **Update configuration files:**
   - Edit `scripts/deploy-cross-account-roles.sh`
   - Replace `YOUR_DEPLOYMENT_ACCOUNT_ID` with your actual deployment account ID
   - Update `TARGET_ACCOUNTS` array with your account IDs

3. **Update the Python script:**
   - Edit `lambda/credential_rotation.py`
   - Update the `load_target_accounts()` method with your account list

### Phase 2: Deploy Cross-Account Roles

**Option A: Automated Deployment (if you have cross-account access)**
```bash
cd scripts
chmod +x deploy-cross-account-roles.sh
./deploy-cross-account-roles.sh
```

**Option B: Manual Deployment (recommended for POC)**

For each target account:

1. **Login to the target account console**
2. **Go to CloudFormation service**
3. **Create a new stack:**
   - Upload template: `templates/cross-account-role.yaml`
   - Stack name: `credential-rotation-cross-account-role`
   - Parameters:
     - DeploymentAccountId: `YOUR_DEPLOYMENT_ACCOUNT_ID`
     - ExternalId: `credential-rotation-2024`
4. **Enable capabilities:** IAM resource creation
5. **Create the stack**

Repeat for all target accounts.

### Phase 3: Deploy Infrastructure in Deployment Account

```bash
cd scripts
chmod +x deploy-infrastructure.sh
./deploy-infrastructure.sh
```

This will create:
- S3 bucket for artifacts
- Lambda function for triggering
- CodeBuild project for execution
- EventBridge rule for scheduling
- IAM roles and policies

### Phase 4: Test the Setup

```bash
cd scripts
python3 test-rotation.py
```

This will verify:
- Cross-account role access
- IAM permissions
- Secrets Manager access
- Lambda function
- CodeBuild project

### Phase 5: Manual Test Run

1. **Trigger Lambda function manually:**
   ```bash
   aws lambda invoke \
     --function-name CredentialRotationTrigger \
     --region us-east-1 \
     response.json
   ```

2. **Check CodeBuild execution:**
   ```bash
   aws codebuild list-builds-for-project \
     --project-name credential-rotation-project
   ```

3. **Verify secrets in Secrets Manager:**
   ```bash
   aws secretsmanager list-secrets \
     --filters Key=name,Values=credential-rotation/
   ```

## Configuration Details

### Account List Management

For production deployment, you have several options to manage the 500+ account list:

**Option 1: S3 Configuration File**
```python
def load_target_accounts(self):
    s3 = boto3.client('s3')
    response = s3.get_object(
        Bucket='your-config-bucket',
        Key='account-list.json'
    )
    return json.loads(response['Body'].read())
```

**Option 2: Parameter Store**
```python
def load_target_accounts(self):
    ssm = boto3.client('ssm')
    response = ssm.get_parameter(
        Name='/credential-rotation/account-list'
    )
    return json.loads(response['Parameter']['Value'])
```

**Option 3: Environment Variable**
```python
def load_target_accounts(self):
    accounts_str = os.environ.get('TARGET_ACCOUNTS', '')
    return accounts_str.split(',')
```

### Scheduling Configuration

The default schedule is every 90 days. To modify:

1. **Edit the EventBridge rule:**
   ```bash
   aws events put-rule \
     --name CredentialRotation90DaySchedule \
     --schedule-expression "rate(90 days)"
   ```

2. **For different intervals:**
   - Every 60 days: `rate(60 days)`
   - Every 30 days: `rate(30 days)`
   - Monthly: `rate(30 days)`
   - Custom cron: `cron(0 0 1 */3 * ?)` (quarterly)

### Security Configuration

**External ID:** Used for additional security in cross-account access
- Default: `credential-rotation-2024`
- Change in all templates and scripts if needed

**Password Policy:** Modify in `credential_rotation.py`
```python
def generate_secure_password(self, length=16):
    # Customize password requirements here
    alphabet = string.ascii_letters + string.digits + "!@#$%^&*"
    # Add your custom logic
```

## Monitoring and Alerting

### CloudWatch Logs
- Lambda logs: `/aws/lambda/CredentialRotationTrigger`
- CodeBuild logs: `/aws/codebuild/credential-rotation-project`

### SNS Notifications (Optional)
Add SNS topic for notifications:

```yaml
NotificationTopic:
  Type: AWS::SNS::Topic
  Properties:
    TopicName: CredentialRotationNotifications
```

### CloudWatch Alarms
Monitor for failures:

```bash
aws cloudwatch put-metric-alarm \
  --alarm-name "CredentialRotationFailures" \
  --alarm-description "Alert on credential rotation failures" \
  --metric-name Errors \
  --namespace AWS/Lambda \
  --statistic Sum \
  --period 300 \
  --threshold 1 \
  --comparison-operator GreaterThanOrEqualToThreshold
```

## Troubleshooting

### Common Issues

1. **Cross-account role assumption fails:**
   - Verify External ID matches
   - Check trust policy in target account
   - Ensure deployment account ID is correct

2. **User not found errors:**
   - Verify BIZ_OPS and Portal_Access users exist
   - Check user names match exactly

3. **Access key creation fails:**
   - User might already have 2 access keys (AWS limit)
   - Check IAM permissions

4. **Secrets Manager errors:**
   - Verify IAM permissions for Secrets Manager
   - Check region consistency

### Debug Commands

```bash
# Test cross-account access
aws sts assume-role \
  --role-arn arn:aws:iam::ACCOUNT_ID:role/CredentialRotationExecutionRole \
  --role-session-name test \
  --external-id credential-rotation-2024

# Check CodeBuild logs
aws logs describe-log-groups --log-group-name-prefix /aws/codebuild/credential-rotation

# List secrets
aws secretsmanager list-secrets --max-items 50
```

## Cost Estimation

### Monthly Costs (Approximate)

**Core Services:**
- Lambda executions: $0.20 (assuming monthly runs)
- CodeBuild: $0.005 per build minute × 10 minutes = $0.05
- Secrets Manager: $0.40 per secret × 1000 secrets = $400
- S3 storage: $0.023 per GB × 1 GB = $0.02
- CloudWatch Logs: $0.50 per GB × 0.1 GB = $0.05

**Total estimated monthly cost: ~$400-450**

**Annual cost: ~$4,800-5,400**

### Cost Optimization Tips

1. **Use S3 for configuration instead of Parameter Store**
2. **Set log retention policies (30-90 days)**
3. **Use lifecycle policies for S3 artifacts**
4. **Consider regional deployment to reduce data transfer**

## Security Best Practices

1. **Least Privilege Access:** Roles have minimal required permissions
2. **External ID:** Additional security layer for cross-account access
3. **Encryption:** All secrets encrypted at rest
4. **Audit Logging:** CloudTrail logs all API calls
5. **Regular Reviews:** Monitor and review access patterns

## Production Readiness Checklist

- [ ] All cross-account roles deployed
- [ ] Test rotation completed successfully
- [ ] Monitoring and alerting configured
- [ ] Documentation updated with account-specific details
- [ ] Backup and recovery procedures documented
- [ ] Team training completed
- [ ] Emergency contact procedures established

## Support and Maintenance

### Regular Tasks
- Monitor CloudWatch logs weekly
- Review failed rotations monthly
- Update account lists as needed
- Test disaster recovery procedures quarterly

### Emergency Procedures
1. **Disable automatic rotation:** Disable EventBridge rule
2. **Manual password reset:** Use AWS Console
3. **Rollback:** Restore from Secrets Manager previous versions
4. **Contact support:** Have AWS Support case ready

---

**Next Steps:**
1. Complete POC with 2-3 accounts
2. Validate all functionality
3. Scale to production with all 500+ accounts
4. Implement monitoring and alerting
5. Train operations team
