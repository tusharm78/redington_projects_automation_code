#!/bin/bash

# Deploy cross-account roles to target accounts
# This script deploys the CredentialRotationExecutionRole to all target accounts

set -e

# Configuration
DEPLOYMENT_ACCOUNT_ID="YOUR_DEPLOYMENT_ACCOUNT_ID"  # Replace with your deployment account ID
EXTERNAL_ID="credential-rotation-2024"
TEMPLATE_FILE="../templates/cross-account-role.yaml"
STACK_NAME="credential-rotation-cross-account-role"

# Target accounts for POC (replace with your actual account IDs)
TARGET_ACCOUNTS=(
    "111111111111"  # Master Account 1
    "222222222222"  # Master Account 2
)

# Colors for output
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
NC='\033[0m' # No Color

echo -e "${YELLOW}Starting deployment of cross-account roles...${NC}"
echo "Deployment Account ID: $DEPLOYMENT_ACCOUNT_ID"
echo "Target Accounts: ${TARGET_ACCOUNTS[@]}"
echo ""

# Function to deploy to a single account
deploy_to_account() {
    local account_id=$1
    echo -e "${YELLOW}Deploying to account: $account_id${NC}"
    
    # Check if we can assume role or if we need manual deployment
    if aws sts get-caller-identity --profile "account-$account_id" >/dev/null 2>&1; then
        # We have access via profile
        aws cloudformation deploy \
            --template-file "$TEMPLATE_FILE" \
            --stack-name "$STACK_NAME" \
            --parameter-overrides \
                DeploymentAccountId="$DEPLOYMENT_ACCOUNT_ID" \
                ExternalId="$EXTERNAL_ID" \
            --capabilities CAPABILITY_NAMED_IAM \
            --profile "account-$account_id" \
            --region us-east-1
        
        if [ $? -eq 0 ]; then
            echo -e "${GREEN}✓ Successfully deployed to account $account_id${NC}"
        else
            echo -e "${RED}✗ Failed to deploy to account $account_id${NC}"
            return 1
        fi
    else
        echo -e "${YELLOW}No direct access to account $account_id${NC}"
        echo "Please deploy manually using the following command:"
        echo ""
        echo "aws cloudformation deploy \\"
        echo "    --template-file $TEMPLATE_FILE \\"
        echo "    --stack-name $STACK_NAME \\"
        echo "    --parameter-overrides \\"
        echo "        DeploymentAccountId=$DEPLOYMENT_ACCOUNT_ID \\"
        echo "        ExternalId=$EXTERNAL_ID \\"
        echo "    --capabilities CAPABILITY_NAMED_IAM \\"
        echo "    --region us-east-1"
        echo ""
        echo "Or use the AWS Console to deploy the CloudFormation template."
        echo ""
    fi
}

# Validate template first
echo -e "${YELLOW}Validating CloudFormation template...${NC}"
aws cloudformation validate-template --template-body file://"$TEMPLATE_FILE"

if [ $? -ne 0 ]; then
    echo -e "${RED}Template validation failed!${NC}"
    exit 1
fi

echo -e "${GREEN}✓ Template validation successful${NC}"
echo ""

# Deploy to each target account
for account_id in "${TARGET_ACCOUNTS[@]}"; do
    deploy_to_account "$account_id"
    echo ""
done

echo -e "${GREEN}Cross-account role deployment process completed!${NC}"
echo ""
echo "Next steps:"
echo "1. Verify the roles were created successfully in each target account"
echo "2. Test cross-account access from the deployment account"
echo "3. Deploy the deployment account infrastructure"
echo ""
echo "To test cross-account access, run:"
echo "aws sts assume-role --role-arn arn:aws:iam::ACCOUNT_ID:role/CredentialRotationExecutionRole --role-session-name test --external-id $EXTERNAL_ID"
