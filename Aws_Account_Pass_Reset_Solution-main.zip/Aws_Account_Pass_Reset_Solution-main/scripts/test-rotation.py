#!/usr/bin/env python3
"""
Test script for credential rotation functionality
Tests cross-account access and rotation capabilities
"""

import boto3
import json
import logging
from botocore.exceptions import ClientError

# Configure logging
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

class RotationTester:
    def __init__(self):
        self.external_id = 'credential-rotation-2024'
        self.test_accounts = [
            '111111111111',  # Replace with your test account IDs
            '222222222222'
        ]
        self.sts_client = boto3.client('sts')
        
    def test_cross_account_access(self, account_id):
        """Test if we can assume the cross-account role"""
        role_arn = f"arn:aws:iam::{account_id}:role/CredentialRotationExecutionRole"
        
        try:
            response = self.sts_client.assume_role(
                RoleArn=role_arn,
                RoleSessionName=f"TestSession-{account_id}",
                ExternalId=self.external_id
            )
            
            logger.info(f"✓ Successfully assumed role in account {account_id}")
            return True
            
        except ClientError as e:
            logger.error(f"✗ Failed to assume role in account {account_id}: {e}")
            return False
    
    def test_iam_permissions(self, account_id):
        """Test IAM permissions in the target account"""
        role_arn = f"arn:aws:iam::{account_id}:role/CredentialRotationExecutionRole"
        
        try:
            # Assume role
            response = self.sts_client.assume_role(
                RoleArn=role_arn,
                RoleSessionName=f"PermissionTest-{account_id}",
                ExternalId=self.external_id
            )
            
            credentials = response['Credentials']
            iam_client = boto3.client(
                'iam',
                aws_access_key_id=credentials['AccessKeyId'],
                aws_secret_access_key=credentials['SecretAccessKey'],
                aws_session_token=credentials['SessionToken']
            )
            
            # Test listing users
            users_response = iam_client.list_users()
            logger.info(f"✓ Can list users in account {account_id} ({len(users_response['Users'])} users found)")
            
            # Check for target users
            user_names = [user['UserName'] for user in users_response['Users']]
            target_users = ['BIZ_OPS', 'Portal_Access']
            
            for user in target_users:
                if user in user_names:
                    logger.info(f"✓ Found target user {user} in account {account_id}")
                else:
                    logger.warning(f"⚠ Target user {user} not found in account {account_id}")
            
            return True
            
        except ClientError as e:
            logger.error(f"✗ IAM permission test failed for account {account_id}: {e}")
            return False
    
    def test_secrets_manager_access(self):
        """Test Secrets Manager access in deployment account"""
        try:
            secrets_client = boto3.client('secretsmanager')
            
            # Try to list secrets
            response = secrets_client.list_secrets(
                Filters=[
                    {
                        'Key': 'name',
                        'Values': ['credential-rotation/']
                    }
                ]
            )
            
            logger.info(f"✓ Secrets Manager access working ({len(response['SecretList'])} secrets found)")
            return True
            
        except ClientError as e:
            logger.error(f"✗ Secrets Manager access failed: {e}")
            return False
    
    def test_lambda_function(self):
        """Test the Lambda trigger function"""
        try:
            lambda_client = boto3.client('lambda')
            
            # Invoke the function
            response = lambda_client.invoke(
                FunctionName='CredentialRotationTrigger',
                InvocationType='RequestResponse'
            )
            
            payload = json.loads(response['Payload'].read())
            
            if response['StatusCode'] == 200:
                logger.info("✓ Lambda function invoked successfully")
                logger.info(f"Response: {payload}")
                return True
            else:
                logger.error(f"✗ Lambda function returned error: {payload}")
                return False
                
        except ClientError as e:
            logger.error(f"✗ Lambda function test failed: {e}")
            return False
    
    def test_codebuild_project(self):
        """Test CodeBuild project"""
        try:
            codebuild_client = boto3.client('codebuild')
            
            # Get project details
            response = codebuild_client.batch_get_projects(
                names=['credential-rotation-project']
            )
            
            if response['projects']:
                logger.info("✓ CodeBuild project exists and is accessible")
                project = response['projects'][0]
                logger.info(f"Project ARN: {project['arn']}")
                logger.info(f"Service Role: {project['serviceRole']}")
                return True
            else:
                logger.error("✗ CodeBuild project not found")
                return False
                
        except ClientError as e:
            logger.error(f"✗ CodeBuild project test failed: {e}")
            return False
    
    def run_all_tests(self):
        """Run all tests"""
        logger.info("=" * 60)
        logger.info("CREDENTIAL ROTATION SYSTEM TESTS")
        logger.info("=" * 60)
        
        test_results = []
        
        # Test 1: Cross-account access
        logger.info("\n1. Testing cross-account access...")
        for account_id in self.test_accounts:
            result = self.test_cross_account_access(account_id)
            test_results.append(('Cross-account access', account_id, result))
        
        # Test 2: IAM permissions
        logger.info("\n2. Testing IAM permissions...")
        for account_id in self.test_accounts:
            result = self.test_iam_permissions(account_id)
            test_results.append(('IAM permissions', account_id, result))
        
        # Test 3: Secrets Manager
        logger.info("\n3. Testing Secrets Manager access...")
        result = self.test_secrets_manager_access()
        test_results.append(('Secrets Manager', 'deployment', result))
        
        # Test 4: Lambda function
        logger.info("\n4. Testing Lambda function...")
        result = self.test_lambda_function()
        test_results.append(('Lambda function', 'deployment', result))
        
        # Test 5: CodeBuild project
        logger.info("\n5. Testing CodeBuild project...")
        result = self.test_codebuild_project()
        test_results.append(('CodeBuild project', 'deployment', result))
        
        # Summary
        logger.info("\n" + "=" * 60)
        logger.info("TEST RESULTS SUMMARY")
        logger.info("=" * 60)
        
        passed = 0
        failed = 0
        
        for test_name, account, result in test_results:
            status = "PASS" if result else "FAIL"
            logger.info(f"{test_name} ({account}): {status}")
            if result:
                passed += 1
            else:
                failed += 1
        
        logger.info(f"\nTotal tests: {len(test_results)}")
        logger.info(f"Passed: {passed}")
        logger.info(f"Failed: {failed}")
        
        if failed == 0:
            logger.info("\n🎉 All tests passed! System is ready for production.")
            return True
        else:
            logger.warning(f"\n⚠ {failed} test(s) failed. Please fix issues before proceeding.")
            return False

def main():
    tester = RotationTester()
    success = tester.run_all_tests()
    
    if success:
        exit(0)
    else:
        exit(1)

if __name__ == "__main__":
    main()
