#!/bin/bash

# Deploy the main infrastructure in the deployment account

set -e

# Configuration
REGION="us-east-1"
DEPLOYMENT_STACK_NAME="credential-rotation-infrastructure"
CODEBUILD_STACK_NAME="credential-rotation-codebuild"
EXTERNAL_ID="credential-rotation-2024"

# Colors for output
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
NC='\033[0m' # No Color

echo -e "${YELLOW}Deploying credential rotation infrastructure...${NC}"
echo "Region: $REGION"
echo ""

# Step 1: Deploy main infrastructure
echo -e "${YELLOW}Step 1: Deploying main infrastructure...${NC}"
aws cloudformation deploy \
    --template-file ../templates/deployment-account-infrastructure.yaml \
    --stack-name "$DEPLOYMENT_STACK_NAME" \
    --parameter-overrides \
        ExternalId="$EXTERNAL_ID" \
    --capabilities CAPABILITY_NAMED_IAM \
    --region "$REGION"

if [ $? -eq 0 ]; then
    echo -e "${GREEN}✓ Main infrastructure deployed successfully${NC}"
else
    echo -e "${RED}✗ Failed to deploy main infrastructure${NC}"
    exit 1
fi

# Get outputs from the infrastructure stack
echo -e "${YELLOW}Getting stack outputs...${NC}"
ARTIFACTS_BUCKET=$(aws cloudformation describe-stacks \
    --stack-name "$DEPLOYMENT_STACK_NAME" \
    --region "$REGION" \
    --query 'Stacks[0].Outputs[?OutputKey==`ArtifactsBucketName`].OutputValue' \
    --output text)

CODEBUILD_ROLE_ARN=$(aws cloudformation describe-stacks \
    --stack-name "$DEPLOYMENT_STACK_NAME" \
    --region "$REGION" \
    --query 'Stacks[0].Outputs[?OutputKey==`CodeBuildRoleArn`].OutputValue' \
    --output text)

echo "Artifacts Bucket: $ARTIFACTS_BUCKET"
echo "CodeBuild Role ARN: $CODEBUILD_ROLE_ARN"
echo ""

# Step 2: Upload source code to S3
echo -e "${YELLOW}Step 2: Uploading source code to S3...${NC}"

# Create source package
mkdir -p /tmp/credential-rotation-source
cp ../lambda/credential_rotation.py /tmp/credential-rotation-source/
cd /tmp/credential-rotation-source
zip -r source.zip .
cd - > /dev/null

# Upload to S3
aws s3 cp /tmp/credential-rotation-source/source.zip s3://"$ARTIFACTS_BUCKET"/source/source.zip

if [ $? -eq 0 ]; then
    echo -e "${GREEN}✓ Source code uploaded successfully${NC}"
else
    echo -e "${RED}✗ Failed to upload source code${NC}"
    exit 1
fi

# Clean up
rm -rf /tmp/credential-rotation-source

# Step 3: Deploy CodeBuild project
echo -e "${YELLOW}Step 3: Deploying CodeBuild project...${NC}"
aws cloudformation deploy \
    --template-file ../templates/codebuild-project.yaml \
    --stack-name "$CODEBUILD_STACK_NAME" \
    --parameter-overrides \
        ArtifactsBucketName="$ARTIFACTS_BUCKET" \
        CodeBuildRoleArn="$CODEBUILD_ROLE_ARN" \
    --region "$REGION"

if [ $? -eq 0 ]; then
    echo -e "${GREEN}✓ CodeBuild project deployed successfully${NC}"
else
    echo -e "${RED}✗ Failed to deploy CodeBuild project${NC}"
    exit 1
fi

echo ""
echo -e "${GREEN}Infrastructure deployment completed successfully!${NC}"
echo ""
echo "Resources created:"
echo "- S3 Bucket: $ARTIFACTS_BUCKET"
echo "- Lambda Function: CredentialRotationTrigger"
echo "- CodeBuild Project: credential-rotation-project"
echo "- EventBridge Rule: CredentialRotation90DaySchedule"
echo "- IAM Roles: Various service roles"
echo ""
echo "Next steps:"
echo "1. Test the Lambda function manually"
echo "2. Verify CodeBuild project can access target accounts"
echo "3. Test the complete rotation process"
echo ""
echo "To test manually:"
echo "aws lambda invoke --function-name CredentialRotationTrigger --region $REGION response.json"
