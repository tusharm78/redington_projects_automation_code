#!/usr/bin/env python3
"""
AWS Multi-Account Credential Rotation Script
Rotates passwords and access keys across multiple AWS accounts
"""

import boto3
import json
import logging
import secrets
import string
from datetime import datetime
from botocore.exceptions import ClientError, NoCredentialsError

# Configure logging
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(levelname)s - %(message)s',
    handlers=[
        logging.FileHandler('rotation_log.txt'),
        logging.StreamHandler()
    ]
)
logger = logging.getLogger(__name__)

class CredentialRotator:
    def __init__(self):
        self.external_id = 'credential-rotation-2024'
        self.target_users = ['BIZ_OPS', 'Portal_Access']
        self.secrets_client = boto3.client('secretsmanager')
        self.sts_client = boto3.client('sts')
        
        # Account list - in production, this would come from a parameter or file
        self.target_accounts = self.load_target_accounts()
        
    def load_target_accounts(self):
        """Load target account IDs from environment or configuration"""
        # For POC - hardcoded accounts
        # In production, load from S3, Parameter Store, or environment
        return [
            '111111111111',  # Master Account 1
            '222222222222',  # Master Account 2
            # Add more accounts here
        ]
    
    def generate_secure_password(self, length=16):
        """Generate a secure password meeting AWS requirements"""
        # AWS password requirements: 8-128 chars, 3 of 4 character types
        alphabet = string.ascii_letters + string.digits + "!@#$%^&*"
        password = ''.join(secrets.choice(alphabet) for _ in range(length))
        
        # Ensure password meets complexity requirements
        has_upper = any(c.isupper() for c in password)
        has_lower = any(c.islower() for c in password)
        has_digit = any(c.isdigit() for c in password)
        has_special = any(c in "!@#$%^&*" for c in password)
        
        if sum([has_upper, has_lower, has_digit, has_special]) >= 3:
            return password
        else:
            # Regenerate if doesn't meet requirements
            return self.generate_secure_password(length)
    
    def assume_cross_account_role(self, account_id):
        """Assume role in target account"""
        role_arn = f"arn:aws:iam::{account_id}:role/CredentialRotationExecutionRole"
        
        try:
            response = self.sts_client.assume_role(
                RoleArn=role_arn,
                RoleSessionName=f"CredentialRotation-{account_id}",
                ExternalId=self.external_id
            )
            
            credentials = response['Credentials']
            return boto3.client(
                'iam',
                aws_access_key_id=credentials['AccessKeyId'],
                aws_secret_access_key=credentials['SecretAccessKey'],
                aws_session_token=credentials['SessionToken']
            )
        except ClientError as e:
            logger.error(f"Failed to assume role in account {account_id}: {e}")
            return None
    
    def rotate_password(self, iam_client, username, account_id):
        """Rotate password for a user"""
        try:
            new_password = self.generate_secure_password()
            
            # Update the login profile
            iam_client.update_login_profile(
                UserName=username,
                Password=new_password,
                PasswordResetRequired=False
            )
            
            # Store in Secrets Manager
            secret_name = f"credential-rotation/{account_id}/{username}/password"
            secret_value = {
                'username': username,
                'password': new_password,
                'account_id': account_id,
                'rotation_date': datetime.now().isoformat(),
                'type': 'password'
            }
            
            self.store_secret(secret_name, secret_value)
            logger.info(f"Password rotated successfully for {username} in account {account_id}")
            return True
            
        except ClientError as e:
            if e.response['Error']['Code'] == 'NoSuchEntity':
                logger.warning(f"User {username} not found in account {account_id}")
            else:
                logger.error(f"Failed to rotate password for {username} in account {account_id}: {e}")
            return False
    
    def rotate_access_keys(self, iam_client, username, account_id):
        """Rotate access keys for a user"""
        try:
            # List existing access keys
            response = iam_client.list_access_keys(UserName=username)
            existing_keys = response['AccessKeyMetadata']
            
            # Create new access key
            new_key_response = iam_client.create_access_key(UserName=username)
            new_access_key = new_key_response['AccessKey']
            
            # Store new credentials in Secrets Manager
            secret_name = f"credential-rotation/{account_id}/{username}/access-key"
            secret_value = {
                'username': username,
                'access_key_id': new_access_key['AccessKeyId'],
                'secret_access_key': new_access_key['SecretAccessKey'],
                'account_id': account_id,
                'rotation_date': datetime.now().isoformat(),
                'type': 'access_key'
            }
            
            self.store_secret(secret_name, secret_value)
            
            # Delete old access keys (keep only the newest one)
            for key in existing_keys:
                if len(existing_keys) > 1:  # Only delete if there are multiple keys
                    iam_client.delete_access_key(
                        UserName=username,
                        AccessKeyId=key['AccessKeyId']
                    )
                    logger.info(f"Deleted old access key {key['AccessKeyId']} for {username}")
            
            logger.info(f"Access key rotated successfully for {username} in account {account_id}")
            return True
            
        except ClientError as e:
            logger.error(f"Failed to rotate access key for {username} in account {account_id}: {e}")
            return False
    
    def store_secret(self, secret_name, secret_value):
        """Store credentials in AWS Secrets Manager"""
        try:
            # Try to update existing secret
            self.secrets_client.update_secret(
                SecretId=secret_name,
                SecretString=json.dumps(secret_value)
            )
        except ClientError as e:
            if e.response['Error']['Code'] == 'ResourceNotFoundException':
                # Create new secret if it doesn't exist
                self.secrets_client.create_secret(
                    Name=secret_name,
                    SecretString=json.dumps(secret_value),
                    Description=f"Rotated credentials for {secret_value.get('username', 'unknown')}"
                )
            else:
                logger.error(f"Failed to store secret {secret_name}: {e}")
                raise
    
    def process_account(self, account_id):
        """Process credential rotation for a single account"""
        logger.info(f"Processing account: {account_id}")
        
        # Assume role in target account
        iam_client = self.assume_cross_account_role(account_id)
        if not iam_client:
            return False
        
        success_count = 0
        total_operations = 0
        
        for username in self.target_users:
            # Rotate password for all users
            total_operations += 1
            if self.rotate_password(iam_client, username, account_id):
                success_count += 1
            
            # Rotate access keys only for Portal_Access user
            if username == 'Portal_Access':
                total_operations += 1
                if self.rotate_access_keys(iam_client, username, account_id):
                    success_count += 1
        
        logger.info(f"Account {account_id}: {success_count}/{total_operations} operations successful")
        return success_count == total_operations
    
    def run_rotation(self):
        """Main method to run credential rotation across all accounts"""
        logger.info("Starting credential rotation process")
        logger.info(f"Target accounts: {len(self.target_accounts)}")
        
        successful_accounts = 0
        failed_accounts = []
        
        for account_id in self.target_accounts:
            try:
                if self.process_account(account_id):
                    successful_accounts += 1
                else:
                    failed_accounts.append(account_id)
            except Exception as e:
                logger.error(f"Unexpected error processing account {account_id}: {e}")
                failed_accounts.append(account_id)
        
        # Summary
        logger.info("=" * 50)
        logger.info("CREDENTIAL ROTATION SUMMARY")
        logger.info("=" * 50)
        logger.info(f"Total accounts processed: {len(self.target_accounts)}")
        logger.info(f"Successful accounts: {successful_accounts}")
        logger.info(f"Failed accounts: {len(failed_accounts)}")
        
        if failed_accounts:
            logger.warning(f"Failed account IDs: {failed_accounts}")
        
        return len(failed_accounts) == 0

def main():
    """Main function"""
    try:
        rotator = CredentialRotator()
        success = rotator.run_rotation()
        
        if success:
            logger.info("Credential rotation completed successfully")
            exit(0)
        else:
            logger.error("Credential rotation completed with errors")
            exit(1)
            
    except Exception as e:
        logger.error(f"Fatal error in credential rotation: {e}")
        exit(1)

if __name__ == "__main__":
    main()
