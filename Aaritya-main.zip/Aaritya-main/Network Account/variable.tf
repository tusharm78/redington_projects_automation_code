variable "vpc_cidr_block" {
  description = "CIDR block for the VPC"
  default = "172.0.0.0/24"
}

######Variable for public subnet
variable "public_subnet_cidr_block" {
  description = "CIDR block for the public subnet"
  default = "172.10.1.0/24"
}

#####Variable for private subnet
variable "private_subnet_cidr_block" {
  description = "CIDR block for the private subnet"
  default = "172.10.2.0/24"
}

####Variable for region
variable "aws_region" {
  description = "AWS region"
  default =  "ap-south-2"
}

####variable for OS disk
variable "os_disk" {
description = "EC2 OS Disk in terms of numbers ex:20gb --> 20"
type = number
default = "15"
}