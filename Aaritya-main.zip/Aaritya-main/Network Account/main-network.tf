provider "aws" {
  region     = "ap-south-1"
  access_key = "******"
  secret_key = "******"
}

#########Creating VPC######

resource "aws_vpc" "network-vpc" {
  cidr_block = var.vpc_cidr_block #CIDR range in variable
  enable_dns_support = true
  enable_dns_hostnames = true
  tags = {
    Environment = "Network"
  }
}


########Creating Public Subnet############
resource "aws_subnet" "network-subnet-public1-ap-south-1a" {
  vpc_id     = aws_vpc.terraform-vpc.id    #VPC ID range
  cidr_block = var.public_subnet_cidr_block
  availability_zone = "ap-south-1a" # Change to your desired availability zone
  map_public_ip_on_launch = true
  tags = {
    Environment = "Network"
  }
}

resource "aws_subnet" "network-subnet-public2-ap-south-1b" {
  vpc_id     = aws_vpc.terraform-vpc.id
  cidr_block = var.public_subnet_cidr_block
  availability_zone = "ap-south-1b" # Change to your desired availability zone
  map_public_ip_on_launch = true
  tags = {
    Environment = "Network"
  }
}

#######Creating Private Subnet##########
resource "aws_subnet" "network-subnet-private1-ap-south-1a" {
  vpc_id     = aws_vpc.terraform-vpc.id
  cidr_block = var.private_subnet_cidr_block
  availability_zone = "ap-south-1a" # Change to your desired availability zone
  tags = {
    Environment = "Network"
  }
}

resource "aws_subnet" "network-subnet-private2-ap-south-1b" {
  vpc_id     = aws_vpc.terraform-vpc.id
  cidr_block = var.private_subnet_cidr_block
  availability_zone = "ap-south-1b" # Change to your desired availability zone
  tags = {
    Environment = "Network"
  }
}

#########Creating Transit Gateway#########
resource "aws_ec2_transit_gateway" "transit-gateway-network" {
  description = "Transit gateway in network account"
  tags = {
    Environment = "Network"
  }
}

########Creating Transit Gateway Attachments###########
resource "aws_ec2_transit_gateway_vpc_attachment" "transit-gateway-attachment-01-network" {
  subnet_ids          = ["subnet-12345678", "subnet-23456789"] # Replace with your subnet IDs
  transit_gateway_id  = aws_ec2_transit_gateway.TransitGT.id
  vpc_id              = aws_vpc.terraform-vpc.id # Replace with your VPC ID
  dns_support         = "enable"
  ipv6_support        = "disable"
  appliance_mode_support = "enable"
}

#########Creating a route table#################
resource "aws_ec2_transit_gateway_route_table" "route_table_1" {
  transit_gateway_id = aws_ec2_transit_gateway.TransitGT.id
  tags = {
    Name = "MyRouteTable"
  }
}

########Creating routes####################
resource "aws_ec2_transit_gateway_route" "route_1" {
  transit_gateway_route_table_id = aws_ec2_transit_gateway_route_table.route_table_1.id
  destination_cidr_block        = "0.0.0.0/0"
  transit_gateway_attachment_id  = aws_ec2_transit_gateway_vpc_attachment.vpc_attachment_1.id
}

########Creating NAT Gateway################
resource "aws_nat_gateway" "my_nat_gateway" {
  allocation_id = aws_eip.my_eip.id
  subnet_id    = aws_subnet.public_subnet.id
}

#########Creating an Elastic IP for the NAT Gateway###########
resource "aws_eip" "my_eip" {}

#########Creating Security Group###########
resource "aws_security_group" "vpc-ssh" {
  vpc_id      = aws_vpc.vpc-dev.id  #VPC ID range of network-vpc
  name        = "OpenVPN-SG"
  description = "OpenVPN-SG"
  ingress {
    description = "Allow Port 22"
    from_port   = 22
    to_port     = 22
    protocol    = "tcp"
    cidr_blocks = ["0.0.0.0/0"]
  }
  ingress {
    description = "Allow ICMP"
    from_port   = All
    to_port     = All
    protocol    = "ICMP"
    cidr_blocks = ["0.0.0.0/0"]
  }
  ingress {
    description = "Allow Port 443"
    from_port   = 443
    to_port     = 443
    protocol    = "tcp"
    cidr_blocks = ["0.0.0.0/0"]
  }
  ingress {
    description = "Allow Port 943"
    from_port   = 943
    to_port     = 943
    protocol    = "tcp"
    cidr_blocks = ["0.0.0.0/0"]
  }
  egress {
    description = "Allow all IP and Ports outbound"
    from_port   = 0
    to_port     = 0
    protocol    = "-1"
    cidr_blocks = ["0.0.0.0/0"]
  }
}

########Creating EC2########## 
resource "aws_instance" "test-keerthana" {
  ami             = "ami-id"
  instance_type   = "t2.micro"             
  key_name        = "key_pair_name"   
 
  subnet_id       = aws_subnet.public_subnet.id  
  security_group  = ["security_group_id"]   
  
  root_block_device {
  volume_size = var.os_disk
    encrypted = true
    delete_on_termination = true
    volume_type = var.os_disk_type
  }
 
  tags = {
    Name = "MyEC2Instance"
  }





