variable "vpc_cidr_block" {
  description = "CIDR block for the VPC"
  default = "10.0.0.0/16"
}

######Variable for public subnet
variable "public_subnet_cidr_block" {
  description = "CIDR block for the public subnet"
  default = "10.0.0.0/20"
}

#####Variable for private subnet
variable "private_subnet_cidr_block" {
  description = "CIDR block for the private subnet"
  default = "10.0.128.0/20"
}

####Variable for region
variable "aws_region" {
  description = "AWS region"
  default =  "ap-south-2"
}

