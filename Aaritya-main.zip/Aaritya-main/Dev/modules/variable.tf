variable "region" {
  description = "The AWS region where the EKS cluster will be created."
  type        = string
}

variable "cluster_name" {
  description = "The name of the EKS cluster."
  type        = string
}

variable "cluster_role_arn" {
  description = "The ARN of the IAM role that manages the EKS cluster."
  type        = string
}

// ... other input variables ...

