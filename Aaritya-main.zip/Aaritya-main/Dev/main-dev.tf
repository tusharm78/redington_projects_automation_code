#########Creating VPC######

resource "aws_vpc" "dev-vpc" {
  cidr_block = var.vpc_cidr_block #CIDR range in variable
  enable_dns_support = true
  enable_dns_hostnames = true
  tags = {
    Environment = "Development"
    Name = "dev-vpc"
  }
}

########Creating Public Subnet############
resource "aws_subnet" "dev-subnet-public1-ap-south-1a" {
  vpc_id     = aws_vpc.terraform-vpc.id    #VPC ID range
  cidr_block = var.public_subnet_cidr_block
  availability_zone = "ap-south-1a" # Change to your desired availability zone
  map_public_ip_on_launch = true
  tags = {
    Name = "dev-subnet-public1-ap-south-1a"
  }
}

resource "aws_subnet" "dev-subnet-public2-ap-south-1b" {
  vpc_id     = aws_vpc.terraform-vpc.id
  cidr_block = var.public_subnet_cidr_block
  availability_zone = "ap-south-1b" # Change to your desired availability zone
  map_public_ip_on_launch = true
  tags = {
    Name = "dev-subnet-public2-ap-south-1b"
  }
}

resource "aws_subnet" "dev-subnet-public3-ap-south-1c" {
  vpc_id     = aws_vpc.terraform-vpc.id
  cidr_block = var.public_subnet_cidr_block
  availability_zone = "ap-south-1c" # Change to your desired availability zone
  map_public_ip_on_launch = true
  tags = {
    Name = "dev-subnet-public3-ap-south-1c"
  }
}

#########Creating Private Subnet############
resource "aws_subnet" "dev-subnet-private1-ap-south-1a" {
  vpc_id     = aws_vpc.terraform-vpc.id
  cidr_block = var.private_subnet_cidr_block
  availability_zone = "ap-south-1a" # Change to your desired availability zone
  tags = {
    Name = "dev-subnet-private1-ap-south-1a"
  }
}

resource "aws_subnet" "dev-subnet-private2-ap-south-1b" {
  vpc_id     = aws_vpc.terraform-vpc.id
  cidr_block = var.private_subnet_cidr_block
  availability_zone = "ap-south-1b" # Change to your desired availability zone
  tags = {
    Name = "dev-subnet-private2-ap-south-1b"
  }
}
resource "aws_subnet" "dev-subnet-private3-ap-south-1c" {
  vpc_id     = aws_vpc.terraform-vpc.id
  cidr_block = var.private_subnet_cidr_block
  availability_zone = "ap-south-1c" # Change to your desired availability zone
  tags = {
    Name = "dev-subnet-private3-ap-south-1c"
  }
}

resource "aws_subnet" "dev-subnet-private4-ap-south-1a" {
  vpc_id     = aws_vpc.terraform-vpc.id
  cidr_block = var.private_subnet_cidr_block
  availability_zone = "ap-south-1a" # Change to your desired availability zone
  tags = {
    Name = "dev-subnet-private4-ap-south-1a"
  }
}

resource "aws_subnet" "dev-subnet-private5-ap-south-1b" {
  vpc_id     = aws_vpc.terraform-vpc.id
  cidr_block = var.private_subnet_cidr_block
  availability_zone = "ap-south-1b" # Change to your desired availability zone
  tags = {
    Name = "dev-subnet-private5-ap-south-1b"
  }
}

resource "aws_subnet" "dev-subnet-private6-ap-south-1c" {
  vpc_id     = aws_vpc.terraform-vpc.id
  cidr_block = var.private_subnet_cidr_block
  availability_zone = "ap-south-1c" # Change to your desired availability zone
  tags = {
    Name = "dev-subnet-private6-ap-south-1c"
  }
}

resource "aws_subnet" "dev-subnet-private7-ap-south-1a" {
  vpc_id     = aws_vpc.terraform-vpc.id
  cidr_block = var.private_subnet_cidr_block
  availability_zone = "ap-south-1a" # Change to your desired availability zone
  tags = {
    Name = "dev-subnet-private7-ap-south-1a"
  }
}

resource "aws_subnet" "dev-subnet-private8-ap-south-1b" {
  vpc_id     = aws_vpc.terraform-vpc.id
  cidr_block = var.private_subnet_cidr_block
  availability_zone = "ap-south-1b" # Change to your desired availability zone
  tags = {
    Name = "ddev-subnet-private8-ap-south-1b"
  }
}

resource "aws_subnet" "dev-subnet-private9-ap-south-1a" {
  vpc_id     = aws_vpc.terraform-vpc.id
  cidr_block = var.private_subnet_cidr_block
  availability_zone = "ap-south-1c" # Change to your desired availability zone
  tags = {
    Name = "dev-subnet-private9-ap-south-1a"
  }
}

resource "aws_subnet" "dev-subnet-private10-ap-south-1a" {
  vpc_id     = aws_vpc.terraform-vpc.id
  cidr_block = var.private_subnet_cidr_block
  availability_zone = "ap-south-1a" # Change to your desired availability zone
  tags = {
    Name = "dev-subnet-private10-ap-south-1a"
  }
}

resource "aws_subnet" "dev-subnet-private11-ap-south-1b" {
  vpc_id     = aws_vpc.terraform-vpc.id
  cidr_block = var.private_subnet_cidr_block
  availability_zone = "ap-south-1b" # Change to your desired availability zone
  tags = {
    Name = "dev-subnet-private11-ap-south-1b"
  }
}

resource "aws_subnet" "dev-subnet-private12-ap-south-1c" {
  vpc_id     = aws_vpc.terraform-vpc.id
  cidr_block = var.private_subnet_cidr_block
  availability_zone = "ap-south-1c" # Change to your desired availability zone
  tags = {
    Name = "dev-subnet-private12-ap-south-1c"
  }
}

########Creating Transit Gateway Attachments###########
resource "aws_ec2_transit_gateway_vpc_attachment" "transit-gateway-attachment-development" {
  subnet_ids          = ["subnet-12345678", "subnet-23456789"] # Replace with your subnet IDs
  transit_gateway_id  = aws_ec2_transit_gateway.TransitGT.id
  vpc_id              = aws_vpc.terraform-vpc.id # Replace with your VPC ID
  dns_support         = "enable"
  ipv6_support        = "disable"
  appliance_mode_support = "enable"
}

########Creating NAT Gateway################
resource "aws_nat_gateway" "my_nat_gateway" {
  allocation_id = aws_eip.my_eip.id
  subnet_id    = aws_subnet.public_subnet.id
}

#########Creating an Elastic IP for the NAT Gateway###########
resource "aws_eip" "my_eip" {}


