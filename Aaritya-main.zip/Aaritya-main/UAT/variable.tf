# This file as Input Variables declared

#  variable for region
variable "aws_region" {
description = "Region"
type = string
default = "us-east-1"    #change the region wrt to reqiurement
}


# variable for OS disk of github runner instance
variable "os_disk" {
description = "EC2 OS Disk in terms of numbers ex:20gb --> 20"
type = number
default = "15"
}

# variable for OS disk type for github runner
variable "os_disk_type" {
description = "Enter the type of OS disk --> gp2, gp3"
type = string
default = "gp3"
}

# variable for declaring the enviroment
variable "environment" {
    description = "enter the environment type"
    type = string
    default = "dev"
}

