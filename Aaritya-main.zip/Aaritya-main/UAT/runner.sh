## This script contains the execution steps for the github runner  ## 

!/bin/bash
chmod +x "$0"                       # Ensure the script itself is always executable
mkdir actions-runner; cd actions-runner
curl -o actions-runner-linux-x64-2.311.0.tar.gz -L https://github.com/actions/runner/releases/download/v2.311.0/actions-runner-linux-x64-2.311.0.tar.gz
echo "29fc8cf2dab4c195bb147384e7e2c94cfd4d4022c793b346a6175435265aa278  actions-runner-linux-x64-2.311.0.tar.gz" | shasum -a 256 -c
./config.sh --url https://github.com/jagadishgowda1/deploy-to-eks-using-github-actions-new --token A6QYFY763JKSITJLGA5P6STFK43QU
tar xzf ./actions-runner-linux-x64-2.311.0.tar.gz
./config.sh --url https://github.com/RedingtonGroup/Aaritya --token A6QYFYYGGRDTW4AKRD5E5VTFMX4IE
./run.sh
./svc.sh install
./svc.sh start