#### This file consists of configuration for githubrunner ####

resource "aws_instance" "aws_instance_githubrunner" {
    ami = "ami-0a7cf821b91bcccbc"
    instance_type = "t2.micro"
    #key_name = "tf-key"

    root_block_device {
        volume_size          = var.os_disk
        encrypted            = true
        delete_on_termination = true
        volume_type          = var.os_disk_type
    }
  
    tags = {
        Name        = "${var.environment}-server-1"
        Created-by  = "Terraform_Automation"
        Created-time = timestamp()
    }

    connection {
        type        = "ssh"
        user        = "ubuntu"  # Update with the appropriate username for your AMI
        private_key = file("tf-key")  # Update with the path to your private key
        host        = self.public_ip  # Replace with your specific method to fetch the public IP of the instance
    }

    provisioner "file" {
        source      = "runner.sh"  # Replace with the actual path to your runner.sh script
        destination = "/home/ubutu/runner.sh"           # Destination path on the EC2 instance
    }

    provisioner "remote-exec" {
        inline = [
            "chmod +x /home/ubutu/runner.sh",  # Make the script executable
            "/home/ubutu/runner.sh"            # Execute the script
        ]
    }
}
