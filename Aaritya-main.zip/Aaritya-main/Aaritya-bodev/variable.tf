# --------------------------------------------------------------- #
  # this configuration file contains variable declared for all resources in this projects
# --------------------------------------------------------------- # 


#variable for region
variable "aws_region" {
    description = "Enter the region"
    type = string
    default = "ap-south-1"      # enter the value according to your requirement
}
#variable for region for replication
variable "aws_replication_region" {
    description = "Enter the region"
    type = string
    default = "ap-south-2"      # enter the value according to your requirement
}

#variable for IAM role replication
variable "replication_role_arn" {
  description = "The name of the IAM role created for replication"
  type        = string
  default     = "arn:aws:iam::433957317038:role/s3replicationcrs"
}

#variable for CIDR range for VPC
variable "aws_vpc" {
    description = "Enter the VPC CIDR range"
    type = string
    default="172.16.28.0/22"     # enter the CIDR range value according to your requirement
}


#variable for availability zone1
variable "aws_availability_zone1" {
    description = "Enter the availabilty zone"
    type = string
    default = "ap-south-1a"
}

#variable for availability zone2
variable "aws_availability_zone2" {
    description = "Enter the availabilty zone"
    type = string
    default = "ap-south-1b"
}

#variable for network firewall subnet
variable "networkfirewall_subnet" {
    description = "Enter the network firewall subnet range"
    type = string
    default = "172.16.28.0/27"   # enter the subnet range value according to your requirement
}

#variable for public subnet
variable "PublicSubnet" {
    description = "Enter the subnet range"
    type = string
    default = "172.16.28.64/26"  # enter the subnet range value according to your requirement
  
}

#variable for dev private subnet in AZ-1a
variable "Subnet_Dev_Private_1" {
  description = "Enter the subnet range"
    type = string
    default = "172.16.28.128/25"   # enter the subnet range value according to your requirement
}

#variable for dev private subnet in AZ-1b
variable "Subnet_Dev_Private_2" {
  description = "Enter the subnet range"
    type = string
    default = "172.16.29.0/25"    # enter the subnet range value according to your requirement
}

#variable for prod private subnet in AZ-1a
variable "Subnet_Prod_Private_1" {
  description = "Enter the subnet range"
    type = string
    default = "172.16.29.128/25"   # enter the subnet range value according to your requirement
}

#variable for prod private subnet in AZ-1b
variable "Subnet_Prod_Private_2" {
  description = "Enter the subnet range"
    type = string
    default = "172.16.30.0/25"      # enter the subnet range value according to your requirement
}

#variable for adding static routes
variable "static_routes" {
  description = "Enter the static routes"
  type = list(string)
  default = ["192.168.2.0/24","192.168.0.0/24"]
}

#creating variable for ec2_bastion key pair
variable "bastion_key" {
  description = "Enter the Key pair name"
  type = string
  default = "bastion_key.pem"       #create keypair with required name
}

#creating variable for os disk for bastion host
variable "bastion_os_disk" {
  description = "Enter the os disk size"   #EC2 OS Disk in terms of numbers ex:20gb --> 20
  type = number
  default = "20"
}


#creating variable for ec2_ssl_vpn key pair
variable "ssl_vpn_key" {
  description = "Enter the Key pair name"
  type = string
  default = "ssl_vpn_key.pem"   #create keypair with required name
}

#creating variable for os disk for ec2_ssl_vpn
variable "sslvpn_os_disk" {
  description = "Enter the os disk size"   #EC2 OS Disk in terms of numbers ex:20gb --> 20
  type = number
  default = "20"
}
#--------------------------------------------------------------------------#
#creating key pair, os disk and data disk for solman server
#--------------------------------------------------------------------------#
#creating variable for ec2_solman key pair
variable "solman_key" {
  description = "Enter the Key pair name"
  type = string
  default = "solman_key.pem"   #create keypair with required name
}

#creating variable for os disk for ec2_solman
variable "solman_os_disk" {
  description = "Enter the os disk size"   #EC2 OS Disk in terms of numbers ex:20gb --> 20
  type = number
  default = "100"
}

#creating variable for data disk for ec2_solman
variable "solman_data_disk" {
  description = "Enter the data disk size"   #EC2 data Disk in terms of numbers ex:20gb --> 20
  type = number
  default = "840"
}

#--------------------------------------------------------------------------#
#creating key pair, os disk and data disk for sandbox server
#--------------------------------------------------------------------------#
#creating variable for ec2_sandbox key pair
variable "sandbox_key" {
  description = "Enter the Key pair name"
  type = string
  default = "sandbox_key.pem"   #create keypair with required name
}

#creating variable for os disk for ec2_sandbox
variable "sandbox_os_disk" {
  description = "Enter the os disk size"   #EC2 OS Disk in terms of numbers ex:20gb --> 20
  type = number
  default = "80"
}

#creating variable for data disk for ec2_sandbox
variable "sandbox_data_disk" {
  description = "Enter the data disk size"   #EC2 data Disk in terms of numbers ex:20gb --> 20
  type = number
  default = "3530"
}

#--------------------------------------------------------------------------#
#creating key pair, os disk and data disk for eccdev server
#--------------------------------------------------------------------------#
#creating variable for ec2_eccdev key pair
variable "eccdev_key" {
  description = "Enter the Key pair name"
  type = string
  default = "eccdev_key.pem"   #create keypair with required name
}

#creating variable for os disk for ec2_eccdev
variable "eccdev_os_disk" {
  description = "Enter the os disk size"   #EC2 OS Disk in terms of numbers ex:20gb --> 20
  type = number
  default = "80"
}

#creating variable for data disk for ec2_eccdev
variable "eccdev_data_disk" {
  description = "Enter the data disk size"   #EC2 data Disk in terms of numbers ex:20gb --> 20
  type = number
  default = "1024"
}

#--------------------------------------------------------------------------#
#creating key pair, os disk and data disk for BWDEV server
#--------------------------------------------------------------------------#
#creating variable for ec2_bwdev key pair
variable "bwdev_key" {
  description = "Enter the Key pair name"
  type = string
  default = "bwdev_key.pem"   #create keypair with required name
}

#creating variable for os disk for ec2_bwdev
variable "bwdev_os_disk" {
  description = "Enter the os disk size"   #EC2 OS Disk in terms of numbers ex:20gb --> 20
  type = number
  default = "80"
}

#creating variable for data disk for ec2_bwdev
variable "bwdev_data_disk_1" {
  description = "Enter the data disk size"   #EC2 data Disk in terms of numbers ex:20gb --> 20
  type = number
  default = "50"
  }


#--------------------------------------------------------------------------#
#creating key pair, os disk and data disk for PODEV server
#--------------------------------------------------------------------------#
#creating variable for ec2_podev key pair
variable "podev_key" {
  description = "Enter the Key pair name"
  type = string
  default = "podev_key.pem"   #create keypair with required name
}

#creating variable for os disk for ec2_podev
variable "podev_os_disk" {
  description = "Enter the os disk size"   #EC2 OS Disk in terms of numbers ex:20gb --> 20
  type = number
  default = "80"
}

#creating variable for data disk for ec2_podev
variable "podev_data_disk" {
  description = "Enter the data disk size"   #EC2 data Disk in terms of numbers ex:20gb --> 20
  type = number
  default = "320"
}

#--------------------------------------------------------------------------#
#creating key pair, os disk and data disk for BODEV server
#--------------------------------------------------------------------------#
#creating variable for ec2_bodev key pair
variable "bodev_key" {
  description = "Enter the Key pair name"
  type = string
  default = "bodev_key.pem"   #create keypair with required name
}

#creating variable for os disk for ec2_bodev
variable "bodev_os_disk" {
  description = "Enter the os disk size"   #EC2 OS Disk in terms of numbers ex:20gb --> 20
  type = number
  default = "80"
}

#creating variable for data disk for ec2_bodev
variable "bodev_data_disk" {
  description = "Enter the data disk size"   #EC2 data Disk in terms of numbers ex:20gb --> 20
  type = number
  default = "230"
}

#--------------PRODUCTION SERVERS---------------------------------------#
#-----------------------------------------------------------------------#
#creating key pair, os disk and data disk for ECCPRD server
#--------------------------------------------------------------------------#
#creating variable for ec2_eccprd key pair
variable "eccprd_key" {
  description = "Enter the Key pair name"
  type = string
  default = "eccprd_key.pem"   #create keypair with required name
}

#creating variable for os disk for ec2_eccprd
variable "eccprd_os_disk" {
  description = "Enter the os disk size"   #EC2 OS Disk in terms of numbers ex:20gb --> 20
  type = number
  default = "100"
}

#creating variable for data disk for ec2_eccprd
variable "eccprd_data_disk1" {
  description = "Enter the data disk size"   #EC2 data Disk in terms of numbers ex:20gb --> 20
  type = number
  default = "3240"
}

#creating variable for data disk for ec2_eccprd
variable "eccprd_data_disk2" {
  description = "Enter the data disk size"   #EC2 data Disk in terms of numbers ex:20gb --> 20
  type = number
  default = "200"
}

#--------------------------------------------------------------------------#
#creating key pair, os disk and data disk for BWPRD server
#--------------------------------------------------------------------------#
#creating variable for ec2_bwprd key pair
variable "bwprd_key" {
  description = "Enter the Key pair name"
  type = string
  default = "bwprd_key.pem"   #create keypair with required name
}

#creating variable for os disk for ec2_bwprd
variable "bwprd_os_disk" {
  description = "Enter the os disk size"   #EC2 OS Disk in terms of numbers ex:20gb --> 20
  type = number
  default = "100"
}

#creating variable for data disk for ec2_bwprd
variable "bwprd_data_disk" {
  description = "Enter the data disk size"   #EC2 data Disk in terms of numbers ex:20gb --> 20
  type = number
  default = "1160"
}

#--------------------------------------------------------------------------#
#creating key pair, os disk and data disk for POPRD server
#--------------------------------------------------------------------------#
#creating variable for ec2_poprd key pair
variable "poprd_key" {
  description = "Enter the Key pair name"
  type = string
  default = "poprd_key.pem"   #create keypair with required name
}

#creating variable for os disk for ec2_poprd
variable "poprd_os_disk" {
  description = "Enter the os disk size"   #EC2 OS Disk in terms of numbers ex:20gb --> 20
  type = number
  default = "100"
}

#creating variable for data disk for ec2_poprd
variable "poprd_data_disk" {
  description = "Enter the data disk size"   #EC2 data Disk in terms of numbers ex:20gb --> 20
  type = number
  default = "640"
}

#--------------------------------------------------------------------------#
#creating key pair, os disk and data disk for BOPRD server
#--------------------------------------------------------------------------#
#creating variable for ec2_bwprd key pair
variable "boprd_key" {
  description = "Enter the Key pair name"
  type = string
  default = "boprd_key.pem"   #create keypair with required name
}

#creating variable for os disk for ec2_boprd
variable "boprd_os_disk" {
  description = "Enter the os disk size"   #EC2 OS Disk in terms of numbers ex:20gb --> 20
  type = number
  default = "100"
}

#creating variable for data disk for ec2_boprd
variable "boprd_data_disk" {
  description = "Enter the data disk size"   #EC2 data Disk in terms of numbers ex:20gb --> 20
  type = number
  default = "290"
}

#--------------------------------------------------------------------------#
#creating key pair, os disk and data disk for WSAPP server
#--------------------------------------------------------------------------#
#creating variable for ec2_wsapp key pair
variable "wsapp_key" {
  description = "Enter the Key pair name"
  type = string
  default = "wsapp_key.pem"   #create keypair with required name
}

#creating variable for os disk for ec2_wsapp
variable "wsapp_os_disk" {
  description = "Enter the os disk size"   #EC2 OS Disk in terms of numbers ex:20gb --> 20
  type = number
  default = "100"
}

#creating variable for data disk for ec2_wsapp
variable "wsapp_data_disk" {
  description = "Enter the data disk size"   #EC2 data Disk in terms of numbers ex:20gb --> 20
  type = number
  default = "180"
}

#--------------------------------------------------------------------------#
#creating key pair, os disk and data disk for WSDB server
#--------------------------------------------------------------------------#
#creating variable for ec2_wsdb key pair
variable "wsdb_key" {
  description = "Enter the Key pair name"
  type = string
  default = "wsdb_key.pem"   #create keypair with required name
}

#creating variable for os disk for ec2_boprd
variable "wsdb_os_disk" {
  description = "Enter the os disk size"   #EC2 OS Disk in terms of numbers ex:20gb --> 20
  type = number
  default = "100"
}

#creating variable for data disk for ec2_boprd
variable "wsdb_data_disk1" {
  description = "Enter the data disk size"   #EC2 data Disk in terms of numbers ex:20gb --> 20
  type = number
  default = "1100"
}

variable "wsdb_data_disk2" {
  description = "Enter the data disk size"   #EC2 data Disk in terms of numbers ex:20gb --> 20
  type = number
  default = "1000"
}

#--------------------------------------------------------------------------#
#creating key pair, os disk and data disk for legatrix server
#--------------------------------------------------------------------------#
#creating variable for ec2_legatrix key pair
variable "legatrix_key" {
  description = "Enter the Key pair name"
  type = string
  default = "legatrix_key.pem"   #create keypair with required name
}

#creating variable for os disk for ec2_legatrix
variable "legatrix_os_disk" {
  description = "Enter the os disk size"   #EC2 OS Disk in terms of numbers ex:20gb --> 20
  type = number
  default = "100"
}

#creating variable for data disk for ec2_legatrix
variable "legatrix_data_disk_1" {
  description = "Enter the data disk size"   #EC2 data Disk in terms of numbers ex:20gb --> 20
  type = number
  default = "150"
}

#creating variable for data disk for ec2_legatrix
variable "legatrix_data_disk_2" {
  description = "Enter the data disk size"   #EC2 data Disk in terms of numbers ex:20gb --> 20
  type = number
  default = "300"
}

#------------------------------------------------------------------------#
#---------------------------S3 BUCKET CREATION---------------------------#
#------------------------------------------------------------------------#

#variable for S3 bucket for the db backup purpose 
variable "bucket_db_bkp" {
  description = "Enter the bucket name"   
  type = string
  default = "test-bkp-rst-07032024"
}

#variable for S3 bucket for the db backup migration 
variable "bucket_database_bkp" {
  description = "Enter the bucket name"   
  type = string
  default = "database-migration-08032024"
}

#variable for S3 bucket for the db log backup 
variable "bucket_development_efs_bkp" {
  description = "Enter the bucket name"   
  type = string
  default = "bkp-efs-development"
}

#variable for S3 bucket for the db log backup 
variable "bucket_production_efs_bkp" {
  description = "Enter the bucket name"   
  type = string
  default = "bkp-efs-production"
}

#variable for DB backup
variable "bucket_production_DB_backup" {
  description = "Enter the bucket name"   
  type = string
  default = "bkp-db-production-25042024"
}

#variable for Legatrix_DB backup
variable "bucket_legatrix_DB_backup" {
  description = "Enter the bucket name"   
  type = string
  default = "bkp-db-production-legatrix"
}


#Replication bucket bkp-efs-production
variable "bucket_production_efs_bkp_crr_replication" {
  description = "Enter the bucket name"   
  type = string
  default = "bkp-efs-production-crr"
}

#Replication bucket bkp-db-production-25042024

variable "bucket_bkp-db-production-25042024" {
  description = "Enter the bucket name"   
  type = string
  default = "bkp-db-production-25042024-crr"
}