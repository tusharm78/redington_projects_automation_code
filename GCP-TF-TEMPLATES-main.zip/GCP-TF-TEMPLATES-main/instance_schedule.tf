module "compute_schedule" {
  source = "./modules/compute_schedule"
  vm_schedules = var.vm_schedules
}
# Example attaching one schedule to a VM
resource "google_compute_instance" "vm1" {
  name         = "vm1"
  machine_type = "e2-micro"
  zone         = var.zone
 
  boot_disk {
    initialize_params {
      image = "debian-cloud/debian-11"
    }
  }
 
  network_interface {
    network       = "default"
    access_config {}
  }
 
  resource_policies = [module.compute_schedule.vm_schedule_policies["vm1"].id]
   
  tags = ["vm1"]
}

