variable "project_id" {
  description = "The GCP project ID"
  type        = string
}

variable "region" {
  description = "The GCP region"
  type        = string
}

variable "credentials_file" {
  description = "Path to the service account JSON key file"
  type        = string
  default     = "" #add the credentials.json path from the local C:Gcp/terraform/module/credentials.json
}

variable "l1_users" {
  description = "List of L1 user emails"
  type        = list(string)
}

variable "l2_users" {
  description = "List of L2 user emails"
  type        = list(string)
}

variable "l3_users" {
  description = "List of L3 user emails"
  type        = list(string)
}

variable "l4_users" {
  description = "List of L4 user emails"
  type        = list(string)
}

variable "vpc_configs" {
  description = "Map of VPCs and their subnet configurations"
  type = map(object({
    vpc_name = string
    subnets = list(object({
      name   = string
      cidr   = string
      region = string
    }))
  }))
}

variable "vm_configs" {
  description = "VM configurations"
  type = map(object({
    name         = string
    machine_type = string
    zone         = string
    subnetwork   = string
    image        = string
    disk_size    = number
  }))
}

variable "buckets_config" {
  description = "Map of GCS bucket configurations"
  type = map(object({
    name         = string
    location     = string
    storage_class = string
    versioning    = bool
    uniform_bucket_level_access = bool

  }))
}

variable "snapshot_schedules" {
  description = "Map of snapshot schedules and their configurations"
  type = map(object({
    name                  = string
    region                = string
    description           = string
    days_in_cycle         = number
    start_time            = string
    retention_days        = number
    on_source_disk_delete = string
    labels                = map(string)
    storage_locations     = list(string)
  }))
}

variable "disk_attachments" {
  description = "Map of disks and their assigned snapshot schedules"
  type = map(object({
    disk_name    = string
    zone         = string
    schedule_key = string
  }))
}

variable "zone" {
  description = "Zone for compute instances"
  type        = string
  default     = "asia-south1-a"
}

variable "vm_schedules" {
  description = "Schedules for VM start and stop"
  type = map(object({
    name           = string
    region         = string
    description    = string
    start_schedule = string
    stop_schedule  = string
    time_zone      = string
  }))
}

# # --------------------------------------------------
# # Variable Block for Cloud SQL
# # --------------------------------------------------

variable "cloudsql_name" {
  type    = string
  default = "my-postgres-public"
}

variable "cloudsql_database_version" {
  type    = string
  default = "POSTGRES_15"
}

variable "cloudsql_tier" {
  type    = string
  default = "db-f1-micro"
}

variable "cloudsql_disk_size" {
  type    = number
  default = 10
}

variable "cloudsql_disk_type" {
  type    = string
  default = "PD_SSD"
}

variable "cloudsql_auto_storage_increase" {
  type    = bool
  default = true
}

variable "cloudsql_backup_enabled" {
  type    = bool
  default = true
}

variable "cloudsql_backup_start_time" {
  type    = string
  default = "03:00"
}

variable "cloudsql_maintenance_day" {
  type    = number
  default = 7
}

variable "cloudsql_maintenance_hour" {
  type    = number
  default = 4
}

variable "cloudsql_database_name" {
  type    = string
  default = "appdb"
}

variable "cloudsql_db_user" {
  type    = string
  default = "dbuser"
}

variable "cloudsql_db_password" {
  type      = string
  sensitive = true
}

variable "cloudsql_root_password" {
  type      = string
  sensitive = true
  default   = ""
}

variable "cloudsql_authorized_networks" {
  description = "Public authorized networks"
  type = list(object({
    name  = string
    value = string
  }))
  default = []
}

variable "cloudsql_labels" {
  type    = map(string)
  default = {}
}

#variable for Artifact Registry

variable "repository_id" {
  description = "Artifact Registry repository name"
  type        = string
}

variable "description" {
  description = "Description of the repository"
  type        = string
  default     = "Docker repository for container images"
}

# Cloud Run

variable "service_name" {
  description = "Name of the Cloud Run service"
  type        = string
}

variable "image" {
  description = "Container image URL for Cloud Run"
  type        = string
}

# - HPPTS Load Balancer

variable "lb_name" {
  description = "Name of the Load Balancer"
  type        = string
}

variable "domain_name" {
  description = "Domain name for SSL cert"
  type        = string
}

variable "backend_service" {
  description = "Backend service URL or resource (e.g., Cloud Run service URL)"
  type        = string
}
