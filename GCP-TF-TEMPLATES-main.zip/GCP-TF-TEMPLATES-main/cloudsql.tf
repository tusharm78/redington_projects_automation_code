# module "cloudsql" {
#   source = "./modules/cloudsql"

#   project               = var.project
#   region                = var.region
#   name                  = var.cloudsql_name
#   database_version      = var.cloudsql_database_version
#   tier                  = var.cloudsql_tier
#   disk_size             = var.cloudsql_disk_size
#   disk_type             = var.cloudsql_disk_type
#   auto_storage_increase = var.cloudsql_auto_storage_increase

#   backup_enabled          = var.cloudsql_backup_enabled
#   backup_start_time       = var.cloudsql_backup_start_time
#   maintenance_window_day  = var.cloudsql_maintenance_day
#   maintenance_window_hour = var.cloudsql_maintenance_hour

#   database_name = var.cloudsql_database_name
#   db_user       = var.cloudsql_db_user
#   db_password   = var.cloudsql_db_password
#   root_password = var.cloudsql_root_password

#   authorized_networks = var.cloudsql_authorized_networks
#   labels              = var.cloudsql_labels
# }
