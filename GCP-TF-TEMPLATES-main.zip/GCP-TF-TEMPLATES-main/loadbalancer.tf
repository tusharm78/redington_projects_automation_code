module "loadbalancer" {
  source                = "./modules/loadbalancer"
  project_id            = var.project_id
  lb_name               = var.lb_name
  region                = var.region
  domain_name           = var.domain_name
  cloud_run_service_name = var.service_name  # Use the same name as your Cloud Run service
}
