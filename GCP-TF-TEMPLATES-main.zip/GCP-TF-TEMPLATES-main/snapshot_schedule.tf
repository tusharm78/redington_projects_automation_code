locals {
  project_snapshot = var.project_id
}

module "snapshot_schedule" {
  source = "./modules/snapshot_schedule"
  
  snapshot_schedules = var.snapshot_schedules
  disk_attachments   = var.disk_attachments
  
}

output "snapshot_policy_ids" {
  value = module.snapshot_schedule.snapshot_policy_ids
}

output "attachments" {
  value = module.snapshot_schedule.attachments
}
