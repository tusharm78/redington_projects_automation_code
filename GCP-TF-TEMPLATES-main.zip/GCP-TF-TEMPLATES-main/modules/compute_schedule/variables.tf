variable "vm_schedules" {
  description = "Map of VM schedules with start/stop times"
  type = map(object({
    name            = string
    region          = string
    description     = string
    start_schedule  = string
    stop_schedule   = string
    time_zone       = string
  }))
}

