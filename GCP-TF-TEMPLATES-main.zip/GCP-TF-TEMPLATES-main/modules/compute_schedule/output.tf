output "vm_schedule_policies" {
  value = google_compute_resource_policy.vm_schedule
}