resource "google_compute_resource_policy" "vm_schedule" {
  for_each = var.vm_schedules

  name        = each.value.name
  region      = each.value.region
  description = each.value.description

  instance_schedule_policy {
    vm_start_schedule {
      schedule = each.value.start_schedule
    }

    vm_stop_schedule {
      schedule = each.value.stop_schedule
    }

    time_zone = each.value.time_zone
  }
}


