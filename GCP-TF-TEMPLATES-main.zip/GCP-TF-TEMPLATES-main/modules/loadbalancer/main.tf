# Reserve a global IP
resource "google_compute_global_address" "default" {
  name    = "${var.lb_name}-ip"
  project = var.project_id
}

# SSL certificate (optional)
resource "google_compute_managed_ssl_certificate" "default" {
  name    = "${var.lb_name}-cert"
  project = var.project_id

  managed {
    domains = [var.domain_name]
  }
}

# Create a Serverless NEG for Cloud Run
resource "google_compute_region_network_endpoint_group" "cloudrun_neg" {
  name                  = "${var.lb_name}-neg"
  project               = var.project_id
  region                = var.region
  network_endpoint_type = "SERVERLESS"

  cloud_run {
    service = var.cloud_run_service_name
  }
}

# Backend service that references the NEG
resource "google_compute_backend_service" "default" {
  name                  = "${var.lb_name}-backend"
  project               = var.project_id
  protocol              = "HTTP"
  load_balancing_scheme = "EXTERNAL_MANAGED"

  backend {
    group = google_compute_region_network_endpoint_group.cloudrun_neg.id
  }
}

# URL map
resource "google_compute_url_map" "default" {
  name            = "${var.lb_name}-url-map"
  default_service = google_compute_backend_service.default.id
  project         = var.project_id
}

# HTTPS proxy
resource "google_compute_target_https_proxy" "default" {
  name             = "${var.lb_name}-https-proxy"
  url_map          = google_compute_url_map.default.id
  ssl_certificates = [google_compute_managed_ssl_certificate.default.id]
  project          = var.project_id
}

# Forwarding rule
resource "google_compute_global_forwarding_rule" "default" {
  name        = "${var.lb_name}-https-rule"
  target      = google_compute_target_https_proxy.default.id
  port_range  = "443"
  ip_address  = google_compute_global_address.default.address
  project     = var.project_id
}

# output "lb_ip" {
#   description = "Public IP of the Load Balancer"
#   value       = google_compute_global_address.default.address
# }
