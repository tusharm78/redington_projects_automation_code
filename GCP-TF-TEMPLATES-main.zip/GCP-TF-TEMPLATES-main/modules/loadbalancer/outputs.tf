output "lb_ip" {
  description = "Public IP of the Load Balancer"
  value       = google_compute_global_address.default.address
}
