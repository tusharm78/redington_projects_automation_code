variable "project_id" {
  description = "Project ID where resources will be created"
  type        = string
}

variable "lb_name" {
  description = "Name prefix for the Load Balancer"
  type        = string
}

variable "region" {
  description = "Region for regional resources like NEG"
  type        = string
}

variable "domain_name" {
  description = "Domain name for managed SSL certificate"
  type        = string
}

variable "cloud_run_service_name" {
  description = "Name of the Cloud Run service to attach to the load balancer"
  type        = string
}
