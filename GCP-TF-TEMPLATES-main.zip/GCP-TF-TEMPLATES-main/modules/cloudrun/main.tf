resource "google_cloud_run_service"  {
  name     = var.service_name
  location = var.region
  project  = var.project_id

  template {
    spec {
      containers {
        image = var.image
      }
    }
  }

  traffic {
    percent         = 100
    latest_revision = true
  }
}

# Allow unauthenticated access (public Cloud Run)
resource "google_cloud_run_service_iam_member" "public_access" {
  service  = google_cloud_run_service.this.name
  location = var.region
  project  = var.project_id
  role     = "roles/run.invoker"
  member   = "allUsers"
}
