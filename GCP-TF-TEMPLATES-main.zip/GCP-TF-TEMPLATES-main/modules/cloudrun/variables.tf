variable "project_id" {
  description = "Project ID where Cloud Run will be deployed"
  type        = string
}

variable "region" {
  description = "Region for Cloud Run service"
  type        = string
}

variable "service_name" {
  description = "Name of the Cloud Run service"
  type        = string
}

variable "image" {
  description = "Container image URL (example: gcr.io/my-project/myapp:latest)"
  type        = string
}
