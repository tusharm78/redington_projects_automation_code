variable "vpc_name" {
  description = "Name of the VPC"
  type        = string
}
variable "project_id" {
  description = "GCP project ID"
  type        = string
}

variable "subnets" {
  description = "List of subnets for the VPC"
  type = list(object({
    name   = string
    cidr   = string
    region = string
  }))
}
