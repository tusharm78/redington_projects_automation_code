output "vpc_id" {
  value = google_compute_network.vpc.id
}

output "subnet_ids" {
  value = { for k, v in google_compute_subnetwork.subnets : k => v.id }
}

output "subnets" {
  description = "Map of subnet self_links by name"
  value = {
    for k, s in google_compute_subnetwork.subnets :
    k => s.self_link
  }
}
