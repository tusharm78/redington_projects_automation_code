variable "name" {
  description = "The name of the GCS bucket."
  type        = string
}

variable "project" {
  description = "The GCP project ID where the bucket will be created."
  type        = string
}

variable "location" {
  description = "The location for the bucket."
  type        = string
}

variable "storage_class" {
  description = "The storage class of the bucket."
  type        = string
}

variable "uniform_bucket_level_access" {
  description = "Enable uniform bucket-level access."
  type        = bool
}

variable "versioning" {
  description = "Enable versioning on the bucket."
  type        = bool
}

variable "force_destroy" {
  description = "Force delete even if bucket contains objects."
  type        = bool
}
