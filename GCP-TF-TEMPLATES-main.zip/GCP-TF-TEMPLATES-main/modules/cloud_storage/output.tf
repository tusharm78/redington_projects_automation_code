output "bucket_name" {
  value = google_storage_bucket.gcs_buckets.name
}

output "bucket_url" {
  value = google_storage_bucket.gcs_buckets.url
}
