resource "google_storage_bucket" "gcs_buckets" {
  name                        = var.name
  location                    = var.location
  project                     = var.project
  storage_class               = var.storage_class
  uniform_bucket_level_access = var.uniform_bucket_level_access

  versioning {
    enabled = var.versioning
  }

  force_destroy = var.force_destroy
}
