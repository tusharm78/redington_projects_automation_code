variable "snapshot_schedules" {
  description = "Map of snapshot schedule configurations"
  type = map(object({
    name                  = string
    region                = string
    description           = string
    days_in_cycle         = number
    start_time            = string
    retention_days        = number
    on_source_disk_delete = string
    labels                = map(string)
    storage_locations     = list(string)
  }))
}

variable "disk_attachments" {
  description = "Map of disk-to-snapshot-schedule attachments"
  type = map(object({
    disk_name    = string
    zone         = string
    schedule_key = string
  }))
}
