output "snapshot_policy_ids" {
  value = { for k, v in google_compute_resource_policy.snapshot_schedule : k => v.id }
}

output "attachments" {
  value = google_compute_disk_resource_policy_attachment.attached
}
