# Create snapshot schedules
resource "google_compute_resource_policy" "snapshot_schedule" {
  for_each = var.snapshot_schedules

  name        = each.value.name
  region      = each.value.region
  description = each.value.description

  snapshot_schedule_policy {
    schedule {
      daily_schedule {
        days_in_cycle = each.value.days_in_cycle
        start_time    = each.value.start_time
      }
    }

    retention_policy {
      max_retention_days    = each.value.retention_days
      on_source_disk_delete = each.value.on_source_disk_delete
    }

    snapshot_properties {
      labels            = each.value.labels
      storage_locations = each.value.storage_locations
    }
  }
}

# Attach disks to their snapshot schedules
resource "google_compute_disk_resource_policy_attachment" "attached" {
  for_each = var.disk_attachments

  name = google_compute_resource_policy.snapshot_schedule[each.value.schedule_key].name
  disk = each.value.disk_name
  zone = each.value.zone
  depends_on = [google_compute_resource_policy.snapshot_schedule]
}
