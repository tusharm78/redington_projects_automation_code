variable "project_id" {
  description = "GCP project ID"
  type        = string
}

variable "role_id" {
  type = string
}

variable "role_title" {
  type = string
}

variable "role_stage" {
  type = string
}

variable "users" {
  type = list(string)
}
variable "predefined" {
  type = bool
}
variable "custom_permissions" {
  type    = list(string)
  default = []
}
variable "role_name" {
  type    = string
  default = ""
}
