# output "iam_bindings" {
#   value = {
#     L1 = var.l1_users
#     L2 = var.l2_users
#     L3 = var.l3_users
#     L4 = var.l4_users
#   }
# }