# # --------------------------------------------------
# # Custom IAM Role
# # --------------------------------------------------
resource "google_project_iam_custom_role" "custom_role" {
  count       = var.predefined ? 0 : 1
  role_id     = var.role_id
  title       = var.role_title
  description = "Custom IAM Role for ${var.role_title}"
  stage       = var.role_stage
  permissions = var.custom_permissions
}

# # --------------------------------------------------
# # Bind Custom Role to Users
# # --------------------------------------------------
resource "google_project_iam_member" "binding" {
  for_each = toset(var.users)
  project  = var.project_id
  role     = var.predefined ? var.role_name : "projects/${var.project_id}/roles/${var.role_id}"
  member   = "user:${each.value}"
}