output "vm_names" {
  value = [for vm in google_compute_instance.vms : vm.name]
}

output "vm_ips" {
  value = { for k, vm in google_compute_instance.vms : k => vm.network_interface[0].access_config[0].nat_ip }
}
