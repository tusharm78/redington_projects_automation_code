variable "project_id" {
  description = "GCP project ID"
  type        = string
}

variable "vm_configs" {
  description = "Map of VM configurations"
  type = map(object({
    name         = string
    machine_type = string
    zone         = string
    image        = string
    disk_size    = number
    subnetwork   = string
  }))
}

variable "subnet_map" {
  type = map(string) # maps subnet keys to real self_link
}
