locals {
  project = var.project_id
}

resource "google_compute_instance" "vms" {

  for_each     = var.vm_configs
  project      = local.project
  name         = each.value.name
  machine_type = each.value.machine_type
  zone         = each.value.zone

  boot_disk {
    initialize_params {
      image = each.value.image
      size  = each.value.disk_size
    }
  }

  network_interface {
    subnetwork = var.subnet_map[each.value.subnetwork]
    access_config {}
  }

  tags = ["vm"]
}
