output "instance_name" {
  value = google_sql_database_instance.postgres.name
}

output "instance_connection_name" {
  description = "Connection name (project:region:instance)"
  value       = google_sql_database_instance.postgres.connection_name
}

output "public_ip" {
  description = "Public IPv4 address of the instance"
  value       = try(google_sql_database_instance.postgres.ip_address[0].ip_address, "")
}

output "database_name" {
  value = google_sql_database.default.name
}

output "db_user" {
  value = google_sql_user.db_user.name
}
