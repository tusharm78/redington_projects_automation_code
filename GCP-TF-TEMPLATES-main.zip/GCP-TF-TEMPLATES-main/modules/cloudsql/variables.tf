variable "project" {
  description = "GCP project ID"
  type        = string
}

variable "region" {
  description = "GCP region for the Cloud SQL instance"
  type        = string
  default     = "asia-south1"
}

variable "name" {
  description = "Cloud SQL instance name"
  type        = string
  default     = "postgres-instance"
}

variable "database_version" {
  description = "Postgres version (e.g. POSTGRES_15)"
  type        = string
  default     = "POSTGRES_15"
}

variable "tier" {
  description = "Machine type (e.g. db-f1-micro, db-g1-small)"
  type        = string
  default     = "db-f1-micro"
}

variable "disk_size" {
  description = "Disk size in GB"
  type        = number
  default     = 10
}

variable "disk_type" {
  description = "Disk type: PD_SSD or PD_HDD"
  type        = string
  default     = "PD_SSD"
}

variable "auto_storage_increase" {
  description = "Enable automatic storage increase"
  type        = bool
  default     = true
}

variable "backup_enabled" {
  description = "Enable automated backups"
  type        = bool
  default     = true
}

variable "backup_start_time" {
  description = "Backup start time (UTC, HH:MM)"
  type        = string
  default     = "03:00"
}

variable "maintenance_window_day" {
  description = "Maintenance day (1=Mon ... 7=Sun)"
  type        = number
  default     = 7
}

variable "maintenance_window_hour" {
  description = "Maintenance start hour (0-23)"
  type        = number
  default     = 4
}

variable "database_name" {
  description = "Initial database name"
  type        = string
  default     = "appdb"
}

variable "db_user" {
  description = "Database user name"
  type        = string
  default     = "dbuser"
}

variable "db_password" {
  description = "Database user password"
  type        = string
  sensitive   = true
}

variable "root_password" {
  description = "Postgres root password"
  type        = string
  sensitive   = true
  default     = ""
}

variable "authorized_networks" {
  description = "List of authorized networks for public access"
  type = list(object({
    name  = string
    value = string
  }))
  default = []
}

variable "labels" {
  description = "Labels for the instance"
  type        = map(string)
  default     = {}
}
