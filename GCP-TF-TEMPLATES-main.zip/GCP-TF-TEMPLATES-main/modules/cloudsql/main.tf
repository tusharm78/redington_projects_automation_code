resource "google_sql_database_instance" "postgres" {
  name             = var.name
  project          = var.project
  region           = var.region
  database_version = var.database_version

  settings {
    tier              = var.tier
    disk_size         = var.disk_size
    disk_type         = var.disk_type
    availability_type = "ZONAL"
    activation_policy = "ALWAYS"
    disk_autoresize   = var.auto_storage_increase

    ip_configuration {
      ipv4_enabled = true

      dynamic "authorized_networks" {
        for_each = var.authorized_networks
        content {
          name  = authorized_networks.value.name
          value = authorized_networks.value.value
        }
      }
    }

    backup_configuration {
      enabled            = var.backup_enabled
      start_time         = var.backup_start_time
      binary_log_enabled = true
    }

    maintenance_window {
      day  = var.maintenance_window_day
      hour = var.maintenance_window_hour
    }

    user_labels = var.labels
  }

  deletion_protection = false
}

resource "google_sql_database" "default" {
  name      = var.database_name
  instance  = google_sql_database_instance.postgres.name
  project   = var.project
  charset   = "UTF8"
  collation = "en_US.UTF8"
}

resource "google_sql_user" "db_user" {
  name     = var.db_user
  password = var.db_password
  instance = google_sql_database_instance.postgres.name
  project  = var.project
  host     = "%"
}

resource "google_sql_user" "postgres_admin" {
  count    = var.root_password != "" ? 1 : 0
  name     = "postgres"
  password = var.root_password
  instance = google_sql_database_instance.postgres.name
  project  = var.project
  host     = "%"
}
