module "cloudrun" {
  source       = "./modules/cloudrun"
  project_id   = var.project_id
  region       = var.region
  service_name = var.service_name
  image        = var.image
}
