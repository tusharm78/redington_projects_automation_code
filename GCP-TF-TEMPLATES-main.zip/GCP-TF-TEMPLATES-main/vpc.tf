# ---------------------------------------------------------
# VPC Module
# ---------------------------------------------------------
# This module dynamically creates multiple VPCs and their
# associated subnets based on the configurations provided
# in `var.vpc_configs`.
#
# for_each:
#   - Iterates over the vpc_configs map so that each VPC 
#     gets its own module instance.
#
# vpc_name:
#   - The name of the VPC to be created, taken from the 
#     configuration of the current iteration.
#
# subnets:
#   - A list/map of subnet configurations for the VPC.
#   - Each subnet will be created inside the respective VPC.
#

module "vpcs" {
  project_id = var.project_id
  source     = "./modules/network"
  for_each   = var.vpc_configs

  vpc_name = each.value.vpc_name
  subnets  = each.value.subnets
}
