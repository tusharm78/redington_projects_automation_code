# ---------------------------------------------------------------------------
# L1 IAM Configuration – Viewer Level Access
# ---------------------------------------------------------------------------
#
# This module assigns **Viewer-level permissions** to L1 users.
# - It uses a predefined IAM role: `roles/viewer`
# - The role provides read-only access across all supported GCP resources
# - No modification, creation, or deletion permissions are granted
# - Ideal for L1 users who only need visibility into the project

module "l1_iam" {
  project_id = var.project_id
  source     = "./modules/iam"
  role_id    = "l1_viewer_role"
  role_title = "L1 Viewer Role"
  role_stage = "GA"
  predefined = true
  users      = var.l1_users
  role_name  = "roles/viewer"
}

# ---------------------------------------------------------------------------
# L2 IAM Configuration – Custom Editor Role (No Delete Permissions)
#
# This module assigns a **restricted Editor-level role** for L2  users.
# It is a *custom IAM role* designed to allow full operational capabilities
# such as creating, updating, managing, and viewing Compute Engine resources,
# but **strictly prohibits any delete actions** to avoid accidental resource loss.
# ---------------------------------------------------------------------------

module "l2_iam" {
  project_id = var.project_id
  source     = "./modules/iam"
  role_id    = "l2_custom_editor"
  role_title = "L2 Custom Editor Role"
  role_stage = "GA"
  predefined = false
  users      = var.l2_users
  custom_permissions = [

    # --- Instances ---
    "compute.instances.create",
    "compute.instances.get",
    "compute.instances.list",
    "compute.instances.start",
    "compute.instances.stop",
    "compute.instances.update",
    "compute.instances.setMetadata",
    "compute.instances.setTags",
    "compute.instances.setLabels",
    "compute.instances.setMachineType",
    "compute.instances.setServiceAccount",
    "compute.instances.attachDisk",
    "compute.instances.detachDisk",
    "compute.instances.addAccessConfig",
    "compute.instances.getSerialPortOutput",
    "compute.instances.osLogin",
    "compute.instances.use",
    "compute.instances.useReadOnly",

    # --- Disks ---
    "compute.disks.create",
    "compute.disks.get",
    "compute.disks.list",
    "compute.disks.attach",
    "compute.disks.use",
    "compute.disks.useReadOnly",

    # --- Snapshots ---
    "compute.snapshots.create",
    "compute.snapshots.get",
    "compute.snapshots.list",
    "compute.snapshots.use",
    "compute.snapshots.useReadOnly",

    # --- Images ---
    "compute.machineImages.get",
    "compute.machineImages.list",
    "compute.images.create",
    "compute.images.get",
    "compute.images.list",
    "compute.images.useReadOnly",
    "compute.resourcePolicies.create",
    "compute.resourcePolicies.get",
    "compute.resourcePolicies.list",
    "compute.imageFamilies.get",

    # --- Networks ---
    "compute.networks.create",
    "compute.networks.get",
    "compute.networks.list",
    "compute.networks.updatePolicy",
    "compute.networks.addPeering",
    "compute.networks.removePeering",
    "compute.networks.updatePeering",
    "compute.networks.use",
    "compute.networks.useExternalIp",

    # --- Subnets ---
    "compute.subnetworks.create",
    "compute.subnetworks.get",
    "compute.subnetworks.list",
    "compute.subnetworks.use",
    "compute.subnetworks.useExternalIp",

    # --- Firewalls ---
    "compute.firewalls.create",
    "compute.firewalls.get",
    "compute.firewalls.list",
    "compute.firewalls.update",

    # --- Routes ---
    "compute.routes.get",
    "compute.routes.list",
    "compute.routes.create",

    # --- Forwarding Rules / Target Pools ---
    "compute.forwardingRules.create",
    "compute.forwardingRules.get",
    "compute.forwardingRules.list",
    "compute.targetPools.get",
    "compute.targetPools.list",
    "compute.targetPools.use",

    # --- Instance Groups ---
    "compute.instanceGroups.create",
    "compute.instanceGroups.get",
    "compute.instanceGroups.list",
    "compute.instanceGroups.update",
    "compute.instanceGroups.use",
    "compute.instanceGroupManagers.create",
    "compute.instanceGroupManagers.get",
    "compute.instanceGroupManagers.list",
    "compute.instanceGroupManagers.update",
    "compute.instanceGroupManagers.use",

    # --- Instance Templates ---
    "compute.instanceTemplates.create",
    "compute.instanceTemplates.get",
    "compute.instanceTemplates.list",
    "compute.instanceTemplates.useReadOnly",

    # --- Metadata, Zones, Machine Types ---
    "compute.zones.list",
    "compute.regions.list",
    "compute.machineTypes.list",
    "compute.projects.get",
    "compute.globalOperations.get",
    "compute.globalOperations.list",
    "compute.zoneOperations.get",
    "compute.zoneOperations.list",
    "compute.regionOperations.get",
    "compute.regionOperations.list",

    # --- External Access / IP ---
    "compute.addresses.create",
    "compute.addresses.get",
    "compute.addresses.list",
    "compute.addresses.use",

    # --- Load Balancers (Core components only) ---
    "compute.backendServices.create",
    "compute.backendServices.get",
    "compute.backendServices.list",
    "compute.backendServices.update",
    "compute.urlMaps.create",
    "compute.urlMaps.get",
    "compute.urlMaps.list",
    "compute.urlMaps.update",
    "compute.targetHttpProxies.create",
    "compute.targetHttpProxies.get",
    "compute.targetHttpProxies.list",
    "compute.targetHttpProxies.update",
    "compute.targetHttpsProxies.create",
    "compute.targetHttpsProxies.get",
    "compute.targetHttpsProxies.list",
    "compute.targetHttpsProxies.update",
    "compute.sslCertificates.create",
    "compute.sslCertificates.get",
    "compute.sslCertificates.list",

    # --- Operations ---
    "compute.operations.get",
    "compute.operations.list",

    # --- Buckets ---
    "storage.buckets.create",
    "storage.buckets.get",
    "storage.buckets.list",
    "storage.buckets.getIamPolicy",
    "storage.buckets.setIamPolicy",
    "storage.buckets.update",
    "storage.buckets.updateLabels",

    # --- Objects (files) ---
    "storage.objects.create",
    "storage.objects.get",
    "storage.objects.list",
    "storage.objects.getIamPolicy",
    "storage.objects.setIamPolicy",
    "storage.objects.update",
    "storage.objects.copy",
    "storage.objects.compose",
    "storage.objects.restore",

    # --- Notifications / Metadata ---
    "storage.notifications.create",
    "storage.notifications.get",
    "storage.notifications.list",

    # --- HMAC Keys (for service accounts) ---
    "storage.hmacKeys.create",
    "storage.hmacKeys.get",
    "storage.hmacKeys.list",
    "storage.hmacKeys.update",

    # --- Insights / Usage ---
    "storage.managedFolders.list",
    "storage.insights.get",
    "storage.locations.list",

    # --- Cloud Run Services ---
    "run.services.create",
    "run.services.get",
    "run.services.list",
    "run.services.update",
    "run.services.getIamPolicy",
    "run.services.setIamPolicy",

    # --- Cloud Run Revisions ---
    "run.revisions.get",
    "run.revisions.list",

    # --- Cloud Run Jobs ---
    "run.jobs.create",
    "run.jobs.get",
    "run.jobs.list",
    "run.jobs.update",
    "run.jobs.run",
    "run.jobs.getIamPolicy",
    "run.jobs.setIamPolicy",

    # --- Cloud Run Domain Mappings ---
    "run.domainmappings.create",
    "run.domainmappings.get",
    "run.domainmappings.list",

    # --- Cloud Run Operations ---
    "run.operations.get",
    "run.operations.list",

    # --- IAM / Service Accounts Integration ---
    "iam.serviceAccounts.actAs",
    "iam.serviceAccounts.get",
    "iam.serviceAccounts.list",

    # --- Supporting GCP APIs (Cloud Build) ---
    "cloudbuild.builds.create",
    "cloudbuild.builds.get",
    "cloudbuild.builds.list",
    "cloudbuild.builds.update",
    "cloudbuild.builds.cancel",
    "cloudbuild.builds.retry",

    # --- Repositories ---
    "artifactregistry.repositories.create",
    "artifactregistry.repositories.get",
    "artifactregistry.repositories.list",
    "artifactregistry.repositories.update",
    "artifactregistry.repositories.uploadArtifacts",
    "artifactregistry.repositories.downloadArtifacts",
    "artifactregistry.repositories.getIamPolicy",
    "artifactregistry.repositories.setIamPolicy",

    # --- Artifacts ---
    "artifactregistry.files.get",
    "artifactregistry.files.list",
    "artifactregistry.packages.get",
    "artifactregistry.packages.list",
    "artifactregistry.packages.update",
    "artifactregistry.versions.get",
    "artifactregistry.versions.list",
    "artifactregistry.versions.update",
    "artifactregistry.tags.create",
    "artifactregistry.tags.get",
    "artifactregistry.tags.list",
    "artifactregistry.tags.update",

    # --- Instances ---
    "sql.instances.create",
    "sql.instances.get",
    "sql.instances.list",
    "sql.instances.update",
    "sql.instances.restart",
    "sql.instances.promoteReplica",
    "sql.instances.demoteMaster",
    "sql.instances.clone",
    "sql.instances.failover",
    "sql.instances.getDiskShrinkConfig",
    "sql.instances.getLatestRecoveryTime",
    "sql.instances.connect",

    # --- Databases ---
    "sql.databases.create",
    "sql.databases.get",
    "sql.databases.list",
    "sql.databases.update",

    # --- Users ---
    "sql.users.create",
    "sql.users.get",
    "sql.users.list",
    "sql.users.update",
    "sql.users.sqlClient", # to connect

    # --- Backups ---
    "sql.backupRuns.create",
    "sql.backupRuns.get",
    "sql.backupRuns.list",
    "sql.backupRuns.restore",
    "sql.backupRuns.use",

    # --- SSL / Connections ---
    "sql.sslCerts.create",
    "sql.sslCerts.get",
    "sql.sslCerts.list",
    "sql.connect",

    # --- Flags & Operations ---
    "sql.flags.list",
    "sql.operations.get",
    "sql.operations.list",

    # --- IAM / Metadata ---
    "sql.tiers.list",
    "sql.caCerts.get",
    "sql.caCerts.list",

    "logging.logEntries.list",
    "logging.logs.list",
    "monitoring.timeSeries.list",
    "monitoring.metricDescriptors.list",

    "vpcaccess.connectors.list",
    "vpcaccess.connectors.get",

    "resourcemanager.projects.get",
    "resourcemanager.projects.list",
  ]
}

# ---------------------------------------------------------------------------
# L3 IAM Configuration – Custom Editor Role with Delete Permissions
#
# This module defines the **L3 support role**, which is an elevated custom IAM
# role that includes all operational and modification capabilities from L2,
# plus **full delete permissions** on Compute Engine resources.
# ---------------------------------------------------------------------------

module "l3_iam" {
  project_id = var.project_id
  source     = "./modules/iam"
  role_id    = "l3_editor_delete"
  role_title = "L3 Editor Delete Role"
  role_stage = "GA"
  predefined = false
  users      = var.l3_users
  custom_permissions = [

    # --- Compute Instances ---
    "compute.instances.create",
    "compute.instances.get",
    "compute.instances.list",
    "compute.instances.start",
    "compute.instances.stop",
    "compute.instances.update",
    "compute.instances.setMetadata",
    "compute.instances.setTags",
    "compute.instances.setLabels",
    "compute.instances.setMachineType",
    "compute.instances.setServiceAccount",
    "compute.instances.attachDisk",
    "compute.instances.detachDisk",
    "compute.instances.addAccessConfig",
    "compute.instances.getSerialPortOutput",
    "compute.instances.osLogin",
    "compute.instances.use",
    "compute.instances.useReadOnly",
    "compute.instances.delete",

    # --- Disks ---
    "compute.disks.create",
    "compute.disks.get",
    "compute.disks.list",
    "compute.disks.attach",
    "compute.disks.use",
    "compute.disks.useReadOnly",
    "compute.disks.delete",

    # --- Snapshots ---
    "compute.snapshots.create",
    "compute.snapshots.get",
    "compute.snapshots.list",
    "compute.snapshots.use",
    "compute.snapshots.useReadOnly",
    "compute.snapshots.delete",

    # --- Images & Policies ---
    "compute.images.create",
    "compute.images.get",
    "compute.images.list",
    "compute.images.useReadOnly",
    "compute.images.delete",
    "compute.machineImages.get",
    "compute.machineImages.list",
    "compute.imageFamilies.get",
    "compute.resourcePolicies.create",
    "compute.resourcePolicies.get",
    "compute.resourcePolicies.list",
    "compute.resourcePolicies.delete",

    # --- Networks ---
    "compute.networks.create",
    "compute.networks.get",
    "compute.networks.list",
    "compute.networks.updatePolicy",
    "compute.networks.addPeering",
    "compute.networks.removePeering",
    "compute.networks.updatePeering",
    "compute.networks.use",
    "compute.networks.useExternalIp",
    "compute.networks.delete",

    # --- Subnets ---
    "compute.subnetworks.create",
    "compute.subnetworks.get",
    "compute.subnetworks.list",
    "compute.subnetworks.use",
    "compute.subnetworks.useExternalIp",
    "compute.subnetworks.delete",

    # --- Firewalls ---
    "compute.firewalls.create",
    "compute.firewalls.get",
    "compute.firewalls.list",
    "compute.firewalls.update",
    "compute.firewalls.delete",

    # --- Routes ---
    "compute.routes.create",
    "compute.routes.get",
    "compute.routes.list",
    "compute.routes.delete",

    # --- Forwarding Rules / Target Pools ---
    "compute.forwardingRules.create",
    "compute.forwardingRules.get",
    "compute.forwardingRules.list",
    "compute.forwardingRules.delete",
    "compute.targetPools.get",
    "compute.targetPools.list",
    "compute.targetPools.use",
    "compute.targetPools.delete",

    # --- Instance Groups / Managers ---
    "compute.instanceGroups.create",
    "compute.instanceGroups.get",
    "compute.instanceGroups.list",
    "compute.instanceGroups.update",
    "compute.instanceGroups.use",
    "compute.instanceGroups.delete",
    "compute.instanceGroupManagers.create",
    "compute.instanceGroupManagers.get",
    "compute.instanceGroupManagers.list",
    "compute.instanceGroupManagers.update",
    "compute.instanceGroupManagers.use",
    "compute.instanceGroupManagers.delete",

    # --- Instance Templates ---
    "compute.instanceTemplates.create",
    "compute.instanceTemplates.get",
    "compute.instanceTemplates.list",
    "compute.instanceTemplates.useReadOnly",
    "compute.instanceTemplates.delete",

    # --- Metadata, Zones, Machine Types ---
    "compute.zones.list",
    "compute.regions.list",
    "compute.machineTypes.list",
    "compute.projects.get",
    "compute.globalOperations.get",
    "compute.globalOperations.list",
    "compute.zoneOperations.get",
    "compute.zoneOperations.list",
    "compute.regionOperations.get",
    "compute.regionOperations.list",
    "compute.operations.get",
    "compute.operations.list",

    # --- External Access / IP ---
    "compute.addresses.create",
    "compute.addresses.get",
    "compute.addresses.list",
    "compute.addresses.use",
    "compute.addresses.delete",

    # --- Load Balancers ---
    "compute.backendServices.create",
    "compute.backendServices.get",
    "compute.backendServices.list",
    "compute.backendServices.update",
    "compute.backendServices.delete",
    "compute.urlMaps.create",
    "compute.urlMaps.get",
    "compute.urlMaps.list",
    "compute.urlMaps.update",
    "compute.urlMaps.delete",
    "compute.targetHttpProxies.create",
    "compute.targetHttpProxies.get",
    "compute.targetHttpProxies.list",
    "compute.targetHttpProxies.update",
    "compute.targetHttpProxies.delete",
    "compute.targetHttpsProxies.create",
    "compute.targetHttpsProxies.get",
    "compute.targetHttpsProxies.list",
    "compute.targetHttpsProxies.update",
    "compute.targetHttpsProxies.delete",
    "compute.sslCertificates.create",
    "compute.sslCertificates.get",
    "compute.sslCertificates.list",
    "compute.sslCertificates.delete",

    # --- Storage Buckets ---
    "storage.buckets.create",
    "storage.buckets.get",
    "storage.buckets.list",
    "storage.buckets.getIamPolicy",
    "storage.buckets.setIamPolicy",
    "storage.buckets.update",
    "storage.buckets.updateLabels",
    "storage.buckets.delete",

    # --- Storage Objects ---
    "storage.objects.create",
    "storage.objects.get",
    "storage.objects.list",
    "storage.objects.getIamPolicy",
    "storage.objects.setIamPolicy",
    "storage.objects.update",
    "storage.objects.copy",
    "storage.objects.compose",
    "storage.objects.restore",
    "storage.objects.delete",

    # --- Storage Metadata / HMAC ---
    "storage.notifications.create",
    "storage.notifications.get",
    "storage.notifications.list",
    "storage.notifications.delete",
    "storage.hmacKeys.create",
    "storage.hmacKeys.get",
    "storage.hmacKeys.list",
    "storage.hmacKeys.update",
    "storage.hmacKeys.delete",
    "storage.managedFolders.list",
    "storage.insights.get",
    "storage.locations.list",

    # --- Cloud Run Services ---
    "run.services.create",
    "run.services.get",
    "run.services.list",
    "run.services.update",
    "run.services.delete",
    "run.services.getIamPolicy",
    "run.services.setIamPolicy",
    "run.revisions.get",
    "run.revisions.list",
    "run.revisions.delete",
    "run.jobs.create",
    "run.jobs.get",
    "run.jobs.list",
    "run.jobs.update",
    "run.jobs.delete",
    "run.jobs.run",
    "run.jobs.getIamPolicy",
    "run.jobs.setIamPolicy",
    "run.domainmappings.create",
    "run.domainmappings.get",
    "run.domainmappings.list",
    "run.domainmappings.delete",
    "run.operations.get",
    "run.operations.list",
    "run.operations.delete",

    # --- IAM / Service Accounts ---
    "iam.serviceAccounts.actAs",
    "iam.serviceAccounts.get",
    "iam.serviceAccounts.list",

    # --- Cloud Build ---
    "cloudbuild.builds.create",
    "cloudbuild.builds.get",
    "cloudbuild.builds.list",
    "cloudbuild.builds.update",
    "cloudbuild.builds.delete",
    "cloudbuild.builds.cancel",
    "cloudbuild.builds.retry",

    # --- Artifact Registry ---
    "artifactregistry.repositories.create",
    "artifactregistry.repositories.get",
    "artifactregistry.repositories.list",
    "artifactregistry.repositories.update",
    "artifactregistry.repositories.uploadArtifacts",
    "artifactregistry.repositories.downloadArtifacts",
    "artifactregistry.repositories.getIamPolicy",
    "artifactregistry.repositories.setIamPolicy",
    "artifactregistry.repositories.delete",
    "artifactregistry.files.get",
    "artifactregistry.files.list",
    "artifactregistry.files.delete",
    "artifactregistry.packages.get",
    "artifactregistry.packages.list",
    "artifactregistry.packages.update",
    "artifactregistry.packages.delete",
    "artifactregistry.versions.get",
    "artifactregistry.versions.list",
    "artifactregistry.versions.update",
    "artifactregistry.versions.delete",
    "artifactregistry.tags.create",
    "artifactregistry.tags.get",
    "artifactregistry.tags.list",
    "artifactregistry.tags.update",
    "artifactregistry.tags.delete",

    # --- Logs / Monitoring ---
    "logging.logEntries.list",
    "logging.logs.list",
    "monitoring.timeSeries.list",
    "monitoring.metricDescriptors.list",

    # --- Networking (VPC Connectors) ---
    "vpcaccess.connectors.create",
    "vpcaccess.connectors.get",
    "vpcaccess.connectors.list",
    "vpcaccess.connectors.delete",

    # --- Cloud SQL ---
    "sql.instances.create",
    "sql.instances.get",
    "sql.instances.list",
    "sql.instances.update",
    "sql.instances.restart",
    "sql.instances.promoteReplica",
    "sql.instances.demoteMaster",
    "sql.instances.clone",
    "sql.instances.failover",
    "sql.instances.getDiskShrinkConfig",
    "sql.instances.getLatestRecoveryTime",
    "sql.instances.delete",
    "sql.databases.create",
    "sql.databases.get",
    "sql.databases.list",
    "sql.databases.update",
    "sql.databases.delete",
    "sql.users.create",
    "sql.users.get",
    "sql.users.list",
    "sql.users.update",
    "sql.users.delete",
    "sql.users.sqlClient",
    "sql.backupRuns.create",
    "sql.backupRuns.get",
    "sql.backupRuns.list",
    "sql.backupRuns.restore",
    "sql.backupRuns.use",
    "sql.backupRuns.delete",
    "sql.sslCerts.create",
    "sql.sslCerts.get",
    "sql.sslCerts.list",
    "sql.sslCerts.delete",
    "sql.connect",
    "sql.instances.connect",
    "sql.flags.list",
    "sql.operations.get",
    "sql.operations.list",
    "sql.operations.delete",
    "sql.tiers.list",
    "sql.caCerts.get",
    "sql.caCerts.list",

    # --- Project Metadata ---
    "resourcemanager.projects.get",
    "resourcemanager.projects.list"
  ]
}

# ---------------------------------------------------------------------------
# L4 IAM Configuration – Full Admin (Owner-Level Access)
#
# This module defines the **L4 administrator role**, which provides complete
# administrative control over the GCP project. Unlike L2 and L3, this level
# does not use a custom permission set — instead, it assigns the **predefined
# GCP Owner role (roles/owner)**.
# ---------------------------------------------------------------------------

module "l4_iam" {
  project_id = var.project_id
  source     = "./modules/iam"
  role_id    = "l4_admin_role"
  role_title = "L4 Admin Role"
  role_stage = "GA"
  predefined = true
  users      = var.l4_users
  role_name  = "roles/owner"
}
