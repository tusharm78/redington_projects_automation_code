# ---------------------------------------------------------
# VM Module
# ---------------------------------------------------------
# This module creates Virtual Machine instances based on the 
# configurations passed through `var.vm_configs`. 
#

module "vms" {
  project_id = var.project_id
  source     = "./modules/compute"
  vm_configs = var.vm_configs
  subnet_map = {
    vpc1-subnet1 = module.vpcs["vpc1"].subnets["vpc1-subnet1"]
    vpc1-subnet2 = module.vpcs["vpc1"].subnets["vpc1-subnet2"]
    vpc2-subnet1 = module.vpcs["vpc2"].subnets["vpc2-subnet1"]
    vpc2-subnet2 = module.vpcs["vpc2"].subnets["vpc2-subnet2"]
  }
}
