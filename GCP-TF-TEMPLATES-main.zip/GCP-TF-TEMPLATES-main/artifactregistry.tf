module "artifactregistry" {
  source        = "./modules/artifactregistry"
  project_id    = var.project_id
  region        = var.region
  repository_id = var.repository_id
  description   = var.description
  labels = {
    environment = "dev"
    team        = "devops"
  }
}
