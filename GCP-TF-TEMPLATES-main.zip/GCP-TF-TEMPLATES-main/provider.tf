terraform {
  required_providers {
    google = {
      source  = "hashicorp/google"
      version = ">= 7.2.0"
      configuration_aliases = [google.bootstrap, google.impersonated]
    }
  }
}

# provider "google" {
#   credentials = file(var.credentials_file)

#   impersonate_service_account = "l2engineers-sa@project-362617.iam.gserviceaccount.com"

#   # impersonate_service_account = module.iam_l2_engineers.service_account_email


# }
provider "google" {
  alias       = "bootstrap"
  project     = var.project_id
  region      = var.region
  credentials = file(var.credentials_file)
}

provider "google" {
  alias                       = "impersonated"
  project                     = var.project_id
  region                      = var.region
  # impersonate_service_account = google_service_account.l2_sa.email
  impersonate_service_account = module.iam_l2_engineers.service_account_email
}