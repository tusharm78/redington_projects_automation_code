# Project ID
project_id = "project-362617"
region     = "asia-south1"

# L1 - Viewer GUI
l1_users = [
  "l1engineer@redingtongroup.com"
]

# L2 - Terraform/CLI, no delete/modify
l2_users = [
  "l2engineer@redingtongroup.com"
]

# L3 - Terraform/CLI, modify
l3_users = [
  "l3engineer@redingtongroup.com"
]

# L4 - Terraform/CLI, admin
l4_users = [
  "l4engineer@redingtongroup.com"
]

vpc_configs = {
  vpc1 = {
    vpc_name = "delivery-teamvpc1"
    subnets = [
      { name = "vpc1-subnet1", cidr = "10.0.0.0/24", region = "asia-south1" },
      { name = "vpc1-subnet2", cidr = "10.0.1.0/24", region = "asia-south1" }
    ]
  }
  vpc2 = {
    vpc_name = "delivery-teamvpc2"
    subnets = [
      { name = "vpc2-subnet1", cidr = "10.1.0.0/24", region = "asia-south1" },
      { name = "vpc2-subnet2", cidr = "10.1.1.0/24", region = "asia-south1" }
    ]
  }
}

vm_configs = {
  vm1 = {
    name         = "vm1"
    machine_type = "e2-medium"
    zone         = "asia-south1-a"
    subnetwork   = "vpc1-subnet1" # just a key, not self_link
    image        = "debian-cloud/debian-11"
    disk_size    = 20
  }
  vm2 = {
    name         = "vm2"
    machine_type = "e2-small"
    zone         = "asia-south1-b"
    subnetwork   = "vpc2-subnet1" # just a key
    image        = "ubuntu-os-cloud/ubuntu-2204-lts"
    disk_size    = 30
  }
}

buckets_config = {
  bucket1 = {
    name          = "terraform-testing-2025"
    location      = "ASIA-SOUTH1"
    storage_class = "STANDARD"
    versioning    = false
    uniform_bucket_level_access = true
  }
}

snapshot_schedules = {
  daily_schedule = {
    name                  = "compute-engine-daily-snapshot"
    region                = "asia-south1"
    description           = "Daily snapshot schedule for compute disks"
    days_in_cycle         = 1
    start_time            = "20:00"
    retention_days        = 1
    on_source_disk_delete = "APPLY_RETENTION_POLICY"
    labels = {
      frequency   = "daily"
      environment = "prod"
    }
    storage_locations = ["asia-south1"]
  }
}

# Disks mapped to specific schedules
disk_attachments = {
  disk1 = {
    disk_name    = "compute-disk-1"
    zone         = "asia-south1-a"
    schedule_key = "daily_schedule"
  }
}


vm_schedules = {
  vm1 = {
    name           = "vm1-schedule"
    region         = "asia-south1"
    description    = "Daily start/stop for vm1"
    start_schedule = "52 03 * * *" 
    stop_schedule  = "50 03 * * *"   
    time_zone      = "Asia/Kolkata"
  }
}

# -------------------------------------
# Cloud sql
# -------------------------------------


cloudsql_name                  = "my-postgres-public"
cloudsql_database_version      = "POSTGRES_15"
cloudsql_tier                  = "db-g1-small"
cloudsql_disk_size             = 20
cloudsql_disk_type             = "PD_SSD"
cloudsql_auto_storage_increase = true

cloudsql_backup_enabled    = true
cloudsql_backup_start_time = "02:00"
cloudsql_maintenance_day   = 7
cloudsql_maintenance_hour  = 2

cloudsql_database_name = "myappdb"
cloudsql_db_user       = "appuser"
cloudsql_db_password   = "YourStrongPassword123!"
cloudsql_root_password = "RootPassword456!"

cloudsql_authorized_networks = [
  { name = "office", value = "203.0.113.45/32" },
  { name = "home", value = "198.51.100.12/32" }
]

cloudsql_labels = {
  environment = "dev"
  owner       = "sriram"
}

# Cloudrun

service_name = "my-cloudrun-service"
image        = "gcr.io/cloudrun/hello"  

# HTTPS Load Balancer

lb_name     = "my-cloudrun-lb"
domain_name = "example.com"
#region      = "asia-south1"