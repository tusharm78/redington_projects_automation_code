# Local variable - helpful for referencing
locals {
  project = var.project_id
}

# Define multiple buckets if needed
module "gcs_buckets" {
  source = "./modules/cloud_storage"

  for_each = var.buckets_config

  name                        = each.value.name
  project                     = local.project
  location                    = each.value.location
  storage_class               = each.value.storage_class
  uniform_bucket_level_access = true
  versioning                  = each.value.versioning
  force_destroy               = true
}
