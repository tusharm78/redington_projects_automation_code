provider "google" {
  project = var.project_id      # 🔧 Replace with your GCP Project ID
  region  = var.region
}

# Create a 10 GB Standard Persistent Disk
resource "google_compute_disk" "example_disk" {
  name  = "compute-disk-1"
  type  = "pd-standard"  # Can be pd-ssd or pd-balanced if needed
  zone  = "asia-south1-a"
  size  = 10             # Disk size in GB
  labels = {
    environment = "prod"
    team        = "infra"
  }
}

output "disk_name" {
  value = google_compute_disk.example_disk.name
}

output "disk_self_link" {
  value = google_compute_disk.example_disk.self_link
}
