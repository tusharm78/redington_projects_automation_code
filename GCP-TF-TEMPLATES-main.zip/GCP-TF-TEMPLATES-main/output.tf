output "project_id" {
  value = var.project_id
}

output "l2_service_account_email" {
  value = module.iam_l2_engineers.service_account_email
}

output "bucket_names" {
  value = { for k, v in module.gcs_buckets : k => v.bucket_name }
}

output "bucket_urls" {
  value = { for k, v in module.gcs_buckets : k => v.bucket_url }
}

output "vm_schedule_policies" {
  value = module.compute_schedule.vm_schedule_policies
}


# Output file for Cloudsql

output "cloudsql_instance_name" {
  value = module.cloudsql.instance_name
}

output "cloudsql_connection_name" {
  value = module.cloudsql.instance_connection_name
}

output "cloudsql_public_ip" {
  value = module.cloudsql.public_ip
}

output "cloudsql_database_name" {
  value = module.cloudsql.database_name
}

output "cloudsql_db_user" {
  value = module.cloudsql.db_user
}

# Cloud run

output "cloud_run_url" {
  description = "Deployed Cloud Run service URL"
  value       = module.cloudrun.cloud_run_url
}

# HTTPS Load Balancer
output "load_balancer_ip" {
  description = "Public IP address of the Load Balancer"
  value       = module.loadbalancer.lb_ip
}
