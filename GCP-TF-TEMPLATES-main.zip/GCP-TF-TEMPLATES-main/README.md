#  GCP Terraform Infrastructure Templates

This repository contains **modular Terraform configurations** for deploying and managing **Google Cloud Platform (GCP)** infrastructure.  
It is designed for scalability, reusability, and easy automation of core GCP services such as Compute Engine, Cloud SQL, Cloud Run, Load Balancer, IAM, and more.

---

##  Repository Structure

### Root Directory
The root Terraform files define the high-level orchestration of all modules and configurations.

| File | Description |
|------|--------------|
| **provider.tf** | Configures the GCP provider and authentication setup. |
| **variables.tf** | Declares global input variables used across resources. |
| **terraform.tfvars** | Defines actual variable values (environment-specific). |
| **output.tf** | Consolidates and exports resource outputs for reuse. |
| **compute.tf** | Manages Compute Engine VM instance configurations. |
| **disk.tf** | Manages persistent disks attached to VM instances. |
| **instance_schedule.tf** | Defines instance scheduling for automated start/stop. |
| **snapshot_schedule.tf** | Configures snapshot schedules for disks. |
| **vpc.tf** | Defines the Virtual Private Cloud (VPC) and subnets. |
| **loadbalancer.tf** | Configures external/global HTTPS load balancer with backend services. |
| **cloudsql.tf** | Manages Cloud SQL instances, users, databases, and backups. |
| **cloudrun.tf** | Deploys Cloud Run services and domain mappings. |
| **artifactregistry.tf** | Sets up Artifact Registry for storing container images or artifacts. |
| **cloud_storage.tf** | Creates GCS buckets for storage, logging, and backups. |
| **iam.tf** | Configures IAM custom roles, binding to the users.|
| **output.tf** | Provides consolidated output values (IPs, URLs, etc.). |

---

###  Modules Directory

Each GCP component has its own self-contained module with:
- `main.tf` → Resource definitions  
- `variables.tf` → Input variables  
- `output.tf` → Resource outputs  

| Module | Description |
|---------|--------------|
| **artifactregistry/** | Creates and manages GCP Artifact Registry repositories. |
| **cloud_storage/** | Manages Cloud Storage buckets, IAM, and notifications. |
| **cloudrun/** | Deploys Cloud Run services and configures IAM & domain mappings. |
| **cloudsql/** | Sets up Cloud SQL instances, users, databases, and backups. |
| **compute/** | Creates Compute Engine instances and associates disks. |
| **compute_schedule/** | Automates Compute Engine start/stop schedules using Cloud Scheduler. |
| **iam/** | Creates custom IAM roles, permissions, and service accounts. |
| **loadbalancer/** | Configures Global HTTPS Load Balancer with backend and URL map. |
| **network/** | Defines VPCs, subnets, firewall rules, and routing. |
| **snapshot_schedule/** | Sets up disk snapshot schedules and retention policies. |

---

##  Getting Started

### 1. Prerequisites
- [Terraform](https://www.terraform.io/downloads.html) v1.5+  
- [Google Cloud SDK](https://cloud.google.com/sdk)  
- A GCP project with sufficient permissions  
- A service account key or impersonation setup  

### 2. Setup

Clone the repository:
```bash
git clone https://github.com/<your-org>/<your-repo>.git
cd <your-repo>
```

Authenticate with GCP:
```bash
gcloud auth login
gcloud auth application-default login
```

Initialize Terraform:
```bash
terraform init
```

Review and apply configurations:
```bash
terraform plan
terrafrom validate
terraform apply
```

---

##  Customization

You can override variables in `terraform.tfvars` or via CLI:
```hcl
project_id     = "my-gcp-project"
region         = "asia-south1"
network_name   = "prod-vpc"
instance_count = 2
```

Each module supports custom variable inputs — refer to each module’s `variables.tf` for details.

---

##  Example Module Usage

Example: Using the **Cloud SQL** module
```hcl
module "cloudsql" {
  source      = "./modules/cloudsql"
  project_id  = var.project_id
  region      = var.region
  instance_name = "my-sql-db"
  tier        = "db-custom-2-4096"
  disk_size   = 50
}
```

---

## IAM and Security

- Custom IAM roles are defined in `iam.tf` with principle of least privilege.  
- IAM custom previlages are used for Terraform execution and resource access.  
- Sensitive variables (like passwords or keys) should be stored securely using Terraform Cloud variables or Secret Manager.

---

##  Modular Architecture

The repository follows a **modular approach** — each service can be deployed independently or together, depending on your environment.  
This enables environment-based setups like:
- **dev/** → Development  
- **staging/** → Testing  
- **prod/** → Production  

---

## GCP Services

- IAM  & IAM Custom Roles 
- VPC Networking  
- Compute Engine 
- Snapshot & Instance Scheduling   
- Cloud Storage (GCS)  
- Load Balancer (Global HTTPS)  
- Cloud SQL  
- Cloud Run  
- Artifact Registry 

---

##  Outputs

After `terraform apply`, key outputs will include:
- Load balancer IP and HTTPS endpoint  
- Cloud SQL connection name  
- Cloud Run service URL  
- GCS bucket names  
- Artifact Registry repo URLs  
- VM instance details  

---

##  Maintenance

To update configurations:
```bash
terraform plan -refresh-only
terraform apply
```

To destroy resources:
```bash
terraform destroy
```
