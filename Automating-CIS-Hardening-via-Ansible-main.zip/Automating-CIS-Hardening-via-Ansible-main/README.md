# OS Hardening

## Demo

### How to Comply with CIS Benchmark Using Ansible Lockdown Roles

## Step 1: Familiarize Yourself with the CIS Benchmark

Start by obtaining the latest CIS Benchmark for RHEL 9. The CIS Benchmark provides comprehensive guidelines and recommendations for securing your RHEL 9 systems. Review the Benchmark document to gain a deep understanding of the hardening steps required.

## Step 2: Install and Configure Ansible

Ensure that Ansible is installed on your system. Ansible is an open-source automation tool that simplifies the process of configuration management and orchestration. Install Ansible on a control machine that will execute the hardening tasks on the target RHEL 9 systems.

## Step 3: Download the Ansible Lockdown Roles

Using your knowledge of the CIS Benchmark, the Ansible Lockdown community has created a series of Ansible roles that incorporate the necessary tasks for hardening RHEL 9. Each role should correspond to a specific CIS Benchmark recommendation. Ansible’s declarative language allows us to declare the desired state of our system, making it easier to enforce security configurations consistently across multiple machines.

Run the following command to install the Ansible role:

```sh
ansible-galaxy install git+https://github.com/ansible-lockdown/RHEL9-CIS.git
```

Example execution output:

```sh
Starting galaxy role install process
- extracting RHEL9-CIS to /Users/lberton/.ansible/roles/RHEL9-CIS
- RHEL9-CIS was installed successfully
```

## Step 4: Create an Ansible Playbook Using the "RHEL9-CIS" Role

To enhance the flexibility and reusability of your playbook, define variables and use Jinja2 templates where appropriate. The Ansible role already includes an example `site.yml` playbook that we can use to execute the code:

```yaml
---
- hosts: all
  become: true
  roles:
      - role: "RHEL9-CIS"
```

## Step 5: Create an Ansible Inventory

Our Ansible inventory defines the list of target hosts and how to connect to them. For example, if you want to target `rhel.example.com` and connect with the SSH username `luca`, define the inventory as follows:

```ini
rhel.example.com

[all:vars]
ansible_connection=ssh
ansible_user=luca
```

## Step 6: Execute the Ansible Playbook

Execute the playbook to enforce the CIS Benchmark configurations on your RHEL 9 system:

```sh
ansible-playbook -i inventory site.yml
```

Example execution output:

```sh
[...]
TASK [RHEL9-CIS : Show Audit Summary] ********************************************************
skipping: [rhel.example.com]

TASK [RHEL9-CIS : If Warnings found Output count and control IDs affected] *******************
ok: [rhel.example.com] => {
    "msg": "You have 16 Warning(s) that require investigating that are related to the following benchmark ID(s)  [1.1.2.1] [1.1.3.1] [1.1.4.1] [1.1.5.1] [1.1.6.1] [1.1.7.1] [1.1.8.1] [1.2.3] [1.6.1.6] [2.4] [4.3] [6.1.10] [6.1.11] [6.1.13] [6.1.14] [6.1.15]"
}

PLAY RECAP ***********************************************************************************
rhel.example.com           : ok=343  changed=4    unreachable=0    failed=0    skipped=173  rescued=0    ignored=0
```

## Step 7: Test and Verify

After execution, review the warnings provided by the playbook and investigate any necessary configurations. Always test the playbook in a staging environment before deploying it to production. Use Ansible’s dry-run mode (`--check`) to preview changes without applying them.

## Step 8: Schedule and Monitor

To ensure continuous compliance with the CIS Benchmark, schedule the execution of the Ansible playbook periodically using tools like `cron` or Ansible Automation Platform. Implement monitoring mechanisms to detect deviations from the desired security configurations. Ansible provides various reporting and logging options to facilitate this monitoring process.

---
By following these steps, you can efficiently harden your RHEL 9 systems and ensure compliance with the CIS Benchmark recommendations using Ansible.
