provider "aws" {
  region = "ap-south-1" # Specify your desired AWS region here
}

resource "aws_s3_bucket" "example_bucket" {
  bucket = "your-unique-bucket-name" # Replace with your desired bucket name

  # Enable versioning for the S3 bucket
  versioning {
    enabled = true
  }

  # Optional: Configure logging for the S3 bucket
  logging {
    target_bucket = "log-bucket-name"   # Replace with the bucket name where logs will be stored
    target_prefix = "s3-logs/"
  }
}

resource "aws_s3_bucket_public_access_block" "example_bucket_public_access" {
  bucket = aws_s3_bucket.example_bucket.id

  # Block public access to all objects and ACLs
  block_public_acls       = true
  ignore_public_acls      = true
  block_public_policy     = true
  restrict_public_buckets = true
}

# Output the bucket name (useful for reference)
output "bucket_name" {
  value = aws_s3_bucket.example_bucket.id
}
