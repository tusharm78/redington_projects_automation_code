provider "aws" {
  region = "ap-south-1"  # Replace with your desired AWS region
}

resource "aws_ecr_repository" "my_ecr_repo" {
  name = "terraform-aws-repo"
  
  image_tag_mutability = "IMMUTABLE"  # Enable tag immutability
  
  }

output "ecr_repo_url" {
  value = aws_ecr_repository.my_ecr_repo.repository_url
}
