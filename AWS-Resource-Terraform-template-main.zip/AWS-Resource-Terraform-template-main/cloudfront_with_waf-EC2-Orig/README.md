# cloudfront_with_waf
Repository for Redington bundle of CloudFront with WAF
Two variations of the bundle available.
1. With EC2 as origin
2. With S3 as origin
