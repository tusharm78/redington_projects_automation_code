terraform {
  required_version = "> 0.14"
  required_providers {
    aws = {
      source  = "hashicorp/aws"
      version = "> 4.0"
    }
  }
}

provider "aws" {
profile = "default"
access_key = ""
secret_key = ""
region  = "ap-south-2"
}
