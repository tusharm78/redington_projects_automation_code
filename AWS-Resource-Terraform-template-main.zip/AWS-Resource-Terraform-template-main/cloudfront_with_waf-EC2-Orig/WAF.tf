resource "aws_wafv2_web_acl" "aclexample2" {
  name        = "managed-rule-example"
  description = "Example of a managed rule."
  scope       = "CLOUDFRONT"

  default_action {
    allow {}
  }

    tags = {
    tag1 = var.waftag1
  }

  visibility_config {
   cloudwatch_metrics_enabled = false
   metric_name                = "friendly-metric-name"
   sampled_requests_enabled   = false
  }
}