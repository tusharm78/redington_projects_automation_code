variable "staticip" {
description = "Enter the Public IP of the VM"
type = string
}

variable "ec2ppublicdns" {
description = "Enter the Public IPV4 DNS of the VM"
type = string
}

variable "cloudfrontenv" {
description = "Specify the environment for the CLoudfront DIstribution"
type = string
}

variable "route53env" {
description = "Specify the environment for the Route53 Records"
type = string
}

variable "waftag1" {
description = "Specify the tag and value for WAF"
type = string
}