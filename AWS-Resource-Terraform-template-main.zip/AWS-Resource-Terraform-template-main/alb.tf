# Create an ALB
/*
resource "aws_lb" "Loadbalancr" {
  name               = "my-lb"
  internal           = false
  load_balancer_type = "application"
  security_groups = [ aws_security_group.vpc-ssh.id , aws_security_group.vpc-web.id]
  subnets            = [aws_subnet.vpc-dev-public-subnet-1.id, aws_subnet.vpc-dev-private-subnet-1.id]


 tags_all = merge({ Pack_Name = var.resource_tags_name }, { Created_by = "Terraform Automation", Distributor_name = "Redington" } , { creation_date = "Mention the date here"})

}


# Create a target group for the ALB
resource "aws_lb_target_group" "lb_tg" {
  name        = "example-tg"
  port        = 80
  protocol    = "HTTP"
  vpc_id      = aws_vpc.vpc-dev.id
  target_type = "instance"
tags_all = merge({ Pack_Name = var.resource_tags_name }, { Created_by = "Terraform Automation", Distributor_name = "Redington" } , { creation_date = "Mention the date here"})

}

resource "aws_lb_target_group_attachment" "test" {
  target_group_arn = aws_lb_target_group.lb_tg.arn
  target_id        = aws_instance.my-ec2-vm.id
 #target_id = "${aws_instance.my-ec2-vm.id} , ${aws_instance.my-ec2-vm2.id}"
   port             = 80
}

resource "aws_lb_target_group_attachment" "test1" {
  target_group_arn = aws_lb_target_group.lb_tg.arn
  target_id        = aws_instance.my-ec2-vm2.id
   port             = 80
}


# Create a listener for the ALB
resource "aws_lb_listener" "lb_list" {
  load_balancer_arn = aws_lb.Loadbalancr.arn
  port              = 80 
  protocol          = "HTTP"

  default_action {
    type             = "forward"
    target_group_arn = aws_lb_target_group.lb_tg.arn

  }



}
*/