######variable for Tag Name
variable "env-name" {
description = "Name of the environment" 
type = string
default = "Prod"    #########Name of the environment
}