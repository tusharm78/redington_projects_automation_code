########Variable for KMS key arn
variable "kms_key_arn" {
description = "kms_key_arn"
type = string
default = ""        ######KMS Key in AWS Ex:arn:aws:kms:ap-south-1:257825142977:key/1cc976e4-7f02-42af-a689-3a92cd93e352
}

######variable for Tag Name
variable "env-name" {
description = "Name of the environment" 
type = string
default = "Prod"    #########Name of the environment
}
