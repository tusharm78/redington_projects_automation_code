############Creating AWS Backup for EC2 server########
resource "aws_backup_vault" "backup_vault_test" {
  name        = "backup_vault_test"
  kms_key_arn = var.kms_key_arn                ####Variable of KMS key in variable file
}

resource "aws_backup_plan" "backup_plan_test" {
  name = "backup_plan_test"

  rule {
    rule_name         = "backup_rule_test"
    target_vault_name = aws_backup_vault.backup_vault_test.name
    schedule          = "cron(30 0 ? * * *)"        #######Cron schedule can be modified as per the requirement

    lifecycle {
      delete_after = 30                         #####Backup retention period
    }
  }

  advanced_backup_setting {
    backup_options = {
      WindowsVSS = "enabled"
    }
    resource_type = "EC2"
  }
  tags = {
    Name    = "Backup-Policy"        ######## Name of the Policy 
    Environment = var.env-name
    Created-by = "Terraform-Automation"
  }
}
