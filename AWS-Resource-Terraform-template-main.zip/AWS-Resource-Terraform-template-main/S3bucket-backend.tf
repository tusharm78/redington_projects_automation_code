#### this file as configuration for creating a S3 bucket needed for backend
## S3 bucket

resource "aws_s3_bucket" "do-n0t-delete-project-demo-terraform-backend" {
    bucket = "do-n0t-delete-project-demo-terraform-backend"                    ## name should be do-not-delete-project(replace project name)-terraform-backend
}
