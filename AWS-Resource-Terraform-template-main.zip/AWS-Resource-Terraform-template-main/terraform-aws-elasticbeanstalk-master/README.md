# Elastic Beanstalk WebServer Environment with Terraform

 ![Elastic Beanstalk Deployment with Terraform]
This terraform configuration will create Elastic Beanstalk WebServer Environment Amazon Linux 2 and PHP 8.0.

<br/>

<br/>




<br/>

Change these variables in the terraform.tfvars file with your own before the deployment.

<br/>

```
region = "ap-south-1"

app_tags = "Example"

application_name = "Example-App"

vpc_id = "vpc-ee2325320"

ec2_subnets = "subnet-d1c325ab"

elb_subnets = ["subnet-d1c325ab","subnet-d1c565ab"]

instance_type = "t3.micro"

disk_size = "20"

keypair = "example"




```

<br/>

When everything is ready you can deploy with these 4 commands.

### Deployment

```
terraform init
terraform validate
terraform plan
terraform apply

```
