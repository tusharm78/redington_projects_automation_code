provider "aws" {
  region  = var.region
}



module "eb" {

  source = "./modules/beanstalk/"
  
  
  app_tags                          = var.app_tags
  application_name                  = var.application_name
  vpc_id                            = var.vpc_id
  ec2_subnets                       = var.ec2_subnets
  elb_subnets                       = var.elb_subnets
  instance_type                     = var.instance_type
  disk_size                         = var.disk_size
  keypair                           = var.keypair
  sshrestrict                       = var.sshrestrict
  
}
