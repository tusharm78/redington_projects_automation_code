region = "ap-south-1"



app_tags = "EBS"

application_name = "EBS-App"

vpc_id = "vpc-0d27522d2fc85eaf9"

ec2_subnets = "subnet-004b5c85717cb8d5e"

elb_subnets = ["subnet-004b5c85717cb8d5e","subnet-066edc3edcf17b87e"]

instance_type = "t3.micro"

disk_size = "20"

keypair = "devopstools"

sshrestrict="0.0.0.0/0"

