####  backend configuration  #####
terraform {
  backend "s3" {
    bucket = "mybucket"                   #replace with the project specific bucketname
    key    = "backend/terraform.tfstate"
    region = "us-east-1"                  #replce the region
    dynamodb_table = "terraform-state-lock-DO-NOT-DELETE"          #do not change the dynamoDB table name
  }
}
