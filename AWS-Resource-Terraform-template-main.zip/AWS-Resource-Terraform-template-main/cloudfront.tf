locals {
 alb_origin_id = "mylb"
}

resource "aws_cloudfront_distribution" "ec2_distribution" {
  origin {
    #domain_name              = aws_eip.static_ip.public_dns
    domain_name = aws_elastic_beanstalk_environment.beanstalkappenv.endpoint_url
 #  origin_access_control_id = aws_cloudfront_origin_access_control.demoorigin.id
    origin_id                = local.alb_origin_id
    #origin_id = aws_elastic_beanstalk_environment.beanstalkappenv.endpoint_url
    custom_origin_config {
      http_port              = 80
      https_port             = 443
      origin_protocol_policy = "match-viewer"
      origin_ssl_protocols   = ["TLSv1.2"]
      
    }
  }
web_acl_id = aws_wafv2_web_acl.aclexample23.arn

  enabled             = true
  is_ipv6_enabled     = false
  comment             = "TF Automation"
  aliases = [ "bobthebuild.com" ]
  
  
  


  default_cache_behavior {
    allowed_methods  = ["DELETE", "GET", "HEAD", "OPTIONS", "PATCH", "POST", "PUT"]
    cached_methods   = ["GET", "HEAD"]
    target_origin_id = local.alb_origin_id
    #cache_policy_id = "658327ea-f89d-4fab-a63d-7e88639e58f6"
cache_policy_id ="4135ea2d-6df8-44a3-9df3-4b5a84be39ad" #-caching disabled

 
    viewer_protocol_policy = "allow-all"
   # viewer_protocol_policy = "redirect-to-https"
    min_ttl                = 0
    default_ttl            = 3600
    max_ttl                = 86400
    
  }



  price_class = "PriceClass_All"

  restrictions {
    geo_restriction {
      restriction_type = "whitelist"
      locations        = ["US", "IN", "CA", "GB", "DE"]
    }
  }

  tags = {
    Environment = "production"
  }

  viewer_certificate {
    acm_certificate_arn = aws_acm_certificate.cert.arn
    minimum_protocol_version = "TLSv1.2_2021"
    cloudfront_default_certificate = false
    ssl_support_method = "sni-only"
   
  }

depends_on = [aws_elastic_beanstalk_application.elasticapp, aws_elastic_beanstalk_environment.beanstalkappenv, aws_wafv2_web_acl.aclexample23]

tags_all = merge({ Pack_Name = var.resource_tags_name }, { Created_by = "Terraform Automation", Distributor_name = "Redington" } , { creation_date = "Mention the date here"})


}
