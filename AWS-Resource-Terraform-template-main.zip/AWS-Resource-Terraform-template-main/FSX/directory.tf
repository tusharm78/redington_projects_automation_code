#### this configuration file creates the aws_directory_service_directory ####

## create aws_directory_service_directory ##



## creates AWS Managed Microsoft AD ##
resource "aws_directory_service_directory" "ms-connector-ad" {
  name     = "corp.notexample.com"                              ## provide the name as per the needs
  password = "SuperSecretPassw0rd"
  edition  = "Standard"
  type     = "MicrosoftAD"              #this creates AWS Managed Microsoft AD

  vpc_settings {
    vpc_id     = aws_vpc.main.id
    subnet_ids = [aws_subnet.foo.id, aws_subnet.bar.id]
  }

  tags = {
    Project = "foo"
  }
}

## creates Simple AD ##
resource "aws_directory_service_directory" "simple-id" {  
  name     = "corp.notexample.com"                          ## provide the name as per the needs
  password = "SuperSecretPassw0rd"
  size     = "Small"

  vpc_settings {
    vpc_id     = aws_vpc.main.id
    subnet_ids = [aws_subnet.foo.id, aws_subnet.bar.id]
  }

  tags = {
    Project = "foo"
  }
}

/*
## creates Simple AD connector##
resource "aws_directory_service_directory" "connector" {
  name     = "corp.notexample.com"                          # ## provide the name of the domain
  password = "SuperSecretPassw0rd"
  size     = "Small"
  type     = "ADConnector"

  connect_settings {
    customer_dns_ips  = ["A.B.C.D"]
    customer_username = "Admin"
    subnet_ids        = [aws_subnet.foo.id, aws_subnet.bar.id]
    vpc_id            = aws_vpc.main.id
  }
}
*/


resource "aws_vpc" "main" {
  cidr_block = "10.0.0.0/16"
}

resource "aws_subnet" "foo" {
  vpc_id            = aws_vpc.main.id
  availability_zone = "us-west-2a"
  cidr_block        = "10.0.1.0/24"
}

resource "aws_subnet" "bar" {
  vpc_id            = aws_vpc.main.id
  availability_zone = "us-west-2b"
  cidr_block        = "10.0.2.0/24"
}
