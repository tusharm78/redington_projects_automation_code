/*
#### this configuration file creates the aws fsx  file systems and the KMS key ####
## choose the corresponding block on FSX as per the requirement and ignore the rest ##


##  AWS fsx windows file system  ##
resource "aws_fsx_windows_file_system" "example" {
  active_directory_id = aws_directory_service_directory.bar.id
  kms_key_id          = aws_kms_key.a.arn
  storage_capacity    = 300                                             #minimum storage capacity will be 32
  deployment_type = "MULTI_AZ_1"                                        #by default deployment type will be single az 
  subnet_ids          = [aws_subnet.bar.id, aws_subnet.foo.id]          #if it is single AZ only one subnet id is enough
  preferred_subnet_id = aws_subnet.bar.id                               #while using multi AZ one preferred subnet id is required  
  throughput_capacity = 1024
  depends_on = [ aws_directory_service_directory.bar ]              #directory should have been created frst if not better to pass depends on
}

## aws kms key creation ##
resource "aws_kms_key" "a" {
  description             = "KMS key 1"
  deletion_window_in_days = 10
}


resource "aws_fsx_ontap_file_system" "test" {
  storage_capacity    = 1024                                            ##minimum storage capacity will be 1024
  subnet_ids          = [aws_subnet.bar.id, aws_subnet.foo.id]          #if it is single AZ only one subnet id is enough
  deployment_type     = "MULTI_AZ_1"                                    # #by default deployment type will be single az                                 
  throughput_capacity = 512 
  preferred_subnet_id = aws_subnet.bar.id                               #while using multi AZ one preferred subnet id is required  
  depends_on = [ aws_directory_service_directory.bar ]              #directory should have been created frst if not better to pass depends on
}



resource "aws_fsx_openzfs_file_system" "test" {
  storage_capacity    = 64
  subnet_ids          = [aws_subnet.bar.id]
  deployment_type     = "SINGLE_AZ_1"
  throughput_capacity = 64
}
*/

resource "aws_fsx_lustre_file_system" "example" {
  #import_path      = "s3://${aws_s3_bucket.example.bucket}"          #include a s3 bucket path if needed
  storage_capacity = 1200
  subnet_ids       = [aws_subnet.bar.id]
}