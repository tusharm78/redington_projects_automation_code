variable "aws_region" {
    description = "Enter the region"
    type = string
    default = "us-west-2"      # enter the value according to your requirement
}
