#######
# Resource block to import server certificate
#######

resource "aws_acm_certificate" "server_vpn_cert" {
  certificate_body  = var.server_cert
  private_key       = var.server_private_key
  certificate_chain = var.ca_cert
}

#######
# Resource block to import client certificate
#######

resource "aws_acm_certificate" "client_vpn_cert" {
  certificate_body  = var.client_cert
  private_key       = var.client_private_key
  certificate_chain = var.ca_cert
}