#######
# Data block to get existing resource details
#######
data "aws_vpc" "vpc" {
  id = var.vpc_id
}

data "aws_security_group" "sg" {
  id = var.security_group_id
}

#######
# Resource block to create client vpn endpoint
#######


resource "aws_ec2_client_vpn_endpoint" "my_client_vpn" {
  description            = var.vpn_endpoint_description
  server_certificate_arn = aws_acm_certificate.server_vpn_cert.arn
  client_cidr_block      = var.client_cidr_block
  vpc_id                 = data.aws_vpc.vpc.id

  security_group_ids = [data.aws_security_group.sg.id]
  split_tunnel       = var.split_tunnel

  # Client authentication
  authentication_options {
    type                       = var.authentication_type
    root_certificate_chain_arn = aws_acm_certificate.client_vpn_cert.arn
  }

  connection_log_options {
    enabled = var.connection_log_options
  }

  client_login_banner_options {
    banner_text = var.banner_text
    enabled     = var.banner_text_enable
  }

  depends_on = [
    aws_acm_certificate.server_vpn_cert,
    aws_acm_certificate.client_vpn_cert
  ]

  tags = var.vpn_endpoint_tags
}

#######
# Resource block to associate subnet
#######

resource "aws_ec2_client_vpn_network_association" "client_vpn_association_private" {
  client_vpn_endpoint_id = aws_ec2_client_vpn_endpoint.my_client_vpn.id
  subnet_id              = var.private_subnet_id
}

#######
# Resource block to create authorization rule
#######

resource "aws_ec2_client_vpn_authorization_rule" "authorization_rule" {
  client_vpn_endpoint_id = aws_ec2_client_vpn_endpoint.my_client_vpn.id

  target_network_cidr  = var.authorization_target_network_cidr
  authorize_all_groups = var.authorize_all_groups
}