terraform {
  required_providers {
    aws = {
      source  = "hashicorp/aws"
      version = "5.94.0"
    }
  }
}

provider "aws" {
  region     = "" #Provide the region
  access_key = "" #Provide the access key
  secret_key = "" #Provide the secret access key
}
