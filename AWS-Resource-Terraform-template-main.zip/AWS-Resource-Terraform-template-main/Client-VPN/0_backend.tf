terraform {  
  backend "s3" {  
    bucket       = ""  #Provide the S3 bucket name
    key          = ""  #Provide the file name with prefix(directory name). Ex: terraform/tfstatefile.tfstate
    region       = ""  #Provide the required region
    use_lockfile = true  #S3 native locking
  }  
}