#######
# Variables for data source
#######

variable "vpc_id" {
  description = "The VPC ID"
}

variable "security_group_id" {
  description = "The security group ID of the VPC"
}

#######
# Variables for Server certificates and key
#######

variable "server_cert" {
  description = "Contents of the server.crt file"
}

variable "server_private_key" {
  description = "Contents of the server.key file"
}

variable "ca_cert" {
  description = "Contents of the ca.crt file"
}

#######
# Variables for Client certificates and key
#######

variable "client_cert" {
  description = "Contents of the client1.domain.tld.crt file"
}

variable "client_private_key" {
  description = "Contents of the client1.domain.tld.key"
}

#######
# Variables for VPN Endpoint
#######

variable "vpn_endpoint_description" {
  description = "A brief description of the Client VPN endpoint"
}

variable "client_cidr_block" {
  description = "The IPv4 address range, in CIDR notation, from which to assign client IP addresses. The address range cannot overlap with the local CIDR of the VPC in which the associated subnet is located, or the routes that you add manually. The address range cannot be changed after the Client VPN endpoint has been created. The CIDR block should be /22 or greater."
}

variable "split_tunnel" {
  description = "Indicates whether split-tunnel is enabled on VPN endpoint. Default value is false"
}

variable "authentication_type" {
  description = "The type of client authentication to be used. Specify certificate-authentication to use certificate-based authentication, directory-service-authentication to use Active Directory authentication, or federated-authentication to use Federated Authentication via SAML 2.0"
}

variable "connection_log_options" {
  description = "Information about the client connection logging options."
}

variable "banner_text" {
  description = "Customizable text that will be displayed in a banner on AWS provided clients when a VPN session is established. UTF-8 encoded characters only. Maximum of 1400 characters."
}

variable "banner_text_enable" {
  description = "Enable or disable a customizable text banner that will be displayed on AWS provided clients when a VPN session is established. The default is false (not enabled)."
}

variable "vpn_endpoint_tags" {
  type        = map(any)
  description = "A mapping of tags"
}

#######
# Variables for subnet association
#######

variable "private_subnet_id" {
  description = "The ID of the subnet to associate with the Client VPN endpoint."
}

#######
# Variables for authorization rule
#######

variable "authorization_target_network_cidr" {
  description = "The IPv4 address range, in CIDR notation, of the network to which the authorization rule applies"
}

variable "authorize_all_groups" {
  description = "Indicates whether the authorization rule grants access to all clients. One of access_group_id or authorize_all_groups must be set."
}