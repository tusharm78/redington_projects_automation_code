resource "aws_route53_zone" "main" {
name = "demosite2.com"

tags = {
Environment = "Prod"
}
}

resource "aws_route53_record" "main-ns" {
zone_id = aws_route53_zone.main.zone_id
name = "example1234.com"
type = "NS"
ttl = "30"
records = aws_route53_zone.main.name_servers
}

/*
resource "aws_route53_record" "www" {
zone_id = aws_route53_zone.main.zone_id
name = "www.example1234.com"
type = "A"
ttl = 300
#value = [aws_instance.my-ec2-vm.static_ip]
records = [var.staticip]
}
*/