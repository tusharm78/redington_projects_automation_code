variable "s3domainname" {
description = "Enter the Regional Domain Name of the S3 Bucket"
type = string
}
