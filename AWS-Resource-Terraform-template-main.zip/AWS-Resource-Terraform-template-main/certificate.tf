
resource "aws_acm_certificate" "cert" {
  domain_name       = "bobthebuild.com"
  validation_method = "DNS"
  key_algorithm = "RSA_2048"
  

tags_all = merge({ Pack_Name = var.resource_tags_name }, { Created_by = "Terraform Automation", Distributor_name = "Redington" } , { creation_date = "Mention the date here"})

  lifecycle {
    create_before_destroy = true
  }
}

resource "aws_route53_record" "hello_cert_dns" {
  allow_overwrite = true
  name =  tolist(aws_acm_certificate.cert.domain_validation_options)[0].resource_record_name
  records = [tolist(aws_acm_certificate.cert.domain_validation_options)[0].resource_record_value]
  type = tolist(aws_acm_certificate.cert.domain_validation_options)[0].resource_record_type
  zone_id = aws_route53_zone.main.zone_id
  ttl = 60
}
