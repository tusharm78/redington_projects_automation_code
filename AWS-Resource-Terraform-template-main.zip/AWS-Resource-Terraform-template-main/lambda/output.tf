

# Define outputs to display information about created resources

output "lambda_function_name" {
  value = aws_lambda_function.example.function_name  # Output the name of the Lambda function
}

output "runtime" {
  description = "The runtime environment for the Lambda function"
  value       = var.runtime   # output of the language that is used
}


output "lambda_function_arn" {
  value = aws_lambda_function.example.arn  # Output the ARN of the Lambda function
}

output "bucket_name" {
  value = aws_s3_bucket.example_bucket.bucket  
  description = "The name of the bucket where the ZIP file is stored."  # Description for better understanding
}

output "bucket_object_key" {
  value = aws_s3_object.example_object.key  # Output the key under which the ZIP file is stored
  description = "The key under which the ZIP file is stored."  # Description for better understanding
}

