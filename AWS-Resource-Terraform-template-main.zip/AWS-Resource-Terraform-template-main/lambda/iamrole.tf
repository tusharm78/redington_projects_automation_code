# Define an IAM role for the Lambda function
resource "aws_iam_role" "lambda_execution_role" {
  # Specify the name of the IAM role
  name = "lambda_execution_role"

  # Define the trust policy allowing Lambda to assume this role
  assume_role_policy = jsonencode({
    Version = "2012-10-17",
    Statement = [
      {
        Action    = "sts:AssumeRole",
        Effect    = "Allow",
        Principal = {
          Service = "lambda.amazonaws.com"
        }
      }
    ]
  })
}