# Define an S3 bucket for storing Lambda function code
resource "aws_s3_bucket" "example_bucket" {
  # Concatenate the bucket name with a random suffix
  bucket = var.bucket_name
}

# Define an S3 object for uploading the Lambda function code
  resource "aws_s3_object" "example_object" {
  # Reference the bucket created above
  bucket = aws_s3_bucket.example_bucket.id

  # Specify the key (filename) for the object
  key    = var.bucket_object_key

  # Specify the local path to the zip file to upload
  source = var.local_zip_path
}