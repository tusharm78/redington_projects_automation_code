provider "aws" {
  region = "ap-south-1"  # Specify the desired AWS region
}
