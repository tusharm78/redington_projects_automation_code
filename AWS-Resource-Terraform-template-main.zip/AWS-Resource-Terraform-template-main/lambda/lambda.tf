resource "aws_lambda_function" "example" {
  
  function_name = var.function_name  # Name of the Lambda function
  s3_bucket     = aws_s3_bucket.example_bucket.id  # S3 bucket where function code is stored
  s3_key        = aws_s3_object.example_object.key  # S3 object (zip file) containing function code
  handler       = var.handler  # Function entry point in code
  runtime       = var.runtime  # Runtime environment for Lambda function
  role          = aws_iam_role.lambda_execution_role.arn  # IAM role for Lambda function
}
