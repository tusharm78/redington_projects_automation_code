variable "bucket_name" {
  description  = "Name of the bucket (Unique)"
  type         = string
  #default      = "" #name of the unique bucket name
}

# Define variables for configuring the Lambda function and S3 bucket
variable "function_name" {
  description = "The name of the Lambda function"
  type        = string       
  #default     = ""
}

variable "runtime" {
  description = "The runtime environment for the Lambda function"
  type        = string       
  #default     = ""    #language to be used 
}

variable "handler" {
  description = "The function entry point in your code"
  type        = string
  default     = "filename.handler_function"  # Default handler function
}

variable "region" {
  description = "The AWS region to deploy resources into"
  type        = string    # prefered region
  #default     = ""
}

variable "local_zip_path" {
  description = "Local path to the zip file to be uploaded to S3"
  type        = string           # Default local path
  #default     = ""
  }

variable "bucket_acl" {
  description = "The access control settings for the bucket"
  type        = string
  default     = "private"  # Default bucket ACL
}

variable "bucket_object_key" {
   description = "The name of the bucket key" 
   type        = string 
   #default    = "" # key.zip format

}
