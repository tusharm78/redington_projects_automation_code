#create rule for starting ec2 instances
resource "aws_cloudwatch_event_rule" "ec2_start" {
  name        = "EC2_Start_daily"
  description = "Trigger EC2 start instance daily"
  
  schedule_expression = "cron(50 7 * * ? *)"
}

#create resource to attach lambda as a target to cloud watch event 
resource "aws_cloudwatch_event_target" "lambda_function" {
  target_id = "lambda"
  rule      = aws_cloudwatch_event_rule.ec2_start.name
  arn       = aws_lambda_function.terraform_lambda_func.arn
}

#allowing permission execution of lambda from cloud watch
resource "aws_lambda_permission" "allow_cloudwatch" {
  statement_id  = "AllowExecutionFromCloudWatch"
  action        = "lambda:InvokeFunction"
  function_name = aws_lambda_function.terraform_lambda_func.function_name  #function_name
  principal     = "events.amazonaws.com"
  source_arn    = aws_cloudwatch_event_rule.ec2_start.arn
  
}

output "teraform_aws_clouwatch_schedule_output" {
  value = aws_cloudwatch_event_rule.ec2_start.schedule_expression
}