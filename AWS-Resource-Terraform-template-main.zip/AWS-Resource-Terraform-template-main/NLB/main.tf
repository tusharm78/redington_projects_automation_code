# Main Configuration file for Terraform
#------------------------------------------------------------------
# Network Load Balancer
#------------------------------------------------------------------

#data "aws_subnet" "selected" {
#  id = "subnet-0801fc2589a56a93a"
#}

resource "aws_lb" "test" {
  name               = "test-nlb-tf"
  internal           = false
  load_balancer_type = "network"
  subnets             = ["subnet-0801fc2589a56a93a"]
  
  enable_deletion_protection = true

  tags = {
    Environment = "production"
  }
}
