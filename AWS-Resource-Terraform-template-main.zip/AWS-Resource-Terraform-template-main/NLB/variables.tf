
# -Declare input Variables 

variable "subnet_id" {
  description = "The Subnet ID to deploy the NLB"
  type = string
  default = "subnet-06f0709289e6731fa"     # enter the value according to your requirement
  }

variable "aws_region" {
    description = "ap-south-1"
    type = string
    default = "ap-south-1"      # enter the value according to your requirement
}
