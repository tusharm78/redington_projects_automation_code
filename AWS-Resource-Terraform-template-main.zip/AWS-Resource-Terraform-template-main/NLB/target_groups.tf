
# Configuration for Target groups
#--------------------------------------------------------------------------
# target_group
#--------------------------------------------------------------------------
resource "aws_lb_target_group" "test" {
  name     = "NLBtg"
  port     = 80
  protocol = "TCP"
  vpc_id   = "vpc-0cdbda063aac2c33d"
}

resource "aws_vpc" "main" {
  cidr_block = "10.0.0.0/16"
}
