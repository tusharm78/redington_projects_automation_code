
resource "aws_route53_zone" "main" {

name = "bobthebuild.com"




tags_all = merge({ Pack_Name = var.resource_tags_name }, { Created_by = "Terraform Automation", Distributor_name = "Redington" } , { creation_date = "Mention the date here"})



}







/*

resource "aws_route53_record" "www" {

zone_id = aws_route53_zone.main.zone_id

name = "bobthebuild123456.com"

type = "CNAME"

ttl = 300

#value = [aws_instance.my-ec2-vm.static_ip]
#records = [aws_acm_certificate.cert.CNAME_value]
records = [aws_elastic_beanstalk_environment.beanstalkappenv.endpoint_url]
#records =  [aws_cloudfront_distribution.ec2_distribution.distribution_domain_name]
#depends_on = [ aws_elastic_beanstalk_environment.beanstalkappenv ]
}

*/
/*
resource "aws_route53_record" "www" {
  zone_id = aws_route53_zone.main.zone_id
  name    = "www.bobthebuild.com"
  type    = "A"
  #ttl     = 300
 # records = [aws_cloudfront_distribution.ec2_distribution.domain_name]
  alias {
    name                   = aws_cloudfront_distribution.ec2_distribution.domain_name
    zone_id                = aws_route53_zone.main.zone_id
    evaluate_target_health = false
  }
  depends_on = [ aws_cloudfront_distribution.ec2_distribution ]
}
*/
