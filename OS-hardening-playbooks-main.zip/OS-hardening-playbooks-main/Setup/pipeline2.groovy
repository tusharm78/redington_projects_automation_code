properties([
    parameters([
        choice(
            choices: ['Ubuntu_Linux_1.yml', 'Ubuntu_Linux_2.yml', 'Ubuntu_Linux_3.yml', 'Ubuntu_Linux_4.yml', 'Ubuntu_Linux_5.yml', 'Ubuntu_Linux_6.yml'],
            description: 'Select the playbook',
            name: 'Playbook'
        ),
        string(
            defaultValue: '',
            description: 'Enter the Group Name',
            name: 'GroupName'
        ),
        choice(
            choices: ['inventory.yml', 'inventory2.yml', 'inventory3.yml'],
            description: 'Select the inventory file',
            name: 'InventoryFile'
        ),
        string(
            defaultValue: '',
            description: 'Enter the GitHub Repository URL',
            name: 'GitHubURL'
        )
    ])
])

pipeline {
    agent any

    stages {
        stage("Check Parameters") {
            steps {
                script {
                    // Check if GroupName is provided
                    if (!params.GroupName?.trim()) {
                        error("Group Name is required. Please enter a valid Group Name.")
                    }
                    echo "Using Group Name: ${params.GroupName}"

                    // Check if GitHubURL is provided
                    if (!params.GitHubURL?.trim()) {
                        error("GitHub Repository URL is required. Please enter a valid URL.")
                    }
                    echo "Using GitHub Repository URL: ${params.GitHubURL}"
                }
            }
        }
        stage("Git") {
            steps {
                // Checkout code from the specified GitHub repository
                checkout scmGit(
                    branches: [[name: '*/main']], 
                    extensions: [], 
                    userRemoteConfigs: [[
                        credentialsId: 'jenkins-pipeline-token', 
                        url: params.GitHubURL // Use the GitHub URL parameter
                    ]]
                )
            }
        }
        stage("Playbook Execution") {
            steps {
                script {
                    // Construct the playbook path based on the selected playbook
                    def playbookPath = "Ubuntu/${params.Playbook}"
                    // Construct extraVars as a map
                    def extraVars = [group_name: params.GroupName]
                    // Execute the Ansible playbook with the given parameters
                    ansiblePlaybook(
                        credentialsId: 'Ubuntu1', 
                        disableHostKeyChecking: true, 
                        installation: 'Ansible', 
                        inventory: params.InventoryFile, // Use the selected inventory file
                        playbook: playbookPath, // Use the constructed playbook path
                        extraVars: extraVars, // Pass the extraVars map
                        vaultTmpPath: ''
                    )
                }
            }
        }
    }
}
