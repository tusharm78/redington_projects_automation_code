# OS-hardening-playbooks
Ansible Plaubooks for OS hardening
