/*
resource "azurerm_resource_group" "log" {
  name     = var.rg_shared_name
  location = var.deploy_location
}
*/

# Creates Log Anaylytics Workspace
resource "azurerm_log_analytics_workspace" "law" {
  name                = "log-redington"
  location            = "Central India"
  resource_group_name = "Terraform-RG"
  sku                 = "PerGB2018"
  retention_in_days   = 30
}