variable "azurerm_linux_web_app" {
  default = "azureappserverg"
}

variable "location" {
  default = "eastus"
}