# Create the resource group
/*
resource "azurerm_resource_group" "rg" {
  name     = "myResourceGroup-${random_integer.ri.result}"
  location = "eastus"
}
*/

# Create the Linux App Service Plan
resource "azurerm_service_plan" "appserviceplan" {
  name                = "webapp-asp"
  location            = "Central India"
  resource_group_name = "Terraform-RG"
  os_type             = "Linux"
  sku_name            = "B1"
  }


# Create the web app, pass in the App Service Plan ID
resource "azurerm_linux_web_app" "webapp" {
  name                  = "redington-webapp-001"
  location              = "Central India"
  resource_group_name   = "Terraform-RG"
  service_plan_id       = azurerm_service_plan.appserviceplan.id
  https_only            = true
  site_config { 
    minimum_tls_version = "1.2"
  }
}

