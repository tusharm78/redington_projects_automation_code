# variable for region
variable "aws_region" {
description = "Region"
type = string
default = "ap-south-1"    #change the region wrt to reqiurement
}

variable "aws_vpc" {
    description = "vpc"
    type = string
    default = "10.1.1.0/24"
  
}
variable "aws_availability_zone" {
    description = "availability zone 1"
    type = string
    default = "ap-south-1a"
  
}
variable "ec2_ami_id" {
    description = "ec2"
    type = string
    default = "ami-007020fd9c84e18c7"
  
}
variable "ec2_instance_type" {
    description = "instancetype"
    type = string
    default = "t3.micro"
  }

variable "os_disk" {
    description = "volumesize"
    type = string
    default = "30"
  
}
variable "os_disk_type" {
    description = "volumetype"
    type = string
    default = "gp3" 
}
variable "aws_key_pair" {
    description = "keypair"
    type = string
    default = "manjeshtesttf.pem"
  
}

variable "data_disk" {
    description = "volumesize"
    type = string
    default = "30"
  
}
variable "data_disk_type" {
    description = "volumetype"
    type = string
    default = "gp3" 
}