#!/bin/bash

## this installs mysql 
sudo apt-get update
sudo apt-get install mysql-server
sudo systemctl start mysql.service
