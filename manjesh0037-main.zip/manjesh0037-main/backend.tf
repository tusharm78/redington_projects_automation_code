terraform {
  backend "s3" {
    bucket = "aaritya-tfstate-backend-2023"                   #replace with the project specific bucketname
    key    = "backend/manjesh/terraform.tfstate"
    region = "ap-south-1"                  #replce the region
    #dynamodb_table = "terraform-state-lock-DO-NOT-DELETE-nazeer"          #do not change the dynamoDB table name
  }
}