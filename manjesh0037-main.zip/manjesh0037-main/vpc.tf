# Create VPC
resource "aws_vpc" "vpc-dev" {
  cidr_block = var.aws_vpc
  enable_dns_hostnames = true
   tags = {
        Name        = "manjeshtf-vpc-1"     
        Created-by  = "Terraform_Automation" 
        Created-time = timestamp()
    }
}

# Create Subnets
resource "aws_subnet" "vpc-dev-public-subnet-1" {
  vpc_id                  = aws_vpc.vpc-dev.id
  cidr_block              = "10.1.1.0/28"
  availability_zone       = var.aws_availability_zone
  map_public_ip_on_launch = true
  tags = {
    Name = "TF-PublicSubnet"
  }
}

/*resource "aws_subnet" "vpc-dev-private-subnet-1" {
  vpc_id                  = aws_vpc.vpc-dev.id
  cidr_block              = "10.1.1.0/28"
  availability_zone       = var.aws_availability_zone
  map_public_ip_on_launch = true
  tags = {
    Name = "TF-PublicSubnet"
  }
}*/

#create routetable
resource "aws_route_table" "vpc_dev_Prt" {
  vpc_id = aws_vpc.vpc-dev.id
  tags = {
    Name = "PublicRT"
  }
}
#create route table association
resource "aws_route_table_association" "vpc_dev_association" {
  route_table_id = aws_route_table.vpc_dev_Prt.id
  subnet_id = aws_subnet.vpc-dev-public-subnet-1.id
}
#Route addition
resource "aws_route" "vpc_dev_publicRT" {
  route_table_id = aws_route_table.vpc_dev_Prt.id
  destination_cidr_block = "0.0.0.0/0"
  gateway_id = aws_internet_gateway.vpc_dev-igw.id
}

#igw creation
resource "aws_internet_gateway" "vpc_dev-igw" {
  vpc_id = aws_vpc.vpc-dev.id
  tags = {
    Name = "manjeshigwtf"
  }
}
