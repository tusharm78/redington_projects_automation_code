###########
# Here, we are referencing the existing resource group & proximity placement group
###########

data "azurerm_resource_group" "rg" {
  name = var.resource_group_name #Provide the resource group name
}

data "azurerm_proximity_placement_group" "ppg" {
  name                = var.proximity_placement_group_name
  resource_group_name = data.azurerm_resource_group.rg.name # Referencing the resource group name
}

########
# Resource block to create availability set
########

resource "azurerm_availability_set" "availability_set" {
  name                         = var.availability_set_name
  location                     = data.azurerm_resource_group.rg.location # Referencing the location of resource group
  resource_group_name          = data.azurerm_resource_group.rg.name # Referencing the resource group name
  platform_update_domain_count = var.platform_update_domain_count
  platform_fault_domain_count  = var.platform_fault_domain_count
  proximity_placement_group_id = data.azurerm_proximity_placement_group.ppg.id # Referencing the proximity placement group id
  tags                         = var.tags
}

