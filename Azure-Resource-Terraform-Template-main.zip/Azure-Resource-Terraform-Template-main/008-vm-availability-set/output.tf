########
# Output block to get vm availability set id
########

output "vm_availability_set_id" {
  value = azurerm_availability_set.availability_set.id # Provides the id of vm availability set
}