######
# Variables for data block
######

variable "resource_group_name" {
  description = "name of the resource group"
  type        = string
  default     = "" # Provide the resource group name
}

variable "proximity_placement_group_name" {
  description = ""
  type        = string
  default     = "" # Provide the proximity placement group name
}

###########
# Availability set variables
###########

variable "availability_set_name" {
  description = "Specifies the name of the availability set."
  type        = string
  default     = "" # Provide the name for availability set
}

variable "platform_update_domain_count" {
  description = "Specifies the number of update domains that are used. Defaults to 5"
  type        = number
  default     = "" # Provide the platform update domain count
}

variable "platform_fault_domain_count" {
  description = "Specifies the number of fault domains that are used. Defaults to 3"
  type        = number
  default     = "" # Provide the platform fault domain count
}

variable "managed" {
  description = "Specifies whether the availability set is managed or not. Possible values are true (to specify aligned) or false (to specify classic). Default is true"
  type        = bool
  default     = "" # Provide the options for whether the availability set is managed or not 
}

variable "tags" {
  description = "tags for the availability set"
  type        = map(any)
  default = {
     "Created_By" = "Terraform_Automation" #This is a mandatory tag
    #"Environment" = "Prod" #You can modify this tag according to your needs
  }
}
