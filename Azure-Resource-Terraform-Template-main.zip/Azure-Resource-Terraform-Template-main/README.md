# This repository contains the terraform templates for the azure resources. All the terraform templates are sepearted into seperated directories for the azure resources.

## To maintain the stability & reliability of the code, please follow the below mentioned instructions.

## Code for each & every resource should be seperated into folders. For ex: resource group and virtual network are seperated into folders as below.

#### If one resource has multiple sub resources, the main & sub resources should be seperated into files as below. 
#### Ex: Virtual network has subnet

#### Below mentioned list of files are mandatory for each & every resource.

    1. provider.tf
    2. backend.tf
    3. resource-name.tf Ex: public-ip.tf, data-disk-attachment.tf
    4. var.tf
    5. output.tf

### Comments are mandatory to know about the code. So, We need to mention the comments as below.

backend.tf
![screenshot of a comment of backend.tf file showing am image](/images/backend.jpg)

resource-name.tf
![screenshot of a comment of resource-name.tf file showing am image](/images/resource.jpg)

var.tf
![screenshot of a comment of var.tf file showing am image](/images/var.jpg)

output.tf
![screenshot of a comment of output.tf file showing am image](/images/ouput.jpg)