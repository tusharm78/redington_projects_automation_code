########
#  Variables for data blocks - Site recovery
########

variable "primary_location" {
  description = "Primary location for resources"
  type        = string
  default     = "Central India" # Primary the primary location
}

variable "secondary_location" {
  description = "Secondary location for resources"
  type        = string
  default     = "Central India" # provide the Secondary Location
}

variable "primary_resource_group_name" {
  description = "Name of the primary resource group"
  type        = string
  default     = "Keerthana-RG" # Provide the primary resource group name
}

variable "secondary_resource_group_name" {
  description = "Name of the secondary resource group"
  type        = string
  default     = "Keerthana-2-RG" # provide the secondary Resource group name 
}

variable "automation_account_name" {
  description = "Name of the automation account"
  type        = string
  default     = "demovault-774-asr-automationaccount" # Provide the automation account name 
}

variable "storage_account_name" {
  description = "Name of the storage account"
  type        = string
  default     = "primaryrecoverycache" # Provide the storage account name 
}

variable "virtual_network_name" {
  description = "Name of the virtual network"
  type        = string
  default     = "asr-vnet" # Provide the virtual network name  
}

variable "subnet_name" {
  description = "Name of the subnet"
  type        = string
  default     = "default" # Provide the subnet name 
}

variable "subnet_address_prefix" {
  description = "Address prefix of the subnet"
  type        = string
  default     = "10.1.0.0/24" # Provide the subnet address prefix 
}

variable "public_ip_name" {
  description = "Name of the public IP"
  type        = string
  default     = "vm-public-ip" # Provide the Public ip name 
}

variable "recovery_vault_name" {
  description = "Name of the recovery services vault"
  type        = string
  default     = "example-recovery-vault" # Provide the Recovery Vault name 
}

variable "site_recovery_fabric_name" {
  description = "Name of the site recovery fabric"
  type        = string
  default     = "primary-fabric" # Provide the site recovery fabric name 
}
