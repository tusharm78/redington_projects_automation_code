#####
# Data block to get the information about existing resources
#####

data "azurerm_resource_group" "primary_rg" {
  name = var.primary_resource_group_name
}

data "azurerm_virtual_network" "primary_vnet" {
  name                = var.primary_virtual_network_name
  resource_group_name = data.azurerm_resource_group.primary_rg.name
}

data "azurerm_subnet" "primary_subnet" {
  name                 = var.primary_subnet_name
  resource_group_name  = data.azurerm_resource_group.primary_rg.name
  virtual_network_name = data.azurerm_virtual_network.primary_vnet.name
}

data "azurerm_virtual_machine" "vm" {
  name                = var.vm_name
  resource_group_name = var.primary_resource_group_name
}

#####
# Resource block to create a new network interface
#####

resource "azurerm_network_interface" "vm" {
  name                = "vm-nic"
  location            = var.primary_location
  resource_group_name = var.primary_resource_group_name

  ip_configuration {
    name                          = "vm"
    subnet_id                     = data.azurerm_subnet.primary_subnet.id
    private_ip_address_allocation = "Dynamic"
    public_ip_address_id          = azurerm_public_ip.primary.id
    virtual_machine_id = data.azurerm_virtual_machine.vm.id
  }
}
