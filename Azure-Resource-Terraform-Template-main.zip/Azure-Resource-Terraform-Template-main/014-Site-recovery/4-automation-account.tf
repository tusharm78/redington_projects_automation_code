########
# Automation Account
########

resource "azurerm_automation_account" "example" {
  name                = var.automation_account_name
  location            = var.primary_location
  resource_group_name = var.primary_resource_group_name
  sku_name            = "Basic"
}
