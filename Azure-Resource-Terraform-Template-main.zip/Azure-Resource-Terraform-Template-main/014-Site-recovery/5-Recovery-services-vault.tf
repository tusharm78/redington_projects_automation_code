########
# Recovery Services Vault
########

resource "azurerm_recovery_services_vault" "vault" {
  name                = var.recovery_vault_name
  location            = var.secondary_location
  resource_group_name = var.secondary_resource_group_name
  sku                 = "Standard"
}
