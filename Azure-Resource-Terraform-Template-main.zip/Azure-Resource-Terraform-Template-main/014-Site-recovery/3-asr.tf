########
# Resource Group for Primary Location
########

resource "azurerm_resource_group" "primary" {
  name     = var.primary_resource_group_name
  location = var.primary_location
}

########
# Resource Group for Secondary Location
########

resource "azurerm_resource_group" "secondary" {
  name     = var.secondary_resource_group_name
  location = var.secondary_location
}


########
# Site Recovery Fabric
########

resource "azurerm_site_recovery_fabric" "primary" {
  name                = var.site_recovery_fabric_name
  resource_group_name = var.secondary_resource_group_name
  recovery_vault_name = var.recovery_vault_name
  location            = azurerm_resource_group.primary.location
}
