########
# Storage Account
########

resource "azurerm_storage_account" "primary" {
  name                     = var.storage_account_name
  location                 = var.primary_location
  resource_group_name      = var.primary_resource_group_name
  account_tier             = "Standard"
  account_replication_type = "LRS"
}
