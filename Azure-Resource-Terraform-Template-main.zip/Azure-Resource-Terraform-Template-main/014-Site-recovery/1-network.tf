########
# Virtual Network
########

resource "azurerm_virtual_network" "primary" {
  name                = var.virtual_network_name
  location            = var.primary_location
  resource_group_name = var.primary_resource_group_name
  address_space       = [var.subnet_address_prefix]
}

########
# Subnet
########

resource "azurerm_subnet" "primary" {
  name                 = var.subnet_name
  resource_group_name  = var.primary_resource_group_name
  virtual_network_name = azurerm_virtual_network.primary.name
  address_prefixes     = [var.subnet_address_prefix]
}

########
# Public IP for Primary Location
########

resource "azurerm_public_ip" "primary" {
  name                = "${var.public_ip_name}-primary"
  location            = var.primary_location
  resource_group_name = var.primary_resource_group_name
  sku                 = "Basic"
  allocation_method   = "Static"
}

########
# Public IP for Secondary Location
########

resource "azurerm_public_ip" "secondary" {
  name                = "${var.public_ip_name}-secondary"
  location            = var.secondary_location
  resource_group_name = var.secondary_resource_group_name
  sku                 = "Basic"
  allocation_method   = "Dynamic"
}

