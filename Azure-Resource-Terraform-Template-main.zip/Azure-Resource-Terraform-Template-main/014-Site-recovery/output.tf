
#########
  #  Output file to for Site Recovery               
#########



output "primary_resource_group_id" {
  value = azurerm_resource_group.primary.id  # It provides the Primary Resource Group id
}

output "secondary_resource_group_id" {
  value = azurerm_resource_group.secondary.id  # it provides the secondary Resource Group id
}

output "automation_account_id" {
  value = azurerm_automation_account.example.id # It provides the automation account id 
}

output "storage_account_id" {
  value = azurerm_storage_account.primary.id  # It provides the Storage Account id 
}

output "virtual_network_id" {
  value = azurerm_virtual_network.primary.id # It provides the virtual network id
}

output "subnet_id" {
  value = azurerm_subnet.primary.id # It provides the subnet id
}

output "public_ip_primary_id" {
  value = azurerm_public_ip.primary.id # It provides the public ip of primary id 
}

output "public_ip_secondary_id" {
  value = azurerm_public_ip.secondary.id # It provides the public ip of the secondary id
}

output "network_interface_vm_id" {
  value = azurerm_network_interface.vm.id # It provides the network interface 
} 

output "recovery_vault_id" {
  value = azurerm_recovery_services_vault.vault.id # It provides the recovery vault id 
}

output "site_recovery_fabric_id" {
  value = azurerm_site_recovery_fabric.primary.id # It provides the Site recovery fabric id 
}
