######
# Output block to get details about peering
######

output "hub_to_spoke_vnet_peering_id" {
  value       = azurerm_virtual_network_peering.hub_to_spoke_vnet_peering.id
  description = "The ID of the Virtual Network Peering"
}

output "spoke_to_hub_vnet_peering" {
  value       = azurerm_virtual_network_peering.spoke_to_hub_vnet_peering.id
  description = "The ID of the Virtual Network Peering"
}