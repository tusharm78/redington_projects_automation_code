########
# Data block to get the information about existing resources
########

data "azurerm_resource_group" "spoke_rg" {
  name = var.spoke_resource_group_name
}

data "azurerm_virtual_network" "spoke_vnet" {
  name                = var.spoke_virtual_network_name
  resource_group_name = data.azurerm_resource_group.spoke_rg.name # Referencing the spoke resource group name
}

########
# Resource block to create spoke_to_hub vnet peering
########

resource "azurerm_virtual_network_peering" "spoke_to_hub_vnet_peering" {
  name                         = var.peering_name_1
  resource_group_name          = data.azurerm_resource_group.spoke_rg.name    # Referencing the spoke resource group name
  virtual_network_name         = data.azurerm_virtual_network.spoke_vnet.name # Referencing the spoke virtual network name
  remote_virtual_network_id    = data.azurerm_virtual_network.hub_vnet.id     # Referencing the spoke virtual network id
  allow_virtual_network_access = var.allow_virtual_network_access_1
  allow_forwarded_traffic      = var.allow_forwarded_traffic_1
  allow_gateway_transit        = var.allow_gateway_transit_1
  use_remote_gateways          = var.use_remote_gateways_1
}