##########
# Variables for data blocks
##########

variable "hub_resource_group_name" {
  description = "name of the resource group"
  type        = string
  default     = "" # Provide the hub resource group name
}

variable "hub_virtual_network_name" {
  description = "name of the virtual network"
  type        = string
  default     = "" # Provide the hub virtual network name
}

variable "spoke_resource_group_name" {
  description = "name of the resource group"
  type        = string
  default     = "" # Provide the spoke resource group name
}

variable "spoke_virtual_network_name" {
  description = "name of the virtual network"
  type        = string
  default     = "" # Provide the spoke virtual network name
}

##########
# Variables for vnet peering hub to spoke
##########

variable "peering_name" {
  description = "The name of the virtual network peering"
  type        = string
  default     = "" #Provide a name for peering. Ex: peer_hub_to_spoke
}

variable "allow_virtual_network_access" {
  description = "Controls if the VMs in the remote virtual network can access VMs in the local virtual network. Defaults to true"
  type        = bool
  default     = "" #Provide a boolean value
}

variable "allow_forwarded_traffic" {
  description = "Controls if forwarded traffic from VMs in the remote virtual network is allowed. Defaults to false"
  type        = bool
  default     = "" #Provide a boolean value
}

variable "allow_gateway_transit" {
  description = "Controls gatewayLinks can be used in the remote virtual network’s link to the local virtual network. Defaults to false"
  type        = bool
  default     = "" #Provide a boolean value
}

variable "use_remote_gateways" {
  description = "Controls if remote gateways can be used on the local virtual network. If the flag is set to true, and allow_gateway_transit on the remote peering is also true, virtual network will use gateways of remote virtual network for transit. Only one peering can have this flag set to true. This flag cannot be set if virtual network already has a gateway. Defaults to false"
  type        = bool
  default     = "" #Provide a boolean value
}

##########
# Variables for vnet peering spoke to hub
##########

variable "peering_name_1" {
  description = "The name of the virtual network peering"
  type        = string
  default     = "" #Provide a name for peering. Ex: peer_spoke_to_hub
}

variable "allow_virtual_network_access_1" {
  description = "Controls if the VMs in the remote virtual network can access VMs in the local virtual network. Defaults to true"
  type        = bool
  default     = "" #Provide a boolean value
}

variable "allow_forwarded_traffic_1" {
  description = "Controls if forwarded traffic from VMs in the remote virtual network is allowed. Defaults to false"
  type        = bool
  default     = "" #Provide a boolean value
}

variable "allow_gateway_transit_1" {
  description = "Controls gatewayLinks can be used in the remote virtual network’s link to the local virtual network. Defaults to false"
  type        = bool
  default     = "" #Provide a boolean value
}

variable "use_remote_gateways_1" {
  description = "Controls if remote gateways can be used on the local virtual network. If the flag is set to true, and allow_gateway_transit on the remote peering is also true, virtual network will use gateways of remote virtual network for transit. Only one peering can have this flag set to true. This flag cannot be set if virtual network already has a gateway. Defaults to false"
  type        = bool
  default     = "" #Provide a boolean value
}