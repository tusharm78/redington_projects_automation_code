########
# Data block to get the information about existing resources
########

data "azurerm_resource_group" "hub_rg" {
  name = var.hub_resource_group_name
}

data "azurerm_virtual_network" "hub_vnet" {
  name                = var.hub_virtual_network_name
  resource_group_name = data.azurerm_resource_group.hub_rg.name # Referencing the hub resource group name
}

########
# Resource block to create hub_to_spoke vnet peering
########

resource "azurerm_virtual_network_peering" "hub_to_spoke_vnet_peering" {
  name                         = var.peering_name
  resource_group_name          = data.azurerm_resource_group.hub_rg.name    # Referencing the hub resource group name
  virtual_network_name         = data.azurerm_virtual_network.hub_vnet.name # Referencing the hub virtual network name
  remote_virtual_network_id    = data.azurerm_virtual_network.spoke_vnet.id # Referencing the hub virtual network id
  allow_virtual_network_access = var.allow_virtual_network_access
  allow_forwarded_traffic      = var.allow_forwarded_traffic
  allow_gateway_transit        = var.allow_gateway_transit
  use_remote_gateways          = var.use_remote_gateways
}

