######
# Variables for data block
######

variable "resource_group_name" {
  description = "The name of the resource group"
  type = string
  default = "" # Provide the resource group name
}

variable "mssql_server_name" {
  description = "The name of the MSSQL Server"
  type = string
  default = "" # Provide the MSSQL server name
}

variable "mssql_elasticpool_name" {
  description = "The name of the MSSQL Elasticpool"
  type = string
  default = "" # Provide the MSSQL elasticpool name
}

#########
# MS_SQL database variables
#########

variable "sql_db_name" {
  type        = string
  description = "The name of the MS SQL Database."
  default = "" #Provide the name for SQL database
}

variable "collation" {
  type        = string
  description = "Specifies the collation of the database"
  default = "" #Provide the collation for the database. Default value is SQL_LATIN1_GENERAL_CP1_CI_AS
}

variable "license_type" {
  type        = string
  description = "Specifies the license type applied to this database. Possible values are LicenseIncluded and BasePrice"
  default = "" #Provide the license type of the database
}

variable "max_size_gb" {
  type        = number
  description = "The max size of the database in gigabytes"
  default = "" #Provide the max size for the database
}

variable "sku_name" {
  type        = string
  description = "Specifies the name of the SKU used by the database. For example, GP_S_Gen5_2,HS_Gen4_1,BC_Gen5_2, ElasticPool, Basic,S0, P2 ,DW100c, DS100"
  default = "" #Provide the sku name which will be used by the database
}

variable "storage_account_type" {
  type        = string
  description = "Specifies the storage account type used to store backups for this database. Possible values are Geo, GeoZone, Local and Zone. Defaults to Geo"
  default = "" #Provide the storage account used to store backups for this database
}

variable "geo_backup_enabled" {
  type        = string
  description = "A boolean that specifies if the Geo Backup Policy is enabled. Defaults to true"
  default = "" #Provide the boolean value to enable or disable geo backup
}

variable "transparent_data_encryption_enabled" {
  type        = string
  description = "If set to true, Transparent Data Encryption will be enabled on the database. Defaults to true"
  default = "" #Provide the boolean value to enable or disable
}

variable "tags" {
  description = "tags for the SQL database"
  type        = map(any)
  default = {
     "Created_By" = "Terraform_Automation" #This is a mandatory tag
    #"Environment" = "Prod" #You can modify this tag according to your needs
  }
}