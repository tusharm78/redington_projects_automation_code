# Below are the list of inputs needed to create MS-SQL database

- SQL database name
- Resource group name 
- Location 
- SQL server name
- SQL Elastic Pool name
- Collation
- Tags (optional)