########
# Output block to get sql db name
########

output "sql_db_name" {
  value = azurerm_mssql_database.sql_db.name # Provides the sql database name
}