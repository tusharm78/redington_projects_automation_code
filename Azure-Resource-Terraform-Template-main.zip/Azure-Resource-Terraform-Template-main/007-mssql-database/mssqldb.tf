###########
# Here, we are referencing the existing SQL server & SQL elastic pool id
###########

data "azurerm_mssql_server" "sql_server" {
  name                = var.mssql_server_name 
  resource_group_name = var.resource_group_name 
}

data "azurerm_mssql_elasticpool" "sql_elastic_pool" {
  name                = var.mssql_elasticpool_name 
  resource_group_name = var.resource_group_name 
  server_name         = data.azurerm_mssql_server.sql_server.name # Referencing the existing SQL server name
}

########
# Resource block to create Azure SQL database
########

resource "azurerm_mssql_database" "sql_db" {
  name                                = var.sql_db_name
  server_id                           = data.azurerm_mssql_server.sql_server.id # Here we are reference the existing SQL server id
  collation                           = var.collation
  license_type                        = var.license_type
  max_size_gb                         = var.max_size_gb
  sku_name                            = var.sku_name
  storage_account_type                = var.storage_account_type
  geo_backup_enabled                  = var.geo_backup_enabled
  transparent_data_encryption_enabled = var.transparent_data_encryption_enabled
  elastic_pool_id                     = data.azurerm_mssql_elasticpool.sql_elastic_pool.id # Here we are reference the existing SQL elastic pool id
  tags                                = var.tags

  # prevent the possibility of accidental data loss
  lifecycle {
    prevent_destroy = true # If, its true, prevents the accidental deletion by running destroy command. If you want to delete change it to false, then run destroy command
  }

}