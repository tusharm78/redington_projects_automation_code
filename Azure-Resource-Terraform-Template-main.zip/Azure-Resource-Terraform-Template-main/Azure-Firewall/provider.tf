provider "azurerm" {
  features {}
}
