########
# Resource block to create managed grafanna dashboard
########

resource "azurerm_dashboard_grafana" "grafanna" {
  name                              = var.grafanna_name
  resource_group_name               = data.azurerm_resource_group.rg.name
  location                          = data.azurerm_resource_group.rg.location
  grafana_major_version             = var.grafanna_version
  api_key_enabled                   = var.api_key_enabled
  deterministic_outbound_ip_enabled = var.deterministic_outbound_ip_enabled

  azure_monitor_workspace_integrations {
    resource_id = azurerm_monitor_workspace.azure_monitor_workspace.id
  }

  identity {
    type = var.grafanna_identity_type
  }

  public_network_access_enabled = var.grafanna_public_network_access_enabled
  sku                           = var.grafanna_sku
  tags                          = var.tags
}