########
# Resource block to create azure monitor data collection endpoint for linux
########

resource "azurerm_monitor_data_collection_endpoint" "dce_linux" {
  name                          = "linux-dce-${data.azurerm_resource_group.rg.location}-${azurerm_kubernetes_cluster.aks_cluster.name}"
  resource_group_name           = data.azurerm_resource_group.rg.name
  location                      = data.azurerm_resource_group.rg.location
  kind                          = var.dce_linux_kind
  public_network_access_enabled = var.endpoint_public_network_access_enabled
  description                   = var.endpoint_description
  tags                          = var.tags
}

########
# Resource block to create azure monitor data collection endpoint for windows
########

resource "azurerm_monitor_data_collection_endpoint" "dce_windows" {
  name                          = "windows-dce-${data.azurerm_resource_group.rg.location}-${azurerm_kubernetes_cluster.aks_cluster.name}"
  resource_group_name           = data.azurerm_resource_group.rg.name
  location                      = data.azurerm_resource_group.rg.location
  kind                          = var.dce_windows_kind
  public_network_access_enabled = var.endpoint_public_network_access_enabled
  description                   = var.endpoint_description_1
  tags                          = var.tags
}