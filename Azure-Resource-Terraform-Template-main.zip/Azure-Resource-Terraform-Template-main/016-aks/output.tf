######
# Output  block to get details about the AKS cluster
######

output "private_fqdn" {
  value = azurerm_kubernetes_cluster.aks_cluster.dns_prefix_private_cluster # The FQDN of the private cluster
}

output "oidc_issuer_url" {
  value = azurerm_kubernetes_cluster.aks_cluster.oidc_issuer_url
}

######
# Output  block to get details about the Azure Monitor Workspace
######

output "azure_monitor_ws_id" {
  value = azurerm_monitor_workspace.azure_monitor_workspace.id # The ID of the azure monitor workspace
}

output "azure_monitor_ws_query_endpoint" {
  value = azurerm_monitor_workspace.azure_monitor_workspace.query_endpoint # The query endpoint of the azure monitor workspace
}

output "azure_monitor_ws_default_data_collection_endpoint_id" {
  value = azurerm_monitor_workspace.azure_monitor_workspace.default_data_collection_endpoint_id # The default data collection endpoint id of the azure monitor workspace
}

output "azure_monitor_ws_default_data_collection_rule_id" {
  value = azurerm_monitor_workspace.azure_monitor_workspace.default_data_collection_rule_id # The default data collection rule id of the azure monitor workspace
}

######
# Output  block to get details about the grafanna
######

output "grafana_url" {
  value = azurerm_dashboard_grafana.grafanna.endpoint # The grafanna endpoint URL to login grafanna
}


