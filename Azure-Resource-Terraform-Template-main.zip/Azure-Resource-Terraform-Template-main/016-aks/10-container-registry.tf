
resource "azurerm_container_registry" "container_registry" {
  name                          = var.container_registry_name
  resource_group_name           = data.azurerm_resource_group.rg.name
  location                      = data.azurerm_resource_group.rg.location
  sku                           = var.container_registry_sku
  admin_enabled                 = var.admin_enabled
  public_network_access_enabled = var.container_registry_public_network_access_enabled
}