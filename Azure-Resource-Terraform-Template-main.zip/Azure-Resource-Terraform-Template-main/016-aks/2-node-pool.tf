########
# Resource block to create kubernetes cluster node pool - windows
########

resource "azurerm_kubernetes_cluster_node_pool" "win_node_pool" {
  name                  = var.windows_node_pool_name
  kubernetes_cluster_id = azurerm_kubernetes_cluster.aks_cluster.id
  vm_size               = var.windows_node_vm_size
  auto_scaling_enabled  = var.windows_node_pool_auto_scale
  max_count             = var.windows_node_pool_max_count
  min_count             = var.windows_node_pool_min_count
  node_count            = var.windows_node_pool_count
  os_sku                = var.windows_node_os_sku
  os_type               = var.windows_node_os_type
  tags                  = var.tags
}

########
# Resource block to create kubernetes cluster node pool - linux
########

resource "azurerm_kubernetes_cluster_node_pool" "linux_node_pool" {
  name                  = var.linux_node_pool_name
  kubernetes_cluster_id = azurerm_kubernetes_cluster.aks_cluster.id
  vm_size               = var.linux_node_vm_size
  auto_scaling_enabled  = var.linux_node_pool_auto_scale
  max_count             = var.linux_node_pool_max_count
  min_count             = var.linux_node_pool_min_count
  node_count            = var.linux_node_pool_count
  os_sku                = var.linux_node_os_sku
  os_type               = var.linux_node_os_type
  tags                  = var.tags
}