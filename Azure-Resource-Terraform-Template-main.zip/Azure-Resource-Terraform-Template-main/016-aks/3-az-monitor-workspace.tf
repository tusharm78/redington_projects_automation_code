########
# Resource block to create azure monitor workspace
########

resource "azurerm_monitor_workspace" "azure_monitor_workspace" {
  name                          = var.azure_monitor_workspace_name
  resource_group_name           = data.azurerm_resource_group.rg.name
  location                      = data.azurerm_resource_group.rg.location
  public_network_access_enabled = var.public_network_access_enabled
  tags                          = var.tags
}