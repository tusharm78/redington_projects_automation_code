terraform {
  required_providers {
    azurerm = {
      source  = "hashicorp/azurerm"
      version = "4.1.0"
    }
  }
  required_version = "~> 1.9.3"
}

provider "azurerm" {
  features {}
  subscription_id = var.subscription_id # You can refer your subscription id from variable. If you don't want to hardcode, you can store id in jenkins and refer that
}

data "azurerm_client_config" "current" {}