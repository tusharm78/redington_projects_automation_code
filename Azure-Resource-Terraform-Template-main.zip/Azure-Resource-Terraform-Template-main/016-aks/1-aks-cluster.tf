########
# Data block for referencing the existing resources
########

data "azurerm_resource_group" "rg" {
  name = var.resource_group_name
}

data "azurerm_subnet" "aks_private_subnet" {
  name                 = var.aks_private_subnet_name
  virtual_network_name = var.virtual_network_name
  resource_group_name  = data.azurerm_resource_group.rg.name
}

data "azurerm_subnet" "app_gateway_subnet" {
  name                 = var.app_gateway_subnet_name
  virtual_network_name = var.virtual_network_name
  resource_group_name  = data.azurerm_resource_group.rg.name
}

# Below data source is used to get the latest version of kubernetes
data "azurerm_kubernetes_service_versions" "current" {
  location        = data.azurerm_resource_group.rg.location
  include_preview = var.k8s_version_preview
}

########
# Resource block to create kubernetes cluster
########

resource "azurerm_kubernetes_cluster" "aks_cluster" {
  name                = var.cluster_name
  location            = data.azurerm_resource_group.rg.location
  resource_group_name = data.azurerm_resource_group.rg.name

  default_node_pool {
    name                 = var.node_pool_name
    vm_size              = var.node_vm_size
    auto_scaling_enabled = var.auto_scaling_enabled
    vnet_subnet_id       = data.azurerm_subnet.aks_private_subnet.id
    max_count            = var.max_count
    min_count            = var.min_count
    node_count           = var.node_count
  }

  identity {
    type = var.identity_type
  }

  dns_prefix = "${var.cluster_name}-cluster"

  ingress_application_gateway {
    subnet_id = data.azurerm_subnet.app_gateway_subnet.id
  }

  kubernetes_version = data.azurerm_kubernetes_service_versions.current.latest_version

  linux_profile {
    admin_username = var.admin_username
    ssh_key {
      key_data = file(var.ssh_key_data) # Referencing the public SSH key local path
    }
  }

  local_account_disabled = var.local_account_disabled


  monitor_metrics {
    annotations_allowed = var.annotations_allowed
    labels_allowed      = var.labels_allowed
  }

  network_profile {
    network_plugin = var.network_plugin
  }

  node_os_upgrade_channel = var.node_os_channel_upgrade
  node_resource_group     = var.node_resource_group
  oidc_issuer_enabled     = var.oidc_issuer_enabled

  # oms_agent {
  #   #log_analytics_workspace_id = data.azurerm_log_analytics_workspace.log_analytics_workspace.id
  #   msi_auth_for_monitoring_enabled = var.msi_auth_for_monitoring_enabled
  # }

  open_service_mesh_enabled = var.open_service_mesh_enabled
  private_cluster_enabled   = var.private_cluster_enabled
  
}