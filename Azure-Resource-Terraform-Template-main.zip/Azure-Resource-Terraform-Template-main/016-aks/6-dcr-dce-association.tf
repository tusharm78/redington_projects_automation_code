########
# Resource block to associate the data collection rule
########

resource "azurerm_monitor_data_collection_rule_association" "dcr_to_aks" {
  name                    = var.dcr_association_name
  target_resource_id      = azurerm_kubernetes_cluster.aks_cluster.id
  data_collection_rule_id = azurerm_monitor_data_collection_rule.dcr.id
  description             = var.dcra_description
  depends_on              = [azurerm_monitor_data_collection_rule.dcr]
}
