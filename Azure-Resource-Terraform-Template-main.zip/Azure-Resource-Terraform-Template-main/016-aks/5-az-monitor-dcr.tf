########
# Resource block to create data collection rule
########

resource "azurerm_monitor_data_collection_rule" "dcr" {
  name                        = "msprom-linux-dcr-${data.azurerm_resource_group.rg.location}-${azurerm_kubernetes_cluster.aks_cluster.name}"
  resource_group_name         = data.azurerm_resource_group.rg.name
  location                    = data.azurerm_resource_group.rg.location
  data_collection_endpoint_id = azurerm_monitor_data_collection_endpoint.dce_linux.id
  kind                        = var.dcr_kind

  data_sources {
    prometheus_forwarder {
      name    = var.prometheus_forwarder_name
      streams = var.prometheus_forwarder_streams
    }
  }

  destinations {
    monitor_account {
      monitor_account_id = azurerm_monitor_workspace.azure_monitor_workspace.id
      name               = azurerm_monitor_workspace.azure_monitor_workspace.name
    }
  }

  data_flow {
    streams      = var.data_flow_streams
    destinations = [azurerm_monitor_workspace.azure_monitor_workspace.name]
  }

  depends_on = [azurerm_monitor_data_collection_endpoint.dce_linux]

}