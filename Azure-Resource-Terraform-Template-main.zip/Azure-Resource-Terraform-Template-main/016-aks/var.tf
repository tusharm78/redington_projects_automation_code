##########
# Variables for data blocks
##########

variable "subscription_id" {
  description = "Azure subscription ID"
  type = string 
  default = "" # Provide the subscription id
}

variable "resource_group_name" {
  description = "The name of the resource group in which the Log Analytics workspace is located in"
  type        = string
  default     = "" # Provide the resource group name
}

variable "virtual_network_name" {
  description = "The name of the virtual network"
  type        = string
  default     = "" # Provide the virtual network name
}

variable "aks_private_subnet_name" {
  description = "The name of the subnet used for aks cluster"
  type        = string
  default     = "" # Provide the subnet name
}

variable "app_gateway_subnet_name" {
  description = "The name of the subnet used for app gateway"
  type        = string
  default     = "" # Provide the subnet name
}

variable "k8s_version_preview" {
  description = "Should Preview versions of Kubernetes in AKS be included? Defaults to true"
  type        = bool
  default     = "" # Provide the boolean value
}

######
# Variables for AKS cluster
######

variable "cluster_name" {
  description = "value"
  type        = string
  default     = "" # Provide the name for kubernetes cluster
}

variable "node_pool_name" {
  description = "The name which should be used for the default Kubernetes Node Pool"
  type        = string
  default     = "" # Provide the name for node pool
}

variable "node_vm_size" {
  description = "The size of the Virtual Machine, such as Standard_DS2_v2"
  type        = string
  default     = "" # Provide the VM Size
}

variable "auto_scaling_enabled" {
  description = "Should the Kubernetes Auto Scaler be enabled for this Node Pool?"
  type        = bool
  default     = "" # Provide the boolean value to enable/disable autoscaling
}

variable "max_count" {
  description = "The maximum number of nodes which should exist within this Node Pool. Valid values are between 0 and 1000 and must be greater than or equal to min_count"
  type        = number
  default     = "" # Provide the count for maximum
}

variable "min_count" {
  description = "The minimum number of nodes which should exist within this Node Pool. Valid values are between 0 and 1000 and must be less than or equal to max_count"
  type        = number
  default     = "" # Provide the count for minimum
}

variable "node_count" {
  description = "The initial number of nodes which should exist in this Node Pool. If specified this must be between 1 and 1000 and between min_count and max_count"
  type        = number
  default     = "" # Provide the count for node pool
}

variable "identity_type" {
  description = "Specifies the type of Managed Service Identity that should be configured on this Kubernetes Cluster. Possible values are SystemAssigned or UserAssigned"
  type        = string
  default     = "" # Provide the identity type
}

variable "admin_username" {
  description = "The Admin Username for the Cluster"
  type        = string
  default     = "" # Provide the name for the admin
}

variable "ssh_key_data" {
  description = "The Public SSH Key used to access the cluster"
  type        = string
  default     = "" # Provide the public SSH key
}

variable "local_account_disabled" {
  description = "If local_account_disabled is set to true, it is required to enable Kubernetes RBAC and AKS-managed Azure AD integration"
  type        = bool
  default     = "" # Provide the boolean value
}

variable "annotations_allowed" {
  description = "Specifies a comma-separated list of Kubernetes annotation keys that will be used in the resource's labels metric."
  type        = string
  default     = "" # Provide the appropriate value
}

variable "labels_allowed" {
  description = "Specifies a Comma-separated list of additional Kubernetes label keys that will be used in the resource's labels metric"
  type        = string
  default     = "" # Provide the appropriate value
}

variable "network_plugin" {
  description = "Network plugin to use for networking. Currently supported values are azure, kubenet and none"
  type        = string
  default     = "" # Provide the appropriate value
}

variable "node_os_channel_upgrade" {
  description = "The upgrade channel for this Kubernetes Cluster Nodes' OS Image. Possible values are Unmanaged, SecurityPatch, NodeImage and None"
  type        = string
  default     = "" # Provide the appropriate value
}

variable "node_resource_group" {
  description = "The name of the Resource Group where the Kubernetes Nodes should exist"
  type        = string
  default     = "" # Provide the name for resource group
}

variable "oidc_issuer_enabled" {
  description = "Enable or Disable the OIDC issuer URL"
  type        = bool
  default     = "" # Provide the boolean value
}

variable "msi_auth_for_monitoring_enabled" {
  description = "Is managed identity authentication for monitoring enabled?"
  type        = bool
  default     = "" # Provide the boolean value
}

variable "open_service_mesh_enabled" {
  description = "Is Open Service Mesh enabled?"
  type        = bool
  default     = "" # Provide the boolean value
}

variable "private_cluster_enabled" {
  description = "Should this Kubernetes Cluster have its API server only exposed on internal IP addresses? This provides a Private IP Address for the Kubernetes API on the Virtual Network where the Kubernetes Cluster is located. Defaults to false"
  type        = bool
  default     = "" # Provide the boolean value
}

variable "tags" {
  type        = map(any)
  description = "A mapping of tags which should be assigned to the VM"
  default = {
    "Created_By"  = "Terraform_Automation" #This is a mandatory tag
    #"Environment" = "Prod" #You can modify this tag according to your needs
  }
}

######
# Variables for windows node pool
######

variable "windows_node_pool_name" {
  description = "The name of the Node Pool which should be created within the Kubernetes Cluster. A Windows Node Pool cannot have a name longer than 6 characters"
  type        = string
  default     = "" # Provide the name for pool. It must not exceed 6 characters

  validation {
    condition     = length(var.windows_node_pool_name) <= 6
    error_message = "A Windows Node Pool cannot have a name longer than 6 characters"
  }

}

variable "windows_node_vm_size" {
  description = "The size of the Virtual Machine, such as Standard_DS2_v2"
  type        = string
  default     = "" # Provide the VM Size
}

variable "windows_node_pool_auto_scale" {
  description = "Whether to enable auto-scaler"
  type        = bool
  default     = "" # Provide the boolean value to enable/disable autoscaling
}

variable "windows_node_pool_max_count" {
  description = "The maximum number of nodes which should exist within this Node Pool. Valid values are between 0 and 1000 and must be greater than or equal to min_count"
  type        = number
  default     = "" # Provide the count for node pool
}

variable "windows_node_pool_min_count" {
  description = "The minimum number of nodes which should exist within this Node Pool. Valid values are between 0 and 1000 and must be less than or equal to max_count"
  type        = number
  default     = "" # Provide the count for node pool
}

variable "windows_node_pool_count" {
  description = "The initial number of nodes which should exist in this Node Pool. If specified this must be between 1 and 1000 and between min_count and max_count"
  type        = number
  default     = "" # Provide the count for node pool
}

variable "windows_node_os_sku" {
  description = "Specifies the OS SKU used by the agent pool. Possible values are AzureLinux, Ubuntu, Windows2019 and Windows2022"
  type        = string
  default     = "" # Provide the os sku type
}

variable "windows_node_os_type" {
  description = "The Operating System which should be used for this Node Pool. Possible values are Linux and Windows. Defaults to Linux"
  type        = string
  default     = "" # Provide the os type
}

######
# Variables for linux node pool
######

variable "linux_node_pool_name" {
  description = "The name of the Node Pool which should be created within the Kubernetes Cluster. A Windows Node Pool cannot have a name longer than 6 characters"
  type        = string
  default     = "" # Provide the name for pool
}

variable "linux_node_vm_size" {
  description = "The size of the Virtual Machine, such as Standard_DS2_v2"
  type        = string
  default     = "" # Provide the VM Size
}

variable "linux_node_pool_auto_scale" {
  description = "Whether to enable auto-scaler"
  type        = bool
  default     = "" # Provide the boolean value to enable/disable autoscaling
}

variable "linux_node_pool_max_count" {
  description = "The maximum number of nodes which should exist within this Node Pool. Valid values are between 0 and 1000 and must be greater than or equal to min_count"
  type        = number
  default     = "" # Provide the count for node pool
}

variable "linux_node_pool_min_count" {
  description = "The minimum number of nodes which should exist within this Node Pool. Valid values are between 0 and 1000 and must be less than or equal to max_count"
  type        = number
  default     = "" # Provide the count for node pool
}

variable "linux_node_pool_count" {
  description = "The initial number of nodes which should exist in this Node Pool. If specified this must be between 1 and 1000 and between min_count and max_count"
  type        = number
  default     = "" # Provide the count for node pool
}

variable "linux_node_os_sku" {
  description = "Specifies the OS SKU used by the agent pool. Possible values are AzureLinux, Ubuntu, Windows2019 and Windows2022"
  type        = string
  default     = "" # Provide the os sku type
}

variable "linux_node_os_type" {
  description = "The Operating System which should be used for this Node Pool. Possible values are Linux and Windows. Defaults to Linux"
  type        = string
  default     = "" # Provide the os type
}

######
# Variables for azure monitor workspace
######

variable "azure_monitor_workspace_name" {
  description = "Specifies the name which should be used for this Azure Monitor Workspace."
  type        = string
  default     = "" # Provide the name
}

variable "public_network_access_enabled" {
  description = "Is public network access enabled? Defaults to true"
  type        = bool
  default     = "" # Provide the boolean value
}

######
# Variables for azure data collection endpoint for Linux
######


variable "dce_linux_kind" {
  description = "he kind of the Data Collection Endpoint. Possible values are Linux and Windows"
  type        = string
  default     = "" # Provide the type of kind
}

variable "endpoint_public_network_access_enabled" {
  description = "Whether network access from public internet to the Data Collection Endpoint are allowed. Possible values are true and false. Default to true"
  type        = bool
  default     = "" # Provide the boolean value
}


variable "endpoint_description" {
  description = "Specifies a description for the Data Collection Endpoint."
  type        = string
  default     = "" # Provide the description for data collection endpoint
}

######
# Variables for azure data collection endpoint for Windows
######

variable "dce_windows_kind" {
  description = "he kind of the Data Collection Endpoint. Possible values are Linux and Windows"
  type        = string
  default     = "" # Provide the type of kind
}

variable "endpoint_description_1" {
  description = "Specifies a description for the Data Collection Endpoint."
  type        = string
  default     = "" # Provide the description
}


######
# Variables for data collection rule
######

variable "dcr_kind" {
  description = "The kind of the Data Collection Rule. Possible values are Linux, Windows, AgentDirectToStore and WorkspaceTransforms. A rule of kind Linux does not allow for windows_event_log data sources. And a rule of kind Windows does not allow for syslog data sources. If kind is not specified, all kinds of data sources are allowed."
  type        = string
  default     = "" # Provide the appropriate value
}

variable "prometheus_forwarder_name" {
  description = "The name which should be used for this data source. This name should be unique across all data sources regardless of type within the Data Collection Rule"
  type        = string
  default     = "" # Provide the name
}

variable "prometheus_forwarder_streams" {
  description = "Specifies a list of streams that this data source will be sent to. A stream indicates what schema will be used for this data and usually what table in Log Analytics the data will be sent to. Possible value is Microsoft-PrometheusMetrics"
  type        = list(string)
  default     = ["Microsoft-PrometheusMetrics"] # Provide the appropriate value
}

variable "data_flow_streams" {
  description = "Specifies a list of streams. Possible values include but not limited to Microsoft-Event, Microsoft-InsightsMetrics, Microsoft-Perf, Microsoft-Syslog, Microsoft-WindowsEvent, and Microsoft-PrometheusMetrics"
  type        = list(string)
  default     = ["Microsoft-PrometheusMetrics"] # Provide the appropriate value
}

######
# Variables for data collection rule association
######

variable "dcr_association_name" {
  description = "The name which should be used for this Data Collection Rule Association"
  type        = string
  default     = "" # Provide the name for data collection rule
}

variable "dcra_description" {
  description = "The description of the Data Collection Rule Association."
  type        = string
  default     = "" # Provide the description for data collection rule
}

######
# Variables for grafanna
######

variable "grafanna_name" {
  description = "Specifies the name which should be used for this Dashboard Grafana"
  type        = string
  default     = "" # Provide the name for grafanna
}

variable "grafanna_version" {
  description = "Which major version of Grafana to deploy. Possible values are 9, 10"
  type        = number
  default     = "" # Provide the version for grafanna
}

variable "api_key_enabled" {
  description = "Whether to enable the api key setting of the Grafana instance. Defaults to false"
  type        = bool
  default     = "" # Provide the boolean value
}

variable "deterministic_outbound_ip_enabled" {
  description = "Whether to enable the Grafana instance to use deterministic outbound IPs. Defaults to false"
  type        = bool
  default     = "" # Provide the boolean value
}

variable "grafanna_public_network_access_enabled" {
  description = "Whether to enable traffic over the public interface. Defaults to true"
  type        = bool
  default     = "" # Provide the boolean value
}

variable "grafanna_identity_type" {
  description = "Specifies the type of Managed Service Identity. Possible values are SystemAssigned, UserAssigned"
  type        = string
  default     = "" # Provide the appropriate value
}

variable "grafanna_sku" {
  description = "The name of the SKU used for the Grafana instance. Possible values are Standard and Essential. Defaults to Standard"
  type        = string
  default     = "" # Provide the apprpriate value
}


######
# Variables for role assignments
######


variable "data_reader_role" {
  description = "Used to assign the role"
  type        = string
  default     = "" # Provide the role name
}

variable "grafanna_admin_role" {
  description = "Used to assign the role"
  type        = string
  default     = "" # Provide the role name
}

variable "acr_pull_role" {
  description = "Used to assign the role"
  type        = string
  default     = "" # Provide the role name
}

variable "aad_check" {
  description = "If the principal_id is a newly provisioned Service Principal set this value to true to skip the Azure Active Directory check which may fail due to replication lag. This argument is only valid if the principal_id is a Service Principal identity. Defaults to false"
  type        = bool
  default     = "" # Provide the boolean value
}

######
# Variables for container registry
######

variable "container_registry_name" {
  description = "Specifies the name of the Container Registry. Only Alphanumeric characters allowed"
  type        = string
  default     = "" # Provide the name for container registry

  validation {
    condition     = can(regex("^[a-zA-Z0-9]*$", var.container_registry_name))
    error_message = "The value must only contain alphanumeric characters."
  }

}

variable "container_registry_sku" {
  description = "The SKU name of the container registry. Possible values are Basic, Standard and Premium"
  type        = string
  default     = "" # Provide the sku for container registry
}

variable "admin_enabled" {
  description = "Specifies whether the admin user is enabled. Defaults to false"
  type        = bool
  default     = "" # Provide the boolean value
}

variable "container_registry_public_network_access_enabled" {
  description = "Whether public network access is allowed for the container registry. Defaults to true"
  type        = bool
  default     = "" # Provide the boolean value. It can be disabled only for Premium SKU
}


