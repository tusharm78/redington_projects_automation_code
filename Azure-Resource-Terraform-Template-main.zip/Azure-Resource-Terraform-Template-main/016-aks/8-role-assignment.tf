########
# Resource block to assign the roles
########

# Assigning monitoring data reader role to current user 

resource "azurerm_role_assignment" "reader_role_to_user" {
  scope                = azurerm_monitor_workspace.azure_monitor_workspace.id
  role_definition_name = var.data_reader_role
  principal_id         = data.azurerm_client_config.current.object_id
}

#Assigning monitoring data reader role to grafanna

resource "azurerm_role_assignment" "reader_role_to_grafanna" {
  scope                = azurerm_monitor_workspace.azure_monitor_workspace.id
  role_definition_name = var.data_reader_role
  principal_id         = azurerm_dashboard_grafana.grafanna.identity[0].principal_id
}

# Assigning Grafanna admin role to current user 

resource "azurerm_role_assignment" "admin_role_to_user" {
  scope                = azurerm_dashboard_grafana.grafanna.id
  role_definition_name = var.grafanna_admin_role
  principal_id         = data.azurerm_client_config.current.object_id
}

# Assigning Acr pull role to K8s cluster

resource "azurerm_role_assignment" "pull_role_to_aks" {
  principal_id                     = azurerm_kubernetes_cluster.aks_cluster.kubelet_identity[0].object_id
  role_definition_name             = var.acr_pull_role
  scope                            = azurerm_container_registry.container_registry.id
  skip_service_principal_aad_check = var.aad_check
}
