########
# Resource block to create MS_SQL firewall rule
########

resource "azurerm_mssql_firewall_rule" "mssql_firewall_rule" {
  name             = var.firewall_rule_name             
  server_id        = azurerm_mssql_server.sql_server.id # Reference the existing SQL server
  start_ip_address = var.start_ip_address              
  end_ip_address   = var.end_ip_address                
}