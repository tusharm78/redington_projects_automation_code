# Below are the list of inputs needed to create MS-SQL Server

- SQL Server name
- Resource group name 
- Location 
- SQL Version 
- Admin login username 
- Admin login password 
- Public network access type 
- Tags (optional)