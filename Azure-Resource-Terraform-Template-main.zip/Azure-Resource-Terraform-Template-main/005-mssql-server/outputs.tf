######
# Output  block to get MS_SQL Server name & FQDN
######

output "sql_server_name" {
  description = "name of the sql server"
  value       = azurerm_mssql_server.sql_server.name
}

output "sql_server_fqdn" {
  description = "Fully qualified domain name of the sql server"
  value       = azurerm_mssql_server.sql_server.fully_qualified_domain_name 
}