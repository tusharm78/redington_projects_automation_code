########
# Data block for referencing the existing resources
########

data "azurerm_resource_group" "rg" {
  name = var.resource_group_name 
}

########
# Resource block to create MS_SQL server
########

resource "azurerm_mssql_server" "sql_server" {
  name                          = var.sql_server_name
  resource_group_name           = data.azurerm_resource_group.rg.name # Referencing the resource group name
  location                      = data.azurerm_resource_group.rg.location # Referencing the location
  version                       = var.sql_version
  administrator_login           = var.admin_login
  administrator_login_password  = var.admin_password
  public_network_access_enabled = var.public_network_access
  tags                          = var.tags
}
