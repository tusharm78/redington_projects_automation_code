######
# Variables for data block
######

variable "subnet_name" {
  description = "The name of the subnet"
  type        = string
  default     = "" # Provide the subnet name
}

variable "vnet_name" {
  description = "The name of the virtual network"
  type        = string
  default     = "" # Provide the vnet name
}

variable "resource_group_name" {
  description = "name of the resource group"
  type        = string
  default     = "" # Provide the resource group name
}

######
# MS_SQL Server Variables
######

variable "sql_server_name" {
  description = "name of the sql server"
  type        = string
  default     = "" #Provide the name for SQL server
}

variable "sql_version" {
  description = "The version for the new server. Valid values are: 2.0 (for v11 server) and 12.0 (for v12 server)"
  type        = string
  default     = "12.0" #Provide the version for the SQL server
}

variable "admin_login" {
  description = "The administrator login name for the new server. Required unless azuread_authentication_only in the azuread_administrator block is true. When omitted, Azure will generate a default username which cannot be subsequently changed."
  type        = string
  default     = "" #Provide the admin login name for the SQL server 
}

variable "admin_password" {
  description = "The password associated with the administrator_login"
  type        = string
  sensitive   = true
  default     = "" #Provide the password for the admin login
}

variable "public_network_access" {
  description = "public network access for the sql server. Ex: true or false"
  type        = string
  default     = "" #Provide the value for public network access
}

variable "tags" {
  description = "tags for the sql server"
  type        = map(string)
  default = {
    "Created_By" = "Terraform_Automation" #This is a mandatory tag
    #"Environment" = "Prod" #You can modify this tag according to your needs
  }
}

######
# MS_SQL Firewall Rules Variables
######

variable "firewall_rule_name" {
  description = "The name of the firewall rule"
  type        = string
  default     = "" #Provide the firewall rule name 
}

variable "start_ip_address" {
  description = "The starting IP address to allow through the firewall for this rule."
  type        = string
  default     = "" #Provide the IP address to allow in firewall
}

variable "end_ip_address" {
  description = "The ending IP address to allow through the firewall for this rule."
  type        = string
  default     = "" #Provide the end IP address to allow in firewall
}

######
# MS_SQL Virtual Network Rules Variables
######

variable "vnet_rule_name" {
  description = "The name of the SQL virtual network rule"
  type        = string
  default     = "" # Provide the name for vnet rule
}

