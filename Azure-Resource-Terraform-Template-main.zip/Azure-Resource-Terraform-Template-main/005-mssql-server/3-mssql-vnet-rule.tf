######
# Here, we are getting the existing subnet information
######

data "azurerm_subnet" "subnet" {
  name                 = var.subnet_name                     
  virtual_network_name = var.vnet_name                       
  resource_group_name  = data.azurerm_resource_group.rg.name # Referencing the resource group name
}

######
# Resource block to create Virtual Network rule
######

resource "azurerm_mssql_virtual_network_rule" "vnet_rule" {
  name      = var.vnet_rule_name 
  server_id = azurerm_mssql_server.sql_server.id # Reference the existing SQL server
  subnet_id = data.azurerm_subnet.subnet.id      # Reference the existing subnet
}