######
# Variables for data blocks
######

variable "resource_group_name" {
  description = "Name of the resource group"
  type        = string
  default     = "" #Provide the existing resource group name
}

variable "virtual_network_name" {
  description = "Name of the Virtual Network"
  type        = string
  default     = "" #Provide the existing virtual network name
}

variable "subnet_name" {
  description = "Name of the subnet"
  type        = string
  default     = "" #Provide the existing subnet name
}

######
# Variables for Virtual machine scale set
######

variable "vm_name" {
  description = "The name of the Linux Virtual Machine Scale Set"
  type        = string
  default     = "" #Provide the name for VM Scale Set
}

variable "admin_username" {
  description = "The username of the local administrator on each Virtual Machine Scale Set instance."
  type        = string
  default     = "" #Provide the username
}

variable "admin_password" {
  description = "The password of the local administrator on each Virtual Machine Scale Set instance."
  type        = string
  default     = "" #Provide the password
}

variable "disable_password_authentication" {
  description = "Should Password Authentication be disabled on this Virtual Machine"
  type        = string
  default     = "" #Provide the password authentication methods. Possible values are true and false. If you want to use password authentication, use false 
}

variable "instances" {
  description = "The number of Virtual Machines in the Scale Set. Defaults to 0"
  type        = number
  default     = "" #Provide the count to launch number of instances
}

variable "vm_sku" {
  description = "The Virtual Machine SKU for the Scale Set, such as Standard_F2"
  type        = string
  default     = "" #Provide the VM Size
}

######
# Network interface variables
######

variable "network_interface_name" {
  description = "Name of the network interface"
  type        = string
  default     = "" #Provide the name for the network interface
}

variable "network_interface_primary" {
  description = "Is this the Primary IP Configuration?"
  type        = bool
  default     = "" # Provide the boolean value. If its the primary nic, provide the value as true else false
}

variable "ip_configuration_name" {
  description = "The Name which should be used for this IP Configuration"
  type        = string
  default     = "" # Provide the name for ip configuration. Ex: ipconfiguration1
}

variable "ip_configuration_primary" {
  description = "Is this the Primary IP Configuration for this Network Interface?"
  type        = bool
  default     = "" # Provide the boolean value. If its the primary ip configuration, provide the value as true else false
}

variable "public_ip_address_name" {
  description = "The Name of the Public IP Address Configuration"
  type        = string
  default     = "" # Provide the name for public IP
}

variable "public_ip_address_version" {
  description = "The Internet Protocol Version which should be used for this public IP address. Possible values are IPv4 and IPv6. Defaults to IPv4"
  type        = string
  default     = "" # Provide the IP version
}



######
# OS Disk block variables
######

variable "storage_account_type" {
  description = "type of storage account for os disk. Ex: StandardSSD_LRS"
  type        = string
  default     = "" #Provide the storage account type for os disk
}

variable "caching" {
  description = "caching type of os disk. Ex: ReadWrite"
  type        = string
  default     = "" # Provide the caching method for os disk
}

######
# Additional capabilities variables
######

variable "ultra_ssd_enabled" {
  description = "Should the capacity to enable Data Disks of the UltraSSD_LRS storage account type be supported on this Virtual Machine Scale Set? Possible values are true or false. Defaults to false"
  type        = bool
  default     = "" # Provide the boolean value
}

variable "storage_account_uri" {
  description = "The Primary/Secondary Endpoint for the Azure Storage Account which should be used to store Boot Diagnostics, including Console Output and Screenshots from the Hypervisor.Passing a null value will utilize a Managed Storage Account to store Boot Diagnostics."
  type        = string
  default     = "" # Provide the uri of the storage account
}

######
# Data disk variables
######

variable "data_disk_caching" {
  description = "The type of Caching which should be used for this Data Disk. Possible values are None, ReadOnly and ReadWrite"
  type        = string
  default     = "" # Provide the possible values from the above description
}

variable "data_disk_create_option" {
  description = "The create option which should be used for this Data Disk. Possible values are Empty and FromImage. Defaults to Empty"
  type        = string
  default     = "" # Provide the option to create data disk
}

variable "data_disk_size_gb" {
  description = "The size of the Data Disk which should be created"
  type        = number
  default     = "" # Provide the size for the data disk
}

variable "data_disk_lun" {
  description = "The Logical Unit Number of the Data Disk, which must be unique within the Virtual Machine"
  type        = number
  default     = "" # Provide the logical unit number. Ex: 1 or 2
}

variable "data_disk_storage_account_type" {
  description = "The Type of Storage Account which should back this Data Disk. Possible values include Standard_LRS, StandardSSD_LRS, StandardSSD_ZRS, Premium_LRS, PremiumV2_LRS, Premium_ZRS and UltraSSD_LRS"
  type        = string
  default     = "" # Provide the storage account type for the data disk
}

###################

variable "do_not_run_extensions_on_overprovisioned_machines" {
  description = "Should Virtual Machine Extensions be run on Overprovisioned Virtual Machines in the Scale Set? Defaults to false"
  type        = bool
  default     = "" # Provide the boolean value
}

variable "encryption_at_host_enabled" {
  description = "Should all of the disks (including the temp disk) attached to this Virtual Machine be encrypted by enabling Encryption at Host"
  type        = bool
  default     = "" # Provide the boolean value
}

variable "platform_fault_domain_count" {
  description = "Specifies the number of fault domains that are used by this Linux Virtual Machine Scale Set"
  type        = number
  default     = "" # The value must be 1 or 5
}

variable "priority" {
  description = "The Priority of this Virtual Machine Scale Set. Possible values are Regular and Spot. Defaults to Regular. When priority is set to Spot an eviction_policy must be specified"
  type        = string
  default     = "" # Provide the value from the above description
}

variable "scale_in_rule" {
  description = "The scale-in policy rule that decides which virtual machines are chosen for removal when a Virtual Machine Scale Set is scaled in. Possible values for the scale-in policy rules are Default, NewestVM and OldestVM, defaults to Default"
  type        = string
  default     = "" # Provide the value from the above description
}

variable "provision_vm_agent" {
  description = "Should the Azure VM Agent be provisioned on each Virtual Machine in the Scale Set? Defaults to true"
  type        = bool
  default     = "" # Provide the boolean value
}

########
# Source Image Reference block variables
########

variable "publisher" {
  description = "publisher of the operating system. Ex: Canonical"
  type        = string
  default     = "" #Provide the publisher for os
}

variable "offer" {
  description = "type of the operating system offered by publisher. Ex: 0001-com-ubuntu-server-jammy"
  type        = string
  default     = "" #Provide the offer for the image
}

variable "sku" {
  description = "sku of the operating system offered by publisher. Ex: 22_04-lts"
  type        = string
  default     = "" #Provide the sku for the image
}

variable "os_version" {
  description = "version of the operating system. Ex: latest"
  type        = string
  default     = "" #Provide the version for the image
}

###################

variable "upgrade_mode" {
  description = "Specifies how Upgrades (e.g. changing the Image/SKU) should be performed to Virtual Machine Instances. Possible values are Automatic, Manual and Rolling. Defaults to Manual"
  type        = string
  default     = "" #Provide the values from the above description
}

variable "vtpm_enabled" {
  description = "Specifies whether vTPM should be enabled on the virtual machine"
  type        = bool
  default     = "" # Provide the boolean value
}

variable "zone_balance" {
  description = "Should the Virtual Machines in this Scale Set be strictly evenly distributed across Availability Zones? Defaults to false. This can only be set to true when one or more zones are configured."
  type        = bool
  default     = "" # Provide the boolean value
}

variable "zones" {
  description = "Specifies a list of Availability Zones in which this Linux Virtual Machine Scale Set should be located"
  type        = set(string)
  default     = [""] # Provide the values for the zones. Ex: 1 or 2
}

##########
# Variables for Network Security Group
##########

variable "nsg_name" {
  description = "Specifies the name of the network security group"
  type        = string
  default     = "" #Provide the network security group name
}

variable "nsg_rule_name" {
  description = "The name of the security rule"
  type        = string
  default     = "" #Provide the network security group rule name. Ex:AllowSSH
}

variable "nsg_rule_priority" {
  description = "Specifies the priority of the rule. The value can be between 100 and 4096. The priority number must be unique for each rule in the collection. The lower the priority number, the higher the priority of the rule"
  type        = number
  default     = "" #Provide the priority of the rule. Ex: 100
}

variable "direction" {
  description = "The direction specifies if rule will be evaluated on incoming or outgoing traffic. Possible values are Inbound and Outbound"
  type        = string
  default     = "" #Provide the direction of the rule

}

variable "access" {
  description = "Specifies whether network traffic is allowed or denied. Possible values are Allow and Deny"
  type        = string
  default     = "" #Provide the access. Ex: Allow or Deny

}

variable "protocol" {
  description = "Network protocol this rule applies to. Possible values include Tcp, Udp, Icmp, Esp, Ah or * (which matches all)"
  type        = string
  default     = "" #Provide the protocol of the rule
}

variable "source_port_range" {
  description = "Source Port or Range. Integer or range between 0 and 65535 or * to match any"
  type        = string
  default     = "" #Provide the source port range
}

variable "destination_port_range" {
  description = "Destination Port or Range. Integer or range between 0 and 65535 or * to match any"
  type        = string
  default     = "" #Provide the destination port range. Ex: 22
}

variable "source_address_prefix" {
  description = "CIDR or source IP range or * to match any IP. Tags such as VirtualNetwork, AzureLoadBalancer and Internet can also be used"
  type        = string
  default     = "" #Provide the source IP or IP ranges. Ex: 0.0.0.0/0 or 1.2.3.4/32
}

variable "destination_address_prefix" {
  description = "CIDR or destination IP range or * to match any IP. Tags such as VirtualNetwork, AzureLoadBalancer and Internet can also be used"
  type        = string
  default     = "" # Provide the destination IP or IP ranges
}

variable "tags" {
  type        = map(any)
  description = "A mapping of tags which should be assigned to the VM"
  default = {
    "Created_By" = "Terraform_Automation" #This is a mandatory tag
    #"Environment" = "Prod" #You can modify this tag according to your needs
  }
}