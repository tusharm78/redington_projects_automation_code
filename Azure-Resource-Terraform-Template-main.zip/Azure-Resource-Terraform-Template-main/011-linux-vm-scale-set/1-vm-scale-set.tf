# Note: The virtual machine scale set with Flexible orchestration mode does not have outbound connectivity. 
# Please use an Azure load balancer or configure a NAT gateway or user-defined routes (UDR) on the subnet.

# Note: this resource will only create Virtual Machine Scale Sets with the Uniform Orchestration Mode.
# For Virtual Machine Scale Sets with Flexible orchestration mode, use azurerm_orchestrated_virtual_machine_scale_set.

########
# Data block to get the information about existing resource group
########

data "azurerm_resource_group" "rg" {
  name = var.resource_group_name
}

data "azurerm_subnet" "subnet" {
  name                 = var.subnet_name
  virtual_network_name = var.virtual_network_name
  resource_group_name  = data.azurerm_resource_group.rg.name # Referencing the resource group name
}

########
# Resource block to create linux VM scale set
########

resource "azurerm_linux_virtual_machine_scale_set" "vmss" {
  name                            = var.vm_name
  location                        = data.azurerm_resource_group.rg.location # Referencing the location
  resource_group_name             = data.azurerm_resource_group.rg.name # Referencing the resource group name
  admin_username                  = var.admin_username
  admin_password                  = var.admin_password
  disable_password_authentication = var.disable_password_authentication
  instances                       = var.instances
  sku                             = var.vm_sku

  network_interface {
    name    = var.network_interface_name
    primary = var.network_interface_primary

    ip_configuration {
      name    = var.ip_configuration_name
      primary = var.ip_configuration_primary
      public_ip_address {
        name    = var.public_ip_address_name
        version = var.public_ip_address_version
      }
      subnet_id = data.azurerm_subnet.subnet.id
    }

    network_security_group_id = azurerm_network_security_group.nsg.id
  }

  os_disk {
    storage_account_type = var.storage_account_type
    caching              = var.caching
  }

  additional_capabilities {
    ultra_ssd_enabled = var.ultra_ssd_enabled
  }

  boot_diagnostics {
    storage_account_uri = var.storage_account_uri
  }

  data_disk {
    caching              = var.data_disk_caching
    create_option        = var.data_disk_create_option
    disk_size_gb         = var.data_disk_size_gb
    lun                  = var.data_disk_lun
    storage_account_type = var.data_disk_storage_account_type
  }

  do_not_run_extensions_on_overprovisioned_machines = var.do_not_run_extensions_on_overprovisioned_machines
  encryption_at_host_enabled                        = var.encryption_at_host_enabled
  platform_fault_domain_count                       = var.platform_fault_domain_count
  priority                                          = var.priority
  provision_vm_agent                                = var.provision_vm_agent

  source_image_reference {
    publisher = var.publisher
    offer     = var.offer
    sku       = var.sku
    version   = var.os_version
  }

  custom_data  = filebase64("./custom-data.sh") # Using shell script via custom data to install apache2 web server
  upgrade_mode = var.upgrade_mode
  vtpm_enabled = var.vtpm_enabled
  zone_balance = var.zone_balance
  zones        = var.zones
  tags         = var.tags
}