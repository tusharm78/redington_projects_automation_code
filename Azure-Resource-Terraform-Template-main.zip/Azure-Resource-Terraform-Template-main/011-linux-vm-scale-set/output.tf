output "vmss_id" {
  value = azurerm_linux_virtual_machine_scale_set.vmss.id # It provides the VM scale set id
}

output "unique_id" {
  value = azurerm_linux_virtual_machine_scale_set.vmss.unique_id # It provides the unique id of VM scale set
}
