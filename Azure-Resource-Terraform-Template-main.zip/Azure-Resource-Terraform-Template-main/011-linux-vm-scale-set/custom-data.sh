#!/usr/bin/bash
sudo apt update
sudo apt install apache2 -y
sudo systemctl enable apache2
sudo echo "This is from $HOSTNAME server" | sudo tee -a /var/www/html/app.html