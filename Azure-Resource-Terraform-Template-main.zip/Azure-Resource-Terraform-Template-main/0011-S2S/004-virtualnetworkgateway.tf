# Data block for Resource group
data "azurerm_resource_group" "rg" {
  name = var.resource_group_name
}
### Data block for virtual_network
data "azurerm_virtual_network" "vnet" {
  name                = var.virtual_network_name
  resource_group_name = data.azurerm_resource_group.rg.name
}
# data block for Gatewaysubnet
data "azurerm_subnet" "subnet_1" {
  name                 = var.subnet_name_1
  virtual_network_name = data.azurerm_virtual_network.vnet.name
  resource_group_name  = data.azurerm_resource_group.rg.name
}

#################
#Creating Virtual Network Gateway#
##################
# Resource for defining a virtual network gateway in Azure
resource "azurerm_virtual_network_gateway" "vpn" {
  name                = var.vng_name                  # Name for the virtual network gateway
  location            = var.region                    # Location where the virtual network gateway will be deployed
  resource_group_name = var.resource_group_name       # Resource group name where the virtual network gateway resources will be deployed
  type                = var.gateway_type              # Type of the virtual network gateway
  sku                 = var.sku                      # SKU of the virtual network gateway
  vpn_type            = var.vpn_type                  # VPN type, in this case, RouteBased
  generation          = var.generation                # Generation of the virtual network gateway
  active_active       = var.active_active_enabled     # Whether active-active mode is enabled for the virtual network gateway

  vpn_client_configuration {                          # Configuration for VPN client
    address_space = var.vpn_client_address_space                # Address space for VPN client
  }

  ip_configuration {                                  # IP configuration for the virtual network gateway
    name                          = var.ip_configuration_name         # Name of the IP configuration
    private_ip_address_allocation = var.private_ip_address_allocation         # Allocation method for private IP address
    subnet_id                     = azurerm_subnet.GatewaySubnet.id  # ID of the subnet where the gateway is deployed
    public_ip_address_id          = azurerm_public_ip.public_ip.id    # ID of the public IP address associated with the gateway
  }
  tags                        = var.tags
  depends_on = [ azurerm_public_ip.public_ip,azurerm_virtual_network.vnet,azurerm_subnet.GatewaySubnet ]
}
