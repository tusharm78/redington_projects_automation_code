
variable "vng_name" {
  type        = string                                   # Type of the variable
  default     = "test"                                   # Default value for the virtual network gateway name
}

variable "region" {
  type        = string                                   # Type of the variable
  default     = "Australia Southeast"                          # Default region for the resources
}

variable "virtual_network_name" {
  type        = string                                   # Type of the variable
  default     = "Sathya-vnet"                          # Default name for the virtual network
}

variable "subnet_name" {
  type        = string                                   # Type of the variable
  default     = "GatewaySubnet"                          # Default name for the subnet
}

variable "gateway_type" {
  type        = string                                   # Type of the variable
  default     = "Vpn"                                    # Default type for the virtual network gateway
}

variable "sku" {
  type        = string                                   # Type of the variable
  default     = "VpnGw1"                                 # Default SKU for the virtual network gateway
}

variable "generation" {
  type        = string                                   # Type of the variable
  default     = "Generation1"                            # Default generation for the virtual network gateway
}

variable "public_ip_name" {
  type        = string                                   # Type of the variable
  default     = "test-public-ip"                         # Default name for the public IP address
}

variable "public_ip_availability_zone" {
  type        = string                                   # Type of the variable
  default     = "default"                                # Default availability zone for the public IP address
}

variable "active_active_enabled" {
  type        = bool                                     # Type of the variable
  default     = false                                    # Default value for enabling active-active mode
}

variable "lng_name" {
  type        = string                                   # Type of the variable
  default     = "test-lng"                               # Default name for the local network gateway
}

variable "gateway_address" {
  type        = string                                   # Type of the variable
  default     = "234.9.56.98"                            # Default IP address for the local network gateway
}

variable "address_space" {
  type        = list(string)                             # Type of the variable
  default     = ["172.10.0.0/16"]      # Default CIDR ranges for the local network gateway
}

variable "connection_name" {
  type        = string                                   # Type of the variable
  default     = "test-connection"                        # Default name for the VPN connection
}

variable "resource_group_name" {
  type        = string                                   # Type of the variable
  default     = "OMM_FORTINET_DEVICES"                           # Default name for the Azure resource group
}

variable "shared_key" {
  type        = string                                   # Type of the variable
  default     = "ikev123456"                             # Default shared key for VPN connection
}

variable "ike_version" {
  type        = string                                   # Type of the variable
  default     = "ikev1"                                  # Default IKE protocol version
}

variable "vpn_type" {
  type        = string                                   # Type of the variable
  default     = "IPsec"                                  # Default type for VPN connection
}

variable "tags" {
  type        = map(string)                              # Type of the variable
  default     = {                                         # Default tags for the resource
    "Created_By" = "Terraform_Automation"               # This is a mandatory tag
    #"Environment" = "Prod"                              # You can modify this tag according to your needs
  }
}

variable "allocation_method" {
  type        = string                                   # Type of the variable
  default     = "Static"                                 # Default method used to allocate the public IP address
}

variable "address_prefixes" {
  type        = list(string)                             # Type of the variable
  default     = ["10.0.1.0/24"]                          # Default address prefixes for the subnet
}


variable "vpn_client_address_space" {
  type        = list(string)                             # Type of the variable
  default     = ["172.10.0.0/16"]                        # Default address space for VPN client
}

variable "private_ip_address_allocation" {
  type        = string                                   # Type of the variable
  default     = "Dynamic"                                # Default allocation method for private IP address
}

variable "ip_configuration_name" {
  type        = string                                   # Type of the variable
  default     = "testIP"                                 # Default name of the IP configuration
}
