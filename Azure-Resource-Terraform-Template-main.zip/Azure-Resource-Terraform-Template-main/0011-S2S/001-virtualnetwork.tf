
####datablock for resource group
data "azurerm_resource_group" "rg" {
  name = var.resource_group_name
}

#################
#Creating Virtual Network#
##################
# Resource for defining a virtual network in Azure
resource "azurerm_virtual_network" "vnet" {
  name                = var.virtual_network_name        # Name for the virtual network
  address_space       = var.address_space                 # Address space for the virtual network
  location            = var.region                      # Location where the virtual network will be deployed
  resource_group_name = var.resource_group_name         # Resource group name where the virtual network resources will be deployed
  tags                        = var.tags
}
