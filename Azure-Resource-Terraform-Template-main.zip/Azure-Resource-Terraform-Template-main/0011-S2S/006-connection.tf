# Data block for Resource group

data "azurerm_resource_group" "rg" {
  name = var.resource_group_name
}
### Data block for virtual_network

data "azurerm_virtual_network" "vnet" {
  name                = var.virtual_network_name
  resource_group_name = data.azurerm_resource_group.rg.name
}

# data block for subnet

data "azurerm_subnet" "subnet_1" {
  name                 = var.subnet_name_1
  virtual_network_name = data.azurerm_virtual_network.vnet.name
  resource_group_name  = data.azurerm_resource_group.rg.name
}
#################
#Establishing connection for Site to Site#
##################
# Resource for establishing a VPN connection in Azure

resource "azurerm_virtual_network_gateway_connection" "vpn_connection" {
  name                        = var.connection_name  # Name for the VPN connection
  location                    = var.region           # Location where the VPN connection will be created
  resource_group_name         = var.resource_group_name  # Resource group name where the VPN connection resources will be deployed
  virtual_network_gateway_id  = azurerm_virtual_network_gateway.vpn.id  # ID of the virtual network gateway on one side of the connection
  local_network_gateway_id    = azurerm_local_network_gateway.lng.id  # ID of the local network gateway on the other side of the connection
  shared_key                  = var.shared_key      # Shared key used for encryption in the VPN connection
  type                        = var.vpn_type         # Type of VPN connection, in this case, IPsec
  tags                        = var.tags
  depends_on = [ azurerm_local_network_gateway.lng,azurerm_virtual_network_gateway.vpn ]

}
