
####datablock for resource group
data "azurerm_resource_group" "rg" {
  name = var.resource_group_name
}

#################
#Creating Subnet#
##################

# Resource for defining a subnet in Azure

resource "azurerm_subnet" "GatewaySubnet" {
  name                 = var.subnet_name                    # Name for the subnet
  resource_group_name  = var.resource_group_name            # Resource group name where the subnet resources will be deployed
  virtual_network_name = azurerm_virtual_network.vnet.name  # Name of the virtual network associated with the subnet
  address_prefixes     = var.address_prefixes                    # Address prefix for the subnet
  depends_on = [ azurerm_virtual_network.vnet ]
}
