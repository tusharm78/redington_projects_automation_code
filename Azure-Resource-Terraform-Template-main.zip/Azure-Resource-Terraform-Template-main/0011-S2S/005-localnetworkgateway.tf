# Data block for Resource group

data "azurerm_resource_group" "rg" {
  name = var.resource_group_name
}
### Data block for virtual_network

data "azurerm_virtual_network" "vnet" {
  name                = var.virtual_network_name
  resource_group_name = data.azurerm_resource_group.rg.name
}

# data block for subnet

data "azurerm_subnet" "subnet_1" {
  name                 = var.subnet_name_1
  virtual_network_name = data.azurerm_virtual_network.vnet.name
  resource_group_name  = data.azurerm_resource_group.rg.name
}
#################
#Creating Local Network Gateway#
##################
# Resource for defining a local network gateway in Azure

resource "azurerm_local_network_gateway" "lng" {
  name                = var.lng_name               # Name for the local network gateway
  location            = var.region                 # Location where the local network gateway will be deployed
  resource_group_name = var.resource_group_name    # Resource group name where the local network gateway resources will be deployed
  gateway_address     = var.gateway_address       # Public IP address of the on-premises VPN device

  address_space       = var.address_space         # Address space for the on-premises network
  tags                = var.tags
}
