# Output block to retrieve the public IP address
output "public_ip_address" {
  value = azurerm_public_ip.public_ip.ip_address  # Output the public IP address value
}

output "gateway_address" {
  value = var.gateway_address   # output of Local Network Gateway Public IP
}

output "address_space" {
  value =  var.address_space    # output of Local Network Gateway Address Space
}