### Data block for virtual_network
data "azurerm_virtual_network" "vnet" {
  name                = var.virtual_network_name
  resource_group_name = data.azurerm_resource_group.rg.name
}
#Creating Public IP for virtual network gateway
##################
# Resource for defining a public IP address in Azure

resource "azurerm_public_ip" "public_ip" {
  name                = var.public_ip_name                                        # Name for the public IP address
  location            = data.azurerm_virtual_network.vnet.location                # Location where the public IP address will be deployed
  resource_group_name = data.azurerm_resource_group.rg.name                       # Resource group name where the public IP address resources will be deployed
  allocation_method   = var.allocation_method                                     # Method used to allocate the public IP address
  sku                 = var.sku                                                   # SKU (Stock Keeping Unit) for the public IP address
  tags                = var.tags
}