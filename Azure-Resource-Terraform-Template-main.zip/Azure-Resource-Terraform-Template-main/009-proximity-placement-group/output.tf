########
# Output block to get proximity placement group name
########

output "proximity_placement_group_name" {
  value = azurerm_proximity_placement_group.proximity_placement_group.name # Provides the proximity placement group name
}