###########
# Here, we are referencing the existing resource group
###########

data "azurerm_resource_group" "rg" {
  name = var.resource_group_name #Provide the resource group name
}

########
# Resource block to create proximity placement group
########

resource "azurerm_proximity_placement_group" "proximity_placement_group" {
  name                = var.proximity_placement_group_name
  location            = data.azurerm_resource_group.rg.location # Referencing the location of the resource group
  resource_group_name = data.azurerm_resource_group.rg.name     # Referencing the name of resource group
  allowed_vm_sizes    = var.allowed_vm_sizes
  zone                = var.zone
  tags                = var.tags
}

