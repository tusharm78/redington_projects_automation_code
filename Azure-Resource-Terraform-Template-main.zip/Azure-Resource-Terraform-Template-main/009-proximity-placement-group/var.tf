######
# Variables for data block
######

variable "resource_group_name" {
  description = "name of the resource group"
  type        = string
  default     = "" # Provide the resource group name
}

######
# Proximity placement group variables
######

variable "proximity_placement_group_name" {
  description = "Specifies the name of the proximity placement group"
  type        = string
  default     = "" #Provide the name for the proximity placement group
}

variable "allowed_vm_sizes" {
  description = "Specifies the supported sizes of Virtual Machines that can be created in the Proximity Placement Group"
  default     = [] #Provide the VM sizes. Ex: ["Standard_b2s", "Standard_b2ms"]
  type        = set(string)
}

variable "zone" {
  description = "Specifies the supported zone of the Proximity Placement Group"
  type        = string
  default     = "" #Provide the zone
}

variable "tags" {
  description = "tags for the proximity placement group"
  type        = map(any)
  default = {
     "Created_By" = "Terraform_Automation" #This is a mandatory tag
    #"Environment" = "Prod" #You can modify this tag according to your needs
  }
}