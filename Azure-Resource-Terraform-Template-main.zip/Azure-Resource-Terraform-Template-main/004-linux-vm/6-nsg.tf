########
# Resource block to create network security group
########

resource "azurerm_network_security_group" "nsg" {
  name                = var.nsg_name
  resource_group_name = data.azurerm_resource_group.rg.name # Referencing the reource group name
  location            = data.azurerm_resource_group.rg.location # Referencing the location
  tags = var.tags
}
