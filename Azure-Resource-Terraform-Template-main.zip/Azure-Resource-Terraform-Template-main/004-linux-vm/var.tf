##########
# Variables for data blocks
##########

variable "resource_group_name" {
  description = "name of the resource group"
  type        = string
  default     = "" # Provide the resource group name
}

variable "virtual_network_name" {
  description = "name of the virtual network"
  type        = string
  default     = "" # Provide the virtual network name
}

variable "subnet_name" {
  description = "Specifies the name of the Subnet"
  type        = string
  default     = "" # Provide the subnet name
}

######
# Variables for Virtual machine
######

variable "vm_name" {
  description = "name of the virtual machine"
  type        = string
  default     = "" #Provide the name for virtual machine
}

variable "vm_size" {
  description = "size of the virtual machine"
  type        = string
  default     = "" #Provide the size for virtual machine. Ex: Standard_B1ls
}

variable "admin_username" {
  description = "login username of the virtual machine"
  type        = string
  default     = "" #Provide the username for virtual machine
}

variable "admin_password" {
  description = "login password of the virtual machine"
  type        = string
  default     = "" #Provide the password for virtual machine
}

variable "disable_password_authentication" {
  description = "Should Password Authentication be disabled on this Virtual Machine"
  type        = string
  default     = "" #Provide the password authentication methods. Possible values are true and false. If you want to use password authentication, use false 
}

######
# OS Disk block variables
######

variable "caching" {
  description = "caching type of os disk. Ex: ReadWrite"
  type        = string
  default     = "" #Provide the caching method for os disk
}

variable "storage_account_type" {
  description = "type of storage account for os disk. Ex: StandardSSD_LRS"
  type        = string
  default     = "" #Provide the storage account type for os disk
}

######
# Source Image Reference block variables
######

variable "publisher" {
  description = "publisher of the operating system. Ex: canonical"
  type        = string
  default     = "" #Provide the publisher for os
}

variable "offer" {
  description = "type of the operating system offered by publisher. Ex: 0001-com-ubuntu-server-jammy"
  type        = string
  default     = "" ##Provide the offer for the image
}

variable "sku" {
  description = "sku of the operating system offered by publisher. Ex: 22_04-lts"
  type        = string
  default     = "" #Provide the sku for the image
}

variable "os_version" {
  description = "version of the operating system. Ex: latest"
  type        = string
  default     = "" #Provide the version for the image
}

variable "tags" {
  type        = map(any)
  description = "A mapping of tags which should be assigned to the VM"
  default = {
     "Created_By" = "Terraform_Automation" #This is a mandatory tag
    #"Environment" = "Prod" #You can modify this tag according to your needs
  }
}

##########
# Variables for creating managed(data) disk
##########

variable "disk_name" {
  description = "Specifies the name of the Managed Disk"
  type        = string
  default     = "" #Provide the name for the disk
}

variable "data_disk_storage_account_type" {
  description = "The type of storage to use for the managed disk. Possible values are Standard_LRS, StandardSSD_ZRS, Premium_LRS, PremiumV2_LRS, Premium_ZRS, StandardSSD_LRS or UltraSSD_LRS"
  type        = string
  default     = "" #Provide the storage account type for data disk
}

variable "create_option" {
  description = "The Create Option of the Data Disk, such as Empty or Attach. Defaults to Attach"
  type        = string
  default     = "" #Provide the value for the create option for the disk
}

variable "disk_size_gb" {
  description = "Specifies the size of the managed disk to create in gigabytes. If create_option is Copy or FromImage, then the value must be equal to or greater than the source's size. The size can only be increased."
  type        = number
  default     = "" # Provide the size as whole number. Ex:10 for 10GB
}

##########
# Variables for attaching managed(data) disk
##########

variable "lun" {
  description = "The Logical Unit Number of the Data Disk, which needs to be unique within the Virtual Machine"
  type        = number
  default     = "" #Provide the lun for the disk
}

variable "data_disk_caching" {
  description = "Specifies the caching requirements for this Data Disk. Possible values include None, ReadOnly and ReadWrite"
  type        = string
  default     = "" #Provide the caching option for data disk
}

##########
# Variables for Public IP
##########

variable "public_ip_name" {
  description = "Specifies the name of the Public IP"
  type        = string
  default     = "" # Provide the name for public ip
}

variable "allocation_method" {
  description = "Defines the allocation method for this IP address. Possible values are Static or Dynamic"
  type        = string
  default     = "" #Provide the allocation method for the public ip
}

##########
# Variables for Network Interface
##########

variable "nic_name" {
  description = "The name of the Network Interface"
  type        = string
  default     = "" #Provide the network interface card name
}

variable "ip_configuration_name" {
  description = "A name used for this IP Configuration"
  type        = string
  default     = "" #Provide the ip configuration name
}

variable "private_ip_address_allocation" {
  description = "The allocation method used for the Private IP Address. Possible values are Dynamic and Static"
  type        = string
  default     = "" #Provide the allocation method for the private ip
}

##########
# Variables for Network Security Group
##########

variable "nsg_name" {
  description = "Specifies the name of the network security group"
  type        = string
  default     = "" #Provide the network security group name
}

##########
# Variables for Network Security Rules - SSH
##########

variable "nsg_rule_ssh" {
  description = "The name of the security rule"
  type        = string
  default     = "" #Provide the network security group rule name . Ex:AllowSSH
}

variable "nsg_rule_ssh_description" {
  description = "A description for this rule"
  type        = string
  default     = "" #Provide the network security group rule name . Ex:AllowSSH from on-premise
}

variable "protocol_ssh" {
  description = "Network protocol this rule applies to. Possible values include Tcp, Udp, Icmp, Esp, Ah or * (which matches all)"
  type        = string
  default     = "" #Provide the protocol of the rule
}

variable "source_port_range" {
  description = "Source Port or Range. Integer or range between 0 and 65535 or * to match any"
  type        = string
  default     = "*" #Provide the source port range
}

variable "destination_port_range_ssh" {
  description = "Destination Port or Range. Integer or range between 0 and 65535 or * to match any"
  type        = string
  default     = "" #Provide the destination port range. Ex: 22
}

variable "source_address_prefix_ssh" {
  description = "CIDR or source IP range or * to match any IP. Tags such as VirtualNetwork, AzureLoadBalancer and Internet can also be used"
  type        = string
  default     = "" #Provide the source IP or IP ranges. Ex: 0.0.0.0/0 or 1.2.3.4/32
}

variable "destination_address_prefix" {
  description = "CIDR or destination IP range or * to match any IP. Tags such as VirtualNetwork, AzureLoadBalancer and Internet can also be used"
  type        = string
  default     = "*" # Provide the destination IP or IP ranges
}

variable "access" {
  description = "Specifies whether network traffic is allowed or denied. Possible values are Allow and Deny"
  type        = string
  default     = "" #Provide the access
}

variable "ssh_priority" {
  description = "Specifies the priority of the rule. The value can be between 100 and 4096. The priority number must be unique for each rule in the collection. The lower the priority number, the higher the priority of the rule"
  type        = number
  default     = "" #Provide the priority of the rule. Ex: 100
}

variable "direction" {
  description = "The direction specifies if rule will be evaluated on incoming or outgoing traffic. Possible values are Inbound and Outbound"
  type        = string
  default     = "" #Provide the direction of the rule

}

##########
# Variables for Network Security Rules - RDP
##########

variable "nsg_rule_rdp" {
  description = "The name of the security rule"
  type        = string
  default     = "" #Provide the network security group rule name . Ex:AllowRDP
}

variable "nsg_rule_rdp_description" {
  description = "A description for this rule"
  type        = string
  default     = "" #Provide the network security group rule name . Ex:AllowRDP from on-premise
}

variable "protocol_rdp" {
  description = "Network protocol this rule applies to. Possible values include Tcp, Udp, Icmp, Esp, Ah or * (which matches all)"
  type        = string
  default     = "*" #Provide the protocol of the rule
}

variable "destination_port_range_rdp" {
  description = "Destination Port or Range. Integer or range between 0 and 65535 or * to match any"
  type        = string
  default     = "" #Provide the destination port range. Ex: 3389
}

variable "source_address_prefix_rdp" {
  description = "CIDR or source IP range or * to match any IP. Tags such as VirtualNetwork, AzureLoadBalancer and Internet can also be used"
  type        = string
  default     = "" #Provide the source IP or IP ranges. Ex: 0.0.0.0/0 or 1.2.3.4/32
}

variable "rdp_priority" {
  description = "Specifies the priority of the rule. The value can be between 100 and 4096. The priority number must be unique for each rule in the collection. The lower the priority number, the higher the priority of the rule"
  type        = number
  default     = "" #Provide the priority of the rule. Ex: 100
}
