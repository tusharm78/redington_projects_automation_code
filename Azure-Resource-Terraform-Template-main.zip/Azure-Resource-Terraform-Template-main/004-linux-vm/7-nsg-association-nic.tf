########
# Resource block to associate network security group with nic
########

resource "azurerm_network_interface_security_group_association" "nsg-association" {
  network_interface_id      = azurerm_network_interface.nic.id      # Referencing the network interface
  network_security_group_id = azurerm_network_security_group.nsg.id # Referencing the network security group
}