######
# Output  block to get details about the VM
######

output "vm_id" {
  value = azurerm_linux_virtual_machine.vm.id # It provides the id of the virtual machine
}

output "private_ip" {
  value = azurerm_linux_virtual_machine.vm.private_ip_address # It provides the private ip of the virtual machine
}

output "public_ip" {
  value = azurerm_linux_virtual_machine.vm.public_ip_address # It provides the public ip of the virtual machine
}