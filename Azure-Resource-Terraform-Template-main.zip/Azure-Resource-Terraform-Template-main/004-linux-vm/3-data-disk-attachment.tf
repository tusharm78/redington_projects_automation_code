########
# Resource block to attach data disk to the virtual machine
########

resource "azurerm_virtual_machine_data_disk_attachment" "example" {
  managed_disk_id    = azurerm_managed_disk.managed_disk.id # Referencing the managed disk
  virtual_machine_id = azurerm_linux_virtual_machine.vm.id # Referencing the virtual machine
  lun                = var.lun
  caching            = var.data_disk_caching
  depends_on = [ azurerm_managed_disk.managed_disk ]
}