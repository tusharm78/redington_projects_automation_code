########
# Data block for referencing the existing resources
########

data "azurerm_resource_group" "rg" {
  name = var.resource_group_name
}

data "azurerm_virtual_network" "vnet" {
  name                = var.virtual_network_name
  resource_group_name = data.azurerm_resource_group.rg.name # Referencing the reource group name
}

data "azurerm_subnet" "subnet" {
  name                 = var.subnet_name
  virtual_network_name = data.azurerm_virtual_network.vnet.name # Referencing the virtual network name
  resource_group_name  = data.azurerm_resource_group.rg.name # Referencing the reource group name
}

########
# Resource block to create linux VM
########

resource "azurerm_linux_virtual_machine" "vm" {
  name                            = var.vm_name
  resource_group_name             = data.azurerm_resource_group.rg.name # Referencing the reource group name
  location                        = data.azurerm_resource_group.rg.location # Referencing the location
  size                            = var.vm_size
  admin_username                  = var.admin_username
  admin_password                  = var.admin_password
  disable_password_authentication = var.disable_password_authentication
  network_interface_ids           = [azurerm_network_interface.nic.id] # Referencing the network interface
  depends_on = [ azurerm_network_interface.nic ]

  os_disk {
    caching              = var.caching
    storage_account_type = var.storage_account_type
  }

  source_image_reference {
    publisher = var.publisher
    offer     = var.offer
    sku       = var.sku
    version   = var.os_version
  }
  
  tags = var.tags
}