######
# Output block 
######

output "vnet_name" {
    description = "The name of the virtual network"
    value = azurerm_virtual_network.vnet.name
}

output "address_space" {
    description = "The list of address spaces used by the virtual network"
    value = azurerm_virtual_network.vnet.subnet
}

