######
# Variables for data block
######

variable "resource_group_name" {
  description = "name of the resource group"
  type        = string
  default     = "" # Provide the resource group name
}

variable "managed_disk_name" {
  description = "name of the managed disk"
  type        = string
  default     = "" # Provide the existing disk name which you want to create a snapshot
}

########
# Snapshot variables
########

variable "snapshot_name" {
  description = "Specifies the name of the Snapshot resource"
  type        = string
  default     = "" # Provide the name for the snapshot
}

variable "create_option" {
  description = "Indicates how the snapshot is to be created. Possible values are Copy or Import"
  type        = string
  default     = "" # Provide the create option for snapshot
}
