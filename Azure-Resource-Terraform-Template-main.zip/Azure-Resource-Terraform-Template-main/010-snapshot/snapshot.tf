#######
# Data block to get the information of existing resources
#######

data "azurerm_resource_group" "rg" {
  name = var.resource_group_name
}

data "azurerm_managed_disk" "existing" {
  name                = var.managed_disk_name
  resource_group_name = data.azurerm_resource_group.rg.name # Referencing the resource group name
}

#######
# Resource block to create snapshot of the disk
#######

resource "azurerm_snapshot" "snapshot" {
  name                = var.snapshot_name
  location            = data.azurerm_resource_group.rg.location # Referencing the resource group location
  resource_group_name = data.azurerm_resource_group.rg.name     # Referencing the resource group name
  create_option       = var.create_option
  source_uri          = data.azurerm_managed_disk.existing.id # Referencing the uri of the source managed disk
}

