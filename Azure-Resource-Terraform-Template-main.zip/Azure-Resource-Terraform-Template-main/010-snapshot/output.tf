########
# Output block to get size of the snapshot disk
########

output "disk_size_gb" {
  value = azurerm_snapshot.snapshot.disk_size_gb
}