######
# Variables for data block
######

variable "resource_group_name" {
  description = "The name of the resource group in which to create the elastic pool. This must be the same as the resource group of the underlying SQL server"
  type        = string
  default = "" #Provide the resource group name
}

variable "mssql_server_name" {
  description = "The name of the Microsoft SQL Server. This needs to be globally unique within Azure"
  type = string
  default = "" #Provide the mssql server name
}

######
# SQL Elastic pool Variables
######

variable "sql_elastic_pool_name" {
  description = "Name of the sql elastic pool"
  type        = string
  default = "" #Provide the name for SQL elastic pool
}

variable "license_type" {
  description = "Specifies the license type applied to this database. Possible values are LicenseIncluded and BasePrice"
  type        = string
  default = "" #Provide the license type of the database
}

variable "max_size_gb" {
  description = "The max data size of the elastic pool in gigabytes"
  type        = number
  default = "" #Provide the disk size of elastic pool 
}

variable "sku_name" {
  description = "Specifies the SKU Name for this Elasticpool. The name of the SKU, will be either vCore based or DTU based. Possible DTU based values are BasicPool, StandardPool, PremiumPool while possible vCore based values are GP_Gen4, GP_Gen5, GP_Fsv2, GP_DC, BC_Gen4, BC_Gen5, BC_DC, or HS_Gen5"
  type        = string
  default = "" #Provide the sku name
}

variable "sku_tier" {
  description = "The tier of the particular SKU. Possible values are GeneralPurpose, BusinessCritical, Basic, Standard, Premium, or HyperScale"
  type        = string
  default = "" #Provide the tier of the particular SKU
}

variable "sku_family" {
  description = "The family of hardware Gen4, Gen5, Fsv2 or DC"
  type        = string
  default = "" #Provide the family of sku
}

variable "sku_capacity" {
  description = "Capacity for the sku which is how many vCores need to configure"
  type        = string
  default = "" #The scale up/out capacity, representing server's compute units. For more information see the documentation for your Elasticpool configuration: vCore_based or DTU_based
}

variable "per_db_min_capacity" {
  description = "The minimum capacity all databases are guaranteed"
  type        = number
  default = "" #Provide the minimum capacity for all databases in a elastic pool. Value must not be higher than sku capacity
}

variable "per_db_max_capacity" {
  description = "The maximum capacity any one database can consume"
  type        = number
  default = "" #Provide the maximum capacity for all databases in a elastic pool. Value must not be higher than sku capacity
}

variable "maintenance_configuration_window" {
  description = "The name of the Public Maintenance Configuration window to apply to the elastic pool."
  type        = string
  default = "" #Provide the Public Maintenance Configuration window to apply to the elastic pool. Default values is SQL_Default
}

variable "tags" {
  type = map(any)
  default = {
     "Created_By" = "Terraform_Automation" #This is a mandatory tag
    #"Environment" = "Prod" #You can modify this tag according to your needs
  }
}