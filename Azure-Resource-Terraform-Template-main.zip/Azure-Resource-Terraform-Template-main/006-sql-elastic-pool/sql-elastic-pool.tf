########
# Data block for referencing the existing resources
########

data "azurerm_resource_group" "rg" {
  name = var.resource_group_name
}

data "azurerm_mssql_server" "sql_server" {
  name                = var.mssql_server_name 
  resource_group_name = data.azurerm_resource_group.rg.name # Referencing the resource group name
}

###########
# Resource block to create SQL elastic pool
###########

resource "azurerm_mssql_elasticpool" "elastic_pool" {
  name                           = var.sql_elastic_pool_name
  resource_group_name            = data.azurerm_resource_group.rg.name # Referencing the resource group name
  location                       = data.azurerm_resource_group.rg.location # Referencing the location
  server_name                    = data.azurerm_mssql_server.sql_server.name # Referencing the sql server name
  license_type                   = var.license_type
  max_size_gb                    = var.max_size_gb
  maintenance_configuration_name = var.maintenance_configuration_window

  sku {
    name     = var.sku_name
    tier     = var.sku_tier
    family   = var.sku_family
    capacity = var.sku_capacity
  }

  per_database_settings {
    min_capacity = var.per_db_min_capacity
    max_capacity = var.per_db_max_capacity
  }
  tags = var.tags
}