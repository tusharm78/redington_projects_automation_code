# Below are the list of inputs needed to create SQL elastic pool

- SQL Elastic pool group name 
- Resource Group Name 
- Location 
- SQL Server name 
- License type 
- Disk Size 
- Maintenance configuration window name 
- SKU 
    - name
    - tier
    - family
    - capacity
- Per database settings 
    - minimum capacity
    - maximum capacity
- Tags (optional)