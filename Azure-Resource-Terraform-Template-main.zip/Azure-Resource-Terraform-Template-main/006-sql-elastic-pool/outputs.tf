########
# Output block to get sql elastic pool name
########

output "sql_elastic_pool_name" {
  value = azurerm_mssql_elasticpool.elastic_pool.name # Provides the elastic pool name
}