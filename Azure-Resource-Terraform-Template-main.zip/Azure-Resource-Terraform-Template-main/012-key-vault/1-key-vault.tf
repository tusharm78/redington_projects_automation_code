########
# Data block to get the information about existing resources
########

data "azurerm_client_config" "current" {} # Used to retrieve tenant id

data "azurerm_resource_group" "rg" {
  name = var.resource_group_name
}

data "azurerm_virtual_network" "vnet" {
  name                = var.virtual_network_name
  resource_group_name = data.azurerm_resource_group.rg.name # Referencing the reource group name
}

data "azurerm_subnet" "subnet" {
  name                 = var.subnet_name
  virtual_network_name = data.azurerm_virtual_network.vnet.name # Referencing the virtual network name
  resource_group_name  = data.azurerm_resource_group.rg.name    # Referencing the reource group name
}

########
# Resource block to create Key vault
########

resource "azurerm_key_vault" "key_vault" {
  name                = var.key_vault_name
  location            = data.azurerm_resource_group.rg.location # Referencing the location
  resource_group_name = data.azurerm_resource_group.rg.name     # Referencing the resource group name
  sku_name            = var.sku_name
  tenant_id           = data.azurerm_client_config.current.tenant_id # Referencing the tenant id

  access_policy {
    tenant_id = data.azurerm_client_config.current.tenant_id # Referencing the tenant id
    object_id = data.azurerm_client_config.current.object_id #  Referencing the object id

    key_permissions     = var.key_permissions
    secret_permissions  = var.secret_permissions
    storage_permissions = var.storage_permissions
  }

  enabled_for_deployment          = var.enabled_for_deployment
  enabled_for_disk_encryption     = var.enabled_for_disk_encryption
  enabled_for_template_deployment = var.enabled_for_template_deployment
  enable_rbac_authorization       = var.enable_rbac_authorization

  network_acls {
    bypass                     = var.bypass
    default_action             = var.default_action
    ip_rules                   = var.ip_rules
    virtual_network_subnet_ids = [data.azurerm_subnet.subnet.id, ] # Referencing the subnet
  }

  purge_protection_enabled      = var.purge_protection_enabled
  public_network_access_enabled = var.public_network_access_enabled
  soft_delete_retention_days    = var.soft_delete_retention_days
  tags                          = var.tags

}