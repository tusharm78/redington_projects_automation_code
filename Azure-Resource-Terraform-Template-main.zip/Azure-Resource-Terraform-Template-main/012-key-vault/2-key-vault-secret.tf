########
# Resource block to create Key vault secret
########

resource "azurerm_key_vault_secret" "key_vault_secret" {
  name         = var.kv_secret_name
  value        = var.kv_secret_value
  key_vault_id = azurerm_key_vault.key_vault.id # Referencing key vault
}