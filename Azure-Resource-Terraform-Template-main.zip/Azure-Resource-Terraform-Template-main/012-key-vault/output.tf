output "key_vault_id" {
  value = azurerm_key_vault.key_vault.id # The ID of the Key Vault
}

output "vault_uri" {
  value = azurerm_key_vault.key_vault.vault_uri # The URI of the Key Vault, used for performing operations on keys and secrets.
}

output "secret_id" {
  value = azurerm_key_vault_secret.key_vault_secret.id # The Key Vault Secret ID.
}