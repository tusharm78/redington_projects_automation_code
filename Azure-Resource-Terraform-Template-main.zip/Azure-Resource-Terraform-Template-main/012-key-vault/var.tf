######
# Variables for Data block
######

variable "resource_group_name" {
  description = "The name of the resource group"
  type        = string
  default     = "" # Provide the name of existing resource group
}

variable "virtual_network_name" {
  description = "name of the virtual network"
  type        = string
  default     = "" # Provide the virtual network name
}

variable "subnet_name" {
  description = "Specifies the name of the Subnet"
  type        = string
  default     = "" # Provide the subnet name
}

######
# Variables for Key Vault
######

variable "key_vault_name" {
  description = "Specifies the name of the Key Vault. The name must be globally unique. If the vault is in a recoverable state then the vault will need to be purged before reusing the name"
  type        = string
  default     = "" # Provide the name for key vault
}

variable "sku_name" {
  description = "The Name of the SKU used for this Key Vault. Possible values are standard and premium"
  type        = string
  default     = "" # Provide the value for sku
}

variable "key_permissions" {
  description = "List of key permissions. Possible values are Backup, Create, Decrypt, Delete, Encrypt, Get, Import, List, Purge, Recover, Restore, Sign, UnwrapKey, Update, Verify, WrapKey, Release, Rotate, GetRotationPolicy and SetRotationPolicy"
  type        = list(string)
  default     = ["Create", "Delete", "Encrypt", "Decrypt", "Get", "List", "Purge"] # Provide the options for key permissions
}

variable "secret_permissions" {
  description = "List of secret permissions, must be one or more from the following: Backup, Delete, Get, List, Purge, Recover, Restore and Set"
  type        = list(string)
  default     = ["Backup", "Delete", "Get", "List", "Purge", "Recover", "Restore", "Set"] # Provide the options for secret permissions
}

variable "storage_permissions" {
  description = "List of storage permissions, must be one or more from the following: Backup, Delete, DeleteSAS, Get, GetSAS, List, ListSAS, Purge, Recover, RegenerateKey, Restore, Set, SetSAS and Update"
  type        = list(string)
  default     = ["Backup", "Delete", "DeleteSAS", "Get", "GetSAS", ] # Provide the options for storage permissions
}

variable "enabled_for_deployment" {
  description = "Boolean flag to specify whether Azure Virtual Machines are permitted to retrieve certificates stored as secrets from the key vault."
  type        = bool
  default     = "" # Provide the boolean value to enable or disable
}

variable "enabled_for_disk_encryption" {
  description = "Boolean flag to specify whether Azure Disk Encryption is permitted to retrieve secrets from the vault and unwrap keys"
  type        = bool
  default     = "" # Provide the boolean value to enable or disable
}

variable "enabled_for_template_deployment" {
  description = "Boolean flag to specify whether Azure Resource Manager is permitted to retrieve secrets from the key vault."
  type        = bool
  default     = "" # Provide the boolean value to enable or disable
}

variable "enable_rbac_authorization" {
  description = "Boolean flag to specify whether Azure Key Vault uses Role Based Access Control (RBAC) for authorization of data actions"
  type        = bool
  default     = "" # Provide the boolean value to enable or disable
}

variable "bypass" {
  description = "Specifies which traffic can bypass the network rules. Possible values are AzureServices and None"
  type        = string
  default     = "" # Provide the value for which traffic can bypass the network rules
}

variable "default_action" {
  description = "The Default Action to use when no rules match from ip_rules / virtual_network_subnet_ids. Possible values are Allow and Deny"
  type        = string
  default     = "" # Provide the value for default action
}

variable "ip_rules" {
  description = "One or more IP Addresses, or CIDR Blocks which should be able to access the Key Vault."
  type        = list(string)
  default     = [""] # Provide the IP or CIDR to access the key vault. Ex: 1.2.3.4/32
}

variable "purge_protection_enabled" {
  description = "Is Purge Protection enabled for this Key Vault? Once Purge Protection has been Enabled it's not possible to Disable it"
  type        = bool
  default     = "" # Provide the boolean value to enable or disable
}

variable "public_network_access_enabled" {
  description = "Whether public network access is allowed for this Key Vault. Defaults to true"
  type        = bool
  default     = "" # Provide the boolean value to enable or disable
}

variable "soft_delete_retention_days" {
  description = "The number of days that items should be retained for once soft-deleted. This value can be between 7 and 90 (the default) days."
  type        = number
  default     = "" # Provide the full number
}

variable "tags" {
  type        = map(any)
  description = "A mapping of tags which should be assigned to the VM"
  default = {
    "Created_By" = "Terraform_Automation" #This is a mandatory tag
    #"Environment" = "Prod" #You can modify this tag according to your needs
  }
}


######
# Variables for Key Vault secret
######

variable "kv_secret_name" {
  description = "Specifies the name of the Key Vault Secret"
  type        = string
  default     = "" # Provide the name for secret. Ex: vmpassword
}

variable "kv_secret_value" {
  description = "Specifies the value of the Key Vault Secret"
  type        = string
  sensitive   = true
  default     = "" # Provide the value for the secret 
}