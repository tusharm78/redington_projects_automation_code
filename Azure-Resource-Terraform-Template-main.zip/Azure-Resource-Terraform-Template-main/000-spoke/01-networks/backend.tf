########
# Azure backend configuration for storing terraform state files
########

terraform {
  backend "azurerm" {
    resource_group_name  = "RG-Do-Not-Delete-Terraform-Backend" #Replace SSWhite keyword with the project name. #Use a seperate resource group for storing the state file
    storage_account_name = "terraformstate02042024" #Change the date in storage account name. Name must be unique
    container_name       = "tfstate"
    key                  = "spokenetworks.terraform.tfstate"
  }
}
