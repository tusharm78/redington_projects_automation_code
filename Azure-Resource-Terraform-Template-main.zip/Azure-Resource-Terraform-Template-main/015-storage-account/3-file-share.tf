########
# Resource block to create file share
########

resource "azurerm_storage_share" "file_share" {
  name                 = var.file_share_name
  storage_account_name = azurerm_storage_account.storage_account.name
  access_tier          = var.file_share_access_tier
  enabled_protocol     = var.enabled_protocol
  quota                = var.file_share_quota

}