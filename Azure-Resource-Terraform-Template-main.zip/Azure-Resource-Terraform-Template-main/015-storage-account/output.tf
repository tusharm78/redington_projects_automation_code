######
# Output  block to get details about the storage account
######

output "storage_account_id" {
  value = azurerm_storage_account.storage_account.id # The ID of the storage account
}

output "storage_account_name" {
  value = azurerm_storage_account.storage_account.name # The name of the storage account
}

######
# Output  block to get details about the container
######

output "container_id" {
  value = azurerm_storage_container.container.id # The ID of the container
}

output "container_name" {
  value = azurerm_storage_container.container.name # The name of the container
}

######
# Output  block to get details about the file share
######

output "file_share_url" {
  value = azurerm_storage_share.file_share.url # The URL of the file share
}