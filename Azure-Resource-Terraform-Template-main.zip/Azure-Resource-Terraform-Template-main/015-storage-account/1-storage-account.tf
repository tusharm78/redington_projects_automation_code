########
# Data block for referencing the existing resources
########

data "azurerm_resource_group" "rg" {
  name = var.resource_group_name
}

########
# Resource block to create storage account
########

resource "azurerm_storage_account" "storage_account" {
  name                             = var.storage_account_name
  resource_group_name              = data.azurerm_resource_group.rg.name
  location                         = data.azurerm_resource_group.rg.location
  account_kind                     = var.account_kind
  account_tier                     = var.account_tier
  account_replication_type         = var.account_replication_type
  cross_tenant_replication_enabled = var.cross_tenant_replication_enabled
  access_tier                      = var.access_tier
  enable_https_traffic_only        = var.enable_https_traffic_only
  min_tls_version                  = var.min_tls_version
  allow_nested_items_to_be_public  = var.allow_nested_items_to_be_public
  shared_access_key_enabled        = var.shared_access_key_enabled
  public_network_access_enabled    = var.public_network_access_enabled
  is_hns_enabled                   = var.is_hns_enabled

  blob_properties {
    delete_retention_policy {
      days = var.blob_delete_retention_policy
    }
    container_delete_retention_policy {
      days = var.container_delete_retention_policy
    }
  }

  network_rules {
    default_action = var.nw_rule_default_action
    bypass         = var.nw_rule_bypass
    ip_rules       = var.nw_ip_rules
  }

  large_file_share_enabled = var.large_file_share_enabled

  routing {
    choice = var.routing_choice
  }

  tags = var.tags

}