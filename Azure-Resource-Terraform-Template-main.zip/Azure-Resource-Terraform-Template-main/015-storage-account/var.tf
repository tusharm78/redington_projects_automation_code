##########
# Variables for data blocks
##########

variable "resource_group_name" {
  description = "name of the resource group"
  type        = string
  default     = "" # Provide the resource group name
}

######
# Variables for storage account
######

variable "storage_account_name" {
  description = "value"
  type        = string
  default     = "" # Provide the name for storage account
}

variable "account_kind" {
  description = "Defines the Kind of account. Valid options are BlobStorage, BlockBlobStorage, FileStorage, Storage and StorageV2. Defaults to StorageV2"
  type        = string
  default     = "" # Provide the account kind
}


variable "account_tier" {
  description = "Defines the Tier to use for this storage account. Valid options are Standard and Premium. For BlockBlobStorage and FileStorage accounts only Premium is valid. Changing this forces a new resource to be created."
  type        = string
  default     = "" # Provide the account tier
}

variable "account_replication_type" {
  description = "Defines the type of replication to use for this storage account. Valid options are LRS, GRS, RAGRS, ZRS, GZRS and RAGZRS. Changing this forces a new resource to be created when types LRS, GRS and RAGRS are changed to ZRS, GZRS or RAGZRS and vice versa."
  type        = string
  default     = "" # Provide the account replication type
}

variable "cross_tenant_replication_enabled" {
  description = "Should cross Tenant replication be enabled? Defaults to true"
  type        = bool
  default     = "" # Provide the boolean value
}

variable "access_tier" {
  description = "Defines the access tier for BlobStorage, FileStorage and StorageV2 accounts. Valid options are Hot and Cool, defaults to Hot"
  type        = string
  default     = "" # Provide the access tier
}

variable "enable_https_traffic_only" {
  description = "Boolean flag which forces HTTPS if enabled, see here for more information. Defaults to true"
  type        = bool
  default     = "" # Provide the boolean value
}

variable "min_tls_version" {
  description = "The minimum supported TLS version for the storage account. Possible values are TLS1_0, TLS1_1, and TLS1_2. Defaults to TLS1_2 for new storage accounts"
  type        = string
  default     = "" # Provide the tls version
}

variable "allow_nested_items_to_be_public" {
  description = "Allow or disallow nested items within this Account to opt into being public. Defaults to true"
  type        = bool
  default     = "" # Provide the boolean value
}

variable "shared_access_key_enabled" {
  description = "Indicates whether the storage account permits requests to be authorized with the account access key via Shared Key. If false, then all requests, including shared access signatures, must be authorized with Azure Active Directory (Azure AD). Defaults to true"
  type        = bool
  default     = "" # Provide the boolean value
}

variable "public_network_access_enabled" {
  description = "Whether the public network access is enabled? Defaults to true"
  type        = bool
  default     = "" # Provide the boolean value
}

variable "is_hns_enabled" {
  description = "Is Hierarchical Namespace enabled? This can be used with Azure Data Lake Storage Gen 2"
  type        = bool
  default     = "" # Provide the boolean value
}

variable "blob_delete_retention_policy" {
  description = "Specifies the number of days that the blob should be retained, between 1 and 365 days. Defaults to 7"
  type        = number
  default     = "" # Provide the blob retention policy in no. of days
}

variable "container_delete_retention_policy" {
  description = "Specifies the number of days that the container should be retained, between 1 and 365 days. Defaults to 7"
  type        = number
  default     = "" # Provide the blob retention policy in no. of days
}

variable "nw_rule_default_action" {
  description = "Specifies the default action of allow or deny when no other rules match. Valid options are Deny or Allow"
  type        = string
  default     = "" # Provide the action
}

variable "nw_rule_bypass" {
  description = "Specifies whether traffic is bypassed for Logging/Metrics/AzureServices. Valid options are any combination of Logging, Metrics, AzureServices, or None"
  type        = list(string)
  default     = ["AzureServices"] # Provide the option to bypass n/w rule
}

variable "nw_ip_rules" {
  description = "List of public IP or IP ranges in CIDR Format. Only IPv4 addresses are allowed. /31 CIDRs, /32 CIDRs, and Private IP address ranges (as defined in RFC 1918), are not allowed"
  type        = list(string)
  default     = [""] # Provide the IP(s) to allow the access
}

variable "large_file_share_enabled" {
  description = "Are Large File Shares Enabled? Defaults to false"
  type        = bool
  default     = "" # Provide the boolean value
}

variable "routing_choice" {
  description = "Specifies the kind of network routing opted by the user. Possible values are InternetRouting and MicrosoftRouting. Defaults to MicrosoftRouting"
  type        = string
  default     = "" # Provide the routing choice
}

variable "tags" {
  type        = map(any)
  description = "A mapping of tags which should be assigned to the VM"
  default = {
    "Created_By" = "Terraform_Automation" #This is a mandatory tag
    #"Environment" = "Prod" #You can modify this tag according to your needs
  }
}

######
# Variables for container
######

variable "container_name" {
  description = "The name of the Container which should be created within the Storage Account. Changing this forces a new resource to be created"
  type        = string
  default     = "" # Provide the container name
}

######
# Variables for file share
######

variable "file_share_name" {
  description = "The name of the share. Must be unique within the storage account where the share is located."
  type        = string
  default     = "" # Provide the file share name
}

variable "file_share_access_tier" {
  description = "The access tier of the File Share. Possible values are Hot, Cool and TransactionOptimized, Premium"
  type        = string
  default     = ""
}

variable "enabled_protocol" {
  description = "The protocol used for the share. Possible values are SMB and NFS. The SMB indicates the share can be accessed by SMBv3.0, SMBv2.1 and REST. The NFS indicates the share can be accessed by NFSv4.1. Defaults to SMB"
  type        = string
  default     = ""
}

variable "file_share_quota" {
  description = "The maximum size of the share, in gigabytes"
  type        = number
  default     = ""
}