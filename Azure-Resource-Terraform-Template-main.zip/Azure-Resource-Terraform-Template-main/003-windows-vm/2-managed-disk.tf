########
# Resource block to create managed(data) disk
########

resource "azurerm_managed_disk" "managed_disk" {
  name                 = var.disk_name
  resource_group_name  = data.azurerm_resource_group.rg.name
  location             = data.azurerm_resource_group.rg.location
  storage_account_type = var.data_disk_storage_account_type
  create_option        = var.create_option
  disk_size_gb         = var.disk_size_gb
  tags                 = var.tags
}