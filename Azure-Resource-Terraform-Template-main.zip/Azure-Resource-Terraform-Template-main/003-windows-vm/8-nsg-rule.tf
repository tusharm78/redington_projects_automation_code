########
# Resource block to create network security rule for ssh
########

resource "azurerm_network_security_rule" "ssh" {
  name                        = var.nsg_rule_ssh
  resource_group_name         = data.azurerm_resource_group.rg.name # Referencing the reource group name
  network_security_group_name = azurerm_network_security_group.nsg.name
  description                 = var.nsg_rule_ssh_description
  protocol                    = var.protocol_ssh
  source_port_range           = var.source_port_range
  destination_port_range      = var.destination_port_range_ssh
  source_address_prefix       = var.source_address_prefix_ssh
  destination_address_prefix  = var.destination_address_prefix
  access                      = var.access
  priority                    = var.ssh_priority
  direction                   = var.direction
}

########
# Resource block to create network security rule for rdp
########

resource "azurerm_network_security_rule" "rdp" {
  name                        = var.nsg_rule_rdp
  resource_group_name         = data.azurerm_resource_group.rg.name # Referencing the reource group name
  network_security_group_name = azurerm_network_security_group.nsg.name
  description                 = var.nsg_rule_rdp_description
  protocol                    = var.protocol_rdp
  source_port_range           = var.source_port_range
  destination_port_range      = var.destination_port_range_rdp
  source_address_prefix       = var.source_address_prefix_rdp
  destination_address_prefix  = var.destination_address_prefix
  access                      = var.access
  priority                    = var.rdp_priority
  direction                   = var.direction
} 