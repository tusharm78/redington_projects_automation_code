########
# Resource block to create public ip
########

resource "azurerm_public_ip" "public_ip" {
  name                = var.public_ip_name
  resource_group_name = data.azurerm_resource_group.rg.name
  location            = data.azurerm_resource_group.rg.location
  allocation_method   = var.allocation_method
  tags                = var.tags
  depends_on          = [data.azurerm_virtual_network.vnet, data.azurerm_subnet.subnet]
}