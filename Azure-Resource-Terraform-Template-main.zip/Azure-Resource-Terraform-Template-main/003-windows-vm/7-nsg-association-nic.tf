########
# Resource block to associate network security group with nic
########

resource "azurerm_network_interface_security_group_association" "nsg-association" {
  network_interface_id      = azurerm_network_interface.nic.id      #Here, we are reference the existing nic
  network_security_group_id = azurerm_network_security_group.nsg.id #Here, we are reference the existing network security group
}