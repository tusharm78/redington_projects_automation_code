######
# Output  block to get details about the resource group
######

output "azurerm_resource_group_name" {
  description = "name of the resource group provisioned"
  value       = azurerm_resource_group.rg.name
}

output "azurerm_resource_group_location" {
  description = "location of the resource group provisioned"
  value       = azurerm_resource_group.rg.location

}
