# Install the ImportExcel module if not already installed
if (-not (Get-Module -ListAvailable -Name ImportExcel)) {
    Install-Module -Name ImportExcel -Scope CurrentUser -Force
}

# Import the ImportExcel module
Import-Module ImportExcel

# Define the output Excel file path in the current directory
$outputFile = "$PWD\Azure_Resource_Details.xlsx"

# Initialize lists to store details for each sheet
$vmPlanDetails = @()
$diskDetails = @()
$snapshotDetails = @()
$publicIPDetails = @()

# Get all resource groups
$resourceGroups = Get-AzResourceGroup

# Loop through each resource group
foreach ($rg in $resourceGroups) {
    Write-Host "Processing Resource Group: $($rg.ResourceGroupName)"
    
    try {
        # Get all VMs in the current resource group
        $vms = Get-AzVM -ResourceGroupName $rg.ResourceGroupName -ErrorAction Stop
        
        # Loop through each VM in the current resource group
        foreach ($vm in $vms) {
            # --- VM Plan Details ---
            $plan = $vm.Plan
            $vmPlanDetails += [PSCustomObject]@{
                VMName          = $vm.Name
                ResourceGroup   = $rg.ResourceGroupName
                PlanName        = if ($plan) { $plan.Name } else { "No marketplace plan" }
                Publisher       = if ($plan) { $plan.Publisher } else { "N/A" }
                Product         = if ($plan) { $plan.Product } else { "N/A" }
                PromotionCode   = if ($plan) { $plan.PromotionCode } else { "N/A" }
            }

            # --- Disk Details ---
            $osDisk = $vm.StorageProfile.OsDisk
            $dataDisks = $vm.StorageProfile.DataDisks
            
            # Fetch the OS disk details
            $osDiskDetails = Get-AzDisk -ResourceGroupName $rg.ResourceGroupName -DiskName $osDisk.Name -ErrorAction SilentlyContinue
            
            # Add OS disk details to the list
            $diskDetails += [PSCustomObject]@{
                VMName          = $vm.Name
                ResourceGroup   = $rg.ResourceGroupName
                DiskType        = "OS Disk"
                DiskName        = $osDisk.Name
                DiskSizeGB      = $osDiskDetails.DiskSizeGB
                StorageType     = $osDiskDetails.Sku.Name
                Caching         = $osDisk.Caching
                EncryptionType  = if ($osDiskDetails.Encryption.Type) { $osDiskDetails.Encryption.Type } else { "EncryptionAtRestWithPlatformKey (Platform-managed key)" }
                DiskEncryptionSet = if ($osDiskDetails.Encryption.DiskEncryptionSetId) { $osDiskDetails.Encryption.DiskEncryptionSetId } else { "N/A" }
            }
            
            # Add data disk details to the list (if any)
            if ($dataDisks) {
                foreach ($dataDisk in $dataDisks) {
                    $dataDiskDetails = Get-AzDisk -ResourceGroupName $rg.ResourceGroupName -DiskName $dataDisk.Name -ErrorAction SilentlyContinue
                    
                    $diskDetails += [PSCustomObject]@{
                        VMName          = $vm.Name
                        ResourceGroup   = $rg.ResourceGroupName
                        DiskType        = "Data Disk"
                        DiskName        = $dataDisk.Name
                        DiskSizeGB      = $dataDiskDetails.DiskSizeGB
                        StorageType     = $dataDiskDetails.Sku.Name
                        Caching         = $dataDisk.Caching
                        Lun             = $dataDisk.Lun
                        EncryptionType  = if ($dataDiskDetails.Encryption.Type) { $dataDiskDetails.Encryption.Type } else { "EncryptionAtRestWithPlatformKey (Platform-managed key)" }
                        DiskEncryptionSet = if ($dataDiskDetails.Encryption.DiskEncryptionSetId) { $dataDiskDetails.Encryption.DiskEncryptionSetId } else { "N/A" }
                    }
                }
            }
        }
    } catch {
        Write-Host "No VMs found in Resource Group: $($rg.ResourceGroupName) or an error occurred."
    }
}

# --- Snapshot Details ---
$snapshots = Get-AzSnapshot
foreach ($snapshot in $snapshots) {
    $snapshotDetails += [PSCustomObject]@{
        SnapshotName      = $snapshot.Name
        ResourceGroup     = $snapshot.ResourceGroupName
        SnapshotType      = if ($snapshot.Incremental) { "Incremental" } else { "Full" }
        SourceDiskID      = $snapshot.CreationData.SourceResourceId
        CreationTime      = $snapshot.TimeCreated
        DiskSizeGB        = $snapshot.DiskSizeGB
        StorageType       = $snapshot.Sku.Name
        EncryptionType    = if ($snapshot.Encryption) { $snapshot.Encryption.Type } else { "Not encrypted" }
        DiskEncryptionSet = if ($snapshot.Encryption.DiskEncryptionSetId) { $snapshot.Encryption.DiskEncryptionSetId } else { "N/A" }
    }
}

# --- Public IP Details ---
$publicIPs = Get-AzPublicIpAddress
foreach ($publicIP in $publicIPs) {
    $vmName = "N/A"
    if ($publicIP.IpConfiguration) {
        $nicId = $publicIP.IpConfiguration.Id -replace "/ipConfigurations/.*", ""
        $nic = Get-AzNetworkInterface -ResourceId $nicId -ErrorAction SilentlyContinue
        if ($nic -and $nic.VirtualMachine) {
            $vm = Get-AzVM -ResourceId $nic.VirtualMachine.Id -ErrorAction SilentlyContinue
            $vmName = if ($vm) { $vm.Name } else { "Unable to retrieve VM details" }
        }
    }
    
    $publicIPDetails += [PSCustomObject]@{
        PublicIPName      = $publicIP.Name
        ResourceGroup     = $publicIP.ResourceGroupName
        IPAddress         = $publicIP.IpAddress
        DNSName           = $publicIP.DnsSettings.Fqdn
        AllocationMethod  = $publicIP.PublicIpAllocationMethod
        SKU               = $publicIP.Sku.Name
        Location          = $publicIP.Location
        AssociatedResource = if ($publicIP.IpConfiguration) { $publicIP.IpConfiguration.Id } else { "Not associated" }
        AttachedVMName    = $vmName
        Tags              = $publicIP.Tags | ConvertTo-Json -Compress
    }
}

# Export all details to a single Excel workbook with separate sheets
$vmPlanDetails | Export-Excel -Path $outputFile -WorksheetName "VM Plan Details" -AutoSize -FreezeTopRow -BoldTopRow
$diskDetails | Export-Excel -Path $outputFile -WorksheetName "Disk Details" -AutoSize -FreezeTopRow -BoldTopRow
$snapshotDetails | Export-Excel -Path $outputFile -WorksheetName "Snapshot Details" -AutoSize -FreezeTopRow -BoldTopRow
$publicIPDetails | Export-Excel -Path $outputFile -WorksheetName "Public IP Details" -AutoSize -FreezeTopRow -BoldTopRow

Write-Host "All details saved to $outputFile"