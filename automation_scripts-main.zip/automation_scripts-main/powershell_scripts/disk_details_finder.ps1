# Install the ImportExcel module if not already installed
if (-not (Get-Module -ListAvailable -Name ImportExcel)) {
    Install-Module -Name ImportExcel -Scope CurrentUser -Force
}

# Import the ImportExcel module
Import-Module ImportExcel

# Define the output Excel file path in the current directory
$outputFile = "$PWD\Disk_Encryption_Details.xlsx"

# Initialize a list to store disk details
$diskDetails = @()

# Get all resource groups
$resourceGroups = Get-AzResourceGroup

# Loop through each resource group
foreach ($rg in $resourceGroups) {
    Write-Host "Processing Resource Group: $($rg.ResourceGroupName)"
    
    try {
        # Get all VMs in the current resource group
        $vms = Get-AzVM -ResourceGroupName $rg.ResourceGroupName -ErrorAction Stop
        
        # Loop through each VM in the current resource group
        foreach ($vm in $vms) {
            # Get disk details for the VM
            $osDisk = $vm.StorageProfile.OsDisk
            $dataDisks = $vm.StorageProfile.DataDisks
            
            # Fetch the OS disk details
            $osDiskDetails = Get-AzDisk -ResourceGroupName $rg.ResourceGroupName -DiskName $osDisk.Name -ErrorAction SilentlyContinue
            
            # Add OS disk details to the list
            $diskDetails += [PSCustomObject]@{
                VMName          = $vm.Name
                ResourceGroup   = $rg.ResourceGroupName
                DiskType        = "OS Disk"
                DiskName        = $osDisk.Name
                DiskSizeGB      = $osDiskDetails.DiskSizeGB
                StorageType     = $osDiskDetails.Sku.Name
                Caching         = $osDisk.Caching
                EncryptionType  = if ($osDiskDetails.Encryption.Type) { $osDiskDetails.Encryption.Type } else { "EncryptionAtRestWithPlatformKey (Platform-managed key)" }
                DiskEncryptionSet = if ($osDiskDetails.Encryption.DiskEncryptionSetId) { $osDiskDetails.Encryption.DiskEncryptionSetId } else { "N/A" }
            }
            
            # Add data disk details to the list (if any)
            if ($dataDisks) {
                foreach ($dataDisk in $dataDisks) {
                    $dataDiskDetails = Get-AzDisk -ResourceGroupName $rg.ResourceGroupName -DiskName $dataDisk.Name -ErrorAction SilentlyContinue
                    
                    $diskDetails += [PSCustomObject]@{
                        VMName          = $vm.Name
                        ResourceGroup   = $rg.ResourceGroupName
                        DiskType        = "Data Disk"
                        DiskName        = $dataDisk.Name
                        DiskSizeGB      = $dataDiskDetails.DiskSizeGB
                        StorageType     = $dataDiskDetails.Sku.Name
                        Caching         = $dataDisk.Caching
                        Lun             = $dataDisk.Lun
                        EncryptionType  = if ($dataDiskDetails.Encryption.Type) { $dataDiskDetails.Encryption.Type } else { "EncryptionAtRestWithPlatformKey (Platform-managed key)" }
                        DiskEncryptionSet = if ($dataDiskDetails.Encryption.DiskEncryptionSetId) { $dataDiskDetails.Encryption.DiskEncryptionSetId } else { "N/A" }
                    }
                }
            }
        }
    } catch {
        Write-Host "No VMs found in Resource Group: $($rg.ResourceGroupName) or an error occurred."
    }
}

# Export the disk details to an Excel file
$diskDetails | Export-Excel -Path $outputFile -AutoSize -FreezeTopRow -BoldTopRow

Write-Host "Disk details saved to $outputFile"