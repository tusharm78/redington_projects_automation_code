# Define the output file path in the current directory
$outputFile = "$PWD\PublicIP_Details_With_VM.txt"

# Get all public IP addresses in the subscription
$publicIPs = Get-AzPublicIpAddress

# Check if any public IP addresses exist
if ($publicIPs.Count -eq 0) {
    Write-Host "No public IP addresses found in the subscription."
    "No public IP addresses found in the subscription." | Out-File -FilePath $outputFile
    exit
}

# Loop through each public IP address
foreach ($publicIP in $publicIPs) {
    # Prepare the output string for public IP details
    $output = "Public IP Name: $($publicIP.Name)`n"
    $output += "Resource Group: $($publicIP.ResourceGroupName)`n"
    $output += "IP Address: $($publicIP.IpAddress)`n"
    $output += "DNS Name: $($publicIP.DnsSettings.Fqdn)`n"
    $output += "Allocation Method: $($publicIP.PublicIpAllocationMethod)`n"
    $output += "SKU: $($publicIP.Sku.Name)`n"
    $output += "Location: $($publicIP.Location)`n"
    
    # Check if the public IP is associated with a resource
    if ($publicIP.IpConfiguration) {
        $output += "Associated Resource: $($publicIP.IpConfiguration.Id)`n"
        
        # Extract the NIC ID from the IP configuration
        $nicId = $publicIP.IpConfiguration.Id -replace "/ipConfigurations/.*", ""
        
        # Get the NIC details
        $nic = Get-AzNetworkInterface -ResourceId $nicId -ErrorAction SilentlyContinue
        
        if ($nic) {
            # Check if the NIC is attached to a VM
            if ($nic.VirtualMachine) {
                $vmId = $nic.VirtualMachine.Id
                $vm = Get-AzVM -ResourceId $vmId -ErrorAction SilentlyContinue
                if ($vm) {
                    $output += "Attached VM Name: $($vm.Name)`n"
                } else {
                    $output += "Attached VM Name: Unable to retrieve VM details`n"
                }
            } else {
                $output += "Attached VM Name: Not attached to a VM`n"
            }
        } else {
            $output += "Attached VM Name: NIC not found`n"
        }
    } else {
        $output += "Associated Resource: Not associated`n"
        $output += "Attached VM Name: Not applicable`n"
    }
    
    $output += "Tags: $($publicIP.Tags | ConvertTo-Json -Compress)`n"
    $output += "-------------------------`n"
    
    # Write the output to the file
    $output | Out-File -FilePath $outputFile -Append
}

Write-Host "Public IP details with DNS and VM information saved to $outputFile"