# Define the output file path in the current directory
$outputFile = "$PWD\Snapshot_Details.txt"

# Get all snapshots in the subscription
$snapshots = Get-AzSnapshot

# Check if any snapshots exist
if ($snapshots.Count -eq 0) {
    Write-Host "No snapshots found in the subscription."
    "No snapshots found in the subscription." | Out-File -FilePath $outputFile
    exit
}

# Loop through each snapshot
foreach ($snapshot in $snapshots) {
    # Prepare the output string for snapshot details
    $output = "Snapshot Name: $($snapshot.Name)`n"
    $output += "Resource Group: $($snapshot.ResourceGroupName)`n"
    $output += "Snapshot Type: $($snapshot.Incremental ? 'Incremental' : 'Full')`n"
    $output += "Source Disk ID: $($snapshot.CreationData.SourceResourceId)`n"
    $output += "Creation Time: $($snapshot.TimeCreated)`n"
    $output += "Disk Size (GB): $($snapshot.DiskSizeGB)`n"
    $output += "Storage Type: $($snapshot.Sku.Name)`n"
    
    # Check encryption details for the snapshot
    if ($snapshot.Encryption) {
        $output += "Encryption Type: $($snapshot.Encryption.Type)`n"
        if ($snapshot.Encryption.DiskEncryptionSetId) {
            $output += "Disk Encryption Set: $($snapshot.Encryption.DiskEncryptionSetId)`n"
        }
    } else {
        $output += "Encryption: Not encrypted`n"
    }
    $output += "-------------------------`n"
    
    # Write the output to the file
    $output | Out-File -FilePath $outputFile -Append
}

Write-Host "Snapshot details saved to $outputFile"