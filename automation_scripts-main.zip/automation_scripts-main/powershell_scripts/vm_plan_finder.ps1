# Define the output file path
$outputFile = "$PWD\VM_Plan_List.txt"

# Get all resource groups
$resourceGroups = Get-AzResourceGroup

# Loop through each resource group
foreach ($rg in $resourceGroups) {
    Write-Host "Processing Resource Group: $($rg.ResourceGroupName)"
    
    try {
        # Get all VMs in the current resource group
        $vms = Get-AzVM -ResourceGroupName $rg.ResourceGroupName -ErrorAction Stop
        
        # Loop through each VM in the current resource group
        foreach ($vm in $vms) {
            # Get the VM plan information
            $plan = $vm.Plan
            
            # Prepare the output string
            $output = "VM Name: $($vm.Name)`n"
            
            # Check if the VM has a plan
            if ($plan) {
                $output += "Plan: $($plan.Name)`n"
                $output += "Publisher: $($plan.Publisher)`n"
                $output += "Product: $($plan.Product)`n"
                $output += "Promotion Code: $($plan.PromotionCode)`n"
            } else {
                $output += "Plan: No marketplace plan associated with this VM.`n"
            }
            $output += "-------------------------`n"
            
            # Write the output to the file
            $output | Out-File -FilePath $outputFile -Append
        }
    } catch {
        $errorMessage = "No VMs found in Resource Group: $($rg.ResourceGroupName) or an error occurred.`n"
        $errorMessage | Out-File -FilePath $outputFile -Append
    }
}

Write-Host "Output saved to $outputFile"