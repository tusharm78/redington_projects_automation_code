import requests
from bs4 import BeautifulSoup
import csv

# URL of the webpage
url = "https://learn.microsoft.com/en-us/azure/azure-resource-manager/management/move-support-resources"

# Send a GET request to the webpage
response = requests.get(url)

# Check if the request was successful
if response.status_code == 200:
    # Parse the HTML content using BeautifulSoup
    soup = BeautifulSoup(response.content, 'html.parser')
    
    # Find all <h2> headers
    h2_headers = soup.find_all('h2')
    
    # Initialize a list to store the hierarchical paths and subscription values
    data = []
    
    # Loop through each <h2> header and its associated table
    for h2 in h2_headers:
        # Get the <h2> header text (field before "/")
        h2_text = h2.text.strip()
        
        # Find the next sibling table
        table = h2.find_next('table')
        
        if table:
            # Extract table headers
            headers = [header.text.strip() for header in table.find_all('th')]
            
            # Check if the table has the required columns
            if 'Resource type' in headers and 'Subscription' in headers:
                # Find the index of the required columns
                resource_type_index = headers.index('Resource type')
                subscription_index = headers.index('Subscription')
                
                # Iterate over the rows of the table (skip the header row)
                for row in table.find_all('tr')[1:]:
                    columns = row.find_all('td')
                    if len(columns) > max(resource_type_index, subscription_index):
                        resource_type = columns[resource_type_index].text.strip()
                        subscription = columns[subscription_index].text.strip()
                        
                        # Combine <h2> header and resource type into the desired format
                        hierarchical_path = f"{h2_text}/{resource_type}"
                        
                        # Append the hierarchical path and subscription to the list
                        data.append([hierarchical_path, subscription])
    
    # Save the data to a CSV file
    with open('output3.csv', 'w', newline='', encoding='utf-8') as csvfile:
        writer = csv.writer(csvfile, delimiter='\t')  # Use tab as delimiter
        writer.writerow(['Hierarchical Path', 'Subscription'])  # Write header
        writer.writerows(data)  # Write data rows
    
    print("Data saved to output3.csv")
else:
    print(f"Failed to retrieve the webpage. Status code: {response.status_code}")
