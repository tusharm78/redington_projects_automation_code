import time
import subprocess
import json
import requests
import sys

# AWS Parameters and Teams Webhook URL
instance_id = "i-05b9ccaada3364ee0"  # Replace with the EC2 instance ID
ami_name = "Sankar-Gitlab-Runner-Test"  # Replace with the desired AMI name
ami_description = "Sankar-Gitlab-Runner-Test"  # Replace with a description for the AMI
ami_tags = [
    {"Key": "Name", "Value": "Sankar-Gitlab-Runner-Test"} # Replace with your desired tags
]  
s3_bucket = "keerthanabucket01"  # Replace with your S3 bucket name
s3_prefix = "exports/"  # Replace with your S3 prefix (e.g., "exports/")
disk_format = "vhd"  # Specify the desired disk image format
teams_webhook_url = "https://redingtonscm.webhook.office.com/webhookb2/7656f8ec-ecd4-4aca-a0e5-4e36f474a8ae@e79918f6-a69b-4b33-8166-e897131f7346/IncomingWebhook/8561275a802e408082a655686d7d45f0/44c70e4d-9b92-4a9d-9aef-33be654f4d8a/V27t_QFqfZRbDcsDFEJseFsW82pFLD-QWGnI8Sx0FpnDg1"  # Replace with your Teams webhook URL

def create_ami(instance_id, ami_name, ami_description, ami_tags):
    """Create an AMI from an EC2 instance with description, tags, and no reboot."""
    try:
        # Convert tags into the correct AWS CLI format
        tags_str = "ResourceType=image,Tags=[" + ",".join([f"{{Key={tag['Key']},Value={tag['Value']}}}" for tag in ami_tags]) + "]"

        # Build the command
        command = [
            "aws", "ec2", "create-image",
            "--instance-id", instance_id,
            "--name", ami_name,
            "--description", ami_description,
            "--tag-specifications", tags_str,
            "--no-reboot"
        ]

        # Debug: Print the command to see how it will be executed
        print(f"Executing command: {' '.join(command)}")

        # Run the command
        result = subprocess.run(command, capture_output=True, text=True)

        # Debug: Print the output and error
        print(f"Command output: {result.stdout}")
        print(f"Command error: {result.stderr}")

        # Check for errors
        if result.returncode != 0:
            print("Command failed. Please verify parameters.")
            return None

        # Parse the output to get the AMI ID
        if not result.stdout.strip():
            print("Error: Empty response from AWS CLI.")
            return None

        output = json.loads(result.stdout)
        ami_id = output["ImageId"]
        print(f"AMI creation started. AMI ID: {ami_id}")
        return ami_id

    except Exception as e:
        print(f"Error creating AMI: {e}")
        return None

def check_ami_status(ami_id):
    """Check the status of the AMI creation process."""
    try:
        result = subprocess.run(
            ["aws", "ec2", "describe-images", "--image-ids", ami_id],
            capture_output=True,
            text=True
        )
        output = json.loads(result.stdout)
        status = output["Images"][0]["State"]
        return status
    except Exception as e:
        print(f"Error checking AMI status: {e}")
        return None

def start_export_task(ami_id, s3_bucket, s3_prefix, disk_format):
    """Start the AMI export process."""
    try:
        result = subprocess.run(
            [
                "aws", "ec2", "export-image",
                "--image-id", ami_id,
                "--disk-image-format", disk_format,
                "--s3-export-location", f"S3Bucket={s3_bucket},S3Prefix={s3_prefix}"
            ],
            capture_output=True,
            text=True
        )
        output = json.loads(result.stdout)
        export_task_id = output["ExportImageTaskId"]
        print(f"Export task started successfully. Task ID: {export_task_id}")
        return export_task_id
    except Exception as e:
        print(f"Error starting export task: {e}")
        return None

def check_export_status(task_id):
    """Check the status of the export-image task."""
    try:
        result = subprocess.run(
            ["aws", "ec2", "describe-export-image-tasks", "--export-image-task-ids", task_id],
            capture_output=True,
            text=True
        )
        output = json.loads(result.stdout)
        status = output["ExportImageTasks"][0]["Status"]
        return status
    except Exception as e:
        print(f"Error checking export status: {e}")
        return None

def send_message_to_teams(webhook_url, message):
    """Send a message to a Teams channel via webhook."""
    payload = {"text": message}
    headers = {"Content-Type": "application/json"}
    try:
        response = requests.post(webhook_url, headers=headers, json=payload)
        if response.status_code == 200:
            print("Message sent to Teams successfully.")
        else:
            print(f"Failed to send message to Teams: {response.status_code}, {response.text}")
    except Exception as e:
        print(f"Error sending message to Teams: {e}")

# Main script logic
ami_id = create_ami(instance_id, ami_name, ami_description, ami_tags)

if ami_id:
    # Wait for the AMI creation to complete
    while True:
        ami_status = check_ami_status(ami_id)
        if ami_status == "available":
            print(f"AMI {ami_id} is ready.")
            send_message_to_teams(teams_webhook_url, f"The AMI creation (ID: {ami_id}) has been completed successfully!")
            break
        elif ami_status == "failed":
            print(f"AMI creation failed.")
            send_message_to_teams(teams_webhook_url, f"The AMI creation (ID: {ami_id}) has failed.")
            sys.exit(1)
        else:
            print(f"AMI creation status: {ami_status}. Checking again in 2 minutes.")
            time.sleep(120)  # Wait 2 minutes before checking again

    # Start the export task
    export_task_id = start_export_task(ami_id, s3_bucket, s3_prefix, disk_format)

    if export_task_id:
        # Monitor the export task
        while True:
            export_status = check_export_status(export_task_id)
            if export_status == "completed":
                send_message_to_teams(teams_webhook_url, f"The AWS EC2 export-image task (ID: {export_task_id}) has been completed successfully!")
                sys.exit(0)  # Exit the script after successful export
            elif export_status == "failed":
                send_message_to_teams(teams_webhook_url, f"The AWS EC2 export-image task (ID: {export_task_id}) has failed.")
                sys.exit(1)
            else:
                print(f"Export task status: {export_status}. Checking again in 5 minutes.")
                time.sleep(300)  # Wait 5 minutes before checking again
    else:
        print("Failed to start the export task. Exiting.")
        sys.exit(1)
else:
    print("Failed to create AMI. Exiting.")
    sys.exit(1)