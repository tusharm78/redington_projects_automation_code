import boto3
import json
import pandas as pd


def get_name_from_tags(tags):
    """Extract the 'Name' tag from a list of tags."""
    if not tags:
        return "N/A"
    for tag in tags:
        if tag['Key'] == 'Name':
            return tag['Value']
    return "N/A"


def get_ec2_details(region):
    ec2_client = boto3.client('ec2', region_name=region)
    instances = []

    # Describe EC2 instances
    response = ec2_client.describe_instances()

    for reservation in response['Reservations']:
        for instance in reservation['Instances']:
            # Fetch VPC, Subnet, and Security Group details
            vpc_id = instance.get('VpcId', 'N/A')
            subnet_id = instance.get('SubnetId', 'N/A')

            # Fetch security groups
            security_groups = [
                {
                    'GroupId': sg['GroupId'],
                    'GroupName': sg['GroupName']
                }
                for sg in instance['SecurityGroups']
            ]

            # Get VPC name
            vpc_name = "N/A"
            if vpc_id != "N/A":
                vpc_response = ec2_client.describe_vpcs(VpcIds=[vpc_id])
                vpc_name = get_name_from_tags(vpc_response['Vpcs'][0].get('Tags'))

            # Get Subnet name
            subnet_name = "N/A"
            if subnet_id != "N/A":
                subnet_response = ec2_client.describe_subnets(SubnetIds=[subnet_id])
                subnet_name = get_name_from_tags(subnet_response['Subnets'][0].get('Tags'))

            # Get EC2 instance name
            instance_name = get_name_from_tags(instance.get('Tags', []))

            # Collect instance details
            instance_details = {
                'Name': instance_name,  # Name column moved to the first position
                'InstanceId': instance.get('InstanceId'),
                'InstanceType': instance.get('InstanceType'),
                'State': instance['State']['Name'],
                'PublicIP': instance.get('PublicIpAddress', 'N/A'),
                'PrivateIP': instance.get('PrivateIpAddress', 'N/A'),
                'AMI': instance.get('ImageId'),
                'KeyName': instance.get('KeyName', 'N/A'),
                'LaunchTime': instance['LaunchTime'].isoformat(),
                'VPCId': vpc_id,
                'VPCName': vpc_name,
                'SubnetId': subnet_id,
                'SubnetName': subnet_name,
                'SecurityGroups': security_groups,
                'EBSVolumes': [
                    {
                        'VolumeId': vol['Ebs']['VolumeId'],
                        'State': vol['Ebs']['Status']
                    }
                    for vol in instance.get('BlockDeviceMappings', [])
                    if 'Ebs' in vol
                ]
            }
            instances.append(instance_details)

    return instances


def save_to_json(instances, output_file):
    """Save details to a JSON file."""
    with open(output_file, 'w') as f:
        json.dump(instances, f, indent=4)
    print(f"Details saved to {output_file}")


def save_to_excel(instances, output_file):
    """Save details to an Excel file."""
    if instances:
        # Convert the list of dictionaries to a pandas DataFrame
        df = pd.DataFrame(instances)
        # Save the DataFrame to an Excel file
        df.to_excel(output_file, index=False)
        print(f"Details saved to {output_file}")
    else:
        print("No instances found to save.")


if __name__ == "__main__":
    region = input("Enter AWS Region (e.g., us-east-1): ")

    print("Fetching EC2 instance details...")
    instances = get_ec2_details(region)

    output_format = input("Save output as JSON or Excel (default: Excel): ").strip().lower()
    output_file = f"ec2_details.{output_format if output_format == 'json' else 'xlsx'}"

    if output_format == "json":
        save_to_json(instances, output_file)
    else:
        save_to_excel(instances, output_file)