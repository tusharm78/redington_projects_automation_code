##########
# Variables for data blocks
##########

variable "resource_group_name" {
  description = "name of the resource group"
  type        = string
  default     = "rg-devqa" # Provide the resource group name
}

variable "virtual_network_name" {
  description = "name of the virtual network"
  type        = string
  default     = "spoke-vnet" # Provide the virtual network name
}

variable "subnet_name" {
  description = "Specifies the name of the Subnet"
  type        = string
  default     = "dev-subnet" # Provide the subnet name
}

##########
# Variables for Virtual machine
##########

variable "vm_name" {
  description = "name of the virtual machine"
  type        = string
  default     = "vm-bull-dev" # Provide the virtual machine
}

variable "vm_size" {
  description = "size of the virtual machine"
  type        = string
  default     = "Standard_E4s_v5" # Provide the virtual machine size. Ex: Standard_b2ms
}

variable "admin_username" {
  description = "login username of the virtual machine"
  type        = string
  default     = "bulldevadmin" # Provide the username
}

variable "admin_password" {
  description = "login password of the virtual machine"
  type        = string
  sensitive   = true
  default     = "Kn#Bv^4h&8dEiZ" # Provide the password
}

##########
# Variables for OS Disk
##########

variable "caching" {
  description = "caching type of os disk. Ex: ReadWrite"
  type        = string
  default     = "ReadWrite" # Provide the caching method for os disk
}

variable "storage_account_type" {
  description = "#The Type of Storage Account which should back this the Internal OS Disk. Possible values are Standard_LRS, StandardSSD_LRS, Premium_LRS, StandardSSD_ZRS and Premium_ZRS."
  type        = string
  default     = "Standard_LRS" # Provide the storage account type for os disk
}

##########
# Variables for Source Image Reference block variables
##########

variable "publisher" {
  description = "Specifies the Publisher of the Marketplace Image this Virtual Machine should be created from. Ex: microsoftwindowsserver"
  type        = string
  default     = "microsoftwindowsserver" # Provide the publisher for os
}

variable "offer" {
  description = "Specifies the offer of the image used to create the virtual machines. Ex: windowsserver"
  type        = string
  default     = "windowsserver" # Provide the offer for the image
}

variable "sku" {
  description = "Specifies the SKU of the image used to create the virtual machines. Ex: 2022-datacenter"
  type        = string
  default     = "2019-datacenter-gensecond" # Provide the sku for the image
}

variable "os_version" {
  description = "Specifies the version of the image used to create the virtual machines Ex: latest"
  type        = string
  default     = "latest" # Provide the version for the image
}

variable "tags" {
  type        = map(any)
  description = "A mapping of tags which should be assigned to the windows VM"
  default = {
    "Created_By" = "Terraform_Automation" # This is a mandatory tag
    #"Environment" = "Prod" # You can modify this tag based to your needs
  }
}

##########
# Variables for license type
##########

variable "license_type" {
  description = "Specifies the type of on-premise license (also known as Azure Hybrid Use Benefit) which should be used for this Virtual Machine. Possible values are None, Windows_Client and Windows_Server"
  type = string
  default = "Windows_Server" # Provide the on-premise license type
}

##########
# Variables for creating managed(data) disk
##########

variable "disk_name" {
  description = "Specifies the name of the Managed Disk"
  type        = string
  default     = "datadisk" # Provide the name for the disk
}

variable "data_disk_storage_account_type" {
  description = "The type of storage to use for the managed disk. Possible values are Standard_LRS, StandardSSD_ZRS, Premium_LRS, PremiumV2_LRS, Premium_ZRS, StandardSSD_LRS or UltraSSD_LRS"
  type        = string
  default     = "Standard_LRS" # Provide the storage account type for data disk
}

variable "create_option" {
  description = "The Create Option of the Data Disk, such as Empty or Attach. Defaults to Attach"
  type        = string
  default     = "Empty" # Provide the value for the create option for the disk
}

variable "disk_size_gb" {
  description = "value"
  type        = string
  default     = "512" # Provide the size of the disk. Ex: 10 or 20. Provide the value as whole number only
}

##########
# Variables for attaching managed(data) disk
##########

variable "lun" {
  description = "The Logical Unit Number of the Data Disk, which needs to be unique within the Virtual Machine"
  type        = number
  default     = "1" #Provide the lun for the disk. Ex: 1
}

variable "data_disk_caching" {
  description = "Specifies the caching requirements for this Data Disk. Possible values include None, ReadOnly and ReadWrite"
  type        = string
  default     = "ReadWrite" #Provide the caching option for data disk
}

##########
# Variables for creating managed(data) disk - 1
##########

variable "disk_name_1" {
  description = "Specifies the name of the Managed Disk"
  type        = string
  default     = "datadisk-1" # Provide the name for the disk
}

variable "data_disk_storage_account_type_1" {
  description = "The type of storage to use for the managed disk. Possible values are Standard_LRS, StandardSSD_ZRS, Premium_LRS, PremiumV2_LRS, Premium_ZRS, StandardSSD_LRS or UltraSSD_LRS"
  type        = string
  default     = "Standard_LRS" # Provide the storage account type for data disk
}

variable "create_option_1" {
  description = "The Create Option of the Data Disk, such as Empty or Attach. Defaults to Attach"
  type        = string
  default     = "Empty" # Provide the value for the create option for the disk
}

variable "disk_size_gb_1" {
  description = "value"
  type        = string
  default     = "512" # Provide the size of the disk. Ex: 10 or 20. Provide the value as whole number only
}

##########
# Variables for attaching managed(data) disk - 1
##########

variable "lun_1" {
  description = "The Logical Unit Number of the Data Disk, which needs to be unique within the Virtual Machine"
  type        = number
  default     = "2" #Provide the lun for the disk. Ex: 1
}

variable "data_disk_caching_1" {
  description = "Specifies the caching requirements for this Data Disk. Possible values include None, ReadOnly and ReadWrite"
  type        = string
  default     = "ReadWrite" #Provide the caching option for data disk
}

##########
# Variables for Public IP
##########

# variable "public_ip_name" {
#   description = "Specifies the name of the Public IP"
#   type        = string
#   default     = "" # Provide the name for public ip
# }

# variable "allocation_method" {
#   description = "Defines the allocation method for this IP address. Possible values are Static or Dynamic"
#   type        = string
#   default     = "" #Provide the allocation method for the public ip
# }

##########
# Variables for Network Interface
##########

variable "nic_name" {
  description = "The name of the Network Interface"
  type        = string
  default     = "nic-bull-dev" #Provide the network interface card name
}

variable "ip_configuration_name" {
  description = "A name used for this IP Configuration"
  type        = string
  default     = "internal" #Provide the network ip configuration name. Ex: internal
}

variable "private_ip_address_allocation" {
  description = "The allocation method used for the Private IP Address. Possible values are Dynamic and Static"
  type        = string
  default     = "Dynamic" #Provide the allocation method for the private ip
}

##########
# Variables for Network Security Group
##########

variable "nsg_name" {
  description = "Specifies the name of the network security group"
  type        = string
  default     = "nsg-bull-dev" #Provide the network security group name
}

variable "nsg_rule_name" {
  description = "The name of the security rule"
  type        = string
  default     = "AllowRDP" #Provide the network security group rule name. Ex: AllowRDP
}

variable "nsg_rule_priority" {
  description = "Specifies the priority of the rule. The value can be between 100 and 4096. The priority number must be unique for each rule in the collection. The lower the priority number, the higher the priority of the rule"
  type        = number
  default     = "100" #Provide the priority of the rule. Ex: 100
}

variable "direction" {
  description = "The direction specifies if rule will be evaluated on incoming or outgoing traffic. Possible values are Inbound and Outbound"
  type        = string
  default     = "Inbound" #Provide the direction of the rule

}

variable "access" {
  description = "Specifies whether network traffic is allowed or denied. Possible values are Allow and Deny"
  type        = string
  default     = "Allow" #Provide the access

}

variable "protocol" {
  description = "Network protocol this rule applies to. Possible values include Tcp, Udp, Icmp, Esp, Ah or * (which matches all)"
  type        = string
  default     = "Tcp" #Provide the protocol of the rule
}

variable "source_port_range" {
  description = "Source Port or Range. Integer or range between 0 and 65535 or * to match any"
  type        = string
  default     = "*" #Provide the source port range
}

variable "destination_port_range" {
  description = "Destination Port or Range. Integer or range between 0 and 65535 or * to match any"
  type        = string
  default     = "3389" #Provide the destination port range. Ex: 3389
}

variable "source_address_prefix" {
  description = "CIDR or source IP range or * to match any IP. Tags such as VirtualNetwork, AzureLoadBalancer and Internet can also be used"
  type        = string
  default     = "" #Provide the source IP or IP ranges. Ex: 0.0.0.0/0 or 1.2.3.4/32
}

variable "destination_address_prefix" {
  description = "CIDR or destination IP range or * to match any IP. Tags such as VirtualNetwork, AzureLoadBalancer and Internet can also be used"
  type        = string
  default     = "*" # Provide the destination IP or IP ranges
}
