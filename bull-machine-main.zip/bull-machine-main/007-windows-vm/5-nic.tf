########
# Resource block to create network interface
########

resource "azurerm_network_interface" "nic" {
  name                = var.nic_name
  resource_group_name = data.azurerm_resource_group.rg.name
  location            = data.azurerm_resource_group.rg.location

  ip_configuration {
    name                          = var.ip_configuration_name
    subnet_id                     = data.azurerm_subnet.subnet.id #Here, we are reference the existing subnet
    private_ip_address_allocation = var.private_ip_address_allocation
    #public_ip_address_id          = azurerm_public_ip.public_ip.id
  }

  tags       = var.tags
  depends_on = [data.azurerm_virtual_network.vnet, data.azurerm_subnet.subnet]

}