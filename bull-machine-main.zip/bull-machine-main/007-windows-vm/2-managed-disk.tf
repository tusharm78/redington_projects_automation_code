########
# Resource block to create managed(data) disk
########

resource "azurerm_managed_disk" "managed_disk" {
  name                 = var.disk_name
  resource_group_name  = data.azurerm_resource_group.rg.name
  location             = data.azurerm_resource_group.rg.location
  storage_account_type = var.data_disk_storage_account_type
  create_option        = var.create_option
  disk_size_gb         = var.disk_size_gb
  tags                 = var.tags
}

########
# Resource block to create managed(data) disk - 1
########

resource "azurerm_managed_disk" "managed_disk_1" {
  name                 = var.disk_name_1
  resource_group_name  = data.azurerm_resource_group.rg.name
  location             = data.azurerm_resource_group.rg.location
  storage_account_type = var.data_disk_storage_account_type_1
  create_option        = var.create_option_1
  disk_size_gb         = var.disk_size_gb_1
  tags                 = var.tags
}
