########
# Resource block to attach data disk to the virtual machine
########

resource "azurerm_virtual_machine_data_disk_attachment" "data_disk_aatchment" {
  managed_disk_id    = azurerm_managed_disk.managed_disk.id
  virtual_machine_id = azurerm_windows_virtual_machine.vm.id
  lun                = var.lun
  caching            = var.data_disk_caching
  depends_on         = [azurerm_managed_disk.managed_disk]
}

########
# Resource block to attach data disk-1 to the virtual machine
########

resource "azurerm_virtual_machine_data_disk_attachment" "data_disk_aatchment_1" {
  managed_disk_id    = azurerm_managed_disk.managed_disk_1.id
  virtual_machine_id = azurerm_windows_virtual_machine.vm.id
  lun                = var.lun_1
  caching            = var.data_disk_caching_1
  depends_on         = [azurerm_managed_disk.managed_disk_1]
}