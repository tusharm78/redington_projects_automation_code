########
# Variables for resource group
########

variable "resource_group_name" {
  type = string
  description = "The Name which should be used for this Resource Group"
  default = "rg-prod" #Provide the resource group name
}

variable "location" {
  type = string
  description = "The Azure Region where the Resource Group should exist"
  default = "Central India" #Provide the location for the resource group
}

variable "tags" {
  type = map(any)
  description = "A mapping of tags which should be assigned to the Resource Group"
  default = {
      "Created_By" = "Terraform_Automation" # This is a mandatory tag
     #"Environment" = "Prod" # You can modify this tag based to your needs
  }
}