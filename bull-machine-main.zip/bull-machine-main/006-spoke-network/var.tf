##########
# Variables for Virtual Network
##########

variable "vnet_name" {
  description = "The name of the virtual network"
  type        = string
  default     = "spoke-vnet" #Provide the name of the virtual network
}

variable "address_space" {
  description = "The address space that is used the virtual network"
  type        = list(string)
  default     = ["172.16.1.0/24"] #Provide the address space for vnet. Ex:10.0.0.0/0
}

variable "resource_group_name" {
  description = "The name of the resource group in which to create the virtual network"
  type        = string
  default     = "rg-devqa" #Provide the resource group name
}

variable "location" {
  description = "The location/region where the virtual network is created"
  type        = string
  default     = "Central India" #Provide the location for the resource group
}

variable "tags" {
  type        = map(any)
  description = "A mapping of tags which should be assigned to the Resource Group"
  default = {
     "Created_By" = "Terraform_Automation" # This is a mandatory tag
    #"Environment" = "Prod" # You can modify this tag based to your needs
  }
}

##########
# Variables for Dev Subnet
##########

variable "subnet_name" {
  description = "The name of the subnet"
  type        = string
  default     = "dev-subnet" #Provide the name of the subnet
}

variable "address_prefixes" {
  description = "The address prefixes to use for the subnet"
  type        = list(string)
  default     = ["172.16.1.128/26"] # Provide the address space for devsubnet
}

##########
# Variables for QA Subnet
##########

variable "subnet_name_1" {
  description = "The name of the subnet"
  type        = string
  default     = "qa-subnet" #Provide the name of the subnet. If you are going to create gateway subnet, put the name as GatewaySubnet
}

variable "address_prefixes_1" {
  description = "The address prefixes to use for the subnet"
  type        = list(string)
  default     = ["172.16.1.64/26"] # Provide the address space for qa Subnet.
}

##########
# Variables for Prod Subnet
##########

variable "subnet_name_2" {
  description = "The name of the subnet"
  type        = string
  default     = "prod-subnet" #Provide the name of the subnet. If you are going to create gateway subnet, put the name as GatewaySubnet
}

variable "address_prefixes_2" {
  description = "The address prefixes to use for the subnet"
  type        = list(string)
  default     = ["172.16.1.0/26"] # Provide the address space for prod Subnet.
}
