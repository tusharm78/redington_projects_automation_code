class MovieFlix {
    constructor() {
        this.currentUser = localStorage.getItem('currentUser');
        this.movies = [];
        this.init();
    }

    async init() {
        if (this.currentUser) {
            await this.loadMovies();
            this.showDashboard();
        } else {
            this.showLogin();
        }
    }

    async loadMovies() {
        try {
            const response = await fetch('/api/movies');
            this.movies = await response.json();
        } catch (error) {
            console.error('Error loading movies:', error);
            this.movies = [];
        }
    }

    showLogin() {
        document.body.innerHTML = `
            <div style="background: linear-gradient(rgba(0,0,0,0.7), rgba(0,0,0,0.7)), #141414; font-family: Arial; color: white; height: 100vh; display: flex; align-items: center; justify-content: center;">
                <div style="background: rgba(0,0,0,0.8); padding: 60px 68px 40px; border-radius: 4px; width: 450px;">
                    <div style="font-size: 32px; font-weight: bold; color: #e50914; margin-bottom: 28px; text-align: center;">MovieFlix</div>
                    <h1 style="font-size: 32px; margin-bottom: 28px;">Sign In</h1>
                    <div style="margin-bottom: 16px;">
                        <input type="text" id="username" placeholder="Username" style="width: 100%; padding: 16px 20px; background: #333; border: none; border-radius: 4px; color: white; font-size: 16px;">
                    </div>
                    <button onclick="movieflix.login()" style="width: 100%; background: #e50914; color: white; padding: 16px; border: none; border-radius: 4px; font-size: 16px; font-weight: bold; cursor: pointer;">Sign In</button>
                    <div id="error" style="color: #e87c03; margin-top: 10px; display: none;"></div>
                </div>
            </div>
        `;
    }

    showDashboard() {
        document.body.innerHTML = `
            <div style="background: #141414; color: white; font-family: Arial; min-height: 100vh;">
                <div style="background: #000; padding: 20px 60px; display: flex; justify-content: space-between; align-items: center;">
                    <div style="font-size: 32px; font-weight: bold; color: #e50914;">MovieFlix</div>
                    <div style="display: flex; align-items: center; gap: 20px;">
                        <span>Welcome, ${this.currentUser}</span>
                        <button onclick="movieflix.logout()" style="background: #e50914; color: white; padding: 8px 16px; border: none; border-radius: 4px; cursor: pointer;">Sign Out</button>
                    </div>
                </div>
                
                <div style="background: linear-gradient(rgba(0,0,0,0.4), rgba(0,0,0,0.4)), #333; height: 400px; display: flex; align-items: center; padding: 0 60px;">
                    <div>
                        <h1 style="font-size: 48px; margin-bottom: 20px;">Unlimited movies, TV shows and more.</h1>
                        <p style="font-size: 18px; margin-bottom: 30px; max-width: 500px;">Watch anywhere. Stream the latest blockbusters and binge-worthy series.</p>
                        <button onclick="movieflix.scrollToMovies()" style="background: #e50914; color: white; padding: 12px 24px; border: none; border-radius: 4px; font-size: 16px; cursor: pointer;">▶ Browse Movies</button>
                    </div>
                </div>

                <div style="padding: 40px 60px;">
                    <h2 style="margin-bottom: 20px; font-size: 24px;">🎬 Movies</h2>
                    <div id="moviesGrid" style="display: grid; grid-template-columns: repeat(auto-fill, minmax(250px, 1fr)); gap: 20px;">
                        ${this.movies.map(movie => `
                            <div onclick="movieflix.playMovie('${movie.filename}')" style="background: #222; border-radius: 8px; overflow: hidden; cursor: pointer; transition: transform 0.3s;" onmouseover="this.style.transform='scale(1.05)'" onmouseout="this.style.transform='scale(1)'">
                                <img src="/api/thumbnails/${movie.thumbnail}" alt="${movie.title}" style="width: 100%; height: 300px; object-fit: cover;">
                                <div style="padding: 15px;">
                                    <h3 style="margin-bottom: 5px; font-size: 16px;">${movie.title}</h3>
                                    <div style="color: #999; font-size: 14px;">${movie.genre}</div>
                                </div>
                            </div>
                        `).join('')}
                    </div>
                </div>
            </div>
        `;
    }

    setUser(username) {
        document.getElementById('username').value = username;
    }

    async login() {
        const username = document.getElementById('username').value;
        const errorDiv = document.getElementById('error');
        
        try {
            const response = await fetch('/api/login', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({ username })
            });
            
            const result = await response.json();
            
            if (result.success) {
                localStorage.setItem('currentUser', username);
                this.currentUser = username;
                await this.loadMovies();
                this.showDashboard();
            } else {
                errorDiv.textContent = result.message;
                errorDiv.style.display = 'block';
            }
        } catch (error) {
            errorDiv.textContent = 'Login failed. Please try again.';
            errorDiv.style.display = 'block';
        }
    }

    logout() {
        localStorage.removeItem('currentUser');
        this.currentUser = null;
        this.showLogin();
    }

    scrollToMovies() {
        document.getElementById('moviesGrid').scrollIntoView({ behavior: 'smooth' });
    }

    playMovie(filename) {
        alert(`🎬 Now Playing: ${filename}\n\nUser: ${this.currentUser}\n\nIn a real streaming app, this would open the video player!`);
    }
}

const movieflix = new MovieFlix();
