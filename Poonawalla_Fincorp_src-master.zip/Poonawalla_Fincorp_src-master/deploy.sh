#!/bin/bash

# Deployment script for Zelevate MovieFlix
# Usage: ./deploy.sh [IMAGE_TAG]

ECR_REGISTRY="737185589565.dkr.ecr.ap-south-1.amazonaws.com"
ECR_REPO="zelevate-frontend-repo"
IMAGE_TAG=${1:-latest}
FULL_IMAGE_NAME="${ECR_REGISTRY}/${ECR_REPO}:${IMAGE_TAG}"

echo "🚀 Deploying Zelevate MovieFlix..."
echo "Image: ${FULL_IMAGE_NAME}"

# Stop existing containers
echo "Stopping existing containers..."
docker stop zelevate-movieflix-new zelevate-database-new 2>/dev/null || true
docker rm zelevate-movieflix-new zelevate-database-new 2>/dev/null || true

# Create network if it doesn't exist
docker network create zelevate-network 2>/dev/null || true

# Start database
echo "Starting database..."
docker run -d --name zelevate-database-new --network zelevate-network \
  -e MYSQL_ROOT_PASSWORD=root123 \
  -e MYSQL_DATABASE=zelevate_prod_dbs \
  -e MYSQL_USER=zelevate \
  -e MYSQL_PASSWORD=prod2024 \
  -p 3307:3306 mysql:8.0

# Wait for database
echo "Waiting for database to start..."
sleep 15

# Pull latest image from ECR
echo "Pulling image from ECR..."
aws ecr get-login-password --region ap-south-1 | docker login --username AWS --password-stdin ${ECR_REGISTRY}
docker pull ${FULL_IMAGE_NAME}

# Start application
echo "Starting application..."
docker run -d --name zelevate-movieflix-new --network zelevate-network \
  -e DB_HOST=zelevate-database-new \
  -e DB_PORT=3306 \
  -e DB_NAME=zelevate_prod_dbs \
  -e DB_USER=zelevate \
  -e DB_PASSWORD=prod2024 \
  -p 8081:8080 ${FULL_IMAGE_NAME}

echo "✅ Deployment completed!"
echo "Application: http://localhost:8081"
echo "Database: localhost:3307"
