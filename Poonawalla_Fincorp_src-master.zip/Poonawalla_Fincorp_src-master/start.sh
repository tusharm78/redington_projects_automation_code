#!/bin/bash

echo "Starting Zelevate MovieFlix Application..."

# Stop any existing containers
docker-compose down

# Build and start the services
docker-compose up -d

echo "Application is starting..."
echo "Database will be available on port 3307"
echo "Application will be available on port 8081"
echo ""
echo "To check logs: docker-compose logs -f"
echo "To stop: docker-compose down"
