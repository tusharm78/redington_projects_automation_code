# Zelevate MovieFlix Application

This project has been extracted from the running Docker container `zelevate-movieflix` and dockerized for easy deployment.

## Project Structure

```
zelevate_final/
├── Dockerfile                       # Docker configuration for the app
├── docker-compose.yml               # Docker Compose configuration
├── start.sh                         # Quick start script
├── app.jar                          # Application JAR file
├── pom.xml                          # Maven configuration
├── src/
│   └── main/
│       ├── java/com/example/        # Compiled Java classes
│       │   ├── MediaApplication.class      # Main Spring Boot application
│       │   ├── AuthController.class        # Authentication controller
│       │   ├── MovieController.class       # Movie management controller
│       │   ├── ThumbnailController.class   # Thumbnail handling controller
│       │   ├── Movie.class                 # Movie entity
│       │   ├── User.class                  # User entity
│       │   ├── MovieRepository.class       # Movie data repository
│       │   ├── UserRepository.class        # User data repository
│       │   └── DataLoader.class            # Data initialization
│       └── resources/
│           ├── application.properties      # Database configuration
│           ├── templates/                  # Thymeleaf templates
│           │   ├── dashboard.html
│           │   ├── movies.html
│           │   └── login.html
│           └── static/                     # Static web resources
│               ├── index.html
│               └── app.js
```

## Quick Start

### Option 1: Using the start script
```bash
cd zelevate_final
./start.sh
```

### Option 2: Using Docker Compose (if available)
```bash
cd zelevate_final
docker-compose up -d
```

### Option 3: Manual Docker commands
```bash
cd zelevate_final

# Create network
docker network create zelevate-network

# Start database
docker run -d --name zelevate-database-new --network zelevate-network \
  -e MYSQL_ROOT_PASSWORD=root123 \
  -e MYSQL_DATABASE=zelevate_prod_dbs \
  -e MYSQL_USER=zelevate \
  -e MYSQL_PASSWORD=prod2024 \
  -p 3307:3306 mysql:8.0

# Wait for database to start, then start application
sleep 10
docker run -d --name zelevate-movieflix-new --network zelevate-network \
  -e DB_HOST=zelevate-database-new \
  -e DB_PORT=3306 \
  -e DB_NAME=zelevate_prod_dbs \
  -e DB_USER=zelevate \
  -e DB_PASSWORD=prod2024 \
  -p 8081:8080 zelevate-app-new
```

## Access Points

- **New Application**: http://localhost:8081
- **New Database**: localhost:3307
- **Original Application**: http://localhost:8080 (if still running)
- **Original Database**: localhost:3306 (if still running)

## Database Configuration

The application connects to MySQL database with these settings:
- Host: zelevate-database-new (in Docker network)
- Port: 3306 (internal), 3307 (external)
- Database: zelevate_prod_dbs
- Username: zelevate
- Password: prod2024

## Management Commands

```bash
# Check container status
docker ps

# View application logs
docker logs zelevate-movieflix-new

# View database logs
docker logs zelevate-database-new

# Stop containers
docker stop zelevate-movieflix-new zelevate-database-new

# Remove containers
docker rm zelevate-movieflix-new zelevate-database-new

# Remove network
docker network rm zelevate-network
```

## Docker Images

- **Application Image**: `zelevate-app-new` (built from extracted JAR)
- **Database Image**: `mysql:8.0`

## Jenkins CI/CD Pipeline

### Prerequisites
- Jenkins server with Docker plugin installed
- AWS CLI configured with ECR permissions
- Docker installed on Jenkins agent

### Pipeline Files
- `Jenkinsfile` - Basic pipeline configuration
- `Jenkinsfile.advanced` - Enhanced pipeline with error handling
- `deploy.sh` - Deployment script for target servers

### Jenkins Setup
1. Create a new Pipeline job in Jenkins
2. Configure SCM to point to your repository
3. Set Pipeline script from SCM
4. Use `Jenkinsfile` or `Jenkinsfile.advanced`

### ECR Repository
- **Registry**: 737185589565.dkr.ecr.ap-south-1.amazonaws.com
- **Repository**: zelevate-frontend-repo
- **Region**: ap-south-1

### Pipeline Stages
1. **Checkout** - Get source code from SCM
2. **Verify Files** - Check required files exist
3. **Build Docker Image** - Create container image
4. **Login to ECR** - Authenticate with AWS ECR
5. **Push to ECR** - Upload image with build number and latest tags
6. **Cleanup** - Remove local images and clean workspace

### Deployment
After successful pipeline execution:
```bash
# Deploy specific version
./deploy.sh 123

# Deploy latest
./deploy.sh
```
