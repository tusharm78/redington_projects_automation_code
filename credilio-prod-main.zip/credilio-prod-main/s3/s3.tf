## S3 bucket
resource "aws_s3_bucket" "do-not-delete-credilio-prod-terraform-backend" {
    bucket = "do-not-delete-credilio-prod-terraform-backend"                    ## name should be do-not-delete-project(replace project name)-terraform-backend
}

terraform {
  required_version = "> 0.14"
  required_providers {
    aws = {
      source  = "hashicorp/aws"
      version = "> 3.0"
    }
  }
}

# Provider Block
provider "aws" {
  region     = "ap-south-1"
  profile = "prod-sso"
}