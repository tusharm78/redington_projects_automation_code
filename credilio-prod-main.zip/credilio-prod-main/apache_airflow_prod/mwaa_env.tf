# Data sources for existing network resources
data "aws_vpc" "existing" {
  id = "vpc-0c1fa416190759c80"
}

data "aws_subnet" "private_1a" {
  id = "subnet-0aa4779518767653a"
}

data "aws_subnet" "private_1b" {
  id = "subnet-0e6ad26bf26dda075"
}

data "aws_subnet" "public" {
  id = "subnet-050e8c168bd80a676"
}

data "aws_nat_gateway" "existing" {
  id = "nat-013ca273f6b0543e1"
}

resource "random_string" "suffix" {
  length  = 8
  special = false
  upper   = false
}

# S3 bucket for MWAA
resource "aws_s3_bucket" "test-credilio-preprod-composer" {
  bucket = "airflow-dag-bucket-${random_string.suffix.result}"
}

resource "aws_s3_bucket_versioning" "test-credilio-preprod-composer_versioning" {
  bucket = aws_s3_bucket.test-credilio-preprod-composer.id
  versioning_configuration {
    status = "Enabled"
  }
}

resource "aws_s3_bucket_public_access_block" "test-credilio-preprod-composer_pab" {
  bucket = aws_s3_bucket.test-credilio-preprod-composer.id
  block_public_acls       = true
  block_public_policy     = true
  ignore_public_acls      = true
  restrict_public_buckets = true
}

# IAM Role with comprehensive permissions
resource "aws_iam_role" "mwaa_execution_role_new" {
  name = "mwaa-execution-role-${random_string.suffix.result}"
  
  assume_role_policy = jsonencode({
    Version = "2012-10-17"
    Statement = [
      {
        Action = "sts:AssumeRole"
        Effect = "Allow"
        Principal = {
          Service = "airflow-env.amazonaws.com"
        }
      }
    ]
  })
}

# Fixed IAM Policy with all required permissions
resource "aws_iam_policy" "mwaa_execution_policy" {
  name = "mwaa-execution-policy-${random_string.suffix.result}"
  
  policy = jsonencode({
    Version = "2012-10-17"
    Statement = [
      {
        Effect = "Allow"
        Action = [
          "airflow:PublishMetrics",
          "airflow:*"
        ]
        Resource = "*"
      },
      {
        Effect = "Allow"
        Action = [
          "s3:GetObject*",
          "s3:GetBucket*",
          "s3:List*",
          "s3:PutObject*",
          "s3:DeleteObject*"
        ]
        Resource = [
          aws_s3_bucket.test-credilio-preprod-composer.arn,
          "${aws_s3_bucket.test-credilio-preprod-composer.arn}/*"
        ]
      },
      {
        Effect = "Allow"
        Action = [
          "logs:CreateLogStream",
          "logs:CreateLogGroup", 
          "logs:PutLogEvents",
          "logs:GetLogEvents",
          "logs:GetLogRecord",
          "logs:GetLogGroupFields",
          "logs:GetQueryResults",
          "logs:DescribeLogGroups",
          "logs:DescribeLogStreams"
        ]
        Resource = [
          "arn:aws:logs:*:*:log-group:airflow-*",
          "arn:aws:logs:*:*:log-group:/aws/amazonmwaa/*"
        ]
      },
      {
        Effect = "Allow"
        Action = [
          "logs:DescribeLogGroups"
        ]
        Resource = "*"
      },
      {
        Effect = "Allow"
        Action = [
          "cloudwatch:PutMetricData",
          "cloudwatch:GetMetricStatistics",
          "cloudwatch:ListMetrics"
        ]
        Resource = "*"
      },
      {
        Effect = "Allow"
        Action = [
          "sqs:ChangeMessageVisibility",
          "sqs:DeleteMessage",
          "sqs:GetQueueAttributes",
          "sqs:GetQueueUrl",
          "sqs:ReceiveMessage",
          "sqs:SendMessage",
          "sqs:CreateQueue",
          "sqs:DeleteQueue"
        ]
        Resource = "arn:aws:sqs:*:*:airflow-celery-*"
      },
      {
        Effect = "Allow"
        Action = [
          "ec2:DescribeVpcs",
          "ec2:DescribeSubnets",
          "ec2:DescribeSecurityGroups",
          "ec2:DescribeNetworkInterfaces",
          "ec2:CreateNetworkInterface",
          "ec2:DeleteNetworkInterface",
          "ec2:AttachNetworkInterface",
          "ec2:DetachNetworkInterface"
        ]
        Resource = "*"
      },
      {
        Effect = "Allow"
        Action = [
          "kms:Decrypt",
          "kms:DescribeKey",
          "kms:GenerateDataKey*",
          "kms:Encrypt"
        ]
        Resource = "*"
      }
    ]
  })
}

resource "aws_iam_role_policy_attachment" "mwaa_execution_policy_attachment" {
  role       = aws_iam_role.mwaa_execution_role_new.name
  policy_arn = aws_iam_policy.mwaa_execution_policy.arn
}

# Security Group for MWAA using existing VPC
resource "aws_security_group" "mwaa_sg_new" {
  name_prefix = "mwaa-sg-prod"
  description = "Security group for MWAA"
  vpc_id      = data.aws_vpc.existing.id

  ingress {
    from_port = 0
    to_port   = 65535
    protocol  = "tcp"
    self      = true
  }

  egress {
    from_port   = 0
    to_port     = 0
    protocol    = "-1"
    cidr_blocks = ["0.0.0.0/0"]
  }

  tags = {
    Name = "mwaa-security-group"
  }
}

# MWAA Environment using existing network resources
resource "aws_mwaa_environment" "mwaa_env_prod" {
  name              = "mwaa-env-${random_string.suffix.result}"
  airflow_version   = "2.10.3"
  environment_class = "mw1.medium"
  
  execution_role_arn = aws_iam_role.mwaa_execution_role_new.arn
  source_bucket_arn  = aws_s3_bucket.test-credilio-preprod-composer.arn
  dag_s3_path        = "dags"

  network_configuration {
    security_group_ids = [aws_security_group.mwaa_sg_new.id]
    subnet_ids         = [
      data.aws_subnet.private_1a.id,
      data.aws_subnet.private_1b.id
    ]
  }

  webserver_access_mode = "PUBLIC_ONLY"
  endpoint_management   = "SERVICE"

  logging_configuration {
    dag_processing_logs {
      enabled   = true
      log_level = "INFO"
    }
    scheduler_logs {
      enabled   = true
      log_level = "INFO"
    }
    task_logs {
      enabled   = true
      log_level = "INFO"
    }
    webserver_logs {
      enabled   = true
      log_level = "INFO"
    }
    worker_logs {
      enabled   = true
      log_level = "INFO"
    }
  }

  min_workers    = 2
  max_workers    = 4
  min_webservers = 2
  max_webservers = 2

  tags = {
    Name        = "mwaa-env"
    Environment = "demo"
  }

  depends_on = [
    aws_s3_bucket_versioning.test-credilio-preprod-composer_versioning
  ]
}

# Outputs
output "vpc_id" {
  value = data.aws_vpc.existing.id
  description = "Existing VPC ID used"
}

output "private_subnet_ids" {
  value = [data.aws_subnet.private_1a.id, data.aws_subnet.private_1b.id]
  description = "Existing private subnet IDs used"
}

output "public_subnet_id" {
  value = data.aws_subnet.public.id
  description = "Existing public subnet ID"
}

output "nat_gateway_id" {
  value = data.aws_nat_gateway.existing.id
  description = "Existing NAT Gateway ID"
}

output "mwaa_webserver_url" {
  value = aws_mwaa_environment.mwaa_env.webserver_url
  description = "MWAA Webserver URL"
}

output "s3_bucket_name" {
  value = aws_s3_bucket.test-credilio-preprod-composer.bucket
  description = "S3 bucket for DAGs"
}

output "mwaa_environment_name" {
  value = aws_mwaa_environment.mwaa_env.name
  description = "MWAA Environment Name"
}
