# # -------------------------------
# # Security Group for MWAA
# # -------------------------------
# resource "aws_security_group" "mwaa_sg" {
#   name        = "mwaa-sg"
#   description = "Security group for MWAA"
#   vpc_id      = "vpc-0c1fa416190759c80"      # Your VPC ID

#   # Ingress (example allows HTTPS from all, ideally restrict to your office IP)
#   ingress {
#     description = "Allow HTTPS from trusted sources"
#     from_port   = 443
#     to_port     = 443
#     protocol    = "tcp"
#     cidr_blocks = ["0.0.0.0/0"]
#   }

#   # Egress - Allow all outbound
#   egress {
#     from_port   = 0
#     to_port     = 0
#     protocol    = "-1"
#     cidr_blocks = ["0.0.0.0/0"]
#   }

#   tags = {
#     Name       = "mwaa-sg"
#     Created-by = "Terraform_Automation"
#   }
# }

# # -------------------------------
# # IAM Role for MWAA Execution
# # -------------------------------
# resource "aws_iam_role" "mwaa_execution_role" {
#   name = "mwaa-execution-role-prod"

#   assume_role_policy = jsonencode({
#     Version = "2012-10-17"
#     Statement = [
#       {
#         Action    = "sts:AssumeRole"
#         Effect    = "Allow"
#         Principal = {
#           Service = "airflow-env.amazonaws.com"
#         }
#       }
#     ]
#   })
# }
# resource "aws_s3_bucket_policy" "composer_bucket_policy" {
#   bucket = "credilio-preprod-composer"
#   policy = jsonencode({
#     Version = "2012-10-17"
#     Statement = [
#       {
#         Effect = "Allow"
#         Principal = {
#           AWS = aws_iam_role.mwaa_execution_role.arn
#         }
#         Action = [
#           "s3:GetObject",
#           "s3:ListBucket"
#         ]
#         Resource = [
#           "arn:aws:s3:::credilio-preprod-composer",
#           "arn:aws:s3:::credilio-preprod-composer/*"
#         ]
#       }
#     ]
#   })
# }

# # Attach required policies to MWAA Execution Role
# resource "aws_iam_role_policy_attachment" "mwaa_policy1" {
#   role       = aws_iam_role.mwaa_execution_role.name
#   policy_arn = "arn:aws:iam::aws:policy/AmazonS3FullAccess"
# }

# resource "aws_iam_role_policy_attachment" "mwaa_policy2" {
#   role       = aws_iam_role.mwaa_execution_role.name
#   policy_arn = "arn:aws:iam::aws:policy/CloudWatchLogsFullAccess"
# }

# resource "aws_iam_role_policy_attachment" "mwaa_policy3" {
#   role       = aws_iam_role.mwaa_execution_role.name
#   policy_arn = "arn:aws:iam::aws:policy/AmazonSSMReadOnlyAccess"
# }

# resource "aws_iam_role_policy_attachment" "mwaa_policy4" {
#   role       = aws_iam_role.mwaa_execution_role.name
#   policy_arn = "arn:aws:iam::aws:policy/AmazonSQSFullAccess"
# }

# # resource "aws_iam_role_policy_attachment" "mwaa_policy5" {
# #   role       = aws_iam_role.mwaa_execution_role.name
# #   policy_arn = "arn:aws:iam::aws:policy/service-role/AmazonMWAAEnvironmentClassPolicy"
# # }


# # -------------------------------
# # MWAA Environment
# # -------------------------------
# data "aws_s3_bucket" "composer_bucket" {
#   bucket = "credilio-preprod-composer"
# }

# resource "aws_mwaa_environment" "mwaa_env" {
#   name              = "prod-mwaa-env"
#   airflow_version   = "2.10.3"
#   environment_class = "mw1.small"

#   execution_role_arn = aws_iam_role.mwaa_execution_role.arn
#   source_bucket_arn  = data.aws_s3_bucket.composer_bucket.arn

#   dag_s3_path          = "dags"

#   network_configuration {
#     security_group_ids = [aws_security_group.mwaa_sg.id]
#     subnet_ids         = ["subnet-0aa4779518767653a", "subnet-0e6ad26bf26dda075"]
#   }

#   webserver_access_mode = "PUBLIC_ONLY"

#   # Add Service-managed Endpoints
#   endpoint_management = "SERVICE"

#   logging_configuration {
#     dag_processing_logs {
#       enabled   = true
#       log_level = "INFO"
#     }
#     scheduler_logs {
#       enabled   = true
#       log_level = "INFO"
#     }
#     task_logs {
#       enabled   = true
#       log_level = "INFO"
#     }
#     webserver_logs {
#       enabled   = true
#       log_level = "INFO"
#     }
#     worker_logs {
#       enabled   = true
#       log_level = "INFO"
#     }
#   }

# min_workers = 1
# max_workers = 25
# min_webservers = 2
# max_webservers = 5

#   tags = {
#     Name       = "prod-mwaa-env"
#     Created-by = "Terraform_Automation"
#   }
# }
