resource "aws_elasticache_replication_group" "redis" {
 replication_group_id = "redis-prod"
 description = "Redis cluster with Multi-AZ and failover"
  multi_az_enabled              = true
  automatic_failover_enabled    = true
}


import {
  to = aws_elasticache_replication_group.redis
  id = "redis-prod"
}