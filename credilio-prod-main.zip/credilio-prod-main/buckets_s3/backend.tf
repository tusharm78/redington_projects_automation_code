# ------------------------------------ #
####  backend configuration  #####
# ------------------------------------ #
terraform {
  backend "s3" {
    bucket = "do-not-delete-credilio-prod-terraform-backend"        #replace with the project specific bucketname
    key    = "statefile/buckets-s3/terraform.tfstate"
    region = "ap-south-1"                                          #replce the region
    dynamodb_table = "terraform-state-lock-DO-NOT-DELETE"          #do not change the dynamoDB table name
    profile ="prod-sso"
  }
}