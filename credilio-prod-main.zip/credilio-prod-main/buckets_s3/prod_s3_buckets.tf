# ------------------------------
# S3 Buckets (31 total)
# ------------------------------

# resource "aws_s3_bucket" "app_novio_in" {
#   bucket = "app.novio.in"

#   tags = {
#     Name       = "app.novio.in"
#     Created-by = "Terraform_Automation"
#   }
# }

resource "aws_s3_bucket" "asia_south1_composer_prepro" {
  bucket = "asia-south1-composer-prepro-2c13029a-bucket"

  tags = {
    Name       = "asia-south1-composer-prepro-2c13029a-bucket"
    Created-by = "Terraform_Automation"
  }
}

resource "aws_s3_bucket" "asia_south1_datarepo_prod" {
  bucket = "asia-south1-datarepo-prod-f11b1fe9-bucket"

  tags = {
    Name       = "asia-south1-datarepo-prod-f11b1fe9-bucket"
    Created-by = "Terraform_Automation"
  }
}

# resource "aws_s3_bucket" "call_center_backup" {
#   bucket = "call-center-backup"

#   tags = {
#     Name       = "call-center-backup"
#     Created-by = "Terraform_Automation"
#   }
# }

resource "aws_s3_bucket" "centralized_data_non_serving_gold_layer" {
  bucket = "centralized-data-non-serving-gold-layer"

  tags = {
    Name       = "centralized-data-non-serving-gold-layer"
    Created-by = "Terraform_Automation"
  }
}

import {
  to = aws_s3_bucket.credilio-admin-report
  id = "credilio-admin-report"
}
resource "aws_s3_bucket" "credilio-admin-report" {
  bucket = "credilio-admin-report"
}

#----------credilio-prod-certificates-----------------#
import {
  to = aws_s3_bucket.credilio-prod-certificates
  id = "credilio-prod-certificates"
}
resource "aws_s3_bucket" "credilio-prod-certificates" {
  bucket = "credilio-prod-certificates"
}

resource "aws_s3_bucket" "credilio_prod_logs" {
  bucket = "credilio-prod-logs"

  tags = {
    Name       = "credilio-prod-logs"
    Created-by = "Terraform_Automation"
  }
}

#----------dev-db-backup-credilio-----------------#
import {
  to = aws_s3_bucket.dev_db_backup_credilio
  id = "dev-db-backup-credilio"
}
resource "aws_s3_bucket" "dev_db_backup_credilio" {
  bucket = "dev-db-backup-credilio"
}


resource "aws_s3_bucket" "gcf_v2_sources_asia_south1" {
  bucket = "gcf-v2-sources-953088596164-asia-south1"

  tags = {
    Name       = "gcf-v2-sources-953088596164-asia-south1"
    Created-by = "Terraform_Automation"
  }
}

resource "aws_s3_bucket" "gcf_v2_sources_us_central1" {
  bucket = "gcf-v2-sources-953088596164-us-central1"

  tags = {
    Name       = "gcf-v2-sources-953088596164-us-central1"
    Created-by = "Terraform_Automation"
  }
}

# resource "aws_s3_bucket" "gcf_v2_uploads_asia_south1" {
#   bucket = "gcf-v2-uploads-953088596164.asia-south1.cloudfunctions.appspot.com"

#   tags = {
#     Name       = "gcf-v2-uploads-953088596164.asia-south1.cloudfunctions.appspot.com"
#     Created-by = "Terraform_Automation"
#   }
# }

# resource "aws_s3_bucket" "gcf_v2_uploads_us_central1" {
#   bucket = "gcf-v2-uploads-953088596164.us-central1.cloudfunctions.appspot.com"

#   tags = {
#     Name       = "gcf-v2-uploads-953088596164.us-central1.cloudfunctions.appspot.com"
#     Created-by = "Terraform_Automation"
#   }
# }

resource "aws_s3_bucket" "link_novio_in" {
  bucket = "link.novio.in"

  tags = {
    Name       = "link.novio.in"
    Created-by = "Terraform_Automation"
  }
}

#----------novio_admin_report-----------------#
import {
  to = aws_s3_bucket.novio_admin_report
  id = "novio-admin-report"
}
resource "aws_s3_bucket" "novio_admin_report" {
  bucket = "novio-admin-report"
}

resource "aws_s3_bucket" "novio_prod_certificates" {
  bucket = "novio-prod-certificates"

  tags = {
    Name       = "novio-prod-certificates"
    Created-by = "Terraform_Automation"
  }
}

resource "aws_s3_bucket" "prj_credilio_prod_appspot" {
  bucket = "prj-credilio-prod.appspot.com"

  tags = {
    Name       = "prj-credilio-prod.appspot.com"
    Created-by = "Terraform_Automation"
  }
}

#----------prj_credilio_prod_cloudbuild-----------------#
import {
  to = aws_s3_bucket.prj_credilio_prod_cloudbuild
  id = "prj-credilio-prod-cloudbuild"
}
resource "aws_s3_bucket" "prj_credilio_prod_cloudbuild" {
   bucket = "prj-credilio-prod-cloudbuild"
}

#----------prod-credilio--------------#
import {
  to = aws_s3_bucket.prod_credilio
  id = "prod-credilio"
}
resource "aws_s3_bucket" "prod_credilio" {
  bucket = "prod-credilio"
}

#----------prod-db-backup-credilio--------------#
import {
  to = aws_s3_bucket.prod_db_backup_credilio
  id = "prod-db-backup-credilio"
}

resource "aws_s3_bucket" "prod_db_backup_credilio" {
  bucket = "prod-db-backup-credilio"
}

#----------prod-db-backup-credilio-adhoc--------------#
import {
  to = aws_s3_bucket.prod_db_backup_credilio_adhoc
  id = "prod-db-backup-credilio-adhoc"
}
resource "aws_s3_bucket" "prod_db_backup_credilio_adhoc" {
  bucket = "prod-db-backup-credilio-adhoc"
}

#----------prod-novio--------------#
import {
  to = aws_s3_bucket.prod_novio
  id = "prod-novio"
}
resource "aws_s3_bucket" "prod_novio" {
  bucket = "prod-novio"
}

resource "aws_s3_bucket" "run_sources_prj_credilio_prod_asia_south1" {
  bucket = "run-sources-prj-credilio-prod-asia-south1"

  tags = {
    Name       = "run-sources-prj-credilio-prod-asia-south1"
    Created-by = "Terraform_Automation"
  }
}

resource "aws_s3_bucket" "staging_prj_credilio_prod_appspot" {
  bucket = "staging.prj-credilio-prod.appspot.com"

  tags = {
    Name       = "staging.prj-credilio-prod.appspot.com"
    Created-by = "Terraform_Automation"
  }
}

#----------www.easycardsloans.com--------------#
import {
  to = aws_s3_bucket.www_easycardsloans_com
  id = "www.easycardsloans.com"
}
resource "aws_s3_bucket" "www_easycardsloans_com" {
  bucket = "www.easycardsloans.com"
}

# resource "aws_s3_bucket" "www_novio_in" {
#   bucket = "www.novio.in"

#   tags = {
#     Name       = "www.novio.in"
#     Created-by = "Terraform_Automation"
#   }
# }

import {
  to = aws_s3_bucket.x_credilio_in
  id = "x.credilio.in"
}
resource "aws_s3_bucket" "x_credilio_in" {
  bucket = "x.credilio.in"
}

##-----Buckets given on 10th sept----------------###
# Terraform script to create 13 S3 buckets


# resource "aws_s3_bucket" "admin_credilio_in" {
#   bucket = "admin.credilio.in"

#   tags = {
#     Name       = "admin.credilio.in"
#     Created-by = "Terraform_Automation"
#   }
# }

resource "aws_s3_bucket" "customer_sbm_credilio_in" {
  bucket = "customer-sbm.credilio.in"

  tags = {
    Name       = "customer-sbm.credilio.in"
    Created-by = "Terraform_Automation"
  }
}

#----------partner-advisor.easycardsloans.com--------------#
import {
  to = aws_s3_bucket.partner_advisor_easycardsloans_com
  id = "partner-advisor.easycardsloans.com"
}
resource "aws_s3_bucket" "partner_advisor_easycardsloans_com" {
  bucket = "partner-advisor.easycardsloans.com"
 }

# resource "aws_s3_bucket" "customer_credilio_in" {
#   bucket = "customer.credilio.in"

#   tags = {
#     Name       = "customer.credilio.in"
#     Created-by = "Terraform_Automation"
#   }
# }

#----------novio.in--------------#
import {
  to = aws_s3_bucket.novio_in
  id = "novio.in"
}
resource "aws_s3_bucket" "novio_in" {
  bucket = "novio.in"
}

#----------customer.easycardsloans.com--------------#
import {
  to = aws_s3_bucket.customer_easycardsloans_com
  id = "customer.easycardsloans.com"
}
resource "aws_s3_bucket" "customer_easycardsloans_com" {
  bucket = "customer.easycardsloans.com"
}

# resource "aws_s3_bucket" "advisor_easycardsloans_com" {
#   bucket = "advisor.easycardsloans.com"

#   tags = {
#     Name       = "advisor.easycardsloans.com"
#     Created-by = "Terraform_Automation"
#   }
# }

# resource "aws_s3_bucket" "admin_novio_in" {
#   bucket = "admin.novio.in"

#   tags = {
#     Name       = "admin.novio.in"
#     Created-by = "Terraform_Automation"
#   }
# }

# resource "aws_s3_bucket" "link_novio_in" {
#   bucket = "link.novio.in"

#   tags = {
#     Name       = "link.novio.in"
#     Created-by = "Terraform_Automation"
#   }
#}

#----------easycardsloans.com-----------------#
import {
  to = aws_s3_bucket.easycardsloans_com
  id = "easycardsloans.com"
}

resource "aws_s3_bucket" "easycardsloans_com" {
  bucket = "easycardsloans.com"
}


resource "aws_s3_bucket" "app_novio_in" {
  bucket = "app.novio.in"

  tags = {
    Name       = "app.novio.in"
    Created-by = "Terraform_Automation"
  }
}

#----------partner-advisor.credilio.in--------------#
import {
  to = aws_s3_bucket.partner_advisor_credilio_in
  id = "partner-advisor.credilio.in"
}
resource "aws_s3_bucket" "partner_advisor_credilio_in" {
  bucket = "partner-advisor.credilio.in"
}

#---------------centralized-data-bronze-layer---------------#
import {
  to = aws_s3_bucket.centralized_data_bronze_layer
  id = "centralized-data-bronze-layer"
}
resource "aws_s3_bucket" "centralized_data_bronze_layer" {
  bucket = "centralized-data-bronze-layer"
}

#-----------------centralized-data-silver-layer---------------#

import {
  to = aws_s3_bucket.centralized_data_silver_layer
  id = "centralized-data-silver-layer"
}
resource "aws_s3_bucket" "centralized_data_silver_layer" {
  bucket = "centralized-data-silver-layer"
}

#---------------credilio-api-prod-certificates-------------------#
import {
  to = aws_s3_bucket.credilio_api_prod_certificates
  id = "credilio-api-prod-certificates"
}
resource "aws_s3_bucket" "credilio_api_prod_certificates" {
  bucket = "credilio-api-prod-certificates"
}

#----------credilio-preprod-composer-----------------#
import {
  to = aws_s3_bucket.credilio_preprod_composer
  id = "credilio-preprod-composer"
}
resource "aws_s3_bucket" "credilio_preprod_composer" {
  bucket = "credilio-preprod-composer"
}

#----------credilio-testing-bucket-----------------#
import {
  to = aws_s3_bucket.credilio_testing_bucket
  id = "credilio-testing-bucket"
}
resource "aws_s3_bucket" "credilio_testing_bucket" {
  bucket = "credilio-testing-bucket"
}

#----------dms-activity-----------------#
import {
  to = aws_s3_bucket.dms_activity
  id = "dms-activity"
}
resource "aws_s3_bucket" "dms_activity" {
  bucket = "dms-activity"
}

#----------qa-admin-credilio.in--------------#
import {
  to = aws_s3_bucket.qa_admin_credilio_in
  id = "qa-admin-credilio.in"
}
resource "aws_s3_bucket" "qa_admin_credilio_in" {
  bucket = "qa-admin-credilio.in"
}

#----------test-centralized-data-silver-layer--------------#
import {
  to = aws_s3_bucket.test_centralized_data_silver_layer
  id = "test-centralized-data-silver-layer"
}
resource "aws_s3_bucket" "test_centralized_data_silver_layer" {
  bucket = "test-centralized-data-silver-layer"
}

#----------test-s3-non-serving-gold-bucket--------------#
import {
  to = aws_s3_bucket.test_s3_non_serving_gold_bucket
  id = "test-s3-non-serving-gold-bucket"
}
resource "aws_s3_bucket" "test_s3_non_serving_gold_bucket" {
  bucket = "test-s3-non-serving-gold-bucket"
}

#----------novio-api-prod-certificates--------------#
import {
  to = aws_s3_bucket.novio_api_prod_certificates
  id = "novio-api-prod-certificates"
}
resource "aws_s3_bucket" "novio_api_prod_certificates" {
  bucket = "novio-api-prod-certificates"
 }