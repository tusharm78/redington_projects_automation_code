# Security Group for RDS (allow PostgreSQL port 5432)
resource "aws_security_group" "rds_sg_1" {
  name        = "rds-securitygroup"
  description = "Allow PostgreSQL traffic"
  vpc_id      = "vpc-0c1fa416190759c80"            # replace with your VPC ID

  ingress {
    description = "PostgreSQL from 34.93.9.37/32"
    from_port   = 5432
    to_port     = 5432
    protocol    = "tcp"
    cidr_blocks = ["34.93.9.37/32"]
  }

  ingress {
    description = "PostgreSQL from 172.20.6.13/32"
    from_port   = 5432
    to_port     = 5432
    protocol    = "tcp"
    cidr_blocks = ["172.20.6.13/32"]
  }

  ingress {
    description = "PostgreSQL from 10.0.0.0/16"
    from_port   = 5432
    to_port     = 5432
    protocol    = "tcp"
    cidr_blocks = ["10.0.0.0/16"]
  }

  ingress {
    description = "SSH from 10.0.0.0/16"
    from_port   = 22
    to_port     = 22
    protocol    = "tcp"
    cidr_blocks = ["10.0.0.0/16"]
  }

  ingress {
    description     = "PostgreSQL from RDS Security Group"
    from_port       = 5432
    to_port         = 5432
    protocol        = "tcp"
    security_groups = ["sg-01be04dd062a7062d"]
  }

  ingress {
    description = "Custom TCP 8080 from 10.0.0.0/16"
    from_port   = 8080
    to_port     = 8080
    protocol    = "tcp"
    cidr_blocks = ["10.0.0.0/16"]
  }

  ingress {
    description = "HTTP from 10.0.0.0/16"
    from_port   = 80
    to_port     = 80
    protocol    = "tcp"
    cidr_blocks = ["10.0.0.0/16"]
  }

  ingress {
    description = "PostgreSQL from 10.0.17.144/32"
    from_port   = 5432
    to_port     = 5432
    protocol    = "tcp"
    cidr_blocks = ["10.0.17.144/32"]
  }

  ingress {
    description = "PostgreSQL from 10.0.1.249/32"
    from_port   = 5432
    to_port     = 5432
    protocol    = "tcp"
    cidr_blocks = ["10.0.1.249/32"]
  }

  ingress {
    description = "PostgreSQL from 10.0.11.179/32"
    from_port   = 5432
    to_port     = 5432
    protocol    = "tcp"
    cidr_blocks = ["10.0.11.179/32"]
  }


  egress {
    from_port   = 0
    to_port     = 0
    protocol    = "-1"
    cidr_blocks = ["0.0.0.0/0"]
  }

  egress {
    from_port   = 5432
    to_port     = 5432
    protocol    = "tcp"
    cidr_blocks = ["172.20.6.13/32"]
  }
}

# DB Subnet Group (using private_subnet_3a and private_subnet_3b)
resource "aws_db_subnet_group" "prod_db_subnet_group_1" {
  name       = "prod_db_subnetgroup"
  subnet_ids = ["subnet-01df85b0113f18896",
                "subnet-0264577c18aed202a"]

  tags = {
    Name        = "prod-db-subnet-group"
    Environment = "Production"
  }
}

# Primary RDS PostgreSQL Instance with Multi-AZ and Encryption
resource "aws_db_instance" "primary_1" {
  identifier              = "prod-db"
  engine                  = "postgres"
  engine_version          = "17.6"
  instance_class          = "db.m7g.2xlarge"
  deletion_protection     = true
  parameter_group_name    = "prod-01-new"

  # Storage config with ENCRYPTION
  allocated_storage       = 1024
  max_allocated_storage   = 3072
  storage_type            = "gp3"
  storage_encrypted       = true  # ← THIS ENABLES ENCRYPTION AT REST
  #kms_key_id              = "alias/aws/rds"  # ← Use AWS managed key or your own KMS key

  # Password Authentication
  #username                = var.rdsusername
  #password                = var.rdspassword

  username                = jsondecode(data.aws_secretsmanager_secret_version.rds_credentials.secret_string)["db_username"]
  password                = jsondecode(data.aws_secretsmanager_secret_version.rds_credentials.secret_string)["db_password"]


  # Networking
  db_subnet_group_name    = aws_db_subnet_group.prod_db_subnet_group_1.name
  vpc_security_group_ids  = [aws_security_group.rds_sg_1.id]
  publicly_accessible     = false
  multi_az                = true

  # Enable CloudWatch log exports
  enabled_cloudwatch_logs_exports = [
    "postgresql"
  ]

  # Backup config
  backup_retention_period = 7
  backup_window           = "20:30-21:30"

  # Maintenance
  skip_final_snapshot     = true
  maintenance_window      = "Sun:21:30-Sun:22:30"
  
  # Tags
  tags = {
    Name        = "prod-db"
    Environment = "Production"
  }
}

data "aws_secretsmanager_secret_version" "rds_credentials" {
      secret_id = "arn:aws:secretsmanager:ap-south-1:110581573467:secret:creds/prod/terraform-7uviJ4"
}

# Read Replica with Encryption (inherits encryption from source)
resource "aws_db_instance" "read_replica_1" {
  identifier              = "prod-db-replica"
  engine                  = "postgres"
  engine_version          = "17.6"
  instance_class          = "db.m7g.2xlarge"
  replicate_source_db     = aws_db_instance.primary_1.arn  # ← Fixed: was 'primary'

  # Storage config
  allocated_storage       = 1024
  max_allocated_storage   = 3072
  storage_type            = "gp3"
  # Read replicas inherit encryption from the source DB

  # Networking
  db_subnet_group_name    = aws_db_subnet_group.prod_db_subnet_group_1.name
  vpc_security_group_ids  = [aws_security_group.rds_sg_1.id]
  publicly_accessible     = false
  multi_az                = true

  # Tags
  tags = {
    Name        = "prod-db-replica"
    Environment = "Production"
  }
}