
# -----------------------------
# OpenSearch Domain
# -----------------------------
resource "aws_opensearch_domain" "prod_elasticsearch" {
  domain_name    = "prod-elasticsearch"
  engine_version = "OpenSearch_3.1"

  cluster_config {
    instance_type          = "c7g.large.search"
    instance_count         = 2
    zone_awareness_enabled = true

   zone_awareness_config {
      availability_zone_count = 2
    }
     dedicated_master_enabled = false
  }

  ebs_options {
    ebs_enabled = true
    volume_type = "gp3"
    volume_size = 20
    iops        = 3000
    throughput  = 125
  }

  vpc_options {
    security_group_ids = [aws_security_group.opensearch_sg.id]
    subnet_ids         = ["subnet-0aa4779518767653a","subnet-0e6ad26bf26dda075"] # Add more subnets if needed
  }

  encrypt_at_rest {
    enabled    = true
  }

  node_to_node_encryption {
    enabled = true
  }

  domain_endpoint_options {
    enforce_https       = true
    tls_security_policy = "Policy-Min-TLS-1-2-2019-07"
  }

  advanced_security_options {
    enabled                        = true
    internal_user_database_enabled = true
    master_user_options {
      master_user_name     = var.master_user_name         # Replace with your master username
      master_user_password = var.master_user_password    # Replace with a secure password 
    }
  }
}

# -----------------------------
# Security Group for OpenSearch
# -----------------------------
resource "aws_security_group" "opensearch_sg" {
  name        = "opensearch-sg"
  description = "Security group for OpenSearch"
  vpc_id      = "vpc-0c1fa416190759c80" # Replace with your VPC ID

  # Ingress - Allow HTTPS access (443) from your trusted CIDR (modify as required)
  ingress {
    description = "Allow HTTPS from trusted sources"
    from_port   = 443
    to_port     = 443
    protocol    = "tcp"
    cidr_blocks = ["10.0.0.0/16"] # Replace with your office/public IP for security
  }


  # Egress - Allow all outbound
  egress {
    from_port   = 0
    to_port     = 0
    protocol    = "-1"
    cidr_blocks = ["0.0.0.0/0"]
  }

  tags = {
    Name       = "opensearch-sg"
    Created-by = "Terraform_Automation"
  }
}
 