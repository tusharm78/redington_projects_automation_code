# resource "aws_msk_cluster" "prod_msk_1" {
#   cluster_name           = "prod-kafka"
#   kafka_version          = "4.0.x.kraft"  # new kafka with Kraft
#   number_of_broker_nodes = "3"
 
#   broker_node_group_info {
#     instance_type = "kafka.m5.large"
#     client_subnets = [
#       "subnet-0e6ad26bf26dda075",
#       "subnet-0aa4779518767653a",
#       "subnet-070e9a6d4f90f3cfa",
#     ]
#     storage_info {
#       ebs_storage_info {
#         volume_size = 50
#       }
#     }
#     security_groups = [aws_security_group.msk.id]
#   }
 
 
#   tags = {
#     Name = "prod_msk"
#     createdthrougg ="Terrform"
#   }
# }
 
 
# resource "aws_security_group" "msk_prod_1" {
#   vpc_id      = "vpc-0c1fa416190759c80"
#   name        = "Msk-prod-sg"
#   description = "sg for MSK"
 
#   ingress {
#   from_port        = 9094
#   to_port          = 9094
#   protocol         = "tcp"
#   cidr_blocks      = ["10.0.0.0/16"]
#   }
 
 
#   egress {
#     from_port        = 0
#     to_port          = 0
#     protocol         = "-1"
#     cidr_blocks      = ["0.0.0.0/0"]
#    }
 
# }
 