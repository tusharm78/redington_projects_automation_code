resource "aws_msk_cluster" "prod" {
  cluster_name           = "prod-msk"
  kafka_version          = "3.8.x"
  number_of_broker_nodes = "3"

  configuration_info {
    arn      = "arn:aws:kafka:ap-south-1:110581573467:configuration/msk-cluster-config/b52aa43a-89e2-4743-8358-5226c760b02e-2"
    revision = 1
  }

  broker_node_group_info {
    instance_type = "kafka.m5.large"
    client_subnets = [
      "subnet-0e6ad26bf26dda075",
      "subnet-0aa4779518767653a",
      "subnet-070e9a6d4f90f3cfa",
    ]
    
    storage_info {
      ebs_storage_info {
        volume_size = 50
      }
    }
  
    security_groups = [aws_security_group.msk.id]
  }
 
  tags = {
    Name = "prod_msk"
    CreatedThrough = "terraform"
  }
}

 
resource "aws_security_group" "msk" {
  vpc_id      = "vpc-0c1fa416190759c80"
  name        = "Msk-sg"
  description = "sg for MSK"
 
  ingress {
  from_port        = 9094
  to_port          = 9094
  protocol         = "tcp"
  cidr_blocks      = ["10.0.0.0/16"]
  }
 
 
  egress {
    from_port        = 0
    to_port          = 0
    protocol         = "-1"
    cidr_blocks      = ["0.0.0.0/0"]
   }
 
}


 