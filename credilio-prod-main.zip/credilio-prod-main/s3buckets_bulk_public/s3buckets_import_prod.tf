# ======================= admin.credilio.in =======================

import {
  to = aws_s3_bucket_website_configuration.admin_credilio_in
  id = "admin.credilio.in"
}

import {
  to = aws_s3_bucket_public_access_block.admin_credilio_in
  id = "admin.credilio.in"
}

import {
  to = aws_s3_bucket_policy.admin_credilio_in
  id = "admin.credilio.in"
}

import {
  to = aws_s3_bucket.admin_credilio_in
  id = "admin.credilio.in"
}

resource "aws_s3_bucket" "admin_credilio_in" {
  bucket = "admin.credilio.in"
}

resource "aws_s3_bucket_public_access_block" "admin_credilio_in" {
  bucket                  = "admin.credilio.in"
  block_public_acls       = false
  block_public_policy     = false
  ignore_public_acls      = false
  restrict_public_buckets = false
}

resource "aws_s3_bucket_website_configuration" "admin_credilio_in" {
  bucket = "admin.credilio.in"

  index_document {
    suffix = "index.html"
  }

  error_document {
    key = "index.html"
  }
}

resource "aws_s3_bucket_policy" "admin_credilio_in" {
  bucket = "admin.credilio.in"
  policy = jsonencode({
    Version = "2008-10-17"
    Id      = "PolicyForCloudFrontPrivateContent"
    Statement = [
      {
        Effect    = "Allow"
        Principal = "*"
        Action    = "s3:GetObject"
        Resource  = "arn:aws:s3:::admin.credilio.in/*"
      }
    ]
  })
}

# ======================= admin.novio.in =======================

import {
  to = aws_s3_bucket_website_configuration.admin_novio_in
  id = "admin.novio.in"
}

import {
  to = aws_s3_bucket_public_access_block.admin_novio_in
  id = "admin.novio.in"
}

import {
  to = aws_s3_bucket_policy.admin_novio_in
  id = "admin.novio.in"
}

import {
  to = aws_s3_bucket.admin_novio_in
  id = "admin.novio.in"
}

resource "aws_s3_bucket" "admin_novio_in" {
  bucket = "admin.novio.in"
}

resource "aws_s3_bucket_public_access_block" "admin_novio_in" {
  bucket                  = "admin.novio.in"
  block_public_acls       = false
  block_public_policy     = false
  ignore_public_acls      = false
  restrict_public_buckets = false
}

resource "aws_s3_bucket_website_configuration" "admin_novio_in" {
  bucket = "admin.novio.in"

  index_document {
    suffix = "index.html"
  }

  error_document {
    key = "index.html"
  }
}

resource "aws_s3_bucket_policy" "admin_novio_in" {
  bucket = "admin.novio.in"
  policy = jsonencode({
    Version = "2008-10-17"
    Id      = "PolicyForCloudFrontPrivateContent"
    Statement = [
      {
        Effect    = "Allow"
        Principal = "*"
        Action    = "s3:GetObject"
        Resource  = "arn:aws:s3:::admin.novio.in/*"
      }
    ]
  })
}

# ======================= advisor.credilio.in =======================

import {
  to = aws_s3_bucket_website_configuration.advisor_credilio_in
  id = "advisor.credilio.in"
}

import {
  to = aws_s3_bucket_public_access_block.advisor_credilio_in
  id = "advisor.credilio.in"
}

import {
  to = aws_s3_bucket_policy.advisor_credilio_in
  id = "advisor.credilio.in"
}

import {
  to = aws_s3_bucket.advisor_credilio_in
  id = "advisor.credilio.in"
}

resource "aws_s3_bucket" "advisor_credilio_in" {
  bucket = "advisor.credilio.in"
}

resource "aws_s3_bucket_public_access_block" "advisor_credilio_in" {
  bucket                  = "advisor.credilio.in"
  block_public_acls       = false
  block_public_policy     = false
  ignore_public_acls      = false
  restrict_public_buckets = false
}

resource "aws_s3_bucket_website_configuration" "advisor_credilio_in" {
  bucket = "advisor.credilio.in"

  index_document {
    suffix = "index.html"
  }

  error_document {
    key = "index.html"
  }
}

resource "aws_s3_bucket_policy" "advisor_credilio_in" {
  bucket = "advisor.credilio.in"
  policy = jsonencode({
    Version = "2008-10-17"
    Id      = "PolicyForCloudFrontPrivateContent"
    Statement = [
      {
        Effect    = "Allow"
        Principal = "*"
        Action    = "s3:GetObject"
        Resource  = "arn:aws:s3:::advisor.credilio.in/*"
      }
    ]
  })
}

# ======================= customer.credilio.in =======================

import {
  to = aws_s3_bucket_website_configuration.customer_credilio_in
  id = "customer.credilio.in"
}

import {
  to = aws_s3_bucket_public_access_block.customer_credilio_in
  id = "customer.credilio.in"
}

import {
  to = aws_s3_bucket_policy.customer_credilio_in
  id = "customer.credilio.in"
}

import {
  to = aws_s3_bucket.customer_credilio_in
  id = "customer.credilio.in"
}

resource "aws_s3_bucket" "customer_credilio_in" {
  bucket = "customer.credilio.in"
}

resource "aws_s3_bucket_public_access_block" "customer_credilio_in" {
  bucket                  = "customer.credilio.in"
  block_public_acls       = false
  block_public_policy     = false
  ignore_public_acls      = false
  restrict_public_buckets = false
}

resource "aws_s3_bucket_website_configuration" "customer_credilio_in" {
  bucket = "customer.credilio.in"

  index_document {
    suffix = "index.html"
  }

  error_document {
    key = "index.html"
  }
}

resource "aws_s3_bucket_policy" "customer_credilio_in" {
  bucket = "customer.credilio.in"
  policy = jsonencode({
    Version = "2008-10-17"
    Id      = "PolicyForCloudFrontPrivateContent"
    Statement = [
      {
        Effect    = "Allow"
        Principal = "*"
        Action    = "s3:GetObject"
        Resource  = "arn:aws:s3:::customer.credilio.in/*"
      }
    ]
  })
}

# ======================= www.novio.in =======================

import {
  to = aws_s3_bucket_website_configuration.www_novio_in
  id = "www.novio.in"
}

import {
  to = aws_s3_bucket_public_access_block.www_novio_in
  id = "www.novio.in"
}

import {
  to = aws_s3_bucket_policy.www_novio_in
  id = "www.novio.in"
}

import {
  to = aws_s3_bucket.www_novio_in
  id = "www.novio.in"
}

resource "aws_s3_bucket" "www_novio_in" {
  bucket = "www.novio.in"
}

resource "aws_s3_bucket_public_access_block" "www_novio_in" {
  bucket                  = "www.novio.in"
  block_public_acls       = false
  block_public_policy     = false
  ignore_public_acls      = false
  restrict_public_buckets = false
}

resource "aws_s3_bucket_website_configuration" "www_novio_in" {
  bucket = "www.novio.in"

  index_document {
    suffix = "index.html"
  }

  error_document {
    key = "index.html"
  }
}

resource "aws_s3_bucket_policy" "www_novio_in" {
  bucket = "www.novio.in"
  policy = jsonencode({
    Version = "2008-10-17"
    Id      = "PolicyForCloudFrontPrivateContent"
    Statement = [
      {
        Effect    = "Allow"
        Principal = "*"
        Action    = "s3:GetObject"
        Resource  = "arn:aws:s3:::www.novio.in/*"
      }
    ]
  })
}


