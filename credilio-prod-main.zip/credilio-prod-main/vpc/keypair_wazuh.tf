# --------------------------------------------------#
# creates key pair for wazuh server-------#
# --------------------------------------------------#

resource "aws_key_pair" "wazuh_key" {
key_name = var.wazuh_key
public_key = tls_private_key.rsa_wazuh.public_key_openssh
}

#key pair which has been created above is encrypted with RSA algorithm 4096 bits, we can change this accroding to requirement 
resource "tls_private_key" "rsa_wazuh" {
algorithm = "RSA"
rsa_bits  = 4096
}

#this creates a file in our working directory and download the aws key pair which we have created above
resource "local_file" "wazuh_key" {
content  = tls_private_key.rsa_wazuh.private_key_pem
filename = var.wazuh_key
depends_on = [aws_key_pair.wazuh_key]
}