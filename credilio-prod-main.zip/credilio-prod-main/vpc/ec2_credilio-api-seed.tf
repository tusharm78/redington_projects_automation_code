# ---------------------------------------------------------#
#creating virtual machine - "credilio-api-seed" VM-----------#
# ---------------------------------------------------------#
resource "aws_instance" "ec2_credilio-api-seed" {
  subnet_id                   = aws_subnet.prod_subnet_1a.id
  associate_public_ip_address = false
  ami                         = "ami-0b9093ea00a0fed92"           #ubuntu 24.04 ami id
  instance_type               = "t4g.medium"                    #add the required instance size here
  disable_api_termination = true
  root_block_device {
  volume_size = var.credilio-api-seed_os_disk
    encrypted = true
    delete_on_termination = true
    volume_type = "gp3"
    tags = {
      Name = "credilio-api-seed_os_disk"
      CreatedThrough = "Terraform_Automation"
    }
  }
  
#here we are referencing the aws key pair which we have created in keypair.tf config file
key_name              = var.credilio-api-seed_key

vpc_security_group_ids = [aws_security_group.sg_credilio-api-seed.id,"sg-02fe03031e423f136"]
  
  #here we are attaching tags to our resources
  tags = {
    "Name" = "credilio-api"
     Created-by  = "Terraform_Automation"

  }
}

# ----------------------------------------------------------- #
#creating security group for "credilio-api-seed" VM
# ----------------------------------------------------------- #
# Create Security Group - SSH Traffic
resource "aws_security_group" "sg_credilio-api-seed" {
  vpc_id      = aws_vpc.vpc-go.id
  name        = "sg_credilio-api-seed"
  description = "VM SSH"

# inbound ssh port
  ingress {
    description = "Allow Port 22"
    from_port   = 22
    to_port     = 22
    protocol    = "tcp"
    cidr_blocks = ["0.0.0.0/0"]
  }

#outbound port 
  egress {
    description = "Allow all IP and Ports outbound"
    from_port   = 0
    to_port     = 0
    protocol    = "-1"
    cidr_blocks = ["0.0.0.0/0"]
  }


  tags = {
    Name = "sg_credilio-api"
    CreatedThrough = "Terraform Automation"
  }
}
