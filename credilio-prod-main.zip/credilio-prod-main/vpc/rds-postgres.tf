# Security Group for RDS (allow PostgreSQL port 5432)
resource "aws_security_group" "rds_sg" {
  name        = "rds-security-group"
  description = "Allow PostgreSQL traffic"
  vpc_id      =  aws_vpc.vpc-go.id             # replace with your VPC ID

  ingress {
    description = "PostgreSQL from 34.93.9.37/32"
    from_port   = 5432
    to_port     = 5432
    protocol    = "tcp"
    cidr_blocks = ["34.93.9.37/32"]
  }

  ingress {
    description = "PostgreSQL from 172.20.6.13/32"
    from_port   = 5432
    to_port     = 5432
    protocol    = "tcp"
    cidr_blocks = ["172.20.6.13/32"]
  }

  ingress {
    description = "PostgreSQL from 10.0.0.0/16"
    from_port   = 5432
    to_port     = 5432
    protocol    = "tcp"
    cidr_blocks = ["10.0.0.0/16"]
  }

  ingress {
    description = "SSH from 10.0.0.0/16"
    from_port   = 22
    to_port     = 22
    protocol    = "tcp"
    cidr_blocks = ["10.0.0.0/16"]
  }

  ingress {
    description     = "PostgreSQL from RDS Security Group"
    from_port       = 5432
    to_port         = 5432
    protocol        = "tcp"
    security_groups = ["sg-01be04dd062a7062d"]
  }

  ingress {
    description = "Custom TCP 8080 from 10.0.0.0/16"
    from_port   = 8080
    to_port     = 8080
    protocol    = "tcp"
    cidr_blocks = ["10.0.0.0/16"]
  }

  ingress {
    description = "HTTP from 10.0.0.0/16"
    from_port   = 80
    to_port     = 80
    protocol    = "tcp"
    cidr_blocks = ["10.0.0.0/16"]
  }

  ingress {
    description = "PostgreSQL from 10.0.17.144/32"
    from_port   = 5432
    to_port     = 5432
    protocol    = "tcp"
    cidr_blocks = ["10.0.17.144/32"]
  }

  ingress {
    description = "PostgreSQL from 10.0.1.249/32"
    from_port   = 5432
    to_port     = 5432
    protocol    = "tcp"
    cidr_blocks = ["10.0.1.249/32"]
  }

  ingress {
    description = "PostgreSQL from 10.0.11.179/32"
    from_port   = 5432
    to_port     = 5432
    protocol    = "tcp"
    cidr_blocks = ["10.0.11.179/32"]
  }


  egress {
    from_port   = 0
    to_port     = 0
    protocol    = "-1"
    cidr_blocks = ["0.0.0.0/0"]
  }

  egress {
    from_port   = 5432
    to_port     = 5432
    protocol    = "tcp"
    cidr_blocks = ["172.20.6.13/32"]
  }
}

# DB Subnet Group (using private_subnet_3a and private_subnet_3b)
resource "aws_db_subnet_group" "prod_db_subnet_group" {
  name       = "prod_db_subnet_group"
  subnet_ids = [
    aws_subnet.prod_subnet_3a.id,
    aws_subnet.prod_subnet_3b.id
  ]

  tags = {
    Name        = "prod-db-subnet-group"
    Environment = "Production"
  }
}

# Primary RDS PostgreSQL Instance with Multi-AZ
resource "aws_db_instance" "primary" {
  identifier              = "db-prod-1"
  engine                  = "postgres"
  engine_version          = "17.6"
  instance_class          = "db.m7g.2xlarge"
  deletion_protection = true
  parameter_group_name = "prod-01"

  # Storage config
  allocated_storage       = 1024             # 1 TB initial storage (GB)
  max_allocated_storage   = 3072             # autoscaling up to 3 TB
  storage_type            = "gp3"

  # Password Authentication
  username                = var.rdsusername
  password                = var.rdspassword   # change it

  # Networking
  db_subnet_group_name    = aws_db_subnet_group.prod_db_subnet_group.name
  vpc_security_group_ids  = [aws_security_group.rds_sg.id]
  publicly_accessible     = false
  multi_az                = true

  # Enable CloudWatch log exports
  enabled_cloudwatch_logs_exports = [
    "postgresql"                              # Needed for failed DB user logins
  ]

  # Backup config
  backup_retention_period = 7
  backup_window = "20:30-21:30"               # Everyday 2:00–3:00 AM IST

  # Maintenance
  skip_final_snapshot     = true
  maintenance_window = "Sun:21:30-Sun:22:30"   # Sunday 3 AM TO 4 AM
  
  # Tags
  tags = {
    Name        = "db-prod-1"
    Environment = "Production"
  }
}
# # Create CloudWatch Log Group with retention policy
# resource "aws_cloudwatch_log_group" "postgresql_logs" {
#   name              = "/aws/rds/db-prod-1"
#   retention_in_days = 90
# }


# Read Replica (with Multi-AZ enabled) - No backup
resource "aws_db_instance" "read_replica" {
  identifier              = "db-prod-1-replica"
  engine                  = "postgres"
  engine_version          = "17.6"
  instance_class          = "db.m7g.2xlarge"
  replicate_source_db     = aws_db_instance.primary.arn

  # Storage config
  allocated_storage       = 1024
  max_allocated_storage   = 3072
  storage_type            = "gp3"

  # Networking
  db_subnet_group_name    = aws_db_subnet_group.prod_db_subnet_group.name
  vpc_security_group_ids  = [aws_security_group.rds_sg.id]
  publicly_accessible     = false
  multi_az                = true

  # Tags
  tags = {
    Name        = "db-prod-1-replica"
    Environment = "Production"
  }
}
