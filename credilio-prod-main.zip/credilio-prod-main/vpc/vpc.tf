# -------------------------------------- #
# Create VPC for prod environmnet
# -------------------------------------- #
resource "aws_vpc" "vpc-go" {
    cidr_block = var.aws_vpc
    enable_dns_hostnames = true
   tags = {
        Name        = "VPC_Credilio"
        Created-by  = "Terraform_Automation"
    }
}

#creating public subnet 1
resource "aws_subnet" "Public-Subnet_1a" {
  vpc_id                  = aws_vpc.vpc-go.id
  cidr_block              = var.PublicSubnet_1
  availability_zone       = var.aws_availability_zone1
  map_public_ip_on_launch = true
  tags = {
    Name = "Subnet_Public_1"
    Created-by  = "Terraform_Automation"
  }
}

#creating public subnet 2
resource "aws_subnet" "Public-Subnet_1b" {
  vpc_id                  = aws_vpc.vpc-go.id
  cidr_block              = var.PublicSubnet_2
  availability_zone       = var.aws_availability_zone2
  map_public_ip_on_launch = true
  tags = {
    Name = "Subnet_Public_2"
    Created-by  = "Terraform_Automation"
  }
}


#creating private subnet 1 for prod environmnet in availability zone 1a
resource "aws_subnet" "prod_subnet_1a" {
  vpc_id                  = aws_vpc.vpc-go.id
  cidr_block              = var.Subnet_prod_Private_1a
  availability_zone       = var.aws_availability_zone1
  map_public_ip_on_launch = false
  tags = {
    Name = "Subnet_prod_Private_1a"
    Created-by  = "Terraform_Automation"
    Environment = "Production"
  }
}

#creating private subnet 2 for prod environmnet in availability zone 1a
resource "aws_subnet" "prod_subnet_2a" {
  vpc_id                  = aws_vpc.vpc-go.id
  cidr_block              = var.Subnet_prod_Private_2a
  availability_zone       = var.aws_availability_zone1
  map_public_ip_on_launch = false
  tags = {
    Name = "Subnet_prod_Private_2a"
    Created-by  = "Terraform_Automation"
    Environment = "Production"
  }
}

#creating private subnet 3 for prod environmnet in availability zone 1a
resource "aws_subnet" "prod_subnet_3a" {
  vpc_id                  = aws_vpc.vpc-go.id
  cidr_block              = var.Subnet_prod_Private_3a
  availability_zone       = var.aws_availability_zone1
  map_public_ip_on_launch = false
  tags = {
    Name = "Subnet_prod_Private_3a"
    Created-by  = "Terraform_Automation"
    Environment = "Productiont"
  }
}

#creating private subnet 1 for prod environmnet in availability zone 1b
resource "aws_subnet" "prod_subnet_1b" {
  vpc_id                  = aws_vpc.vpc-go.id
  cidr_block              = var.Subnet_prod_Private_1b
  availability_zone       = var.aws_availability_zone2
  map_public_ip_on_launch = false
  tags = {
    Name = "Subnet_prod_Private_1b"
    Created-by  = "Terraform_Automation"
    Environment = "Production"
  }
}

#creating private subnet 2 for prod environmnet in availability zone 1b
resource "aws_subnet" "prod_subnet_2b" {
  vpc_id                  = aws_vpc.vpc-go.id
  cidr_block              = var.Subnet_prod_Private_2b
  availability_zone       = var.aws_availability_zone2
  map_public_ip_on_launch = false
  tags = {
    Name = "Subnet_prod_Private_2b"
    Created-by  = "Terraform_Automation"
    Environment = "Production"
  }
}

#creating private subnet 3 for prod environmnet in availability zone 1b
resource "aws_subnet" "prod_subnet_3b" {
  vpc_id                  = aws_vpc.vpc-go.id
  cidr_block              = var.Subnet_prod_Private_3b
  availability_zone       = var.aws_availability_zone2
  map_public_ip_on_launch = false
  tags = {
    Name = "Subnet_prod_Private_3b"
    Created-by  = "Terraform_Automation"
    Environment = "Production"
  }
}

# Creating Internet Gateway
resource "aws_internet_gateway" "vpc-igw" {
  vpc_id = aws_vpc.vpc-go.id
  tags = {
    Name = "IGW-Credilio"
    Created-by  = "Terraform_Automation"
  }
}

# Create a NAT gateway in the public subnet
resource "aws_eip" "nat_eip" {
  domain = "vpc"
  tags = {
    Name = "eip_nat_gw"
  }
}

resource "aws_nat_gateway" "nat" {
  allocation_id = aws_eip.nat_eip.id
  subnet_id     = aws_subnet.Public-Subnet_1a.id
  tags = {
    Name = "Ngw_Credilio"
    Created-by  = "Terraform_Automation"
  }
}

# Create a NAT gateway in the public subnet
resource "aws_eip" "nat_eip_1b" {
  domain = "vpc"
  tags = {
    Name = "eip_nat_gw_1b"
  }
}

resource "aws_nat_gateway" "nat-1b" {
  allocation_id = aws_eip.nat_eip_1b.id
  subnet_id     = aws_subnet.Public-Subnet_1b.id
  tags = {
    Name = "Ngw_Credilio_1b"
    Created-by  = "Terraform_Automation"
  }
}

#creating public route table
resource "aws_route_table" "rt_public" {
  vpc_id = aws_vpc.vpc-go.id

  tags = {
    Name    = "RT-Public"   # Route table for Public subnet is created
    Created-by  = "Terraform_Automation"
  }
}
#associating public route table with respective public subnet 1
resource "aws_route_table_association" "public_rt_1" {
  route_table_id = aws_route_table.rt_public.id     # public route table is associated with respective public subnet
  subnet_id      = aws_subnet.Public-Subnet_1a.id
}

#associating public route table with respective public subnet 2
resource "aws_route_table_association" "public_rt_2" {
  route_table_id = aws_route_table.rt_public.id     # public route table is associated with respective public subnet
  subnet_id      = aws_subnet.Public-Subnet_1b.id
}

#creating prod-private-subnet route table
resource "aws_route_table" "rt_prod_private" {
  vpc_id = aws_vpc.vpc-go.id

  tags = {
    Name    = "RT-prod-Private"   # Route table for prod Private subnet is created
    Created-by  = "Terraform_Automation"
  }
}

#creating prod-private-subnet route table for AZ 2
resource "aws_route_table" "rt_prod_private_2" {
  vpc_id = aws_vpc.vpc-go.id

  tags = {
    Name    = "RT-prod-Private_2"   # Route table for prod Private subnet is created
    Created-by  = "Terraform_Automation"
  }
}
#associating prod-private-subnet route table with respective prod private subnet 1
resource "aws_route_table_association" "prod-Private_rt_1" {
  route_table_id = aws_route_table.rt_prod_private.id    # prod private route table is associated with respective prod private subnet
  subnet_id      = aws_subnet.prod_subnet_1a.id
}

#associating prod-private-subnet route table with respective prod private subnet 2
resource "aws_route_table_association" "prod-Private_rt_2" {
  route_table_id = aws_route_table.rt_prod_private.id    # prod private route table is associated with respective prod private subnet
  subnet_id      = aws_subnet.prod_subnet_2a.id
}

#associating prod-private-subnet route table with respective prod private subnet 3
resource "aws_route_table_association" "prod-Private_rt_3" {
  route_table_id = aws_route_table.rt_prod_private.id    # prod private route table is associated with respective prod private subnet
  subnet_id      = aws_subnet.prod_subnet_3a.id
}

#associating prod-private-subnet route table with respective prod private subnet 1
resource "aws_route_table_association" "prod-Private_rt_4" {
  route_table_id = aws_route_table.rt_prod_private_2.id    # prod private route table is associated with respective prod private subnet
  subnet_id      = aws_subnet.prod_subnet_1b.id
}

#associating prod-private-subnet route table with respective prod private subnet 2
resource "aws_route_table_association" "prod-Private_rt_5" {
  route_table_id = aws_route_table.rt_prod_private_2.id   # prod private route table is associated with respective prod private subnet
  subnet_id      = aws_subnet.prod_subnet_2b.id
}

#associating prod-private-subnet route table with respective prod private subnet 3
resource "aws_route_table_association" "prod-Private_rt_6" {
  route_table_id = aws_route_table.rt_prod_private_2.id   # prod private route table is associated with respective prod private subnet
  subnet_id      = aws_subnet.prod_subnet_3b.id
}

# Create Route in Route Table for Internet Access
resource "aws_route" "public_rt" {
  route_table_id         = aws_route_table.rt_public.id
  destination_cidr_block = "0.0.0.0/0"
  gateway_id             = aws_internet_gateway.vpc-igw.id
}

# Create Route in Route Table for NAT GW in az 1
resource "aws_route" "private_rt" {
  route_table_id         = aws_route_table.rt_prod_private.id
  destination_cidr_block = "0.0.0.0/0"
  nat_gateway_id = aws_nat_gateway.nat.id
}

# Create Route in Route Table for NAT GW in az 2
resource "aws_route" "private_rt_2b" {
  route_table_id         = aws_route_table.rt_prod_private_2.id
  destination_cidr_block = "0.0.0.0/0"
  nat_gateway_id = aws_nat_gateway.nat-1b.id
}

#-------------------------------------------------------------------------------------------------------#
# ------------------------------------------------------------------------------------------------------#
# Create VPC for wordpress environmnet
#-------------------------------------------------------------------------------------------------------#
# ------------------------------------------------------------------------------------------------------#

resource "aws_vpc" "vpc-wordpress" {
    cidr_block = var.aws_vpc_wp
    enable_dns_hostnames = true
   tags = {
        Name        = "VPC_WP_Credilio"
        Created-by  = "Terraform_Automation"
    }
}

#creating public subnet 1
resource "aws_subnet" "Public-Subnet-Wordpress_1a" {
  vpc_id                  = aws_vpc.vpc-wordpress.id
  cidr_block              = var.PublicSubnetWordpress_1
  availability_zone       = var.aws_availability_zone1
  map_public_ip_on_launch = true
  tags = {
    Name = "Subnet_Public_wordpress_1"
    Created-by  = "Terraform_Automation"
  }
}

#creating public subnet 2
resource "aws_subnet" "Public-Subnet-Wordpress_1b" {
  vpc_id                  = aws_vpc.vpc-wordpress.id
  cidr_block              = var.PublicSubnetWordpress_2
  availability_zone       = var.aws_availability_zone2
  map_public_ip_on_launch = true
  tags = {
    Name = "Subnet_Public_wordpress_2"
    Created-by  = "Terraform_Automation"
  }
}


#creating private subnet 1 for wordpress environmnet in availability zone 1a
resource "aws_subnet" "wordpress_subnet_1a" {
  vpc_id                  = aws_vpc.vpc-wordpress.id
  cidr_block              = var.Subnet_wordpress_Private_1a
  availability_zone       = var.aws_availability_zone1
  map_public_ip_on_launch = false
  tags = {
    Name = "Subnet_wordpress_Private_1a"
    Created-by  = "Terraform_Automation"
    Environment = "Wordpress"
  }
}

#creating private subnet 2 for wordpress environmnet in availability zone 1a
resource "aws_subnet" "wordpress_subnet_2a" {
  vpc_id                  = aws_vpc.vpc-wordpress.id
  cidr_block              = var.Subnet_wordpress_Private_2a
  availability_zone       = var.aws_availability_zone1
  map_public_ip_on_launch = false
  tags = {
    Name = "Subnet_wordpress_Private_2a"
    Created-by  = "Terraform_Automation"
    Environment = "Wordpress"
  }
}

#creating private subnet 1 for wordpress environmnet in availability zone 1b
resource "aws_subnet" "wordpress_subnet_1b" {
  vpc_id                  = aws_vpc.vpc-wordpress.id
  cidr_block              = var.Subnet_wordpress_Private_1b
  availability_zone       = var.aws_availability_zone2
  map_public_ip_on_launch = false
  tags = {
    Name = "Subnet_wordpress_Private_1b"
    Created-by  = "Terraform_Automation"
    Environment = "Wordpress"
  }
}

#creating private subnet 2 for wordpress environmnet in availability zone 1b
resource "aws_subnet" "wordpress_subnet_2b" {
  vpc_id                  = aws_vpc.vpc-wordpress.id
  cidr_block              = var.Subnet_wordpress_Private_2b
  availability_zone       = var.aws_availability_zone2
  map_public_ip_on_launch = false
  tags = {
    Name = "Subnet_wordpress_Private_2b"
    Created-by  = "Terraform_Automation"
    Environment = "Wordpress"
  }
}

# Creating Internet Gateway
resource "aws_internet_gateway" "vpc-igw-wp" {
  vpc_id = aws_vpc.vpc-wordpress.id
  tags = {
    Name = "IGW-wp-Credilio"
    Created-by  = "Terraform_Automation"
  }
}

# Create a NAT gateway in the public subnet
resource "aws_eip" "nat_eip_wp" {
  domain = "vpc"
  tags = {
    Name = "eip_nat_gw_wp"
  }
}

resource "aws_nat_gateway" "nat-wp" {
  allocation_id = aws_eip.nat_eip_wp.id
  subnet_id     = aws_subnet.Public-Subnet-Wordpress_1a.id
  tags = {
    Name = "Ngw_wp_Credilio"
    Created-by  = "Terraform_Automation"
  }
}

#creating public route table
resource "aws_route_table" "rt_public_wp" {
  vpc_id = aws_vpc.vpc-wordpress.id

  tags = {
    Name    = "RT-Public_wp"   # Route table for Public subnet is created
    Created-by  = "Terraform_Automation"
  }
}
#associating public route table with respective public subnet 1
resource "aws_route_table_association" "public_rt_wp_1" {
  route_table_id = aws_route_table.rt_public_wp.id     # public route table is associated with respective public subnet
  subnet_id      = aws_subnet.Public-Subnet-Wordpress_1a.id
}

#associating public route table with respective public subnet 2
resource "aws_route_table_association" "public_rt_wp_2" {
  route_table_id = aws_route_table.rt_public_wp.id    # public route table is associated with respective public subnet
  subnet_id      = aws_subnet.Public-Subnet-Wordpress_1b.id
}

#creating prod-private-subnet route table
resource "aws_route_table" "rt_private_wp" {
  vpc_id = aws_vpc.vpc-wordpress.id

  tags = {
    Name    = "RT-Private-wordpress"   # Route table for prod Private subnet is created
    Created-by  = "Terraform_Automation"
  }
}
#associating wordpress-private-subnet route table with respective prod private subnet 1
resource "aws_route_table_association" "wp-Private_rt_1" {
  route_table_id = aws_route_table.rt_private_wp.id    # prod private route table is associated with respective prod private subnet
  subnet_id      = aws_subnet.wordpress_subnet_1a.id
}

#associating wordpress-private-subnet route table with respective prod private subnet 2
resource "aws_route_table_association" "wp-Private_rt_2" {
  route_table_id = aws_route_table.rt_private_wp.id      # prod private route table is associated with respective prod private subnet
  subnet_id      = aws_subnet.wordpress_subnet_1b.id
}

#associating wordpress-private-subnet route table with respective prod private subnet 1
resource "aws_route_table_association" "wp-Private_rt_3" {
  route_table_id = aws_route_table.rt_private_wp.id    # prod private route table is associated with respective prod private subnet
  subnet_id      = aws_subnet.wordpress_subnet_2a.id
}

#associating wordpress-private-subnet route table with respective prod private subnet 2
resource "aws_route_table_association" "wp-Private_rt_4" {
  route_table_id = aws_route_table.rt_private_wp.id    # prod private route table is associated with respective prod private subnet
  subnet_id      = aws_subnet.wordpress_subnet_2b.id
}

# Create Route in Route Table for Internet Access
resource "aws_route" "public_rt_wp" {
  route_table_id         = aws_route_table.rt_public_wp.id
  destination_cidr_block = "0.0.0.0/0"
  gateway_id             = aws_internet_gateway.vpc-igw-wp.id
}

# Create Route in Route Table for NAT GW
resource "aws_route" "private_rt_wp" {
  route_table_id         = aws_route_table.rt_private_wp.id
  destination_cidr_block = "0.0.0.0/0"
  nat_gateway_id = aws_nat_gateway.nat-wp.id
}