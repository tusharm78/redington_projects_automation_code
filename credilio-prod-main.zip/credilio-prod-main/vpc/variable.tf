#variable for region
variable "aws_region" {
    description = "Enter the region"
    type = string
    default = "ap-south-1"      # enter the value according to your requirement
}

#variable for CIDR range for VPC
variable "aws_vpc" {
    description = "Enter the VPC CIDR range"
    type = string
    default="10.0.0.0/16"     # enter the CIDR range value according to your requirement
}

#variable for availability zone1
variable "aws_availability_zone1" {
    description = "Enter the availabilty zone"
    type = string
    default = "ap-south-1a"
}

#variable for availability zone2
variable "aws_availability_zone2" {
    description = "Enter the availabilty zone"
    type = string
    default = "ap-south-1b"
}

#variable for public subnet in AZ-1a
variable "PublicSubnet_1" {
    description = "Enter the subnet range"
    type = string
    default = "10.0.0.0/20"  # enter the subnet range value according to your requirement
  
}
#variable for public subnet in AZ-1b
variable "PublicSubnet_2" {
    description = "Enter the subnet range"
    type = string
    default = "10.0.16.0/20"  # enter the subnet range value according to your requirement
  
}

#variable for prod private subnet 1 in AZ-1a
variable "Subnet_prod_Private_1a" {
  description = "Enter the subnet range"
    type = string
    default = "10.0.32.0/20"   # enter the subnet range value according to your requirement
}

#variable for prod private subnet 2 in AZ-1a
variable "Subnet_prod_Private_2a" {
  description = "Enter the subnet range"
    type = string
    default = "10.0.64.0/20"   # enter the subnet range value according to your requirement
}

#variable for prod private subnet 3 in AZ-1a
variable "Subnet_prod_Private_3a" {
  description = "Enter the subnet range"
    type = string
    default = "10.0.96.0/20"   # enter the subnet range value according to your requirement
}

#variable for prod private subnet 1 in AZ-1b
variable "Subnet_prod_Private_1b" {
  description = "Enter the subnet range"
    type = string
    default = "10.0.48.0/20"    # enter the subnet range value according to your requirement
}

#variable for prod private subnet 2 in AZ-1b
variable "Subnet_prod_Private_2b" {
  description = "Enter the subnet range"
    type = string
    default = "10.0.80.0/20"    # enter the subnet range value according to your requirement
}

#variable for prod private subnet 3 in AZ-1b
variable "Subnet_prod_Private_3b" {
  description = "Enter the subnet range"
    type = string
    default = "10.0.112.0/20"    # enter the subnet range value according to your requirement
}

#--------------------Variable declaration for wordpress starts from here------------------------#
#variable for CIDR range for VPC
variable "aws_vpc_wp" {
    description = "Enter the VPC CIDR range"
    type = string
    default="10.2.0.0/16"     # enter the CIDR range value according to your requirement
}

#variable for wordpress public subnet in AZ-1a
variable "PublicSubnetWordpress_1" {
    description = "Enter the subnet range"
    type = string
    default = "10.2.0.0/20"  # enter the subnet range value according to your requirement
  
}
#variable for wordpress public subnet in AZ-1b
variable "PublicSubnetWordpress_2" {
    description = "Enter the subnet range"
    type = string
    default = "10.2.16.0/20"  # enter the subnet range value according to your requirement
  
}

#variable for wordpress private subnet 1 in AZ-1a
variable "Subnet_wordpress_Private_1a" {
  description = "Enter the subnet range"
    type = string
    default = "10.2.32.0/20"   # enter the subnet range value according to your requirement
}

#variable for wordpress private subnet 2 in AZ-1a
variable "Subnet_wordpress_Private_2a" {
  description = "Enter the subnet range"
    type = string
    default = "10.2.64.0/20"   # enter the subnet range value according to your requirement
}

#variable for wordpress private subnet 1 in AZ-1b
variable "Subnet_wordpress_Private_1b" {
  description = "Enter the subnet range"
    type = string
    default = "10.2.48.0/20"    # enter the subnet range value according to your requirement
}

#variable for wordpress private subnet 2 in AZ-1b
variable "Subnet_wordpress_Private_2b" {
  description = "Enter the subnet range"
    type = string
    default = "10.2.80.0/20"    # enter the subnet range value according to your requirement
}

#-------------------------Varible declaration for wordpress ends here-------------------------#


#-----------------------------------#
#---------prod vpn------------------#
#-----------------------------------#

variable "prod_vpn_key" {
  description = "Enter the Key pair name"
  type = string
  default = "prod_vpn_key.pem"                        #create keypair with required name
}

#creating variable for os disk for prod vpn
variable "prod-vpn_os_disk" {
  description = "Enter the os disk size"               #EC2 OS Disk in terms of numbers ex:20gb --> 20
  type = number
  default = "20"
}
#-----------------------------------#

#------------------------------------------#
#---------sbm-accops-prod------------------#
#------------------------------------------#

variable "sbm-accops-prod_key" {
  description = "Enter the Key pair name"
  type = string
  default = "sbm-accops-prod_key.pem"                        #create keypair with required name
}

#creating variable for os disk for prod vpn
variable "sbm-accops-prod_os_disk" {
  description = "Enter the os disk size"               #EC2 OS Disk in terms of numbers ex:20gb --> 20
  type = number
  default = "20"
}
#--------------------------------------------#

#--------------------------------------------#
#---------credilio-api-seed------------------#
#--------------------------------------------#

variable "credilio-api-seed_key" {
  description = "Enter the Key pair name"
  type = string
  default = "credilio-api-seed_key.pem"                        #create keypair with required name
}

#creating variable for os disk for prod vpn
variable "credilio-api-seed_os_disk" {
  description = "Enter the os disk size"               #EC2 OS Disk in terms of numbers ex:20gb --> 20
  type = number
  default = "30"
}
#--------------------------------------------#

#--------------------------------------------#
#---------------------wazuh------------------#
#--------------------------------------------#

variable "wazuh_key" {
  description = "Enter the Key pair name"
  type = string
  default = "wazuh_key.pem"                        #create keypair with required name
}

#creating variable for os disk for prod vpn
variable "wazuh_os_disk" {
  description = "Enter the os disk size"               #EC2 OS Disk in terms of numbers ex:20gb --> 20
  type = number
  default = "50"                                       #changed os disk fro 30 to 50 as per client's requirement
}
#--------------------------------------------#

##-------------RDS--------------------------##

variable "rdsusername" {
  type = string
}

variable "rdspassword" {
  type = string
}