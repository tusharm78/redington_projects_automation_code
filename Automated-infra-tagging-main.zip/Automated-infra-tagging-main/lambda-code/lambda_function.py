import boto3
import json
import os

def lambda_handler(event, context):


    # Parse the event for resource type and details
    try:
        event_source = event['detail']['eventSource']
        event_name = event['detail']['eventName']
        print(event_name)
        # Get tag key and value from environment variables
        tag_key1 = os.environ.get('TAG_KEY_1', 'Default_Key')
        tag_value1 = os.environ.get('TAG_VALUE_1', 'Default_Value')
        tag_key2 = os.environ.get('TAG_KEY_2', 'Default_Key')
        tag_value2 = os.environ.get('TAG_VALUE_2', 'Default_Value')
        
        
###### 1) TAG the EC2 instance
        if event_source == 'ec2.amazonaws.com' and event_name == 'RunInstances':
            # Initialize AWS clients
            ec2_client = boto3.client('ec2')
            items = event['detail']['responseElements']['instancesSet']['items']

        
            for item in items:
                resource_id = item['instanceId']
        
                # Tag EC2 instance
                ec2_client.create_tags(
                    Resources=[resource_id],
                    Tags=[
                        {'Key': tag_key1, 'Value': tag_value1},
                        {'Key': tag_key2, 'Value': tag_value2},
                        # Add more tags as needed
                    ]
                )
        
                # Get EBS volumes attached to the EC2 instance
                response = ec2_client.describe_instances(InstanceIds=[resource_id])
                for reservation in response['Reservations']:
                    for instance in reservation['Instances']:
                        for volume in instance['BlockDeviceMappings']:
                            ebs_volume_id = volume['Ebs']['VolumeId']
                            # Tag EBS volume with the same tags as EC2 instance
                            ec2_client.create_tags(
                                Resources=[ebs_volume_id],
                                Tags=[
                                    {'Key': tag_key1, 'Value': tag_value1},
                                    {'Key': tag_key2, 'Value': tag_value2},
                                    # Add more tags as needed
                                ]
                            )
        
            return {
                'statusCode': 200,
                'body': json.dumps('Tags updated successfully for EC2 and associated EBS volumes!')
            }
            
####### 2) TAG the S3 Bucket
        elif event_source == 's3.amazonaws.com' and event_name == 'CreateBucket':
            s3_client = boto3.client('s3')
            resource_id = event['detail']['requestParameters']['bucketName']
            
            # Tag S3 bucket
            s3_client.put_bucket_tagging(
                Bucket=resource_id,
                Tagging={
                    'TagSet': [
                        {'Key': tag_key1, 'Value': tag_value1},
                        {'Key': tag_key2, 'Value': tag_value2},
                        # Add more tags as needed
                    ]
                }
            )
            
            return {
                'statusCode': 200,
                'body': json.dumps('Tags updated successfully for S3 bucket!')
            }       

        
######### 3) TAG EBS Volume
        elif event_source == 'ec2.amazonaws.com' and event_name == 'CreateVolume':
            ebs_client = boto3.client('ec2')
            volume_id = event['detail']['responseElements']['volumeId']

            print(volume_id)
            
            
            if volume_id:
                ebs_client.create_tags(
                    Resources=[volume_id],
                    Tags=[
                        {'Key': tag_key1, 'Value': tag_value1},
                        {'Key': tag_key2, 'Value': tag_value2},
                        # Add more tags as needed
                    ]
                )
            
                return {
                    'statusCode': 200,
                    'body': json.dumps(f'Tags updated successfully for EBS volume {volume_id}!')
                }
            
######### 4) Tag EC2 Snapshot
        elif event_source == 'ec2.amazonaws.com' and event_name == 'CreateSnapshot':
            ec2_client = boto3.client('ec2')
            snapshot_id = event['detail']['responseElements']['snapshotId']
            
            ec2_client.create_tags(
                Resources=[snapshot_id],
                Tags=[
                    {'Key': tag_key1, 'Value': tag_value1},
                    {'Key': tag_key2, 'Value': tag_value2},
                    # Add more tags as needed
                ]
            )
            
            return {
                'statusCode': 200,
                'body': json.dumps('Tags updated successfully for EC2 snapshot!')
            }
        
######## 5) TAG the CloudWatch logs resource
        elif event_source == 'logs.amazonaws.com' and event_name == 'CreateLogGroup':
            cloudwatchlogs_client = boto3.client('logs')
            resource_name = event['detail']['requestParameters']['logGroupName']
 
            # Tag CloudWatch resource
            response = cloudwatchlogs_client.tag_log_group(
                logGroupName=resource_name,
                tags={
                    tag_key1 : tag_value1,
                    tag_key2 : tag_value2,
                    # Add more tags as needed
                }
            )
        
            return {
                'statusCode': 200,
                'body': json.dumps('Tags updated successfully for CloudWatch resource!')
            }
        
        
######## 6) Tag the Transit gateway
        elif event_source == 'ec2.amazonaws.com' and event_name == 'CreateTransitGateway':
            ec2_client = boto3.client('ec2')
            tgw_id = event['detail']['responseElements']['CreateTransitGatewayResponse']['transitGateway']['transitGatewayId']
            print(tgw_id)
            ec2_client.create_tags(
                Resources=[tgw_id],
                Tags=[
                    {'Key': tag_key1, 'Value': tag_value1},
                    {'Key': tag_key2, 'Value': tag_value2},
                    # Add more tags as needed
                ]
            )

            return {
                'statusCode': 200,
                'body': json.dumps(f'Tags updated successfully for TransitGateway {tgw_id}!')
            }
            
            
######## 7) Tag the RDS instance    
        elif event_source == 'rds.amazonaws.com' and event_name == 'CreateDBInstance':
            rds_client = boto3.client('rds')
            # Retrieve the RDS instance identifier from the event
            
            resource_arn = event['detail']['responseElements']['dBInstanceArn']
            
            rds_client.add_tags_to_resource(
                ResourceName=resource_arn,
                Tags=[
                    {'Key': tag_key1, 'Value': tag_value1},
                    {'Key': tag_key2, 'Value': tag_value2},
                    # Add more tags as needed
                ]
            )
            
            return {
                'statusCode': 200,
                'body': json.dumps('Tags updated successfully for RDS instance!')
            }
            
######## 8) TAG the FSx File System
        elif event_source == 'fsx.amazonaws.com' and event_name == 'CreateFileSystem':
            fsx_client = boto3.client('fsx')
            resource_id = event['detail']['responseElements']['fileSystem']['resourceARN']
            
            # Tag FSx File System
            fsx_client.tag_resource(
                ResourceARN=resource_id,
                Tags=[
                    {'Key': tag_key1, 'Value': tag_value1},
                    {'Key': tag_key2, 'Value': tag_value2},
                    # Add more tags as needed
                ]
            )
    
            return {
                'statusCode': 200,
                'body': json.dumps('Tags updated successfully for FSx File System!')
            }
            
            
######## 9) Tag the Fsx Storage Virtual Machines (SVM)
        elif event_source == 'fsx.amazonaws.com' and event_name == 'CreateStorageVirtualMachine':
            fsx_client = boto3.client('fsx')
            resource_id = event['detail']['responseElements']['storageVirtualMachine']['resourceARN']
            print(resource_id)
            # Your tagging logic for SVMs
            fsx_client.tag_resource(
                ResourceARN=resource_id,
                Tags=[
                    {'Key': tag_key1, 'Value': tag_value1},
                    {'Key': tag_key2, 'Value': tag_value2},
                    # Add more tags as needed
                ]
            )
            return {
                'statusCode': 200,
                'body': json.dumps(f'Tags updated successfully for SVM {resource_id}!')
            }
            
            
 ######## 10) Tag the Fsx Volume
        elif event_source == 'fsx.amazonaws.com' and event_name == 'CreateVolume':
            fsx_client = boto3.client('fsx')
            resource_id = event['detail']['responseElements']['volume']['resourceARN']
            print(resource_id)
            # Your tagging logic for SVMs
            fsx_client.tag_resource(
                ResourceARN=resource_id,
                Tags=[
                    {'Key': tag_key1, 'Value': tag_value1},
                    {'Key': tag_key2, 'Value': tag_value2},
                    # Add more tags as needed
                ]
            )
            return {
                'statusCode': 200,
                'body': json.dumps(f'Tags updated successfully for SVM {resource_id}!')
            }           
            

######## 11) TAG the Redshift Cluster
        elif event_source == 'redshift.amazonaws.com' and event_name == 'CreateCluster':
            redshift_client = boto3.client('redshift')
            resource_id = event['detail']['responseElements']['clusterIdentifier']
            region = event['detail']['awsRegion']
            accountid = event['detail']['userIdentity']['accountId']
            
            resource_arn = f"arn:aws:redshift:{region}:{accountid}:cluster:{resource_id}"
            
            # Tag Redshift Cluster
            redshift_client.create_tags(
                ResourceName=resource_arn,
                Tags=[
                    {'Key': tag_key1, 'Value': tag_value1},
                    {'Key': tag_key2, 'Value': tag_value2},
                    # Add more tags as needed
                ]
            )
            
            return {
                'statusCode': 200,
                'body': json.dumps('Tags updated successfully for Redshift Cluster!')
            } 

######## 12.) TAG the SNS Topic
        elif event_source == 'sns.amazonaws.com' and event_name == "CreateTopic":
            sns_client = boto3.client('sns')
            resource_id = event['detail']['responseElements']['topicArn']
    
            # Tag SNS Topic
            sns_client.tag_resource(
                ResourceArn=resource_id,
                Tags=[
                    {'Key': tag_key1, 'Value': tag_value1},
                    {'Key': tag_key2, 'Value': tag_value2},

                    # Add more tags as needed
		
                ]
            )
    
            return {
                'statusCode': 200,
                'body': json.dumps('Tags updated successfully for SNS Topic!')
            }       
            
        else:
            return {
                'statusCode': 400,
                'body': json.dumps('Event does not match expected pattern.')
            }
            
    except KeyError as e:
        return {
            'statusCode': 400,
            'body': json.dumps(f'Error: Missing key - {str(e)}')
        }