# Automated Infrastructure Tagging

## Overview

This repository provides an automated tagging solution on AWS, using Lambda functions, EventBridge rules and CloudFormation. The solution responds to specific AWS cloudtrail API events via , ensuring resources are appropriately tagged at the time of creation. The Lambda function's code is stored in an S3 bucket, and the entire setup can be deployed as a CloudFormation stack.

## Workflow

![image](https://github.com/RedingtonGroup/Automated-infra-tagging/assets/154952093/cbda30e0-573c-48b3-a938-d5918305418d)


### Components

- **Lambda Function:** Responsible for automated tagging of AWS resources. It is written in Python and triggered by specific AWS API events (via CloudTrail).
- **EventBridge Rules:** Rules are defined for specific AWS API events to trigger the Lambda function.
- **S3 Bucket:** Stores the Lambda function code (lambda_function.zip). It facilitates easy access and deployment of the Lambda function.


### Prerequisites

- AWS Account
- AWS CLI installed and configured

## Deployment Steps

### 1. Clone the github repostory:
```bash
git clone https://github.com/RedingtonGroup/Automated-infra-tagging.git
```

### 2. Upload Lambda Code to S3 Bucket 

- Create an S3 bucket in a specific region where you want to deploy these resources.
- Upload the Lambda function code (`lambda_function.zip`) from the repository to the S3 bucket.

```bash
aws s3api create-bucket --bucket YOUR_BUCKET_NAME --region YOUR_REGION
aws s3 cp lambda_function.zip s3://YOUR_BUCKET_NAME/
```

### 2. Deploy CloudFormation Stack

- Modify the CloudFormation template (`tagging_cft.yaml`) with your S3 bucket name and other parameters if needed.
- Deploy the CloudFormation stack.

```bash
aws cloudformation create-stack --stack-name YOUR_STACK_NAME --template-body file://tagging_cft.yaml --capabilities CAPABILITY_IAM
```

### 3. Verify Deployment

- Check the CloudFormation stack events for successful deployment.
- Verify the existence of the Lambda function, EventBridge rules, and permissions.

## Parameters

- `S3BucketParameter`: The name of the S3 bucket where Lambda code is stored.
- `S3KeyParameter`: The path to the Lambda code file in the S3 bucket.

## Cleanup

To delete the CloudFormation stack:

```bash
aws cloudformation delete-stack --stack-name YOUR_STACK_NAME
```

## AWS Resource Tagger Lambda Function

This AWS Lambda function automatically tags various AWS resources based on specific CloudTrail events. Written in Python, it uses the Boto3 SDK to interact with AWS services.

### Purpose

The function's primary purpose is to streamline resource tagging by responding to specific AWS CloudTrail events. It supports tagging for various resource types:

1. **EC2 Instances and Associated EBS Volumes:**

   - Trigger: `RunInstances`.
   - Tags the EC2 instance and its associated EBS volumes.

2. **S3 Buckets:**

   - Trigger: `CreateBucket`.
   - Tags the newly created S3 bucket.

3. **EBS Volumes:**

   - Trigger: `CreateVolume`.
   - Tags the newly created EBS volume.

4. **EC2 Snapshots:**

   - Trigger: `CreateSnapshot`.
   - Tags the newly created EC2 snapshot.

5. **CloudWatch Logs:**

   - Trigger: `CreateLogGroup`.
   - Tags the newly created CloudWatch log group.

6. **Transit Gateway:**

   - Trigger: `CreateTransitGateway`.
   - Tags the newly created Transit Gateway.

7. **RDS Instances:**

   - Trigger: `CreateDBInstance`.
   - Tags the newly created RDS instance.

8. **Amazon FSx File System:**

   - Trigger: `CreateFileSystem`.
   - Tags the newly created FSx File System.

9. **Amazon FSx Storage Virtual Machines (SVM):**

   - Trigger: `CreateStorageVirtualMachine`.
   - Tags the newly created FSx Storage Virtual Machine.

10. **Amazon FSx Volume:**

    - Trigger: `CreateVolume`.
    - Tags the newly created FSx Volume.

11. **Amazon Redshift Cluster:**

    - Trigger: `CreateCluster`.
    - Tags the newly created Amazon Redshift Cluster.

### Configuration

The Lambda function uses environment variables to set default tag keys and values:

- `TAG_KEY_1`, `TAG_VALUE_1`: Default tag key and value for tagging.
- `TAG_KEY_2`, `TAG_VALUE_2`: Additional tag key and value for tagging.

### How it Works

The Lambda function is triggered by CloudTrail events. Upon triggering, it parses the event to identify the resource type and the specific event that occurred. Based on this information, it uses Boto3 clients to interact with the corresponding AWS service and apply tags to the relevant resource.

### Deployment

Deploy this Lambda function using AWS CloudFormation. The provided CloudFormation template creates the necessary resources and associates the Lambda function with an EventBridge rule to capture specified events.

--- 

# Note
<br>

## 🚀 To add any new service in the existing solution.
1. First, update the IAM permission (to tag the resource) of that specific service in AutoTaggingLambdaRole block of Cloudformation template(CFT). 
For instance, if we are adding the SNS topic as a new service in existing solution then we have to add the permission for that as below.
```
Resources:
  AutoTaggingLambdaRole:
    Type: AWS::IAM::Role
    Properties:
      AssumeRolePolicyDocument:
        Version: '2012-10-17'
        Statement:
          - Effect: Allow
            Principal:
              Service: lambda.amazonaws.com
            Action: sts:AssumeRole
      Policies:
        - PolicyName: LambdaExecutionAndTaggingPolicy
          PolicyDocument:
            Version: '2012-10-17'
            Statement:
              - Effect: Allow
                Action:
                  - logs:CreateLogGroup
                  - logs:CreateLogStream
                  - logs:PutLogEvents
                Resource: arn:aws:logs:*:*:*
              - Sid: VisualEditor0
                Effect: Allow
                Action:
                  - ec2:CreateTags
                  - ec2:DescribeInstances
                  - ec2:DescribeVolumes
                  - s3:TagResource
                  - logs:UntagResource
                  - logs:TagResource
                  - logs:TagLogGroup
                  - s3:PutBucketTagging
                  - fsx:TagResource
                  - rds:AddTagsToResource
                  - redshift:CreateTags
                  - sns:TagResource
                Resource: '*'
```

2. Add the Event pattern for that service in Eventbridge rule block of CFT. You can identify the correct pattern which can trigger when resource is created by looking at the event in CloudTrail.

   ![cloudtrail](images/cloudtrail.png)

   According to that, you can create a eventbridge rule pattern for the resource creation of that service.

   ![eventbridge](images/eventbridgepattern.png)

3. At last, you just need to the add the logic inside the lambda code for that service as below.

   ![lambdacode](images/lambdacode.png)

## 🚀 Setting up Automated Infrastructure Tagging in Multi-Account Scenarios with Stack Sets

To deploy the Automated Infrastructure Tagging solution in a multi-account setup using AWS Stack Sets, follow these steps:

**1. Preparation:**
   - **Master Account:** Ensure you have access to the AWS Master account, which will be used to manage the deployment across multiple accounts.
   - **Permissions:** Make sure the IAM role used for deployment has the necessary permissions to create and manage Stack Sets in the target accounts.

**2. Configuration:**
   - **CloudFormation Template:** Prepare the CloudFormation template (`Auto-tagging-cft.yaml`) with the required parameters and configurations for the tagging solution.
   - **Parameters:** Define parameters such as S3 bucket name, Lambda function code path, tag keys, and values as per your tagging requirements.
   - **Stack Set Configuration:** Include Stack Set configuration details in the CloudFormation template, specifying the target AWS accounts and regions where the solution will be deployed.

**3. Deployment:**
   - **Create Stack Set:** Use the AWS Management Console, AWS CLI, or SDK to create a Stack Set using the prepared CloudFormation template.
   - **Specify Accounts and Regions:** Define the target AWS accounts and regions where the solution will be deployed as part of the Stack Set configuration.
   - **Deploy Stack Set:** Initiate the deployment of the Stack Set to deploy the tagging solution across all specified AWS accounts and regions simultaneously.

**4. Monitoring and Management:**
   - **Stack Set Operations:** Monitor the status of Stack Set operations to ensure successful deployment across all target accounts and regions.
   - **Tagging Compliance:** Regularly monitor tagging compliance across resources in all accounts to ensure consistency and adherence to tagging policies.
   - **Updates and Maintenance:** Periodically update the CloudFormation template and Stack Set configurations to accommodate changes in tagging requirements or infrastructure.

**5. Troubleshooting:**
   - **Logs and Monitoring:** Utilize AWS CloudTrail logs and CloudWatch metrics for troubleshooting and monitoring deployment activities and resource tagging.
   - **AWS Support:** In case of any issues or challenges during deployment, reach out to AWS Support for assistance and guidance.

By following these steps, you can efficiently deploy the Automated Infrastructure Tagging solution across multiple AWS accounts using Stack Sets, ensuring consistent tagging practices and streamlined management of resources organization-wide.

### 🔍 Questions from Session:

**Q.1 What happens if a resource already has existing tags when the tagging solution is implemented? Does the solution overwrite the existing tag values?**

Ans. If a resource already has existing tags when the tagging solution is implemented, the solution will overwrite the existing tag values with the values specified in CFT configuration. This ensures consistency in tagging across all resources managed by the solution.

**Q2. How does the tagging solution manage conflicts with Terraform's state file if resources are initially created with Terraform and then tagged using the CloudFormation solution?**

Ans. When resources are initially created with Terraform and later tagged using the solution, potential conflicts may arise with Terraform's state file. To avoid conflicts, it's essential to align the configurations of Terraform and the tagging solution. By ensuring consistency between the two tools, conflicts can be minimized, and resource management remains smooth.

**Q3. If we have to deploy this solution in a multi-account setup, how can we do that?**

Ans.  To deploy this solution in a Multi-account setup, we can utilize AWS Stack Sets. We need to set up the solution in the AWS Master account, which has the necessary permissions across all target accounts. Stack Sets allow us to centrally manage and deploy CloudFormation stacks across multiple AWS accounts and regions simultaneously, ensuring consistent tagging across the entire organization.


## Feel free to reach out if you need further assistance or clarification on any step of the process!
