Architecture Overview:
The architecture consists of several key components:

VPC (Virtual Private Cloud):

This is the isolated network that hosts all resources (ALB, EC2 instances, RDS database). Within the VPC, you’ll have:
Public Subnets: Where the Application Load Balancer (ALB) will reside.
Private Subnets: Where the EC2 instances and the RDS PostgreSQL database are located.
Application Load Balancer (ALB):

The ALB is responsible for routing incoming HTTP requests to the EC2 instances based on the listener rules (typically, HTTP on port 80).
The ALB sits in the public subnet because it needs to be accessible from the internet.
The ALB will route traffic to EC2 instances that are running a web application or API.
EC2 Instances:

These instances run the application or services that are being accessed via the ALB.
The EC2 instances will be placed in a private subnet, meaning they will not have direct internet access.
The ALB forwards incoming traffic to these EC2 instances based on load balancing and health checks.
RDS PostgreSQL:

The RDS database is hosted in a private subnet to secure it from direct internet access.
The EC2 instances can communicate with the RDS database, but the database is not directly accessible from the internet.
VPC Security:

Security Groups are used to control inbound and outbound traffic.
The ALB security group will allow inbound traffic on port 80 from the internet, while the EC2 instances will allow traffic only from the ALB.
The EC2 instances can also connect to the RDS database on the appropriate PostgreSQL port (typically 5432).

![Untitled Diagram (21)](https://github.com/user-attachments/assets/b9352f4b-b5ff-48f4-9ba2-108df2c8034e)



Jenkins Integration with Terraform:
Jenkins is a popular CI/CD tool that automates the process of building, testing, and deploying applications and infrastructure. In this case, Jenkins will be used to run Terraform commands for provisioning the infrastructure.

Jenkins Server:
The Jenkins server will be configured with the appropriate AWS credentials to manage resources in the client’s AWS account.
It will trigger the Terraform plan and apply commands to deploy the infrastructure defined in the Terraform templates.
Jenkins can be configured to monitor the GitHub repository for any changes (such as a new commit with updated Terraform configuration files). When changes are detected, Jenkins will initiate the Terraform deployment process.
GitHub Repository:
The Terraform templates (configuration files) will be stored in a GitHub repository. This enables version control, collaboration, and ease of deployment.
Jenkins will integrate with GitHub, pulling the latest version of the Terraform files when a change is detected, and then running the terraform plan and terraform apply commands to provision the resources.
