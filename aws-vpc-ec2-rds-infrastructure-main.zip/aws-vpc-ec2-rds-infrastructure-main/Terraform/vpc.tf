provider "aws" {
  region = "us-west-1"  # Change this to your preferred AWS region
  alias = "vpc"
}

# Create the VPC
resource "aws_vpc" "main_vpc" {
  cidr_block = "10.0.0.0/16"
  enable_dns_support = true
  enable_dns_hostnames = true

  tags = {
    Name = "main-vpc"
  }
}

# Create public subnets
resource "aws_subnet" "public_subnet_1" {
  vpc_id                  = aws_vpc.main_vpc.id
  cidr_block              = "10.0.1.0/24"
  availability_zone       = "us-west-1a"
  map_public_ip_on_launch = true

  tags = {
    Name = "public-subnet-1"
  }
}

resource "aws_subnet" "public_subnet_2" {
  vpc_id                  = aws_vpc.main_vpc.id
  cidr_block              = "10.0.2.0/24"
  availability_zone       = "us-west-1b"
  map_public_ip_on_launch = true

  tags = {
    Name = "public-subnet-2"
  }
}

# Create private subnets
resource "aws_subnet" "private_subnet_1" {
  vpc_id                  = aws_vpc.main_vpc.id
  cidr_block              = "10.0.3.0/24"
  availability_zone       = "us-west-1a"

  tags = {
    Name = "private-subnet-1"
  }
}

resource "aws_subnet" "private_subnet_2" {
  vpc_id                  = aws_vpc.main_vpc.id
  cidr_block              = "10.0.4.0/24"
  availability_zone       = "us-west-1b"

  tags = {
    Name = "private-subnet-2"
  }
}

# Create an internet gateway for the VPC
resource "aws_internet_gateway" "internet_gateway" {
  vpc_id = aws_vpc.main_vpc.id

  tags = {
    Name = "main-internet-gateway"
  }
}

# Create a security group for the EC2 instances
resource "aws_security_group" "ec2_sg" {
  name_prefix = "ec2_sg"
  vpc_id      = aws_vpc.main_vpc.id

  ingress {
    from_port   = 22
    to_port     = 22
    protocol    = "tcp"
    cidr_blocks = ["0.0.0.0/0"]
  }

  egress {
    from_port   = 0
    to_port     = 0
    protocol    = "-1"
    cidr_blocks = ["0.0.0.0/0"]
  }

  tags = {
    Name = "ec2-security-group"
  }
}

# Create an Elastic IP for the NAT Gateway
resource "aws_eip" "nat_eip" {
  domain = "vpc"
}

# Create the NAT Gateway
resource "aws_nat_gateway" "nat_gateway" {
  allocation_id = aws_eip.nat_eip.id
  subnet_id     = aws_subnet.public_subnet_1.id

  depends_on = [aws_eip.nat_eip]
}

# Create a route table for the public subnet and associate it
resource "aws_route_table" "public_route_table" {
  vpc_id = aws_vpc.main_vpc.id

  route {
    cidr_block = "0.0.0.0/0"
    gateway_id = aws_internet_gateway.internet_gateway.id
  }

  tags = {
    Name = "public-route-table"
  }
}

resource "aws_route_table_association" "public_subnet_association_1" {
  subnet_id      = aws_subnet.public_subnet_1.id
  route_table_id = aws_route_table.public_route_table.id
}

resource "aws_route_table_association" "public_subnet_association_2" {
  subnet_id      = aws_subnet.public_subnet_2.id
  route_table_id = aws_route_table.public_route_table.id
}

# Create a route table for private subnets and associate it
resource "aws_route_table" "private_route_table" {
  vpc_id = aws_vpc.main_vpc.id

  route {
    cidr_block     = "0.0.0.0/0"
    nat_gateway_id = aws_nat_gateway.nat_gateway.id
  }

  tags = {
    Name = "private-route-table"
  }
}

resource "aws_route_table_association" "private_subnet_association_1" {
  subnet_id      = aws_subnet.private_subnet_1.id
  route_table_id = aws_route_table.private_route_table.id
}

resource "aws_route_table_association" "private_subnet_association_2" {
  subnet_id      = aws_subnet.private_subnet_2.id
  route_table_id = aws_route_table.private_route_table.id
}

# Create an EC2 instance in the public subnet
resource "aws_instance" "ec2_instance_1" {
  ami                         = "ami-05c65d8bb2e35991a"  # Updated AMI ID
  instance_type               = "t2.micro"
  subnet_id                   = aws_subnet.public_subnet_1.id
  security_groups             = [aws_security_group.ec2_sg.id]  # Reference the correct security group
  key_name                    = "my-key"  # Replace with your SSH key name
  associate_public_ip_address = true

  tags = {
    Name = "ec2-instance-1"
  }

  depends_on = [aws_security_group.ec2_sg]  # Ensure security group is created first
}

# Create another EC2 instance in the private subnet
resource "aws_instance" "ec2_instance_2" {
  ami                         = "ami-05c65d8bb2e35991a"  # Updated AMI ID
  instance_type               = "t2.micro"
  subnet_id                   = aws_subnet.private_subnet_1.id
  security_groups             = [aws_security_group.ec2_sg.id]  # Reference the correct security group
  key_name                    = "my-key"  # Replace with your SSH key name
  associate_public_ip_address = false  # No public IP for private subnet instances

  tags = {
    Name = "ec2-instance-2"
  }

  depends_on = [aws_security_group.ec2_sg]  # Ensure security group is created first
}

# Output the EC2 instance public IP
output "ec2_instance_1_public_ip" {
  value = aws_instance.ec2_instance_1.public_ip
}

# Output the VPC ID
output "vpc_id" {
  value = aws_vpc.main_vpc.id
}

# Output the security group ID
output "security_group_id" {
  value = aws_security_group.ec2_sg.id
}
