# Reference the VPC and EC2 instances from the main configuration
provider "aws" {
  region = "us-west-1"  # Change this to your preferred AWS region
}

# Define the ALB security group
resource "aws_security_group" "alb_sg" {
  name_prefix = "alb_sg"
  vpc_id      = aws_vpc.main_vpc.id

  ingress {
    from_port   = 80
    to_port     = 80
    protocol    = "tcp"
    cidr_blocks = ["0.0.0.0/0"]
  }

  egress {
    from_port   = 0
    to_port     = 0
    protocol    = "-1"
    cidr_blocks = ["0.0.0.0/0"]
  }

  tags = {
    Name = "alb-security-group"
  }
}

# Create the ALB
resource "aws_lb" "application_lb" {
  name               = "application-lb"
  internal           = false
  load_balancer_type = "application"
  security_groups   = [aws_security_group.alb_sg.id]
  subnets            = [aws_subnet.public_subnet_1.id, aws_subnet.public_subnet_2.id]
  enable_deletion_protection = false

  tags = {
    Name = "Application Load Balancer"
  }
}

# Create a Target Group
resource "aws_lb_target_group" "ec2_target_group" {
  name     = "ec2-target-group"
  port     = 80
  protocol = "HTTP"
  vpc_id   = aws_vpc.main_vpc.id

  health_check {
    path = "/"
    port = 80
    protocol = "HTTP"
    interval = 30
    timeout  = 5
    healthy_threshold = 2
    unhealthy_threshold = 2
  }

  tags = {
    Name = "EC2 Target Group"
  }
}

# Register the EC2 instances with the Target Group
resource "aws_lb_target_group_attachment" "ec2_target_attachment_1" {
  target_group_arn = aws_lb_target_group.ec2_target_group.arn
  target_id       = aws_instance.ec2_instance_1.id
  port            = 80
}

resource "aws_lb_target_group_attachment" "ec2_target_attachment_2" {
  target_group_arn = aws_lb_target_group.ec2_target_group.arn
  target_id       = aws_instance.ec2_instance_2.id
  port            = 80
}

# Create an ALB Listener
resource "aws_lb_listener" "http_listener" {
  load_balancer_arn = aws_lb.application_lb.arn
  port              = 80
  protocol          = "HTTP"

  default_action {
    type             = "forward"
    target_group_arn = aws_lb_target_group.ec2_target_group.arn
  }
}

# Output the ALB DNS name
output "alb_dns_name" {
  value = aws_lb.application_lb.dns_name
}
