# Create a security group for RDS
resource "aws_security_group" "rds_sg" {
  name_prefix = "rds_sg"
  vpc_id      = aws_vpc.main_vpc.id

  # Allow incoming traffic on PostgreSQL (5432) from instances within the VPC only
  ingress {
    from_port   = 5432
    to_port     = 5432
    protocol    = "tcp"
    cidr_blocks = ["10.0.0.0/16"]  # Restrict to within the VPC
  }

  egress {
    from_port   = 0
    to_port     = 0
    protocol    = "-1"
    cidr_blocks = ["0.0.0.0/0"]
  }

  tags = {
    Name = "rds-security-group"
  }
}

# Create an RDS Subnet Group (grouping the private subnets)
resource "aws_db_subnet_group" "rds_subnet_group" {
  name       = "rds_subnet_group"
  subnet_ids = [aws_subnet.private_subnet_1.id, aws_subnet.private_subnet_2.id]  # Private subnets

  tags = {
    Name = "rds-subnet-group"
  }
}

# Create the RDS instance in the private subnets
resource "aws_db_instance" "rds_instance" {
  allocated_storage      = 20
  engine                 = "postgres"  # Use PostgreSQL engine
  instance_class         = "db.t3.micro"  # Modify the instance type according to your needs
  db_name                = "mydb"
  username               = "dbadmin"  # Use a non-reserved username
  password               = "password123"  # Change the master password (store securely)
  db_subnet_group_name   = aws_db_subnet_group.rds_subnet_group.name
  vpc_security_group_ids = [aws_security_group.rds_sg.id]
  multi_az               = false  # Set to true for high availability
  publicly_accessible    = false  # Ensure the instance is not publicly accessible
  skip_final_snapshot    = true  # Disable snapshot on deletion (use with caution)

  tags = {
    Name = "rds-instance"
  }
}


# Output the RDS instance endpoint
output "rds_endpoint" {
  value = aws_db_instance.rds_instance.endpoint
}

# Output the RDS instance ID
output "rds_instance_id" {
  value = aws_db_instance.rds_instance.id
}
