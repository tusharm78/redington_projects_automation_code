terraform {
  required_providers {
    azurerm = {
      source  = "hashicorp/azurerm"
      version = "3.95.0"
    }
  }
  required_version = "~> 1.7.2"
}

provider "azurerm" {
  features {}


  subscription_id  = "<azure_subscription_id>" #(get from the portal)
  tenant_id  = "<azure_subscription_tenant_id>" #(get from azure AD)
  client_id  = "<service_principal_appid>" #(create an app registration(service account) and under certificates and secrets create a client id and secret)
  client_secret  = "<service_principal_password>"
}
  
  