# Resource-12: SSH and Jenkins Setup on EC2
resource "null_resource" "jenkins_setup" {
  connection {
    type        = "ssh"
    user        = "ec2-user"
    private_key = file(var.private_key_path)
    host        = aws_eip.public_ip.public_ip
  }

  provisioner "remote-exec" {
    inline = [
      "sudo yum update -y",
      "sudo wget -O /etc/yum.repos.d/jenkins.repo https://pkg.jenkins.io/redhat-stable/jenkins.repo",
      "sudo rpm --import https://pkg.jenkins.io/redhat-stable/jenkins.io.key",
      "sudo yum install fontconfig java-17-openjdk -y",
      "sudo yum install jenkins -y",
      "sudo systemctl enable jenkins",
      "sudo systemctl start jenkins",
      "echo 'Jenkins Installed'",
      
      # Install Jenkins Plugins
      "java -jar jenkins-cli.jar -s http://localhost:8080/ install-plugin sonar github aws-credentials aws-java-sdk aws-codebuild aws-codedeploy aws-codepipeline --restart",
      
      "echo 'Jenkins Plugins Installed'"
    ]
  }

  depends_on = [aws_instance.my-ec2-vm1, aws_eip.public_ip]
}
