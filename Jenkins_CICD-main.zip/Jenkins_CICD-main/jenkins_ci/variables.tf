variable "ami_id" {
  default = "ami-05c179eced2eb9b5b"
}

variable "instance_type" {
  default = "t3.medium"
}

variable "private_key_path" {
  description = "Path to the private key file (.pem) for SSH access"
}

variable "public_key_path" {
  description = "Path to the public key file for EC2 key pair"
}
