# Output Jenkins URL
output "Jenkins_url" {
  value = join("", ["http://", aws_eip.public_ip.public_ip, ":8080"])
}
