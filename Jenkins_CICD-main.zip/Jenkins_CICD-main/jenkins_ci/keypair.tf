resource "aws_key_pair" "jenkins_keypair" {
  key_name   = "jenkins-key"
  public_key = file(var.public_key_path)
}
