# Provider Configuration for AWS
provider "aws" {
  region = "ap-south-1"
}
