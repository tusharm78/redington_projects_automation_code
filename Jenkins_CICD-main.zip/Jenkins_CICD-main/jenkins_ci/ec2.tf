# Resource-10: Elastic IP (EIP) for EC2
resource "aws_eip" "public_ip" {
  vpc      = true
  instance = aws_instance.my-ec2-vm1.id
}

# Resource-11: EC2 Instance for Jenkins
resource "aws_instance" "my-ec2-vm1" {
  subnet_id                   = aws_subnet.vpc-dev-public-subnet-1.id
  associate_public_ip_address = true
  ami                         = var.ami_id
  instance_type               = var.instance_type
  key_name                    = aws_key_pair.jenkins_keypair.key_name
  vpc_security_group_ids      = [aws_security_group.vpc-ssh.id, aws_security_group.vpc-web.id]

  tags = {
    Name = "Jenkins Server Automation"
  }
}
