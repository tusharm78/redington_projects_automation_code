# EKS_logs_Grafana_Loki
Grafana Loki, a friendly and efficient tool that makes log management in Kubernetes simple, affordable, and even a bit fun to work with


