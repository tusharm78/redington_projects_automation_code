# AWS IAM L2 General 

This Terraform code provisions an AWS IAM user with L2 (Level 2) general permissions, enforcing security best practices such as MFA and region restrictions. It is designed for scenarios where users require administrative access via CLI only with important safety boundaries.

## Features

- **IAM User Creation**: Creates a named IAM user with only CLI access.
- **Access Key Generation**: Generates access and secret keys for CLI/API access.
- **MFA Enforcement**: Attaches a custom policy requiring MFA for sensitive actions.
- **Region Restriction**: Denies actions outside the `ap-south-1` region (except for global services).
- **Permission Boundary**: Applies a boundary policy to prevent destructive actions (e.g., delete, terminate).
- **Policy Attachments**: Attaches AWS managed and custom policies for required permissions.

## Files

- `0_provider.tf`: AWS provider configuration.
- `0_backend.tf`: Remote S3 backend configuration for state management.
- `1_iam_user.tf`: IAM user and access key resources.
- `2_iam_policy.tf`: Custom IAM policies (MFA enforcement, region restriction, permission boundary).
- `4_iam_policy_attach.tf`: Attaches policies to the user.
- `var.tf`: Input variables (e.g., user name).
- `output.tf`: Outputs user ARN, access key, and secret key.

## Outputs

- `user_arn`: The ARN of the created IAM user.
- `cli_user_access_key`: The access key for CLI/API use (sensitive).
- `cli_user_secret_key`: The secret key for CLI/API use (sensitive).

## Security Notes

- **MFA is enforced** for sensitive actions.
- **Destructive actions are denied** by the permission boundary.
- **Region is restricted** to `ap-south-1` for most actions.
