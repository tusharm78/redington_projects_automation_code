terraform {  
  backend "s3" {  
    bucket       = "terraform"  #Provide the bucket name
    key          = "terraform/tfstatefile.tfstate"  #Provide the file name with prefix
    region       = "ap-south-1"  #Provide the region name
    use_lockfile = true  #S3 native locking
  }  
}