# Creating an IAM user
resource "aws_iam_user" "L2_user" {
  name                 = var.iam_user_name
  permissions_boundary = aws_iam_policy.permissions_boundary.arn #Attaching permission boundary
}

# Creating an Access key for CLI access
resource "aws_iam_access_key" "L2_user_key" {
  user = aws_iam_user.L2_user.name
}

