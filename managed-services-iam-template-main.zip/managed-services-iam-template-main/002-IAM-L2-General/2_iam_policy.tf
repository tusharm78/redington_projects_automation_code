
# Creating a IAM Policy for MFA(CLI)
resource "aws_iam_policy" "MFAForCLI_policy" {
  name        = "MFAForCLI-Test"
  description = "MFAForCLI-Test"

  policy = jsonencode({
    Version = "2012-10-17"
    Statement = [
      {
        Sid    = "AllowViewAccountInfo"
        Effect = "Allow"
        Action = [
          "iam:GetAccountPasswordPolicy",
          "iam:ListVirtualMFADevices"
        ]
        Resource = "*"
      },

      {
        Sid    = "AllowManageOwnAccessKeys"
        Effect = "Allow"
        Action = [
          "iam:CreateAccessKey",
          "iam:DeleteAccessKey",
          "iam:ListAccessKeys",
          "iam:UpdateAccessKey",
          "iam:GetAccessKeyLastUsed"
        ]
        Resource = "arn:aws:iam::*:user/$${aws:username}"
      },

      {
        Sid    = "AllowManageOwnVirtualMFADevice"
        Effect = "Allow"
        Action = [
          "iam:CreateVirtualMFADevice"
        ]
        Resource = "arn:aws:iam::*:mfa/*"
      },

      {
        Sid    = "AllowManageOwnUserMFA"
        Effect = "Allow"
        Action = [
          "iam:DeactivateMFADevice",
          "iam:EnableMFADevice",
          "iam:ListMFADevices",
          "iam:ResyncMFADevice"
        ]
        Resource = "arn:aws:iam::*:user/$${aws:username}"
      },

      {
        Sid    = "DenyAllExceptListedIfNoMFA"
        Effect = "Deny"
        NotAction = [
          "iam:CreateVirtualMFADevice",
          "iam:EnableMFADevice",
          "iam:GetUser",
          "iam:GetMFADevice",
          "iam:ListMFADevices",
          "iam:ListVirtualMFADevices",
          "iam:ResyncMFADevice",
          "sts:GetSessionToken"
        ]
        Resource = "*"
        Condition = {
          BoolIfExists = {
            "aws:MultiFactorAuthPresent" = "false"
            "aws:ViaAWSService"          = "false"
          }
        }
      }
    ]
  })
}

#Creating an IAM Policy to restrict region
resource "aws_iam_policy" "deny_outside_ap_south_1" {
  name        = "DenyOutsideApSouth1"
  description = "This policy denies all region except ap-south-1"
  policy = jsonencode({
    Version = "2012-10-17"
    Statement = [
      {
        Sid    = "DenyAllOutsideRequestedRegions"
        Effect = "Deny"
        NotAction = [
          "cloudfront:*",
          "iam:*",
          "route53:*",
          "support:*"
        ]
        Resource = "*"
        Condition = {
          StringNotEquals = {
            "aws:RequestedRegion" = [
              "ap-south-1"
            ]
          }
        }
      }
    ]
  })
}

# Creating an IAM policy for permission boundary

resource "aws_iam_policy" "permissions_boundary" {
  name        = "AdminAccessWithoutDelete-Test"
  description = ""
  policy = jsonencode({
    Version = "2012-10-17"
    Statement = [
      {
        Sid    = "AllowSafeDescribeListGet"
        Effect = "Allow"
        Action = [
          "ec2:Describe*",
          "ec2:Get*",
          "s3:List*",
          "s3:Get*",
          "rds:Describe*",
          "iam:EnableMFADevice",
          "iam:Get*",
          "iam:List*",
          "lambda:GetFunction",
          "lambda:ListFunctions",
          "cloudformation:Describe*",
          "cloudwatch:GetMetricData",
          "cloudwatch:DescribeAlarms",
          "dynamodb:Describe*",
          "dynamodb:List*",
          "ssm:Describe*",
          "ssm:GetParameter",
          "ssm:ListDocuments",
          "logs:Describe*",
          "logs:GetLogEvents",
          "logs:FilterLogEvents",
          "sns:ListTopics",
          "sqs:ListQueues",
          "elasticloadbalancing:Describe*",
          "kms:Describe*",
          "kms:List*"
        ]
        Resource = "*"
      },
      {
        Sid    = "DenyAllOutsideRequestedRegions"
        Effect = "Deny"
        NotAction = [
          "cloudfront:*",
          "iam:*",
          "s3:List*",
          "route53:*",
          "support:*"
        ]
        Resource = "*"
        Condition = {
          StringNotEquals = {
            "aws:RequestedRegion" = [
              "ap-south-1"
            ]
          }
        }
      },
      {
        Sid    = "DenyDestructiveActions"
        Effect = "Deny"
        Action = [
          "ec2:TerminateInstances",
          "ec2:DeleteVolume",
          "ec2:DeleteSnapshot",
          "ec2:DeleteKeyPair",
          "ec2:DeleteSecurityGroup",
          "ec2:DeleteVpc",
          "ec2:RevokeSecurityGroupIngress",
          "ec2:RevokeSecurityGroupEgress",
          "ec2:DetachVolume",
          "ec2:DisassociateAddress",
          "s3:DeleteBucket",
          "s3:DeleteObject",
          "s3:DeleteObjectVersion",
          "rds:DeleteDBInstance",
          "rds:DeleteDBSnapshot",
          "rds:DeleteDBCluster",
          "iam:DeleteUser",
          "iam:DeleteRole",
          "iam:DeletePolicy",
          "iam:DetachRolePolicy",
          "iam:DetachUserPolicy",
          "iam:RemoveUserFromGroup",
          "lambda:DeleteFunction",
          "lambda:DeleteLayerVersion",
          "lambda:RemovePermission",
          "cloudformation:DeleteStack",
          "logs:DeleteLogGroup",
          "logs:DeleteLogStream",
          "cloudwatch:DeleteAlarms",
          "dynamodb:DeleteTable",
          "dynamodb:DeleteItem",
          "ssm:DeleteParameter",
          "ssm:DeleteDocument",
          "sns:DeleteTopic",
          "sqs:DeleteQueue",
          "sqs:DeleteMessage",
          "sqs:PurgeQueue",
          "kms:RevokeGrant",
          "ecs:DeregisterContainerInstance",
          "ecs:DeregisterTaskDefinition",
          "elasticloadbalancing:DeregisterTargets"
        ]
        Resource = "*"
      }
    ]
  })
}
