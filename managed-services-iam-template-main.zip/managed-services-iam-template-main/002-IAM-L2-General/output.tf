# Output the user arn
output "user_arn" {
  description = "The ARN assigned by AWS for this user"
  value       = aws_iam_user.L2_user.arn
}

# Output the access key  
output "cli_user_access_key" {
  description = "The access key for the user"
  value       = aws_iam_access_key.L2_user_key.id
  sensitive   = true
}

# Output the secret key
output "cli_user_secret_key" {
  description = "The secret access key for the user"
  value       = aws_iam_access_key.L2_user_key.secret
  sensitive   = true
}
