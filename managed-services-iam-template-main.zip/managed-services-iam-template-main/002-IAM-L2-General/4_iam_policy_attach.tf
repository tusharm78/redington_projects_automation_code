# Attaching a policy to the user
resource "aws_iam_user_policy_attachment" "L2_user_admin" {
  user       = aws_iam_user.L2_user.name
  policy_arn = "arn:aws:iam::aws:policy/AdministratorAccess" # Administrator Access
}

resource "aws_iam_user_policy_attachment" "L2_user_mfa" {
  user       = aws_iam_user.L2_user.name
  policy_arn = aws_iam_policy.MFAForCLI_policy.arn
}

resource "aws_iam_user_policy_attachment" "L2_user_region_deny" {
  user       = aws_iam_user.L2_user.name
  policy_arn = aws_iam_policy.deny_outside_ap_south_1.arn
}