#Enforcing MFA via policy
resource "aws_iam_user_policy_attachment" "mfa" {
  user       = aws_iam_user.user.name
  policy_arn = "arn:aws:iam::533266968553:policy/MFA-Access" # Enforcing MFA. Without enabling the MFA user can't able to access anything

}

# Attaching a read only policy to the user
resource "aws_iam_user_policy_attachment" "user_readonly" {
  user       = aws_iam_user.user.name
  policy_arn = "arn:aws:iam::aws:policy/ReadOnlyAccess" # Full Read only policy
}
