terraform {  
  backend "s3" {  
    bucket       = "terraform"  #Provide the bucket name
    key          = "terraform/user1.tfstate"  #Provide the file name with prefix
    region       = "ap-south-1"  #Provide the region name
    use_lockfile = true  #S3 native locking
  }  
}