#######
# Variables for IAM user
#######

variable "iam_user_name" {
  description = "The user's name"
  type        = string
  default     = "L1-user"
}