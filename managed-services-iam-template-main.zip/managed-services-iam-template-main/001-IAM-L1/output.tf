
output "user_arn" {
  description = "The ARN assigned by AWS for this user"
  value       = aws_iam_user.user.arn
}

output "console_password" {
  description = "Console password for the user to login"
  value       = aws_iam_user_login_profile.user.password
  sensitive   = true
}