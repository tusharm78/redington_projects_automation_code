# AWS IAM L1 Terraform code

This terraform code provisions a basic AWS IAM user with enforced MFA and read-only access, suitable for L1 (Level 1) users. It is designed for use with Terraform and leverages AWS best practices for user management and security.

## Features
- Creates an IAM user with a specified name
- Enables AWS Console access for the user
- Enforces Multi-Factor Authentication (MFA) via a custom policy
- Attaches AWS-managed ReadOnlyAccess policy
- Outputs the user's ARN and (optionally) the initial console password

## Files Overview
- `0_backend.tf`: Configures the S3 backend for remote Terraform state storage
- `0_provider.tf`: Sets up the AWS provider and region
- `1_iam_user.tf`: Declares the IAM user and enables console login
- `2_iam_policy.tf`: Attaches MFA enforcement and read-only policies to the user
- `output.tf`: Outputs the IAM user's ARN and console password
- `var.tf`: Declares the variable for the IAM user's name

## Requirements
- Terraform >= 1.0
- An S3 bucket for remote state (see `0_backend.tf`)


## Security Notes
- MFA is enforced. The user cannot access AWS resources without enabling MFA.
- The initial console password is output as a sensitive value. Handle with care.

