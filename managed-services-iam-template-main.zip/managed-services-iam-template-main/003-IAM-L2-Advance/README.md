# AWS IAM L2 Advance Terraform code

This Terraform code provisions an AWS IAM user with advanced L2 (Level 2) permissions, focusing on enhanced security and operational safety. It is suitable for users who require administrative access with strict boundaries to prevent destructive actions and enforce region restrictions.

## Features

- **IAM User Creation**: Creates a named IAM user with a permissions boundary.
- **Console Access**: Enables AWS Management Console access for the user.
- **Permission Boundary**: Attaches a custom policy that allows all actions except destructive operations (delete, terminate, etc.) and restricts actions to the `ap-south-1` region.
- **Policy Attachments**: Attaches AWS managed AdministratorAccess and a custom MFA policy to the user.

## Files

- `0_provider.tf`: AWS provider configuration.
- `0_backend.tf`: S3 backend configuration for remote state.
- `1_iam_user.tf`: IAM user and login profile resources.
- `2_iam_policy.tf`: Custom permission boundary policy.
- `3_iam_policy_attachment.tf`: Attaches policies to the user.
- `var.tf`: Input variables (e.g., user name).
- `output.tf`: Outputs user ARN, console password, and policy ARN.

## Outputs

- `user_arn`: The ARN of the created IAM user.
- `console_password`: The initial console password for the user (sensitive).
- `policy_arn`: The ARN of the permission boundary policy.

## Security Notes

- **Destructive actions are denied** by the permission boundary.
- **Region is restricted** to `ap-south-1` for most actions.
- **MFA enforcement** is expected via an attached policy (referenced in the attachments).

