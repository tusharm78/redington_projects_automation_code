# Creating a IAM Policy for permission boundary
resource "aws_iam_policy" "safe_policy" {
  name        = "AdminstratorAccessWithDenyAllDestructiveActions"
  description = "Policy allowing all operations, denying destructive(delete, terminate, revoke.,etc) actions and outside ap-south-1"

  policy = jsonencode({
    "Version" = "2012-10-17"
    "Statement" = [
      {
        "Sid"      = "AllowSafeDescribeListGet"
        "Effect"   = "Allow"
        "Action"   = "*"
        "Resource" = "*"
      },
      {
        "Sid"    = "DenyAllOutsideRequestedRegions"
        "Effect" = "Deny"
        "NotAction" = [
          "cloudfront:*",
          "iam:*",
          "route53:*",
          "support:*"
        ]
        "Resource" = "*"
        "Condition" = {
          "StringNotEquals" = {
            "aws:RequestedRegion" = ["ap-south-1"]
          }
        }
      },
      {
        "Sid"    = "DenyDestructiveActions"
        "Effect" = "Deny"
        "Action" = [
          "ec2:TerminateInstances",
          "ec2:DeleteVolume",
          "ec2:DeleteSnapshot",
          "ec2:DeleteKeyPair",
          "ec2:DeleteSecurityGroup",
          "ec2:DeleteVpc",
          "ec2:RevokeSecurityGroupIngress",
          "ec2:RevokeSecurityGroupEgress",
          "ec2:DetachVolume",
          "ec2:DisassociateAddress",
          "s3:DeleteBucket",
          "s3:DeleteObject",
          "s3:DeleteObjectVersion",
          "rds:DeleteDBInstance",
          "rds:DeleteDBSnapshot",
          "rds:DeleteDBCluster",
          "iam:DeleteUser",
          "iam:DeleteRole",
          "iam:DeletePolicy",
          "iam:DetachRolePolicy",
          "iam:DetachUserPolicy",
          "iam:RemoveUserFromGroup",
          "lambda:DeleteFunction",
          "lambda:DeleteLayerVersion",
          "lambda:RemovePermission",
          "cloudformation:DeleteStack",
          "logs:DeleteLogGroup",
          "logs:DeleteLogStream",
          "cloudwatch:DeleteAlarms",
          "dynamodb:DeleteTable",
          "dynamodb:DeleteItem",
          "ssm:DeleteParameter",
          "ssm:DeleteDocument",
          "sns:DeleteTopic",
          "sqs:DeleteQueue",
          "sqs:DeleteMessage",
          "sqs:PurgeQueue",
          "kms:RevokeGrant",
          "ecs:DeregisterContainerInstance",
          "ecs:DeregisterTaskDefinition",
          "elasticloadbalancing:DeregisterTargets"
        ]
        "Resource" = "*"
      }
    ]
  })
}
