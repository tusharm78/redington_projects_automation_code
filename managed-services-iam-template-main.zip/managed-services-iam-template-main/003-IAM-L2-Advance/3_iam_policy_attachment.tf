# Attaching a policy to the user
resource "aws_iam_user_policy_attachment" "admin_access" {
  user       = aws_iam_user.l2_user.name
  policy_arn = "arn:aws:iam::aws:policy/AdministratorAccess" # Administrator policy
}

resource "aws_iam_user_policy_attachment" "mfa" {
  user       = aws_iam_user.l2_user.name
  policy_arn = "arn:aws:iam::533266968553:policy/MFA-Access" # Enforcing MFA
}
