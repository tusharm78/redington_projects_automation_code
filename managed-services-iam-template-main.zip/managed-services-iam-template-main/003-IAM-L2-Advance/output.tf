
output "user_arn" {
  description = "The ARN assigned by AWS for this user"
  value       = aws_iam_user.l2_user.arn
}

output "console_password" {
  description = ""
  value       = aws_iam_user_login_profile.l2_user.password
  sensitive   = true
}

output "policy_arn" {
  description = ""
  value       = aws_iam_policy.safe_policy.arn
}