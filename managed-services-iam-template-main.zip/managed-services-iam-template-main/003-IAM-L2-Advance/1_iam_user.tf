# Creating an IAM user
resource "aws_iam_user" "l2_user" {
  name                 = var.iam_user_name
  permissions_boundary = aws_iam_policy.safe_policy.arn
}

# Enabling the console access for the user
resource "aws_iam_user_login_profile" "l2_user" {
  user                    = aws_iam_user.l2_user.name
  password_reset_required = false
}