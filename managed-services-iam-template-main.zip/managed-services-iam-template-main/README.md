
# Terraform code to create AWS IAM Users

This repository contains various terraform code to automate the creation of AWS IAM Users with different set of privileges.



## Documentation

# 1. L1 User
The L1 user is provisioned with Two IAM policies are attached:

- #### MFA Enforcement – Access to AWS resources is denied until MFA is configured.
- #### ReadOnly Access – Grants view-only permissions across supported AWS services.

# 2. L2 User - General
The L2 user is provisioned with only CLI access. Two IAM policies are attached with permission boundary:

- #### MFA Enforcement – Access to AWS resources is denied until MFA is configured.
- #### Region Restriction – Allows access only to the Mumbai region (ap-south-1).
- #### Permission Boundary – Restricts the user from performing destructive actions such as delete, terminate, revoke, detach, disassociate, and remove, etc., The policy covers commonly used services, but may not include all required actions. Review and customize it as needed. Use with caution.

# 3. L2 User - Advance
The L2 user-adavance is provisioned with Two IAM policies are attached with permission boundary:

- #### MFA Enforcement – Access to AWS resources is denied until MFA is configured.
- #### Administrator Access with permission boundary – Grants full access to all AWS services and resources. However, actual access is controlled by a permission boundary that restricts destructive actions (like delete, terminate, revoke) and enforces region restriction to Mumbai (ap-south-1). This ensures elevated access while maintaining operational safeguards. Use with caution and customize as needed.

# 4. L3 User
The L3 user is provisioned with Two IAM policies are attached:
- #### MFA Enforcement – Access to AWS resources is denied until MFA is configured.
- #### Administrator Access – Grants full access to all AWS resources and services. Users with this permission can perform any action without restrictions. Assign only to trusted users, as it provides complete control over the account. Use with caution.

## Using AWS CLI with MFA

To obtain temporary credentials with MFA:

```sh
aws sts get-session-token --serial-number <mfa-device-arn> --token-code <mfa-code>
```

### Setting Environment Variables

**Windows:**
```cmd
set AWS_ACCESS_KEY_ID=<access-key-id>
set AWS_SECRET_ACCESS_KEY=<secret-access-key>
set AWS_SESSION_TOKEN=<session-token>
```

**Linux/macOS:**
```sh
export AWS_ACCESS_KEY_ID=<access-key-id>
export AWS_SECRET_ACCESS_KEY=<secret-access-key>
export AWS_SESSION_TOKEN=<session-token>
```