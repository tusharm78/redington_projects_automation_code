# Creating an IAM user
resource "aws_iam_user" "L3_user" {
  name = var.iam_user_name
}

# Enabling the console access for the user
resource "aws_iam_user_login_profile" "L3_user" {
  user                    = aws_iam_user.L3_user.name
  password_reset_required = false
}