# AWS IAM L3 Terraform code

This Terraform code provisions an AWS IAM user with L3 (Level 3) permissions, granting full administrative access with enforced MFA for maximum security. It is suitable for users who require the highest level of access to AWS resources.

## Features

- **IAM User Creation**: Creates a named IAM user.
- **Console Access**: Enables AWS Management Console access for the user.
- **Administrator Access**: Attaches the AWS managed `AdministratorAccess` policy.
- **MFA Enforcement**: Attaches a custom or pre-existing MFA policy to require multi-factor authentication.

## Files

- `0_provider.tf`: AWS provider configuration.
- `0_backend.tf`: S3 backend configuration for remote state.
- `1_iam_user.tf`: IAM user and login profile resources.
- `2_iam_policy_attachment.tf`: Attaches policies to the user.
- `var.tf`: Input variables (e.g., user name).
- `output.tf`: Outputs user ARN, console password, and MFA policy ARN.

## Outputs

- `user_arn`: The ARN of the created IAM user.
- `console_password`: The initial console password for the user (sensitive).
- `mfa_policy_arn`: The ARN of the attached MFA policy.

## Security Notes

- **Full administrative access** is granted—use with caution.
- **MFA is enforced** for all console logins.
