
output "user_arn" {
  description = "The ARN assigned by AWS for this user"
  value       = aws_iam_user.L3_user.arn
}

output "console_password" {
  description = "Console password for the user"
  value       = aws_iam_user_login_profile.L3_user.password
  sensitive   = true
}

output "mfa_policy_arn" {
  description = "The ARN of the policy"
  value       = aws_iam_policy.mfa_for_console.arn
}