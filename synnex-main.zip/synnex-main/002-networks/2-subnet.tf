########
# Resource block to create subnet
########

resource "azurerm_subnet" "subnet" {
  name                 = var.subnet_name
  resource_group_name  = var.resource_group_name
  virtual_network_name = var.vnet_name
  address_prefixes     = var.address_prefixes
  depends_on           = [azurerm_virtual_network.vnet]
}

########
# Resource block to create a Gateway subnet
########

resource "azurerm_subnet" "subnet_1" {
  name                 = var.subnet_name_1
  resource_group_name  = var.resource_group_name
  virtual_network_name = var.vnet_name
  address_prefixes     = var.address_prefixes_1
  depends_on           = [azurerm_virtual_network.vnet]
}