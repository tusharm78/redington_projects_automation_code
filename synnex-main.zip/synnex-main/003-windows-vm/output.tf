######
# Output block to get details about the VM
######

output "vm-id" {
  description = "The ID of the Windows Virtual Machine"
  value = azurerm_windows_virtual_machine.vm.id
}

output "private-ip" {
  description = "The Primary Private IP Address assigned to this Virtual Machine"
  value = azurerm_windows_virtual_machine.vm.private_ip_address
}

output "public-ip" {
  description = "The Primary Public IP Address assigned to this Virtual Machine"
  value = azurerm_windows_virtual_machine.vm.public_ip_address
}