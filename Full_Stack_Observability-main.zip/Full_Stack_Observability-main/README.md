# EKS Monitoring and Observability Setup

This repository contains Ansible playbooks to set up monitoring and observability for an EKS (Elastic Kubernetes Service) cluster. The setup is divided into three components:
- **Logs**: Collected using OpenTelemetry and sent to Amazon S3.
- **Metrics**: Collected using Prometheus and visualized with Grafana.
- **Traces**: Captured using AWS X-Ray for distributed tracing.

## Folder Structure

```bash
.
├── logs_metrics/                         # Contains playbooks related to logging (OpenTelemetry -> S3) and metrics (Prometheus & Grafana)
│   └── main_playbook.yaml                # Main playbook for setting up logs and metrics
├── Full_Stack_Observability/Traces/
│   └── Xray_Automation_Script/           # Contains X-Ray automation script
│       └── mainXray.yaml                 # Playbook to configure X-Ray tracing
├── inventory                             # Ansible inventory file (to be created)
