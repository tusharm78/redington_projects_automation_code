# this file consists of variables declared

variable "aws_region" {
    description = "enter the value for region"
    type = string
    default = "ap-south-1"                              #change the value as per requirement
}