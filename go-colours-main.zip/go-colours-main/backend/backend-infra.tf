#### this file as configuration for creating a S3 bucket & dynamodb table needed for backend
#### do not make any modifications 


## S3 bucket
resource "aws_s3_bucket" "do-not-delete-go-colours-terraform-backend" {
    bucket = "do-not-delete-go-colours-terraform-backend"                    ## name should be do-not-delete-project(replace project name)-terraform-backend
}


## dynamo db table
resource "aws_dynamodb_table" "terraform-state-lock-DO-NOT-DELETE" {
    name = "terraform-state-lock-DO-NOT-DELETE"
    billing_mode = "PAY_PER_REQUEST"
    hash_key = "LockID"

    attribute {
      name = "LockID"
      type = "S"
    }
}