#### S3 bucket ####

#### S3 bucket for test DB backup ####

resource "aws_s3_bucket" "s3-bucket_db_bkp" {
  bucket = var.bucket_db_bkp

  tags = {
     Name = "test-bkp-rst-07032024"
     Created-by  = "Terraform_Automation"
  }
}

#### S3 bucket for  DB backup ####
resource "aws_s3_bucket" "s3-bucket_datbase_bkp" {
  bucket = var.bucket_database_bkp

  tags = {
     Name = "database-migration-08032024"
     Created-by  = "Terraform_Automation"
  }
}

#### S3 bucket for  DB log backup ####
resource "aws_s3_bucket" "s3-bucket_development_efs_bkp" {
  bucket = var.bucket_development_efs_bkp

  tags = {
     Name = "bkp-efs-development"
     Created-by  = "Terraform_Automation"
  }
}

/*resource "aws_s3_bucket_versioning" "s3-bucket_development_efs_bkp_versioning" {
  bucket = aws_s3_bucket.s3-bucket_development_efs_bkp.id
  versioning_configuration {
    status = "Enabled"
  }
}*/

#### S3 bucket for  DB log backup ####
resource "aws_s3_bucket" "s3-bucket_production_efs_bkp" {
  bucket = var.bucket_production_efs_bkp

  tags = {
     Name = "bkp-efs-production"
     Created-by  = "Terraform_Automation"
  }
}

resource "aws_s3_bucket_versioning" "s3-bucket_production_efs_bkp_versioning" {
  bucket = aws_s3_bucket.s3-bucket_production_efs_bkp.id
  versioning_configuration {
    status = "Enabled"
  }
}


### S3 bucket for DB backup
resource "aws_s3_bucket" "s3-bucket_production_DB_backup" {
  bucket = var.bucket_production_DB_backup

  tags = {
     Name = "DB-Backup"
     Created-by  = "Terraform_Automation"
  }
}
resource "aws_s3_bucket_versioning" "s3-bucket_production_DB_backup" {
  bucket = aws_s3_bucket.s3-bucket_production_DB_backup.id
  versioning_configuration {
    status = "Enabled"
  }
}

### S3 bucket for DB-Legatrix backup
resource "aws_s3_bucket" "s3-bucket_legatrix_DB_backup_" {
  bucket = var.bucket_legatrix_DB_backup

  tags = {
     Name = "DB-Legatrix-Backup"
     Created-by  = "Terraform_Automation"
  }
}
########################################efs-backup-bucket########################
resource "aws_s3_bucket" "s3-efs-bucket-dump" {
  bucket = var.efs_backup_old

  tags = {
     Name = "efs-bucket"
     Created-by  = "Terraform_Automation"
  }
}
