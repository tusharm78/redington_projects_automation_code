# ------------------------------------- #
#creating virtual machine - BWDEV VM
# ------------------------------------- #
resource "aws_instance" "ec2_bwdev" {
  subnet_id                   = aws_subnet.dev_subnet_1a.id
  associate_public_ip_address = false
  ami                         = "ami-05a5bb48beb785bf1"   #rhel 9 ami id
  instance_type               = "r6a.xlarge"              #add the required instance size here
  root_block_device {
  volume_size = var.bwdev_os_disk
    encrypted = true
    delete_on_termination = true
    volume_type = "gp3"
    tags = {
        Name = "Bwdev_os_Disk"
        Created-by  = "Terraform_Automation"
        
     }
  }
  

#here we are referencing the aws key pair which we have created in keypair.tf config file
key_name              = var.bwdev_key
depends_on = [aws_key_pair.bwdev_key]

vpc_security_group_ids = [aws_security_group.sg_bwdev.id,aws_security_group.sg_sap-ports.id]
  
#here we are attaching tags to our resources
tags = {
    "Name" = "Bwdev"
     Created-by  = "Terraform_Automation"
     Environment = "Dev"
     backup = "dev-bkp"

  }
}

# ----------------------------------------------------------- #
## this creates a data disk EBS volume
# ------------------------------------------------------------ #

resource "aws_ebs_volume" "bwdev_data_disk_1" {
  availability_zone = var.aws_availability_zone1
  size = var.bwdev_data_disk_1
  encrypted = true
  type = "gp3"

  tags = {
    Name = "bwdev_data_disk_1"
    Created-by  = "Terraform_Automation"
  }
}

#this attachs the data disk EBS volume created above to the server

resource "aws_volume_attachment" "bwdev_data_disk_attach_1" {
  device_name = "/dev/sdf"
  volume_id   = aws_ebs_volume.bwdev_data_disk_1.id
  instance_id = aws_instance.ec2_bwdev.id
}



# ----------------------------------------------------------- #
#creating security group for BWDEV VM
# ----------------------------------------------------------- #
# Create Security Group - SSH Traffic
resource "aws_security_group" "sg_bwdev" {
  vpc_id      = aws_vpc.vpc-go.id
  name        = "sg_bwdev"
  description = "VM SSH"
 
 # inbound ssh port
  ingress {
    description = "Allow Port 22"
    from_port   = 22
    to_port     = 22
    protocol    = "tcp"
    cidr_blocks = ["10.10.8.224/27","192.168.0.0/24","192.168.2.0/24","192.168.1.0/24","192.168.10.0/24","172.16.28.118/32","13.200.248.213/32","172.16.28.0/22"]
  }
   
   ingress {
    description = "Allow Port 5902"
    from_port   = 5900
    to_port     = 5902
    protocol    = "tcp"
    cidr_blocks = ["10.10.8.224/27","192.168.0.0/24","192.168.2.0/24","192.168.1.0/24","192.168.10.0/24","172.16.28.118/32","13.200.248.213/32"]
  }
  ingress {
    description = "VNC Port 5903 09/06/24"
    from_port   = 5903
    to_port     = 5903
    protocol    = "tcp"
    cidr_blocks = ["192.168.10.0/24","192.168.1.0/24","192.168.0.0/24","192.168.2.0/24"]
  }
# outbound port   
 egress {
    description = "Allow all IP and Ports outbound"
    from_port   = 0
    to_port     = 0
    protocol    = "-1"
    cidr_blocks = ["0.0.0.0/0"]
  }

  tags = {
    Name = "sg_bwdev"
    CreatedThrough = "Terraform Automation"
  }
}

