#This cofiguration file consists of resources required for site -to-site connection.
#Creating vpn gateway for Go colours client
 resource "aws_vpn_gateway" "vpn_gateway_go_colours" {
  vpc_id = aws_vpc.vpc-go.id
   tags = {
    Name = "Vgw_go_colors"
    CreatedThrough = "terraform automation"
  }
}

#creating customer gateway for chennai ho airtel 
resource "aws_customer_gateway" "customer_gateway_ch_ho_airtel" {
  bgp_asn    = 65000
  ip_address = "125.20.163.11"
  type       = "ipsec.1"
   tags = {
    Name = "cgw_chennai_ho_airtel"
    CreatedThrough = "terraform automation"
  }
}

#creating customer gateway for tirupur wh airtel
resource "aws_customer_gateway" "customer_gateway_tr_wh_airtel" {
  bgp_asn    = 65000
  ip_address = "182.74.134.91"
  type       = "ipsec.1"
   tags = {
    Name = "cgw_tirupur_wh_airtel"
    CreatedThrough = "terraform automation"
  }
}

#creating customer gateway for tirupur ho tata
resource "aws_customer_gateway" "customer_gateway_tr_ho_tata" {
  bgp_asn    = 65000
  ip_address = "49.249.33.3"
  type       = "ipsec.1"
   tags = {
    Name = "cgw_tirupur_ho_tata"
    CreatedThrough = "terraform automation"
  }
}
 
#creating site-2-site chennai ho airtel 
resource "aws_vpn_connection" "s2s_ch_ho_airtel" {
  vpn_gateway_id      = aws_vpn_gateway.vpn_gateway_go_colours.id
  customer_gateway_id = aws_customer_gateway.customer_gateway_ch_ho_airtel.id
  type                = "ipsec.1"
  static_routes_only  = true
 
  tags = {
    Name = "s2s_chennai_ho_airtel"
    CreatedThrough = "terraform automation"
  }
}
#adding static routes to chennai ho airtel
resource "aws_vpn_connection_route" "route_ch_ho_airtel" {
  destination_cidr_block = "192.168.1.0/24"
  vpn_connection_id      = aws_vpn_connection.s2s_ch_ho_airtel.id
}

#creating site-2-site tirupur wh airtel
resource "aws_vpn_connection" "s2s_tr_wh_airtel" {
  vpn_gateway_id      = aws_vpn_gateway.vpn_gateway_go_colours.id
  customer_gateway_id = aws_customer_gateway.customer_gateway_tr_wh_airtel.id
  type                = "ipsec.1"
  static_routes_only  = true
 
  tags = {
    Name = "s2s_tirupur_wh_airtel"
    CreatedThrough = "terraform automation"
  }
}

#adding static routes to tirupati wh airtel
resource "aws_vpn_connection_route" "route_tr_wh_airtel" {
  destination_cidr_block = "192.168.10.0/24"
  vpn_connection_id      = aws_vpn_connection.s2s_tr_wh_airtel.id
}

#creating site-2-site tirupur ho tata
resource "aws_vpn_connection" "s2s_tr_ho_tata" {
  vpn_gateway_id      = aws_vpn_gateway.vpn_gateway_go_colours.id
  customer_gateway_id = aws_customer_gateway.customer_gateway_tr_ho_tata.id
  type                = "ipsec.1"
  static_routes_only  = true
 
  tags = {
    Name = "s2s_tirupur_ho_tata"
    CreatedThrough = "terraform automation"
  }
}

#adding static routes to tirupur ho tata
resource "aws_vpn_connection_route" "tirupur_ho_tata" {
  for_each = { for idx, cidr_block in var.static_routes : idx => cidr_block }

  vpn_connection_id      = aws_vpn_connection.s2s_tr_ho_tata.id
  destination_cidr_block = each.value
}

