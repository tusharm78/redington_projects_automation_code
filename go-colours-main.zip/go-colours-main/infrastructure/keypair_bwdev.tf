resource "aws_key_pair" "bwdev_key" {
key_name = var.bwdev_key
public_key = tls_private_key.rsa_bwdev.public_key_openssh
}

#key pair which has been created above is encrypted with RSA algorithm 4096 bits, we can change this accroding to requirement 
resource "tls_private_key" "rsa_bwdev" {
algorithm = "RSA"
rsa_bits  = 4096
}

#this creates a file in our working directory and download the aws key pair which we have created above
resource "local_file" "bwdev_key" {
content  = tls_private_key.rsa_bwdev.private_key_pem
filename = var.bwdev_key
depends_on = [aws_key_pair.bwdev_key]
}