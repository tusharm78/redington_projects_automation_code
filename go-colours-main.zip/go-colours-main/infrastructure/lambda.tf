###########################Start#########################
resource "aws_lambda_function" "ec2_status_alert_1" {
  filename      = "lambda_function_2.zip"
  function_name = "lambda_function_start_alert"
  role          = aws_iam_role.lambda_iam_role.arn
  handler       = "lambda_function_start_alert.lambda_handler"
  runtime       = "python3.8"
  timeout       = 120
  environment {
    variables = {
      INSTANCE_IDS = "i-0275a4a490d30bb69,i-09b042ad5e2491617"

      TOPIC_ARN   = aws_sns_topic.snstopicforlambda.arn
    }
  }

}

##########################Stop#############################
resource "aws_lambda_function" "ec2_status_alert_2" {
  filename      = "lambda_function_3.zip"
  function_name = "lambda_function_stop_alert"
  role          =  aws_iam_role.lambda_iam_role.arn
  handler       = "lambda_function_stop_alert.lambda_handler"
  runtime       = "python3.8"
  timeout       = 120

  environment {
    variables = {
      INSTANCE_IDS = "i-0275a4a490d30bb69,i-09b042ad5e2491617"

      TOPIC_ARN   = aws_sns_topic.snstopicforlambda.arn
    }
  }

}
