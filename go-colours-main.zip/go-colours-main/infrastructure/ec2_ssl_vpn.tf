# ------------------------------------- #
#creating virtual machine - SSL VPN VM
# ------------------------------------- #
resource "aws_instance" "ec2_sslvpn" {
  subnet_id                   = aws_subnet.Public-Subnet.id
  associate_public_ip_address = true
  ami                         = "ami-03f4878755434977f"  #ubuntu 22.04 ami id
  instance_type               = "t3a.medium"        #add the required instance size here
  root_block_device {
  volume_size = var.sslvpn_os_disk
    encrypted = true
    delete_on_termination = true
    volume_type = "gp3"
    tags = {
      Name = "ssl_os_disk"
      CreatedThrough = "Terraform_Automation"
    }
  }
  
#here we are referencing the aws key pair which we have created in keypair.tf config file
key_name              = var.ssl_vpn_key

vpc_security_group_ids = [aws_security_group.sg_ssl_vpn.id]
  
  #here we are attaching tags to our resources
  tags = {
    "Name" = "SSL-VPN"
     Created-by  = "Terraform_Automation"

  }
}

# ----------------------------------------------------------- #
#this creates and attach a elastic public ip to SSL VPN VM
# ----------------------------------------------------------- #
resource "aws_eip" "ssl_public_ip" {
  domain = "vpc"
  instance = aws_instance.ec2_sslvpn.id
    tags = {
    Name = "eip_ssl_vpn"
    Created-by  = "Terraform_Automation"
  }
}

# ----------------------------------------------------------- #
#creating security group for SSL VPN VM
# ----------------------------------------------------------- #
# Create Security Group - SSH Traffic
resource "aws_security_group" "sg_ssl_vpn" {
  vpc_id      = aws_vpc.vpc-go.id
  name        = "sg_ssl_vpn"
  description = "VM SSH"

# inbound ssh port
  ingress {
    description = "Allow Port 22"
    from_port   = 22
    to_port     = 22
    protocol    = "tcp"
    cidr_blocks = ["0.0.0.0/0"]
  }
# inbound ssl port
  ingress {
    description = "SSL port"
    from_port   = 1194
    to_port     = 1194
    protocol    = "udp"
    cidr_blocks = ["0.0.0.0/0"]
  }
  ingress {
    description = "VNC Port 5903 09/06/24"
    from_port   = 5903
    to_port     = 5903
    protocol    = "tcp"
    cidr_blocks = ["192.168.10.0/24","192.168.1.0/24","192.168.0.0/24","192.168.2.0/24"]
  }

#outbound port 
  egress {
    description = "Allow all IP and Ports outbound"
    from_port   = 0
    to_port     = 0
    protocol    = "-1"
    cidr_blocks = ["0.0.0.0/0"]
  }

  tags = {
    Name = "sg_ssl_vpn"
    CreatedThrough = "Terraform Automation"
  }
}
