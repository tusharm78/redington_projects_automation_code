terraform {
  required_version = "> 0.14"
  required_providers {
    aws = {
      source  = "hashicorp/aws"
      version = "> 3.0"
    }
  }
}

# Provider Block
provider "aws" {
  region     = var.aws_region
}
# Region replication
provider "aws" {
  alias = "replication"
  region     = var.aws_replication_region
}