resource "aws_key_pair" "podev_key" {
key_name = var.podev_key
public_key = tls_private_key.rsa_podev.public_key_openssh
}

#key pair which has been created above is encrypted with RSA algorithm 4096 bits, we can change this accroding to requirement 
resource "tls_private_key" "rsa_podev" {
algorithm = "RSA"
rsa_bits  = 4096
}

#this creates a file in our working directory and download the aws key pair which we have created above
resource "local_file" "podev_key" {
content  = tls_private_key.rsa_podev.private_key_pem
filename = var.podev_key
depends_on = [aws_key_pair.podev_key]
}