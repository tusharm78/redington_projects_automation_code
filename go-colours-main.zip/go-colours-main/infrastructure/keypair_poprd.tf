resource "aws_key_pair" "poprd_key" {
key_name = var.poprd_key
public_key = tls_private_key.rsa_poprd.public_key_openssh
}

#key pair which has been created above is encrypted with RSA algorithm 4096 bits, we can change this accroding to requirement 
resource "tls_private_key" "rsa_poprd" {
algorithm = "RSA"
rsa_bits  = 4096
}

#this creates a file in our working directory and download the aws key pair which we have created above
resource "local_file" "poprd_key" {
content  = tls_private_key.rsa_poprd.private_key_pem
filename = var.poprd_key
depends_on = [aws_key_pair.poprd_key]
}