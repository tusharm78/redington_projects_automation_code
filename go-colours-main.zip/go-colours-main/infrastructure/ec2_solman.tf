# ------------------------------------- #
#creating virtual machine - Solman VM
# ------------------------------------- #
resource "aws_instance" "ec2_solman" {
  subnet_id                   = aws_subnet.Public-Subnet.id
  associate_public_ip_address = true
  ami                         = "ami-05a5bb48beb785bf1"   #rhel 9 ami id
  instance_type               = "r6i.xlarge"              #add the required instance size here
  root_block_device {
  volume_size = var.solman_os_disk
    encrypted = true
    delete_on_termination = true
    volume_type = "gp3"
    tags = {
        Name = "Solman_os_Disk"
        Created-by  = "Terraform_Automation"
     }
  }
  

#here we are referencing the aws key pair which we have created in keypair.tf config file
key_name              = var.solman_key

vpc_security_group_ids = [aws_security_group.sg_solman.id,aws_security_group.sg_sap-ports.id]
  
#here we are attaching tags to our resources
tags = {
    "Name" = "Solman"
     Created-by  = "Terraform_Automation"
     backup = "prod-bkp"

  }
}

# ----------------------------------------------------------- #
## this creates and attach a elastic public ip to SSL VPN VM
# ----------------------------------------------------------- #
resource "aws_eip" "solam_pubblic_ip" {
  domain = "vpc"
  instance = aws_instance.ec2_solman.id
    tags = {
    Name = "eip_solman"
    Created-by  = "Terraform_Automation"
  }
}

# ----------------------------------------------------------- #
## this creates a data disk EBS volume
# ------------------------------------------------------------ #
resource "aws_ebs_volume" "solman_data_disk" {
  availability_zone = var.aws_availability_zone1
  size = var.solman_data_disk
  encrypted = true
  type = "gp3"

  tags = {
    Name = "Solman_Data_Disk"
    Created-by  = "Terraform_Automation"
  }
}

#this attachs the data disk EBS volume created above to the server
resource "aws_volume_attachment" "solman_data_disk_attach" {
  device_name = "/dev/sdh"
  volume_id   = aws_ebs_volume.solman_data_disk.id
  instance_id = aws_instance.ec2_solman.id
}

# ----------------------------------------------------------- #
#creating security group for Solman VM
# ----------------------------------------------------------- #
# Create Security Group - SSH Traffic
resource "aws_security_group" "sg_solman" {
  vpc_id      = aws_vpc.vpc-go.id
  name        = "sg_solman"
  description = "VM SSH"
 
 # inbound ssh port
  ingress {
    description = "Allow Port 22"
    from_port   = 22
    to_port     = 22
    protocol    = "tcp"
    cidr_blocks = ["10.10.8.224/27","192.168.0.0/24","192.168.2.0/24","192.168.1.0/24","192.168.10.0/24","172.16.28.118/32","13.200.248.213/32","172.16.28.0/22"]
  }
   ingress {
    description = "Allow Port 5902"
    from_port   = 5900
    to_port     = 5902
    protocol    = "tcp"
    cidr_blocks = ["10.10.8.224/27","192.168.0.0/24","192.168.2.0/24","192.168.1.0/24","192.168.10.0/24","172.16.28.118/32","13.200.248.213/32"]
  }
  ingress {
    description = "Allow Port 8000-8100 "
    from_port   = 8000
    to_port     = 8100
    protocol    = "tcp"
    cidr_blocks = ["172.16.28.0/22"]
  }

  ingress {
    description = "Allow Port 3000-3700 "
    from_port   = 3000
    to_port     = 3700
    protocol    = "tcp"
    cidr_blocks = ["0.0.0.0/0"]
  }

  ingress {
    description = "Allow Port ICMP"
    from_port   = -1
    to_port     = -1
    protocol    = "icmp"
    cidr_blocks = ["0.0.0.0/0"]
  }

  ingress {
    description = "VNC Port 5903 09/06/24"
    from_port   = 5903
    to_port     = 5903
    protocol    = "tcp"
    cidr_blocks = ["192.168.10.0/24","192.168.1.0/24","192.168.0.0/24","192.168.2.0/24"]
  }
   
# outbound port   
 egress {
    description = "Allow all IP and Ports outbound"
    from_port   = 0
    to_port     = 0
    protocol    = "-1"
    cidr_blocks = ["0.0.0.0/0"]
  }

  tags = {
    Name = "sg_solman"
    CreatedThrough = "Terraform Automation"
  }
}

