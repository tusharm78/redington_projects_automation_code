resource "aws_key_pair" "eccprd_key" {
key_name = var.eccprd_key
public_key = tls_private_key.rsa_eccprd.public_key_openssh
}

#key pair which has been created above is encrypted with RSA algorithm 4096 bits, we can change this accroding to requirement 
resource "tls_private_key" "rsa_eccprd" {
algorithm = "RSA"
rsa_bits  = 4096
}

#this creates a file in our working directory and download the aws key pair which we have created above
resource "local_file" "eccprd_key" {
content  = tls_private_key.rsa_eccprd.private_key_pem
filename = var.eccprd_key
depends_on = [aws_key_pair.eccprd_key]
}
