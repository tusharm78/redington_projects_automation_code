# ------------------------------------- #
#creating virtual machine - BWPRD VM
# ------------------------------------- #
resource "aws_instance" "ec2_bwprd" {
  subnet_id                   = aws_subnet.prod_subnet_1a.id
  associate_public_ip_address = false
  ami                         = "ami-05a5bb48beb785bf1"   #rhel 9 ami id
  instance_type               = "r6i.2xlarge"              #add the required instance size here
  root_block_device {
  volume_size = var.bwprd_os_disk
    encrypted = true
    delete_on_termination = true
    volume_type = "gp3"
    tags = {
        Name = "Bwprd_os_Disk"
        Created-by  = "Terraform_Automation"
     }
  }
  

#here we are referencing the aws key pair which we have created in keypair.tf config file
key_name              = var.bwprd_key
depends_on = [aws_key_pair.bwprd_key]

vpc_security_group_ids = [aws_security_group.sg_bwprd.id,aws_security_group.sg_sap-ports.id]
  
#here we are attaching tags to our resources
tags = {
    "Name" = "Bwprd"
     Created-by  = "Terraform_Automation"
     Environment = "Prod"
     backup = "prod-bkp"

  }
}

# ----------------------------------------------------------- #
## this creates a data disk EBS volume
# ------------------------------------------------------------
resource "aws_ebs_volume" "bwprd_data_disk" {
  availability_zone = var.aws_availability_zone1
  size = var.bwprd_data_disk
  encrypted = true
  type = "gp3"

  tags = {
    Name = "Bwprd_Data_Disk"
    Created-by  = "Terraform_Automation"
  }
}

#this attachs the data disk EBS volume created above to the server
resource "aws_volume_attachment" "bwprd_data_disk_attach" {
  device_name = "/dev/sdh"
  volume_id   = aws_ebs_volume.bwprd_data_disk.id
  instance_id = aws_instance.ec2_bwprd.id
}

##############################################################################
##########################Backup disk########################################
##############################################################################

resource "aws_ebs_volume" "bwprd_data_disk2" {
  availability_zone = var.aws_availability_zone1
  size = var.bwprd_data_disk2
  encrypted = true
  type = "st1"

  tags = {
    Name = "Backup_disk"
    Created-by  = "Terraform_Automation"
  }
}

#this attachs the Backup data disk EBS volume created above to the server
resource "aws_volume_attachment" "bwprd_data_disk_attach2" {
  device_name = "/dev/sdl"
  volume_id   = aws_ebs_volume.bwprd_data_disk2.id
  instance_id = aws_instance.ec2_bwprd.id
}



# ----------------------------------------------------------- #
#creating security group for BWPRD VM
# ----------------------------------------------------------- #
# Create Security Group - SSH Traffic
resource "aws_security_group" "sg_bwprd" {
  vpc_id      = aws_vpc.vpc-go.id
  name        = "sg_bwprd"
  description = "VM SSH"
 
 # inbound ssh port
  ingress {
    description = "Allow Port 22"
    from_port   = 22
    to_port     = 22
    protocol    = "tcp"
    cidr_blocks = ["10.10.8.224/27","192.168.0.0/24","192.168.2.0/24","192.168.1.0/24","192.168.10.0/24","172.16.28.118/32","13.200.248.213/32","172.16.28.0/22"]
  }
  ingress {
    description = "Allow Port 5900-5902"
    from_port   = 5900
    to_port     = 5902
    protocol    = "tcp"
    cidr_blocks = ["10.10.8.224/27","192.168.0.0/24","192.168.2.0/24","192.168.1.0/24","192.168.10.0/24","172.16.28.118/32","13.200.248.213/32"]
  }

  ingress {
    description = "Allow Port 3000-3700 "
    from_port   = 3000
    to_port     = 3700
    protocol    = "tcp"
    cidr_blocks = ["0.0.0.0/0"]
  }

  ingress {
    description = "Allow Port 8000-8100 "
    from_port   = 8000
    to_port     = 8100
    protocol    = "tcp"
    cidr_blocks = ["172.16.28.0/22"]
  }

  ingress {
    description = "Allow Port 3200-3299 "
    from_port   = 3200
    to_port     = 3299
    protocol    = "tcp"
    cidr_blocks = ["0.0.0.0/0"]
  }
  
  ingress {
    description = "Allow Port 6000 - 6412 "
    from_port   = 6000
    to_port     = 6412
    protocol    = "tcp"
    cidr_blocks = ["0.0.0.0/0"]
  }
  ingress {
    description = "VNC Port 5903 09/06/24"
    from_port   = 5903
    to_port     = 5903
    protocol    = "tcp"
    cidr_blocks = ["192.168.10.0/24","192.168.1.0/24","192.168.0.0/24","192.168.2.0/24"]
  } 

  #############NFS port#############

   ingress {
    description = "NFS port"
    from_port   = 2049
    to_port     = 2049
    protocol    = "tcp"
    cidr_blocks = ["172.16.28.112/32", "172.16.28.82/32"]
  } 

# outbound port   
 egress {
    description = "Allow all IP and Ports outbound"
    from_port   = 0
    to_port     = 0
    protocol    = "-1"
    cidr_blocks = ["0.0.0.0/0"]
  }

  tags = {
    Name = "sg_bwprd"
    CreatedThrough = "Terraform Automation"
  }
}