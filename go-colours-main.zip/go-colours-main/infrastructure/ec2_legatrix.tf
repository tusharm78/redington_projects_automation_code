# ------------------------------------- #
#creating virtual machine - Legatrix VM
# ------------------------------------- #

resource "aws_instance" "ec2_legatrix" {
  subnet_id                   = aws_subnet.Public-Subnet.id
  associate_public_ip_address = true
  ami                         = "ami-0ba62e9b2fdc3e1ff"   #Windows mssql web ami id here
  instance_type               = "r6i.xlarge"              #add the required instance size here
  iam_instance_profile = "Legtraix_S3andSSM"
  root_block_device {
  volume_size = var.legatrix_os_disk
    encrypted = false
    delete_on_termination = true
    volume_type = "gp3"
    tags = {
        Name = "legatrix_os_Disk"
        Created-by  = "Terraform_Automation"
     }
  }
  

#here we are referencing the aws key pair which we have created in keypair.tf config file
key_name              = var.legatrix_key
depends_on = [aws_key_pair.legatrix_key]

vpc_security_group_ids = [aws_security_group.sg_legatrix.id]
  
#here we are attaching tags to our resources
tags = {
    "Name" = "legatrix"
     Created-by  = "Terraform_Automation"
     backup = "prod-bkp"
   
  }
  
}

# ----------------------------------------------------------- #
## this creates and attach a elastic public ip to legatrix VM
# ----------------------------------------------------------- #
resource "aws_eip" "legatrix_public_ip" {
  domain = "vpc"
  instance = aws_instance.ec2_legatrix.id
    tags = {
    Name = "eip_legatrix"
    Created-by  = "Terraform_Automation"
  }
}
# ----------------------------------------------------------- #
## this creates a data disk EBS volume
# ------------------------------------------------------------
resource "aws_ebs_volume" "legatrix_data_disk_1" {
  availability_zone = var.aws_availability_zone1
  size = var.legatrix_data_disk_1
  encrypted = true
  type = "gp3"

  tags = {
    Name = "legatrix_Data_Disk_1"
    Created-by  = "Terraform_Automation"
  }
}

resource "aws_ebs_volume" "legatrix_data_disk_2" {
  availability_zone = var.aws_availability_zone1
  size = var.legatrix_data_disk_2
  encrypted = true
  type = "st1"

  tags = {
    Name = "legatrix_data_disk_2"
    Created-by  = "Terraform_Automation"
  }
}


#this attachs the data disk EBS volume created above to the server
resource "aws_volume_attachment" "legatrix_data_disk_attach_1" {
  device_name = "/dev/sdg"
  volume_id   = aws_ebs_volume.legatrix_data_disk_1.id
  instance_id = aws_instance.ec2_legatrix.id
}

#this attachs the data disk EBS volume created above to the server
resource "aws_volume_attachment" "legatrix_data_disk_attach_2" {
  device_name = "/dev/sdf"
  volume_id   = aws_ebs_volume.legatrix_data_disk_2.id
  instance_id = aws_instance.ec2_legatrix.id
}



# ----------------------------------------------------------- #
#creating security group for legatrix VM
# ----------------------------------------------------------- #
# Create Security Group - SSH Traffic
resource "aws_security_group" "sg_legatrix" {
  vpc_id      = aws_vpc.vpc-go.id
  name        = "sg_legatrix"
  description = "VM RDP"
 
 # inbound ssh port
  ingress {
    description = "Allow Port 3389"
    from_port   = 3389
    to_port     = 3389
    protocol    = "tcp"
    cidr_blocks = ["10.10.8.224/27","192.168.0.0/24","192.168.2.0/24","192.168.1.0/24","192.168.10.0/24","172.16.28.118/32","13.200.248.213/32","172.16.28.0/22"]
  }
   
 ingress {
    description = "Allow Port 8085"
    from_port   = 8085
    to_port     = 8085
    protocol    = "tcp"
    cidr_blocks = ["0.0.0.0/0"]
  }


# outbound port   
 egress {
    description = "Allow all IP and Ports outbound"
    from_port   = 0
    to_port     = 0
    protocol    = "-1"
    cidr_blocks = ["0.0.0.0/0"]
  }

  tags = {
    Name = "sg_legatrix"
    CreatedThrough = "Terraform Automation"
  }
}