# ------------------------------------- #
#creating virtual machine - PODEV VM - NEW
# ------------------------------------- #
resource "aws_instance" "ec2_podev_new" {
  subnet_id                   = aws_subnet.dev_subnet_1a.id
  associate_public_ip_address = false
  ami                         = "ami-022ce6f32988af5fa" #"ami-0a2c4abaac9aa281a"   #rhel 8.8 ami id
  instance_type               = "r6a.xlarge"              #add the required instance size here
  private_ip = "172.16.28.250"
  iam_instance_profile = "ec2_ssm_role"
  root_block_device {
  volume_size = var.podev_os_disk_new
    encrypted = false
    delete_on_termination = true
    volume_type = "gp3"
    tags = {
        Name = "Podev_os_Disk_new"
        Created-by  = "Terraform_Automation"
     }
  }
  

#here we are referencing the aws key pair which we have created in keypair.tf config file
key_name              = var.podev_key_new
depends_on = [aws_key_pair.podev_key_new]

vpc_security_group_ids = [aws_security_group.sg_podev-new.id,aws_security_group.sg_sap-ports.id]
  
#here we are attaching tags to our resources
tags = {
    "Name" = "Podev-new"
     Created-by  = "Terraform_Automation"
  }
}

# ----------------------------------------------------------- #
## this creates a data disk EBS volume
# ------------------------------------------------------------
resource "aws_ebs_volume" "podev_data_disk_new" {
  availability_zone = var.aws_availability_zone1
  size = var.podev_data_disk_new
  encrypted = true
  type = "gp3"

  tags = {
    Name = "Podev_Data_Disk"
    Created-by  = "Terraform_Automation"
  }
}

#this attachs the data disk EBS volume created above to the server
resource "aws_volume_attachment" "podev_data_disk_attach-new" {
  device_name = "/dev/sdd"
  volume_id   = aws_ebs_volume.podev_data_disk_new.id
  instance_id = aws_instance.ec2_podev_new.id
}


# ----------------------------------------------------------- #
#creating security group for PODEV VM
# ----------------------------------------------------------- #
# Create Security Group - SSH Traffic
resource "aws_security_group" "sg_podev-new" {
  vpc_id      = aws_vpc.vpc-go.id
  name        = "sg_podev-new"
  description = "VM SSH"
 
 # inbound ssh port
  ingress {
    description = "Allow Port 22"
    from_port   = 22
    to_port     = 22
    protocol    = "tcp"
    cidr_blocks = ["10.10.8.224/27","192.168.0.0/24","192.168.2.0/24","192.168.1.0/24","192.168.10.0/24","172.16.28.118/32","13.200.248.213/32","172.16.28.0/22"]
  }
  ingress {
    description = "Allow Port 5902"
    from_port   = 5900
    to_port     = 5902
    protocol    = "tcp"
    cidr_blocks = ["10.10.8.224/27","192.168.0.0/24","192.168.2.0/24","192.168.1.0/24","192.168.10.0/24","172.16.28.118/32","13.200.248.213/32"]
  }
  ingress {
    description = "Allow Port 5902"
    from_port   = 50000
    to_port     = 50000
    protocol    = "tcp"
    cidr_blocks = ["0.0.0.0/0"]
  }
    ingress {
    description = "Allow Port 3200-3399"
    from_port   = 3200
    to_port     = 3399
    protocol    = "tcp"
    cidr_blocks = ["0.0.0.0/0"]
  }

   ingress {
    description = "Allow Port 4800-5000"
    from_port   = 4800
    to_port     = 5000
    protocol    = "tcp"
    cidr_blocks = ["172.16.28.0/22"]
  }
  ingress {
    description = "Allow Port 32768 - 65535"
    from_port   = 32768
    to_port     = 65535
    protocol    = "tcp"
    cidr_blocks = ["172.16.28.0/22"]
  }
  ingress {
    description = "Allow Port 3600-3700"
    from_port   = 3600 
    to_port     = 3700
    protocol    = "tcp"
    cidr_blocks = ["172.16.28.0/22","172.16.28.82/32"]
  }
  
  ingress {
    description = "Allow Port 8000-8200"
    from_port   = 8000
    to_port     = 8200
    protocol    = "tcp"
    cidr_blocks = ["0.0.0.0/0"]
  }
  ingress {
    description = "Allow Port 44300 - 44399"
    from_port   = 44300
    to_port     = 44399
    protocol    = "tcp"
    cidr_blocks = ["172.16.28.0/22"]
  }

  ingress {
    description = "Allow Port 50000 - 51000"
    from_port   = 50000
    to_port     = 51000
    protocol    = "tcp"
    cidr_blocks = ["0.0.0.0/0"]
  }
  ingress {
    description = "Allow Port 21443"
    from_port   = 21443
    to_port     = 21443
    protocol    = "tcp"
    cidr_blocks = ["172.16.29.173/32"]    #wsdb
  }
  ingress {
    description = "Allow Port 8000-8100 "
    from_port   = 8000
    to_port     = 8100
    protocol    = "tcp"
    cidr_blocks = ["172.16.28.0/22","172.16.28.82/32"]
  }
  ingress {
    description = "Allow Port icmp"
    from_port   = 0
    to_port     = 0
    protocol    = "icmp"
    cidr_blocks = ["0.0.0.0/0"]
  }

  ingress {
    description = "VNC Port 5903 09/06/24"
    from_port   = 5903
    to_port     = 5903
    protocol    = "tcp"
    cidr_blocks = ["192.168.10.0/24","192.168.1.0/24","192.168.0.0/24","192.168.2.0/24"]
  }

   ingress {
    description = "eccdev_ec2"
    from_port   = 50000
    to_port     = 50000
    protocol    = "tcp"
    cidr_blocks = ["172.16.28.189/32"]
  }
 ingress {
    description = "MYSQL"
    from_port   = 3306
    to_port     = 3306
    protocol    = "tcp"
    cidr_blocks = ["152.52.93.77/32"]
  }
   ingress {
    description = "MSSQL"
    from_port   = 1433
    to_port     = 1433
    protocol    = "tcp"
    cidr_blocks = ["182.74.134.90/32"]
  }

# outbound port   
 egress {
    description = "Allow all IP and Ports outbound"
    from_port   = 0
    to_port     = 0
    protocol    = "-1"
    cidr_blocks = ["0.0.0.0/0"]
  }

  tags = {
    Name = "sg_podev"
    CreatedThrough = "Terraform Automation"
  }
}
