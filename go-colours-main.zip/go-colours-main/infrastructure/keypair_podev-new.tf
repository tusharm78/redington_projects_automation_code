resource "aws_key_pair" "podev_key_new" {
key_name = var.podev_key_new
public_key = tls_private_key.rsa_podev_new.public_key_openssh
}

#key pair which has been created above is encrypted with RSA algorithm 4096 bits, we can change this accroding to requirement 
resource "tls_private_key" "rsa_podev_new" {
algorithm = "RSA"
rsa_bits  = 4096
}

#this creates a file in our working directory and download the aws key pair which we have created above
resource "local_file" "podev_key_new" {
content  = tls_private_key.rsa_podev_new.private_key_pem
filename = var.podev_key_new
depends_on = [aws_key_pair.podev_key_new]
}