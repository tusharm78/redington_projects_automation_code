# ------------------------------------- #
#creating virtual machine - BOPRD VM
# ------------------------------------- #
resource "aws_instance" "ec2_boprd" {
  subnet_id                   = aws_subnet.Public-Subnet.id
  associate_public_ip_address = true
  ami                         = "ami-0ca1515fd7ca0203d"   #rhel 9 ami id
  instance_type               = "r6i.xlarge"              #add the required instance size here
  root_block_device {
  volume_size = var.boprd_os_disk
    encrypted = true
    delete_on_termination = true
    volume_type = "gp3"
    tags = {
        Name = "Boprd_os_Disk"
        Created-by  = "Terraform_Automation"
     }
  }
  

#here we are referencing the aws key pair which we have created in keypair.tf config file
key_name              = var.boprd_key
depends_on = [aws_key_pair.boprd_key]

vpc_security_group_ids = [aws_security_group.sg_boprd.id,aws_security_group.sg_sap-ports.id]
  
#here we are attaching tags to our resources
tags = {
    "Name" = "Boprd"
     Created-by  = "Terraform_Automation"
     Environment = "Prod"
     backup = "prod-bkp"

  }
}

# ----------------------------------------------------------- #
## this creates and attach a elastic public ip to BOPRD VM
# ----------------------------------------------------------- #
resource "aws_eip" "boprd_public_ip" {
  domain = "vpc"
  instance = aws_instance.ec2_boprd.id
    tags = {
    Name = "eip_boprd"
    Created-by  = "Terraform_Automation"
  }
}
# ----------------------------------------------------------- #
## this creates a data disk EBS volume
# ------------------------------------------------------------
resource "aws_ebs_volume" "boprd_data_disk" {
  availability_zone = var.aws_availability_zone1
  size = var.boprd_data_disk
  encrypted = true
  type = "gp3"

  tags = {
    Name = "Boprd_Data_Disk"
    Created-by  = "Terraform_Automation"
  }
}

#this attachs the data disk EBS volume created above to the server
resource "aws_volume_attachment" "boprd_data_disk_attach" {
  device_name = "/dev/sdh"
  volume_id   = aws_ebs_volume.boprd_data_disk.id
  instance_id = aws_instance.ec2_boprd.id
}

# ----------------------------------------------------------- #
#creating security group for BOPRD VM
# ----------------------------------------------------------- #
# Create Security Group - SSH Traffic
resource "aws_security_group" "sg_boprd" {
  vpc_id      = aws_vpc.vpc-go.id
  name        = "sg_boprd"
  description = "VM SSH"
 
 # inbound ssh port
  ingress {
    description = "Allow Port 22"
    from_port   = 22
    to_port     = 22
    protocol    = "tcp"
    cidr_blocks = ["10.10.8.224/27","192.168.0.0/24","192.168.2.0/24","192.168.1.0/24","192.168.10.0/24","172.16.28.118/32","13.200.248.213/32","172.16.28.0/22"]
  }
  ingress {
    description = "Allow Port 5900-5902"
    from_port   = 5900
    to_port     = 5902
    protocol    = "tcp"
    cidr_blocks = ["10.10.8.224/27","192.168.0.0/24","192.168.2.0/24","192.168.1.0/24","192.168.10.0/24","172.16.28.118/32","13.200.248.213/32"]
  }
  ingress {
    description = "Allow Port 8080"
    from_port   = 8080
    to_port     = 8080
    protocol    = "tcp"
    cidr_blocks = ["0.0.0.0/0"]
  }
  ingress {
    description = "Allow Port icmp"
    from_port   = 0
    to_port     = 0
    protocol    = "icmp"
    cidr_blocks = ["0.0.0.0/0"]
  }
  ingress {
    description = "Allow Port 3200"
    from_port   = 3200
    to_port     = 3200
    protocol    = "tcp"
    cidr_blocks = ["0.0.0.0/0"]
  } 

  ingress {
    description = "Allow Port 3300"
    from_port   = 3300
    to_port     = 3300
    protocol    = "tcp"
    cidr_blocks = ["0.0.0.0/0"]
  }
  ingress {
    description = "Allow Port 6001"
    from_port   = 6001
    to_port     = 6001
    protocol    = "tcp"
    cidr_blocks = ["0.0.0.0/0"]
  }
  ingress {
    description = "Allow Port 6400-6404"
    from_port   = 6400
    to_port     = 6404
    protocol    = "tcp"
    cidr_blocks = ["0.0.0.0/0"]
  }
  ingress {
    description = "Allow Port 6406-6409"
    from_port   = 6406
    to_port     = 6409
    protocol    = "tcp"
    cidr_blocks = ["0.0.0.0/0"]
  }
  
  ingress {
    description = "Allow Port 6411-6412"
    from_port   = 6411
    to_port     = 6412
    protocol    = "tcp"
    cidr_blocks = ["0.0.0.0/0"]
  }

  ingress {
    description = "VNC Port 5903 09/06/24"
    from_port   = 5903
    to_port     = 5903
    protocol    = "tcp"
    cidr_blocks = ["192.168.10.0/24","192.168.1.0/24","192.168.0.0/24","192.168.2.0/24"]
  }

# outbound port   
 egress {
    description = "Allow all IP and Ports outbound"
    from_port   = 0
    to_port     = 0
    protocol    = "-1"
    cidr_blocks = ["0.0.0.0/0"]
  }

  tags = {
    Name = "sg_boprd"
    CreatedThrough = "Terraform Automation"
  }
}