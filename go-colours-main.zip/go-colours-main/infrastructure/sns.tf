resource "aws_sns_topic" "snstopicforlambda" {
  name = "go-color"
  display_name = "Go-Colors-EC2_status-Alert"
}
resource "aws_sns_topic_policy" "sns-target-policy" {
  arn    = aws_sns_topic.snstopicforlambda.arn
  policy = data.aws_iam_policy_document.events_to_sns_topic_policy.json
}

data "aws_iam_policy_document" "events_to_sns_topic_policy" {
  statement {
    effect  = "Allow"
    actions = ["SNS:Publish"]

    principals {
      type        = "Service"
      identifiers = ["events.amazonaws.com"]
    }

    resources = [aws_sns_topic.snstopicforlambda.arn]
  }
}
resource "aws_sns_topic_subscription" "snsmailconfirmation_1" {
  topic_arn = aws_sns_topic.snstopicforlambda.id
  protocol  = "email"
  endpoint  = "devanand@gocolors.com" 
}
resource "aws_sns_topic_subscription" "snsmailconfirmation_2" {
  topic_arn = aws_sns_topic.snstopicforlambda.id
  protocol  = "email"
  endpoint  = "aws.support.ril@redingtongroup.com" 
}
