######################Start Mon-Fri#############################

resource "aws_cloudwatch_event_rule" "lambda_rule_1"{
  name = "startscheduleec2"
  schedule_expression = "cron(3 2 ? * MON-FRI *)"
  description = "Alert rule for instance not started as per schedule MON-FRI"
}


resource "aws_cloudwatch_event_target" "status_check_target_1" {
  rule = aws_cloudwatch_event_rule.lambda_rule_1.name
  arn  = aws_lambda_function.ec2_status_alert_1.arn
}

resource "aws_lambda_permission" "lambda_cloudwatch_1" {
  statement_id  = "AllowExecutionFromCloudWatch"
  action        = "lambda:InvokeFunction"
  function_name = aws_lambda_function.ec2_status_alert_1.function_name
  principal     = "events.amazonaws.com"
  source_arn    = aws_cloudwatch_event_rule.lambda_rule_1.arn
}


#############################Start-Sat-1st###################
resource "aws_cloudwatch_event_rule" "lambda_rule_1_1"{
  name = "startscheduleec2-Sat-1st"
  schedule_expression = "cron(18 3 ? * 7#1 *)"
  description = "Alert rule for instance not started as per schedule 1st Sat"
}


resource "aws_cloudwatch_event_target" "status_check_target_1_1" {
  rule = aws_cloudwatch_event_rule.lambda_rule_1_1.name
  arn  = aws_lambda_function.ec2_status_alert_1.arn
}

resource "aws_lambda_permission" "lambda_cloudwatch_1_1" {
  statement_id  = "AllowExecutionFromCloudWatch_1_1"
  action        = "lambda:InvokeFunction"
  function_name = aws_lambda_function.ec2_status_alert_1.function_name
  principal     = "events.amazonaws.com"
  source_arn    = aws_cloudwatch_event_rule.lambda_rule_1_1.arn
}


########################Start-Sat-3rd#######################

resource "aws_cloudwatch_event_rule" "lambda_rule_1_3"{
  name = "startscheduleec2-Sat-3rd"
  schedule_expression = "cron(18 3 ? * 7#3 *)"
  description = "Alert rule for instance not started as per schedule 3rd Sat"
}


resource "aws_cloudwatch_event_target" "status_check_target_1_3" {
  rule = aws_cloudwatch_event_rule.lambda_rule_1_3.name
  arn  = aws_lambda_function.ec2_status_alert_1.arn
}

resource "aws_lambda_permission" "lambda_cloudwatch_1_3" {
  statement_id  = "AllowExecutionFromCloudWatch_1_3"
  action        = "lambda:InvokeFunction"
  function_name = aws_lambda_function.ec2_status_alert_1.function_name
  principal     = "events.amazonaws.com"
  source_arn    = aws_cloudwatch_event_rule.lambda_rule_1_3.arn
}

########################Start-Sat-5th#########################

resource "aws_cloudwatch_event_rule" "lambda_rule_1_5"{
  name = "startscheduleec2-Sat-5th"
  schedule_expression = "cron(18 3 ? * 7#5 *)"
  description = "Alert rule for instance not started as per schedule 5th Sat"
}


resource "aws_cloudwatch_event_target" "status_check_target_5" {
  rule = aws_cloudwatch_event_rule.lambda_rule_1_5.name
  arn  = aws_lambda_function.ec2_status_alert_1.arn
}

resource "aws_lambda_permission" "lambda_cloudwatch_5" {
  statement_id  = "AllowExecutionFromCloudWatch_1_5"
  action        = "lambda:InvokeFunction"
  function_name = aws_lambda_function.ec2_status_alert_1.function_name
  principal     = "events.amazonaws.com"
  source_arn    = aws_cloudwatch_event_rule.lambda_rule_1_5.arn
}



############################stop############################

resource "aws_cloudwatch_event_rule" "lambda_rule_2" {
  name = "stopscheduleec2"
  schedule_expression = "cron(33 13 ? * MON-FRI *)"
  description = "Alert rule for instance not stopped as per schedule Mon-FRI"
}


resource "aws_cloudwatch_event_target" "status_check_target_2" {
  rule = aws_cloudwatch_event_rule.lambda_rule_2.name
  arn  = aws_lambda_function.ec2_status_alert_2.arn
}

resource "aws_lambda_permission" "lambda_cloudwatch_2" {
  statement_id  = "AllowExecutionFromCloudWatch"
  action        = "lambda:InvokeFunction"
  function_name = aws_lambda_function.ec2_status_alert_2.function_name
  principal     = "events.amazonaws.com"
  source_arn    = aws_cloudwatch_event_rule.lambda_rule_2.arn
}




############################Stop_Sat_1st############################

resource "aws_cloudwatch_event_rule" "lambda_rule_2_1" {
  name = "stopscheduleec2-Sat-1st"
  schedule_expression = "cron(33 13 ? * 7#1 *)"
  description = "Alert rule for instance not stopped as per schedule 1st Sat"
}


resource "aws_cloudwatch_event_target" "status_check_target_2_1" {
  rule = aws_cloudwatch_event_rule.lambda_rule_2_1.name
  arn  = aws_lambda_function.ec2_status_alert_2.arn
}

resource "aws_lambda_permission" "lambda_cloudwatch_2_1" {
  statement_id  = "AllowExecutionFromCloudWatch_1_1"
  action        = "lambda:InvokeFunction"
  function_name = aws_lambda_function.ec2_status_alert_2.function_name
  principal     = "events.amazonaws.com"
  source_arn    = aws_cloudwatch_event_rule.lambda_rule_2_1.arn
}


############################Stop_Sat_3rd############################

resource "aws_cloudwatch_event_rule" "lambda_rule_2_3" {
  name = "stopscheduleec2-Sat-3rd"
  schedule_expression = "cron(33 13 ? * 7#3 *)"
  description = "Alert rule for instance not stopped as per schedule 3rd Sat"
}


resource "aws_cloudwatch_event_target" "status_check_target_2_3" {
  rule = aws_cloudwatch_event_rule.lambda_rule_2_3.name
  arn  = aws_lambda_function.ec2_status_alert_2.arn
}

resource "aws_lambda_permission" "lambda_cloudwatch_2_3" {
  statement_id  = "AllowExecutionFromCloudWatch_1_3"
  action        = "lambda:InvokeFunction"
  function_name = aws_lambda_function.ec2_status_alert_2.function_name
  principal     = "events.amazonaws.com"
  source_arn    = aws_cloudwatch_event_rule.lambda_rule_2_3.arn
}

############################Stop_Sat_5th############################

resource "aws_cloudwatch_event_rule" "lambda_rule_2_5" {
  name = "stopscheduleec2-Sat-5th"
  schedule_expression = "cron(33 13 ? * 7#5 *)"
  description = "Alert rule for instance not stopped as per schedule 5th Sat"
}


resource "aws_cloudwatch_event_target" "status_check_target_2_5" {
  rule = aws_cloudwatch_event_rule.lambda_rule_2_5.name
  arn  = aws_lambda_function.ec2_status_alert_2.arn
}

resource "aws_lambda_permission" "lambda_cloudwatch_2_5" {
  statement_id  = "AllowExecutionFromCloudWatch_1_5"
  action        = "lambda:InvokeFunction"
  function_name = aws_lambda_function.ec2_status_alert_2.function_name
  principal     = "events.amazonaws.com"
  source_arn    = aws_cloudwatch_event_rule.lambda_rule_2_5.arn
}