# ----------------------------------------------------------- #
#creating security group for SAP PORTS
# ----------------------------------------------------------- #
# Create Security Group
resource "aws_security_group" "sg_sap-ports" {
  vpc_id      = aws_vpc.vpc-go.id
  name        = "sg_sap-ports"
  description = "SAP Ports"
 
 # inbound sap port
  ingress {
    description = "Allow Port icmp"
    from_port   = 0
    to_port     = 0
    protocol    = "icmp"
    cidr_blocks = ["0.0.0.0/0"]
  }
  ingress {
    description = "Allow Port 3200"
    from_port   = 3200
    to_port     = 3200
    protocol    = "tcp"
    cidr_blocks = ["0.0.0.0/0"]
  } 

  ingress {
    description = "Allow Port 3299"
    from_port   = 3299
    to_port     = 3299
    protocol    = "tcp"
    cidr_blocks = ["0.0.0.0/0"]
  }  

  ingress {
    description = "Allow Port 8000-8100 "
    from_port   = 8000
    to_port     = 8100
    protocol    = "tcp"
    cidr_blocks = ["172.16.28.0/22"]
  }

  ingress {
    description = "Allow Port 3000-3700"
    from_port   = 3000
    to_port     = 3700
    protocol    = "tcp"
    cidr_blocks = ["0.0.0.0/0"]
  }
  ingress {
    description = "Allow port 3300-3301"
    from_port   = 3300
    to_port     = 3301
    protocol    = "tcp"
    cidr_blocks = ["0.0.0.0/0"]
  }
   ingress {
    description = "Allow port 3300-3301"
    from_port   = 3300
    to_port     = 3301
    protocol    = "tcp"
    cidr_blocks = ["172.16.28.250/32"]
  }
   ingress {
    description = "Allow port 8000-8001"
    from_port   = 8000
    to_port     = 8001
    protocol    = "tcp"
    cidr_blocks = ["172.16.28.250/32"]
  }

ingress {
    description = "Allow port 3600-3601"
    from_port   = 3600
    to_port     = 3601
    protocol    = "tcp"
    cidr_blocks = ["0.0.0.0/0"]
  }

  ingress {
    description = "Allow port 8101-8110"
    from_port   = 8101
    to_port     = 8110
    protocol    = "tcp"
    cidr_blocks = ["0.0.0.0/0"]
  }
 ingress {
    description = "Port_3300"
    from_port   = 3300
    to_port     = 3300
    protocol    = "tcp"
    cidr_blocks = ["172.16.28.82/32"]
  }

  ingress {
    description = "Port_3300"
    from_port   = 3300
    to_port     = 3300
    protocol    = "tcp"
    cidr_blocks = ["172.16.28.82/32"]
  }

  ingress {
    description = "Port_3301"
    from_port   = 3301
    to_port     = 3301
    protocol    = "tcp"
    cidr_blocks = ["172.16.28.82/32"]
  }

  ingress {
    description = "Port_3601"
    from_port   = 3601
    to_port     = 3601
    protocol    = "tcp"
    cidr_blocks = ["172.16.28.82/32"]
  }

  ingress {
    description = "Port_50000"
    from_port   = 50000
    to_port     = 50000
    protocol    = "tcp"
    cidr_blocks = ["172.16.28.82/32"]
  }
  
# outbound port   
 egress {
    description = "Allow all IP and Ports outbound"
    from_port   = 0
    to_port     = 0
    protocol    = "-1"
    cidr_blocks = ["0.0.0.0/0"]
  }

  tags = {
    Name = "sg_sap-ports"
    CreatedThrough = "Terraform Automation"
  }
}