# ------------------------------------- #
#creating virtual machine - POPRD_new VM
# ------------------------------------- #

resource "aws_instance" "ec2_poprd_new1" {
  subnet_id                   = aws_subnet.Public-Subnet.id
  associate_public_ip_address = true
  ami                         = "ami-05e7e472455ddb0cd"   #rhel 9 ami id here
  instance_type               = "r6i.xlarge"     
  private_ip                  = "172.16.28.85"            #add the required instance size here
  iam_instance_profile = "ec2_ssm_role"
  root_block_device {
  volume_size = var.poprd_new1_os_disk
    encrypted = false
    delete_on_termination = true
    volume_type = "gp3"
    tags = {
        Name = "Poprd_new1_os_Disk"
        Created-by  = "Terraform_Automation"
        
     }
  }
  

#here we are referencing the aws key pair which we have created in keypair.tf config file
key_name              = var.poprd_new12_key
depends_on = [aws_key_pair.poprd_new1_key]

vpc_security_group_ids = [aws_security_group.sg_poprd_new1.id]
  
#here we are attaching tags to our resources
tags = {
    "Name" = "Poprd_new1"
     Created-by  = "Terraform_Automation"
     backup = "prod-bkp"
  }
}



#
# ----------------------------------------------------------- #
## this creates and attach a elastic public ip to Poprd_new VM
# ----------------------------------------------------------- #
resource "aws_eip" "poprd_new1_public_ip" {
  domain = "vpc"
  instance = aws_instance.ec2_poprd_new1.id
    tags = {
    Name = "eip_poprd_new1"
    Created-by  = "Terraform_Automation"
  }
}
# ----------------------------------------------------------- #
## this creates a data disk EBS volume
# ------------------------------------------------------------
resource "aws_ebs_volume" "poprd_new1_data_disk" {
  availability_zone = var.aws_availability_zone1
  size = var.poprd_new1_data_disk
  encrypted = true
  type = "gp3"

  tags = {
    Name = "Poprd_new1_Data_Disk"
    Created-by  = "Terraform_Automation"
  }
}


#this attachs the data disk EBS volume created above to the server
resource "aws_volume_attachment" "poprd_new1_data_disk_attach" {
  device_name = "/dev/sdf"
  volume_id   = aws_ebs_volume.poprd_new1_data_disk.id
  instance_id = aws_instance.ec2_poprd_new1.id
}

# ----------------------------------------------------------- #
#creating security group for POPRD VM
# ----------------------------------------------------------- #
# Create Security Group - SSH Traffic
resource "aws_security_group" "sg_poprd_new1" {
  vpc_id      = aws_vpc.vpc-go.id
  name        = "sg_poprd_new1"
  description = "VM SSH"
 
 # inbound ssh port
  ingress {
    description = "Allow Port 22"
    from_port   = 22
    to_port     = 22
    protocol    = "tcp"
    cidr_blocks = ["10.10.8.224/27","192.168.0.0/24","192.168.2.0/24","192.168.1.0/24","192.168.10.0/24","172.16.28.118/32","13.200.248.213/32","172.16.28.0/22"]
  }
  ingress {
    description = "Allow Port 5900-5902"
    from_port   = 5900
    to_port     = 5902
    protocol    = "tcp"
    cidr_blocks = ["10.10.8.224/27","192.168.0.0/24","192.168.2.0/24","192.168.1.0/24","192.168.10.0/24","172.16.28.118/32","13.200.248.213/32"]
  }
  ingress {
    description = "Allow Port 5902"
    from_port   = 50000
    to_port     = 50000
    protocol    = "tcp"
    cidr_blocks = ["0.0.0.0/0"]
  }
  ingress {
    description = "Allow Port 8080"
    from_port   = 8080
    to_port     = 8080
    protocol    = "tcp"
    cidr_blocks = ["0.0.0.0/0"]
  }

  ingress {
    description = "Allow Port 21443"
    from_port   = 21443
    to_port     = 21443
    protocol    = "tcp"
    cidr_blocks = ["172.16.29.173/32"]    #wsdb
  }

  ingress {
    description = "Allow Port 50000-51000"
    from_port   = 50000
    to_port     = 51000
    protocol    = "tcp"
    cidr_blocks = ["172.16.28.0/22"]
  }
  ingress {
    description = "Allow Port 8000-8200"
    from_port   = 8000
    to_port     = 8200
    protocol    = "tcp"
    cidr_blocks = ["172.16.28.112/32"]
  }

ingress {
    description = "Allow Port 3200-3299"
    from_port   = 3200
    to_port     = 3299
    protocol    = "tcp"
    cidr_blocks = ["172.16.28.0/22"]
  }

  ingress {
    description = "Allow Port 3200-3399"
    from_port   = 3200
    to_port     = 3399
    protocol    = "tcp"
    cidr_blocks = ["172.16.28.112/32","172.16.29.173/32","172.16.28.249/32","152.52.93.77/32"]
  }

   ingress {
    description = "Allow Port 4800-5000"
    from_port   = 4800
    to_port     = 5000
    protocol    = "tcp"
    cidr_blocks = ["172.16.28.112/32","172.16.29.173/32"]
  }
  ingress {
    description = "Allow Port 32768 - 65535"
    from_port   = 32768
    to_port     = 65535
    protocol    = "tcp"
    cidr_blocks = ["172.16.28.112/32","172.16.29.173/32"]
  }
  ingress {
    description = "Allow Port 3600-3700"
    from_port   = 3600 
    to_port     = 3700
    protocol    = "tcp"
    cidr_blocks = ["172.16.28.112/32","172.16.29.173/32","172.16.28.249/32"]
  }
  

  ingress {
    description = "Allow Port 8000-8200"
    from_port   = 8000
    to_port     = 8200
    protocol    = "tcp"
    cidr_blocks = ["172.16.28.112/32","172.16.29.173/32","172.16.28.249/32"]
  }
  ingress {
    description = "Allow Port 44300 - 44399"
    from_port   = 44300
    to_port     = 44399
    protocol    = "tcp"
    cidr_blocks = ["172.16.28.112/32","172.16.29.173/32"]
  }

  ingress {
    description = "Allow Port 50000 - 51000"
    from_port   = 50000
    to_port     = 51000
    protocol    = "tcp"
    cidr_blocks = ["172.16.28.112/32","172.16.29.173/32"]
  }
  ingress {
    description = "Allow Port 8000-8100 "
    from_port   = 8000
    to_port     = 8100
    protocol    = "tcp"
    cidr_blocks = ["172.16.28.0/22"]
  }

  ingress {
    description = "Allow Port icmp"
    from_port   = 0
    to_port     = 0
    protocol    = "icmp"
    cidr_blocks = ["0.0.0.0/0"]
  }
   ingress {
    description = "VNC Port 5903 09/06/24"
    from_port   = 5903
    to_port     = 5903
    protocol    = "tcp"
    cidr_blocks = ["192.168.10.0/24","192.168.1.0/24","192.168.0.0/24","192.168.2.0/24"]
  }
   ingress {
    description = "Port_3300"
    from_port   = 3300
    to_port     = 3300
    protocol    = "tcp"
    cidr_blocks = ["172.16.28.250/32"]
  }
    ingress {
    description = "Port_3301"
    from_port   = 3301
    to_port     = 3301
    protocol    = "tcp"
    cidr_blocks = ["172.16.28.250/32"]
  }

  ingress {
    description = "Port_3601"
    from_port   = 3601
    to_port     = 3601
    protocol    = "tcp"
    cidr_blocks = ["172.16.28.250/32"]
  }

   ingress {
    description = "Port_50000"
    from_port   = 50000
    to_port     = 50000
    protocol    = "tcp"
    cidr_blocks = ["172.16.28.250/32"]
  }
    ingress {
    description = "sql-port"
    from_port   = 1433
    to_port     = 1433
    protocol    = "tcp"
    cidr_blocks = ["14.98.43.234/32"]
  }
    ingress {
    description = "sql-port-1"
    from_port   = 3306
    to_port     = 3306
    protocol    = "tcp"
    cidr_blocks = ["152.52.93.77/32"]
  }
    ingress {
    description = "Port_8101"
    from_port   = 8101
    to_port     = 8101
    protocol    = "tcp"
    cidr_blocks = ["172.16.0.0/16"]
  }
  ingress {
    description = "Allow Port 8000-8200"
    from_port   = 8000
    to_port     = 8200
    protocol    = "tcp"
    cidr_blocks = ["172.16.28.112/32"]
  }

# outbound port   
 egress {
    description = "Allow all IP and Ports outbound"
    from_port   = 0
    to_port     = 0
    protocol    = "-1"
    cidr_blocks = ["0.0.0.0/0"]
  }

  tags = {
    Name = "sg_poprd"
    CreatedThrough = "Terraform Automation"
  }
}