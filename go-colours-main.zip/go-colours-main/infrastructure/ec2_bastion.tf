# ------------------------------------- #
#creating ec2 vm - bastion host
# ------------------------------------- #
resource "aws_instance" "ec2_bastion" {
  subnet_id                   = aws_subnet.Public-Subnet.id
  associate_public_ip_address = true
  ami                         = "ami-06b72b3b2a773be2b"  #amazon linux 2023 ami - add the required ami
  instance_type               = "t3.small"        #add the required instance size here
  root_block_device {
  volume_size = var.bastion_os_disk
    encrypted = true
    delete_on_termination = true
    volume_type = "gp3"   
    tags = {
      Name = "bastion_os_disk"
      CreatedThrough = "Terraform_Automation"
      
    }
  }
  
#here we are referencing the aws key pair which we have created in keypair_bastion.tf config file
key_name              = var.bastion_key             

vpc_security_group_ids = [aws_security_group.sg_bastion_host.id]
  
  #here we are attaching tags to our resources created
  tags = {
    "Name" = "Bastion-Host"
     Created-by  = "Terraform_Automation"

  }
}

# ----------------------------------------------------------- #
#this creates and attach a elastic public ip to bastion host 
# ----------------------------------------------------------- #
resource "aws_eip" "public_ip" {
  domain = "vpc"
  instance = aws_instance.ec2_bastion.id
  tags = {
    Name = "eip_bastion_host"
    Created-by  = "Terraform_Automation"
  }
}

# ----------------------------------------------------------- #
#creating security group for bastion host
# ----------------------------------------------------------- #
# Create Security Group - SSH Traffic
resource "aws_security_group" "sg_bastion_host" {
  vpc_id      = aws_vpc.vpc-go.id
  name        = "sg_bastion_host"
  description = "VM SSH"

# inbound ssh port
  ingress {
    description = "Allow Port 22"
    from_port   = 22
    to_port     = 22
    protocol    = "tcp"
    cidr_blocks = ["10.10.8.224/27","192.168.0.0/24","192.168.2.0/24","192.168.1.0/24","192.168.10.0/24","172.16.28.118/32","13.200.248.213/32","172.16.28.0/22"]
  }
  ingress {
    description = "Allow Port 21443"
    from_port   = 21443
    to_port     = 21443
    protocol    = "tcp"
    cidr_blocks = ["172.16.29.173/32"]    #wsdb
  }
  ingress {
    description = "Allow Port icmp"
    from_port   = 0
    to_port     = 0
    protocol    = "icmp"
    cidr_blocks = ["0.0.0.0/0"]
  }
 ingress {
    description = "VNC Port 5903 09/06/24"
    from_port   = 5903
    to_port     = 5903
    protocol    = "tcp"
    cidr_blocks = ["192.168.10.0/24","192.168.1.0/24","192.168.0.0/24","192.168.2.0/24","10.8.0.0/24"]
  }


  # outbound 
  egress {
    description = "Allow all IP and Ports outbound"
    from_port   = 0
    to_port     = 0
    protocol    = "-1"
    cidr_blocks = ["0.0.0.0/0"]
  }

  tags = {
    Name = "sg_bastion_host"
  }
}