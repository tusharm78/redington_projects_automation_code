# ------------------------------------- #
#creating virtual machine - WSDB VM
# ------------------------------------- #
resource "aws_instance" "ec2_wsdb" {
  subnet_id                   = aws_subnet.prod_subnet_1a.id
  associate_public_ip_address = false
  ami                         = "ami-0ba62e9b2fdc3e1ff"   #Microsoft Windows Server 2022 with SQL Server 2022 Web
  instance_type               = "r6i.2xlarge"  #"r6a.xlarge"              #add the required instance size here
  root_block_device {
  volume_size = var.wsdb_os_disk
    encrypted = true
    delete_on_termination = true
    volume_type = "gp3"
    tags = {
        Name = "wsdb_os_Disk"
        Created-by  = "Terraform_Automation"
     }
  }
  

#here we are referencing the aws key pair which we have created in keypair.tf config file
key_name              = var.wsdb_key
depends_on = [aws_key_pair.wsdb_key]

vpc_security_group_ids = [aws_security_group.sg_wsdb.id]
  
#here we are attaching tags to our resources
tags = {
    "Name" = "WSDB"
     Created-by  = "Terraform_Automation"
     Environment = "Prod"
     backup = "prod-bkp-daily"

  }
}

# ----------------------------------------------------------- #
## this creates a data disk EBS volume
# ------------------------------------------------------------
resource "aws_ebs_volume" "wsdb_data_disk1" {
  availability_zone = var.aws_availability_zone1
  size = var.wsdb_data_disk1
  encrypted = true
  type = "gp3"

  tags = {
    Name = "WSDB_Data_Disk1"
    Created-by  = "Terraform_Automation"
  }
}

resource "aws_ebs_volume" "wsdb_data_disk2" {
  availability_zone = var.aws_availability_zone1
  size = var.wsdb_data_disk2
  encrypted = true
  type = "gp3"

  tags = {
    Name = "WSDB_Data_Disk2"
    Created-by  = "Terraform_Automation"
  }
}

resource "aws_ebs_volume" "wsdb_data_disk3" {
  availability_zone = var.aws_availability_zone1
  size = var.wsdb_data_disk3
  encrypted = true
  type = "gp3"

  tags = {
    Name = "WSDB_Data_Disk3_L_drive"
    Created-by  = "Terraform_Automation"
  }
}



#this attachs the data disk EBS volume created above to the server
resource "aws_volume_attachment" "wsdb_data_disk_attach1" {
  device_name = "/dev/sdh"
  volume_id   = aws_ebs_volume.wsdb_data_disk1.id
  instance_id = aws_instance.ec2_wsdb.id
}
resource "aws_volume_attachment" "wsdb_data_disk_attach2" {
  device_name = "/dev/sdf"
  volume_id   = aws_ebs_volume.wsdb_data_disk2.id
  instance_id = aws_instance.ec2_wsdb.id
}

resource "aws_volume_attachment" "wsdb_data_disk_attach3" {
  device_name = "/dev/sdv"
  volume_id   = aws_ebs_volume.wsdb_data_disk3.id
  instance_id = aws_instance.ec2_wsdb.id
}

# ----------------------------------------------------------- #
#creating security group for WSDB VM
# ----------------------------------------------------------- #
# Create Security Group - SSH Traffic
resource "aws_security_group" "sg_wsdb" {
  vpc_id      = aws_vpc.vpc-go.id
  name        = "sg_wsdb"
  description = "VM RDP"
 
 # inbound ssh port
  ingress {
    description = "Allow Port 3389"
    from_port   = 3389
    to_port     = 3389
    protocol    = "tcp"
    cidr_blocks = ["10.10.8.224/27","192.168.0.0/24","192.168.2.0/24","192.168.1.0/24","192.168.10.0/24","172.16.28.118/32","13.200.248.213/32","172.16.28.0/22"]
  }

  ingress {
    description = "Allow Port 21"
    from_port   = 21
    to_port     = 21
    protocol    = "tcp"
    cidr_blocks = ["172.16.28.101/32"]
  }
  ingress {
    description = "Allow Port 1443"
    from_port   = 1443
    to_port     = 1443
    protocol    = "tcp"
    cidr_blocks = ["172.16.28.101/32"]
  }

  ingress {
    description = "Allow Port all"
    from_port   = 0
    to_port     = 0
    protocol    = "tcp"
    cidr_blocks = ["172.16.28.101/32"]
  }

  ingress {
    description = "Allow Port 21443"
    from_port   = 21443
    to_port     = 21443
    protocol    = "tcp"
    cidr_blocks = ["172.16.28.101/32"]
  }
  ingress {
    description = "Allow Port 21443"
    from_port   = 21443
    to_port     = 21443
    protocol    = "tcp"
    cidr_blocks = ["172.16.28.249/32"]
  }
  ingress {
    description = "Allow Port 21443"
    from_port   = 21443
    to_port     = 21443
    protocol    = "tcp"
    cidr_blocks = ["172.16.28.82/32"]
  }

  ingress {
    description = "Allow Port 3200-3399"
    from_port   = 3200
    to_port     = 3399
    protocol    = "tcp"
    cidr_blocks = ["172.16.28.82/32"]
  }

   ingress {
    description = "Allow Port 4800-5000"
    from_port   = 4800
    to_port     = 5000
    protocol    = "tcp"
    cidr_blocks = ["172.16.28.82/32"]
  }
  ingress {
    description = "Allow Port 32768 - 65535"
    from_port   = 32768
    to_port     = 65535
    protocol    = "tcp"
    cidr_blocks = ["172.16.28.82/32"]
  }
  ingress {
    description = "Allow Port 3600-3699"
    from_port   = 3600 
    to_port     = 3699
    protocol    = "tcp"
    cidr_blocks = ["172.16.28.82/32"]
  }
  

  ingress {
    description = "Allow Port 8000-8200"
    from_port   = 8000
    to_port     = 8200
    protocol    = "tcp"
    cidr_blocks = ["172.16.28.82/32"]
  }
  ingress {
    description = "Allow Port 44300 - 44399"
    from_port   = 44300
    to_port     = 44399
    protocol    = "tcp"
    cidr_blocks = ["172.16.28.82/32"]
  }

  ingress {
    description = "Allow Port 50000 - 51000"
    from_port   = 50000
    to_port     = 51000
    protocol    = "tcp"
    cidr_blocks = ["172.16.28.82/32"]
  }

   ingress {
    description = "Allow Port FTP-2123"
    from_port   = 2123
    to_port     = 2123
    protocol    = "tcp"
    cidr_blocks = ["0.0.0.0/0"]
  }

  ingress {
    description = "Allow Port FTP-2124"
    from_port   = 2124
    to_port     = 2124
    protocol    = "tcp"
    cidr_blocks = ["0.0.0.0/0"]
  }

  ingress {
    description = "Allow Port icmp"
    from_port   = 0
    to_port     = 0
    protocol    = "icmp"
    cidr_blocks = ["0.0.0.0/0"]
  }
  ingress {
    description = "EDR"
    from_port   = 443
    to_port     = 443
    protocol    = "tcp"
    cidr_blocks = ["0.0.0.0/0"]
  }

    ingress {
    description = "EDR"
    from_port   = 1500
    to_port     = 1500
    protocol    = "tcp"
    cidr_blocks = ["0.0.0.0/0"]
  }

   ingress {
    description = "Port_21443"
    from_port   = 21443
    to_port     = 21443
    protocol    = "tcp"
    cidr_blocks = ["172.16.28.250/32"]
  }

   ingress {
    description = "Allow Port 21443"
    from_port   = 21443
    to_port     = 21443
    protocol    = "tcp"
    cidr_blocks = ["172.16.28.85/32"]
  }


# outbound port   
 egress {
    description = "Allow all IP and Ports outbound"
    from_port   = 0
    to_port     = 0
    protocol    = "-1"
    cidr_blocks = ["0.0.0.0/0"]
  }

  tags = {
    Name = "sg_wsdb"
    CreatedThrough = "Terraform Automation"
  }
}
