# ------------------------------------- #
#creating virtual machine - POPRD VM
# ------------------------------------- #

resource "aws_instance" "ec2_poprd" {
  subnet_id                   = aws_subnet.Public-Subnet.id
  associate_public_ip_address = true
  ami                         = "ami-05e7e472455ddb0cd"   #rhel 9 ami id here
  instance_type               = "r6i.xlarge"              #add the required instance size here
  iam_instance_profile = "Prd_S3_SSM"
  root_block_device {
  volume_size = var.poprd_os_disk
    encrypted = false
    delete_on_termination = true
    volume_type = "gp3"
    tags = {
        Name = "Poprd_os_Disk"
        Created-by  = "Terraform_Automation"
     }
  }
  

#here we are referencing the aws key pair which we have created in keypair.tf config file
key_name              = var.poprd_key
depends_on = [aws_key_pair.poprd_key]

vpc_security_group_ids = [aws_security_group.sg_poprd.id]
  
#here we are attaching tags to our resources
tags = {
    "Name" = "Poprd"
     Created-by  = "Terraform_Automation"
     Environment = "Prod"
     backup = "prod-bkp"

  }
}


#
# ----------------------------------------------------------- #
## this creates and attach a elastic public ip to SSL VPN VM
# ----------------------------------------------------------- #
resource "aws_eip" "poprd_pubblic_ip" {
  domain = "vpc"
  instance = aws_instance.ec2_poprd.id
    tags = {
    Name = "eip_poprd"
    Created-by  = "Terraform_Automation"
  }
}
# ----------------------------------------------------------- #
## this creates a data disk EBS volume
# ------------------------------------------------------------
resource "aws_ebs_volume" "poprd_data_disk" {
  availability_zone = var.aws_availability_zone1
  size = var.poprd_data_disk
  encrypted = true
  type = "gp3"

  tags = {
    Name = "Poprd_Data_Disk"
    Created-by  = "Terraform_Automation"
  }
}


#this attachs the data disk EBS volume created above to the server
resource "aws_volume_attachment" "poprd_data_disk_attach" {
  device_name = "/dev/sdf"
  volume_id   = aws_ebs_volume.poprd_data_disk.id
  instance_id = aws_instance.ec2_poprd.id
}
##################################New data disk for Backup##############################
resource "aws_ebs_volume" "poprd_data_disk1" {
  availability_zone = var.aws_availability_zone1
  size = var.poprd_data_disk1
  encrypted = true
  type = "st1"

  tags = {
    Name = "Poprd_Backup_Data_Disk"
    Created-by  = "Terraform_Automation"
  }
}

##this attachs the data disk EBS volume created above to the server
resource "aws_volume_attachment" "poprd_data_disk_attach1" {
  device_name = "/dev/sdn"
  volume_id   = aws_ebs_volume.poprd_data_disk1.id
  instance_id = aws_instance.ec2_poprd.id
} 


# ----------------------------------------------------------- #
#creating security group for POPRD VM
# ----------------------------------------------------------- #
# Create Security Group - SSH Traffic
resource "aws_security_group" "sg_poprd" {
  vpc_id      = aws_vpc.vpc-go.id
  name        = "sg_poprd"
  description = "VM SSH"
 
 # inbound ssh port
  ingress {
    description = "Allow Port 22"
    from_port   = 22
    to_port     = 22
    protocol    = "tcp"
    cidr_blocks = ["10.10.8.224/27","192.168.0.0/24","192.168.2.0/24","192.168.1.0/24","192.168.10.0/24","172.16.28.118/32","13.200.248.213/32","172.16.28.0/22"]
  }
  ingress {
    description = "Allow Port 5900-5902"
    from_port   = 5900
    to_port     = 5902
    protocol    = "tcp"
    cidr_blocks = ["10.10.8.224/27","192.168.0.0/24","192.168.2.0/24","192.168.1.0/24","192.168.10.0/24","172.16.28.118/32","13.200.248.213/32"]
  }
  ingress {
    description = "Allow Port 5902"
    from_port   = 50000
    to_port     = 50000
    protocol    = "tcp"
    cidr_blocks = ["0.0.0.0/0"]
  }
  ingress {
    description = "Allow Port 8080"
    from_port   = 8080
    to_port     = 8080
    protocol    = "tcp"
    cidr_blocks = ["0.0.0.0/0"]
  }

  ingress {
    description = "Allow Port 21443"
    from_port   = 21443
    to_port     = 21443
    protocol    = "tcp"
    cidr_blocks = ["172.16.29.173/32"]    #wsdb
  }

  ingress {
    description = "Allow Port 50000-51000"
    from_port   = 50000
    to_port     = 51000
    protocol    = "tcp"
    cidr_blocks = ["0.0.0.0/0"]
  }
  ingress {
    description = "Allow Port 8000-8200"
    from_port   = 8000
    to_port     = 8200
    protocol    = "tcp"
    cidr_blocks = ["0.0.0.0/0"]
  }

ingress {
    description = "Allow Port 3200-3299"
    from_port   = 3200
    to_port     = 3299
    protocol    = "tcp"
    cidr_blocks = ["0.0.0.0/0"]
  }

  ingress {
    description = "Allow Port 3200-3399"
    from_port   = 3200
    to_port     = 3399
    protocol    = "tcp"
    cidr_blocks = ["172.16.28.112/32","172.16.29.173/32","172.16.28.249/32"]
  }

   ingress {
    description = "Allow Port 4800-5000"
    from_port   = 4800
    to_port     = 5000
    protocol    = "tcp"
    cidr_blocks = ["172.16.28.112/32","172.16.29.173/32"]
  }
  ingress {
    description = "Allow Port 32768 - 65535"
    from_port   = 32768
    to_port     = 65535
    protocol    = "tcp"
    cidr_blocks = ["172.16.28.112/32","172.16.29.173/32"]
  }
  ingress {
    description = "Allow Port 3600-3700"
    from_port   = 3600 
    to_port     = 3700
    protocol    = "tcp"
    cidr_blocks = ["172.16.28.112/32","172.16.29.173/32","172.16.28.249/32"]
  }
  

  ingress {
    description = "Allow Port 8000-8200"
    from_port   = 8000
    to_port     = 8200
    protocol    = "tcp"
    cidr_blocks = ["172.16.28.112/32","172.16.29.173/32","172.16.28.249/32"]
  }
  ingress {
    description = "Allow Port 44300 - 44399"
    from_port   = 44300
    to_port     = 44399
    protocol    = "tcp"
    cidr_blocks = ["172.16.28.112/32","172.16.29.173/32"]
  }

  ingress {
    description = "Allow Port 50000 - 51000"
    from_port   = 50000
    to_port     = 51000
    protocol    = "tcp"
    cidr_blocks = ["172.16.28.112/32","172.16.29.173/32"]
  }
  ingress {
    description = "Allow Port 8000-8100 "
    from_port   = 8000
    to_port     = 8100
    protocol    = "tcp"
    cidr_blocks = ["172.16.28.0/22"]
  }

  ingress {
    description = "Allow Port icmp"
    from_port   = 0
    to_port     = 0
    protocol    = "icmp"
    cidr_blocks = ["0.0.0.0/0"]
  }
   ingress {
    description = "VNC Port 5903 09/06/24"
    from_port   = 5903
    to_port     = 5903
    protocol    = "tcp"
    cidr_blocks = ["192.168.10.0/24","192.168.1.0/24","192.168.0.0/24","192.168.2.0/24"]
  }
   ingress {
    description = "Port_3300"
    from_port   = 3300
    to_port     = 3300
    protocol    = "tcp"
    cidr_blocks = ["172.16.28.250/32"]
  }
    ingress {
    description = "Port_3301"
    from_port   = 3301
    to_port     = 3301
    protocol    = "tcp"
    cidr_blocks = ["172.16.28.250/32"]
  }

  ingress {
    description = "Port_3601"
    from_port   = 3601
    to_port     = 3601
    protocol    = "tcp"
    cidr_blocks = ["172.16.28.250/32"]
  }

   ingress {
    description = "Port_50000"
    from_port   = 50000
    to_port     = 50000
    protocol    = "tcp"
    cidr_blocks = ["172.16.28.250/32"]
  }


  ######################NFS port################3

    ingress {
    description = "NFS port"
    from_port   = 2049
    to_port     = 2049
    protocol    = "tcp"
    cidr_blocks = ["172.16.29.143/32"]
  } 
# outbound port   
 egress {
    description = "Allow all IP and Ports outbound"
    from_port   = 0
    to_port     = 0
    protocol    = "-1"
    cidr_blocks = ["0.0.0.0/0"]
  }

  tags = {
    Name = "sg_poprd"
    CreatedThrough = "Terraform Automation"
  }
}