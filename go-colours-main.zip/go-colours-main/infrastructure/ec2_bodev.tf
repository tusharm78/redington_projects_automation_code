# ------------------------------------- #
#creating virtual machine - BODEV VM
# ------------------------------------- #
resource "aws_instance" "ec2_bodev" {
  subnet_id                   = aws_subnet.dev_subnet_1a.id
  associate_public_ip_address = false
  ami                         = "ami-05a5bb48beb785bf1"   #rhel 9 ami id
  instance_type               = "r6a.xlarge"              #add the required instance size here
  root_block_device {
  volume_size = var.bodev_os_disk
    encrypted = true
    delete_on_termination = true
    volume_type = "gp3"
    tags = {
        Name = "Bodev_os_Disk"
        Created-by  = "Terraform_Automation"
     }
  }
  

#here we are referencing the aws key pair which we have created in keypair_bodev.tf config file
key_name              = var.bodev_key
depends_on = [aws_key_pair.bodev_key]

vpc_security_group_ids = [aws_security_group.sg_bodev.id,aws_security_group.sg_sap-ports.id]
  
#here we are attaching tags to our resources
tags = {
    "Name" = "Bodev"
     Created-by  = "Terraform_Automation"
     Environment = "Dev"
     backup = "dev-bkp"
  }
}

# ----------------------------------------------------------- #
## this creates a data disk EBS volume
# ------------------------------------------------------------
resource "aws_ebs_volume" "bodev_data_disk" {
  availability_zone = var.aws_availability_zone1
  size = var.bodev_data_disk
  encrypted = true
  type = "gp3"

  tags = {
    Name = "Bodev_Data_Disk"
    Created-by  = "Terraform_Automation"
  }
}

#this attachs the data disk EBS volume created above to the server
resource "aws_volume_attachment" "bodev_data_disk_attach" {
  device_name = "/dev/sdh"
  volume_id   = aws_ebs_volume.bodev_data_disk.id
  instance_id = aws_instance.ec2_bodev.id
}


# ----------------------------------------------------------- #
#creating security group for BODEV VM
# ----------------------------------------------------------- #
# Create Security Group - SSH Traffic
resource "aws_security_group" "sg_bodev" {
  vpc_id      = aws_vpc.vpc-go.id
  name        = "sg_bodev"
  description = "VM SSH"
 
 # inbound ssh port
  ingress {
    description = "Allow Port 22"
    from_port   = 22
    to_port     = 22
    protocol    = "tcp"
    cidr_blocks = ["10.10.8.224/27","192.168.0.0/24","192.168.2.0/24","192.168.1.0/24","192.168.10.0/24","172.16.28.118/32","13.200.248.213/32","172.16.28.0/22"]
  }
  ingress {
    description = "Allow Port 5902"
    from_port   = 5900
    to_port     = 5902
    protocol    = "tcp"
    cidr_blocks = ["10.10.8.224/27","192.168.0.0/24","192.168.2.0/24","192.168.1.0/24","192.168.10.0/24","172.16.28.118/32","13.200.248.213/32"]
  }
  ingress {
    description = "VNC Port 5903 09/06/24"
    from_port   = 5903
    to_port     = 5903
    protocol    = "tcp"
    cidr_blocks = ["192.168.10.0/24","192.168.1.0/24","192.168.0.0/24","192.168.2.0/24"]
  }
   
# outbound port   
 egress {
    description = "Allow all IP and Ports outbound"
    from_port   = 0
    to_port     = 0
    protocol    = "-1"
    cidr_blocks = ["0.0.0.0/0"]
  }

  tags = {
    Name = "sg_bodev"
    CreatedThrough = "Terraform Automation"
  }
}

