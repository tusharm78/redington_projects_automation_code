output "aws_eip_nat_eip" {
   description = "Nat IP"
     value = aws_eip.nat_eip
}

output "aws_subnet_Public-Subnet"{
    description = "public_Subnet-id"
    value = aws_subnet.Public-Subnet.id 
}