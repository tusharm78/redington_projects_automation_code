# -------------------------------------- #
# Create VPC
# -------------------------------------- #
resource "aws_vpc" "vpc-go" {
    cidr_block = var.aws_vpc
    enable_dns_hostnames = true
   tags = {
        Name        = "VPC_Go-Colors"
        Created-by  = "Terraform_Automation"
    }
}

# ---------------------------------------------------------------------- #

# ------------------------------------ #
#create subnet for network firewall 
# ------------------------------------ #
resource "aws_subnet" "networkfirewall_subnet" {
  vpc_id                  = aws_vpc.vpc-go.id
  cidr_block              = var.networkfirewall_subnet
  availability_zone       = var.aws_availability_zone1
  map_public_ip_on_launch = true
  tags = {
    Name = "Subnet_Network_Firewall"
    Created-by  = "Terraform_Automation"
  }
}

# Route Table
#creating Route table for network firewall
resource "aws_route_table" "rt_networkfirewall" {
  vpc_id = aws_vpc.vpc-go.id
  tags = {
    Name    = "RT-NetworkFirewall"   # Route table for network firewall is created
    Created-by  = "Terraform_Automation"
  }
}

#associating network firewall route table with respective network firewall subnet
resource "aws_route_table_association" "rt_networkfirewall" {
  route_table_id = aws_route_table.rt_networkfirewall.id   # Network firewall route table is associated with respective network firewall subnet
  subnet_id      = aws_subnet.networkfirewall_subnet.id
}


#creating public subnet
resource "aws_subnet" "Public-Subnet" {
  vpc_id                  = aws_vpc.vpc-go.id
  cidr_block              = var.PublicSubnet
  availability_zone       = var.aws_availability_zone1
  map_public_ip_on_launch = true
  tags = {
    Name = "Subnet_Public"
    Created-by  = "Terraform_Automation"
  }
}

#creating private subnet for dev environmnet in availability zone 1a
resource "aws_subnet" "dev_subnet_1a" {
  vpc_id                  = aws_vpc.vpc-go.id
  cidr_block              = var.Subnet_Dev_Private_1
  availability_zone       = var.aws_availability_zone1
  map_public_ip_on_launch = false
  tags = {
    Name = "Subnet_Dev_Private_1"
    Created-by  = "Terraform_Automation"
    Environment = "Development"
  }
}

#creating private subnet for dev environmnet in availability zone 1b
resource "aws_subnet" "dev_subnet_1b" {
  vpc_id                  = aws_vpc.vpc-go.id
  cidr_block              = var.Subnet_Dev_Private_2
  availability_zone       = var.aws_availability_zone2
  map_public_ip_on_launch = false
  tags = {
    Name = "Subnet_Dev_Private_2"
    Created-by  = "Terraform_Automation"
    Environment = "Development"
  }
}
#creating private subnet for prod environmnet in availability zone 1a
resource "aws_subnet" "prod_subnet_1a" {
  vpc_id                  = aws_vpc.vpc-go.id
  cidr_block              = var.Subnet_Prod_Private_1
  availability_zone       = var.aws_availability_zone1
  map_public_ip_on_launch = false
  tags = {
    Name = "Subnet_Prod_Private_1"
    Created-by  = "Terraform_Automation"
    Environment = "Production"
  }
}

#creating private subnet for prod environmnet in availability zone 1b
resource "aws_subnet" "prod_subnet_1b" {
  vpc_id                  = aws_vpc.vpc-go.id
  cidr_block              = var.Subnet_Prod_Private_2
  availability_zone       = var.aws_availability_zone2
  map_public_ip_on_launch = false
  tags = {
    Name = "Subnet_Prod_Private_2"
    Created-by  = "Terraform_Automation"
    Environment = "Production"
  }
}


# Creating Internet Gateway
resource "aws_internet_gateway" "vpc-igw" {
  vpc_id = aws_vpc.vpc-go.id
  tags = {
    Name = "IGW-Go-Colors"
    Created-by  = "Terraform_Automation"
  }
}

# Create a NAT gateway in the public subnet
resource "aws_eip" "nat_eip" {
  domain = "vpc"
  tags = {
    Name = "eip_nat_gw"
  }
}

resource "aws_nat_gateway" "nat" {
  allocation_id = aws_eip.nat_eip.id
  subnet_id     = aws_subnet.Public-Subnet.id
  tags = {
    Name = "Ngw_Go-Colors"
    Created-by  = "Terraform_Automation"
  }
}



#creating public route table
resource "aws_route_table" "rt_public" {
  vpc_id = aws_vpc.vpc-go.id

  tags = {
    Name    = "RT-Public"   # Route table for Public subnet is created
    Created-by  = "Terraform_Automation"
  }
}
#associating public route table with respective public subnet
resource "aws_route_table_association" "public_rt" {
  route_table_id = aws_route_table.rt_public.id     # public route table is associated with respective public subnet
  subnet_id      = aws_subnet.Public-Subnet.id
}

#creating dev-private-subnet route table
resource "aws_route_table" "rt_dev_private" {
  vpc_id = aws_vpc.vpc-go.id

  tags = {
    Name    = "RT-Dev-Private"   # Route table for Dev Private subnet is created
    Created-by  = "Terraform_Automation"
  }
}
#associating dev-private-subnet route table with respective dev private subnet
resource "aws_route_table_association" "Dev-Private_rt" {
  route_table_id = aws_route_table.rt_dev_private.id    # dev private route table is associated with respective dev private subnet
  subnet_id      = aws_subnet.dev_subnet_1a.id
}

#creating prod-private-subnet route table
resource "aws_route_table" "rt_prod_private" {
  vpc_id = aws_vpc.vpc-go.id

  tags = {
    Name    = "RT-Prod-Private"   # Route table for Dev Private subnet is created
    Created-by  = "Terraform_Automation"
  }
}
#associating prod-private-subnet route table with respective prod private subnet
resource "aws_route_table_association" "Prod-Private_rt" {
  route_table_id = aws_route_table.rt_prod_private.id   # dev private route table is associated with respective dev private subnet
  subnet_id      = aws_subnet.prod_subnet_1a.id
}

data "aws_vpc_endpoint" "nw_firewall" {
  id = "vpce-07a195d844c289cd7"  # Replace 'vpc-id' with the ID of the existing VPC you want to use
}

# Create Route in Route Table for Internet Access
resource "aws_route" "public_rt" {
  route_table_id         = aws_route_table.rt_public.id
  destination_cidr_block = "0.0.0.0/0"
  vpc_endpoint_id =     data.aws_vpc_endpoint.nw_firewall.id
  #gateway_id             = aws_internet_gateway.vpc-igw.id
}



##Endpoint_configuration_S3

resource "aws_vpc_endpoint" "s3" {
  vpc_id       = aws_vpc.vpc-go.id
  service_name = "com.amazonaws.ap-south-1.s3"
 
  tags = {
    Name = "S3_endpoint"
    created_by = "Terraform_Automation"
  }
}

##Prod_configuration
 
resource "aws_vpc_endpoint_route_table_association" "rt_endpoint_prod" {
route_table_id = aws_route_table.rt_prod_private.id
vpc_endpoint_id = aws_vpc_endpoint.s3.id
}


##Dev_configuration
 
resource "aws_vpc_endpoint_route_table_association" "rt_endpoint_dev" {
route_table_id = aws_route_table.rt_dev_private.id
vpc_endpoint_id = aws_vpc_endpoint.s3.id
}