# ------------------------------------- #
#creating virtual machine - WSAPP VM
# ------------------------------------- #
resource "aws_instance" "ec2_wsapp" {
  subnet_id                   = aws_subnet.Public-Subnet.id
  associate_public_ip_address = true
  ami                         = "ami-09b9e25b6db1d130c"    #Microsoft Windows Server 2022
  instance_type               = "r6i.2xlarge"              #add the required instance size here
  root_block_device {
  volume_size = var.wsapp_os_disk
    encrypted = true
    delete_on_termination = true
    volume_type = "gp3"
    tags = {
        Name = "Wsapp_os_Disk"
        Created-by  = "Terraform_Automation"
     }
  }
  

#here we are referencing the aws key pair which we have created in keypair.tf config file
key_name              = var.wsapp_key
depends_on = [aws_key_pair.wsapp_key]

vpc_security_group_ids = [aws_security_group.sg_wsapp.id]
  
#here we are attaching tags to our resources
tags = {
    "Name" = "WSAPP"
     Created-by  = "Terraform_Automation"
     Environment = "Prod"
     backup = "prod-bkp"

  }
}
# ----------------------------------------------------------- #
## this creates and attach a elastic public ip to WS APP VM
# ----------------------------------------------------------- #
resource "aws_eip" "wsapp_public_ip" {
  domain = "vpc"
  instance = aws_instance.ec2_wsapp.id
    tags = {
    Name = "eip_wsapp"
    Created-by  = "Terraform_Automation"
  }
}
# ----------------------------------------------------------- #
## this creates a data disk EBS volume
# ------------------------------------------------------------
resource "aws_ebs_volume" "wsapp_data_disk" {
  availability_zone = var.aws_availability_zone1
  size = var.wsapp_data_disk
  encrypted = true
  type = "gp3"

  tags = {
    Name = "Wsapp_Data_Disk"
    Created-by  = "Terraform_Automation"
  }
}

#this attachs the data disk EBS volume created above to the server
resource "aws_volume_attachment" "wsapp_data_disk_attach" {
  device_name = "/dev/sdh"
  volume_id   = aws_ebs_volume.wsapp_data_disk.id
  instance_id = aws_instance.ec2_wsapp.id
}

# ----------------------------------------------------------- #
#creating security group for WSAPP VM
# ----------------------------------------------------------- #
# Create Security Group - SSH Traffic
resource "aws_security_group" "sg_wsapp" {
  vpc_id      = aws_vpc.vpc-go.id
  name        = "sg_wsapp"
  description = "VM RDP"
 
 # inbound rdp port
  ingress {
    description = "Allow Port 3389"
    from_port   = 3389
    to_port     = 3389
    protocol    = "tcp"
    cidr_blocks = ["10.10.8.224/27","192.168.0.0/24","192.168.2.0/24","192.168.1.0/24","192.168.10.0/24","172.16.28.118/32","13.200.248.213/32","172.16.28.0/22"]
  }
  ingress {
    description = "Allow Port 1.Test_"
    from_port   = 584
    to_port     = 584
    protocol    = "tcp"
    cidr_blocks = ["0.0.0.0/0"]
  }
   ingress {
    description = "Allow Port GoColorsLive "
    from_port   = 5001
    to_port     = 5001
    protocol    = "tcp"
    cidr_blocks = ["0.0.0.0/0"]
  }

   ingress {
    description = "Allow Port WSDB"
    from_port   = 0
    to_port     = 0
    protocol    = "tcp"
    cidr_blocks = ["172.16.29.173/32"]
  }

  ingress {
    description = "Allow Port Default web site"
    from_port   = 80
    to_port     = 80
    protocol    = "tcp"
    cidr_blocks = ["0.0.0.0/0"]
  }
  ingress {
    description = "Allow Port PathFinderADSR-And-eShopUAT-krypton - GoColorsReports"
    from_port   = 5010
    to_port     = 5011
    protocol    = "tcp"
    cidr_blocks = ["0.0.0.0/0"]
  }

   ingress {
    description = "Allow Port GoColorsUAT_Titanium "
    from_port   = 7001
    to_port     = 7001
    protocol    = "tcp"
    cidr_blocks = ["0.0.0.0/0"]
  }

  ingress {
    description = "Allow Port Test "
    from_port   = 4001
    to_port     = 4001
    protocol    = "tcp"
    cidr_blocks = ["0.0.0.0/0"]
  }

  ingress {
    description = "Allow Port Wsreport "
    from_port   = 2123
    to_port     = 2123
    protocol    = "tcp"
    cidr_blocks = ["125.17.254.186/32","103.59.187.18/32","49.249.121.170/32","10.10.8.224/27","192.168.0.0/24","192.168.2.0/24","192.168.1.0/24","192.168.10.0/24","172.16.29.173/32","172.16.28.118/32"]
  }
   ingress {
    description = "Allow Port EAMALL "
    from_port   = 21
    to_port     = 21
    protocol    = "tcp"
    cidr_blocks = ["0.0.0.0/0"]
  }

  ingress {
    description = "Allow Port FTP-2123"
    from_port   = 2123
    to_port     = 2123
    protocol    = "tcp"
    cidr_blocks = ["0.0.0.0/0"]
  }

  ingress {
    description = "Allow Port FTP-2124"
    from_port   = 2124
    to_port     = 2124
    protocol    = "tcp"
    cidr_blocks = ["0.0.0.0/0"]
  }

  ingress {
    description = "Allow Port FTP site "
    from_port   = 2121
    to_port     = 2121
    protocol    = "tcp"
    cidr_blocks = ["0.0.0.0/0"]
  }

   ingress {
    description = "Allow Port Wspromo "
    from_port   = 8089
    to_port     = 8089
    protocol    = "tcp"
    cidr_blocks = ["0.0.0.0/0"]
  }

  ingress {
    description = "Allow Port DelhiAirport "
    from_port   = 2525
    to_port     = 2525
    protocol    = "tcp"
    cidr_blocks = ["0.0.0.0/0"]
  }

   ingress {
    description = "Allow Port 7080 "
    from_port   = 7080
    to_port     = 7080
    protocol    = "tcp"
    cidr_blocks = ["0.0.0.0/0"]
  }
  ingress {
    description = "Allow Port 8001 "
    from_port   = 8001
    to_port     = 8001
    protocol    = "tcp"
    cidr_blocks = ["0.0.0.0/0"]
  }


##FTP__port
  ingress {
    description = "Allow Port FTP"
    from_port   = 49152
    to_port     = 65535
    protocol    = "tcp"
    cidr_blocks = ["172.16.29.173/32"]
  }

  ingress {
    description = "Allow Port ICMP"
    from_port   = -1
    to_port     = -1
    protocol    = "icmp"
    cidr_blocks = ["0.0.0.0/0"]
  }

  ingress {
    description = "port_6001-6003"
    from_port   = 6001
    to_port     = 6003
    protocol    = "tcp"
    cidr_blocks = ["0.0.0.0/0"]
  }

# outbound port   
 egress {
    description = "Allow all IP and Ports outbound"
    from_port   = 0
    to_port     = 0
    protocol    = "-1"
    cidr_blocks = ["0.0.0.0/0"]
  }

  tags = {
    Name = "sg_wsapp"
    CreatedThrough = "Terraform Automation"
  }
}