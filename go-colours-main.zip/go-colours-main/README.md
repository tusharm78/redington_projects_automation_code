# Go-Colours
Go-Colours-implementation-aws

#### This is a repo for Go-Colours-implementation on aws

## Architecture
![Architecture](https://github.com/RedingtonGroup/go-colours/assets/158027164/edf79d61-1ffb-4307-a928-52fefe3ff36d)


## Scope of Work 

### Creation of AWS Account
- Creation of AWS root account
- Setting of AWS Account Root User Password and Enable MFA
- Configuring IAM users and Multi-Factor Authentication (MFA) as per requirement
 
### Creation of VPC
- Adding IPv4 CIDR Blocks to a VPC
- Creation of Subnets with public and private CIDR blocks
- Route tables configuration
- Creation and configuration of Internet gateways
- Subnet routing with routing tables
- Subnet security
- Setting up network ACL’s
- Setting up network interfaces
- Cloud watch monitoring with configuration for alerts.
- Elastic IP addressing.

### Configuring AWS Identity and Access Management (AWS IAM) to securely control access to AWS resources.
- Create IAM user, group and role as per business requirement.
- Create policies and permission for specific user/group/role.

### Establishing VPN Gateway for secure and private connectivity
- Create a customer gateway
- Create a target gateway
- Configure routing
- Update the security group
- Create a Site-to-Site VPN connection
- Download the configuration file
- Configure the customer gateway device
 
### Configuration of internet gateway.
### Setting up EC2
- Configuration of NAT gateway in public subnet in VPC for routing egress traffic from the private subnet in VPC.
- Setting default encryption for relevant services like EBS etc
- Configure Bastion host in public subnet.
- Configure Elastic IP’s
 
- Setting up Elastic File Storage (EFS)
- Setting up S3
- Setting up Ec2 connect endpoint.
- Configure system manager for update and patching.
- Configuring Key Management Service (KMS)
- Setting up Network firewall

### Bill of Quantity (BOQ):

- Primary Region (DC): https://calculator.aws/#/estimate?id=9b0e2cf771a43817ea25c6b43716f64a0632d5af
